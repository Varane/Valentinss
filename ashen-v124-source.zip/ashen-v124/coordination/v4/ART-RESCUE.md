# Figure art rescue

Status: source ready; facade syntax and figure regression checks passed. Fresh browser appearance remains root-owned verification.

## Findings

The current `dist/figures.mjs` already uses the authored body, face, palette, equipment and animation modules. B1 status reports source-ready-verified. The obsolete inline implementation is no longer present; replacing the facade wholesale would discard completed work.

The authored face contains actual skull, nose, lip, ear, brow and hair volume. The outfit modules already use restrained silhouettes with no glowing trim or added spikes. The remaining integration issue was material inconsistency between the cloth torso and its underlying sleeves, plus ordinary shoes protruding from equipped rune boots.

## Changes owned by this rescue

Only `dist/figures.mjs` changed. Existing figure-owned materials now use warm charcoal leather, dark slate trousers, desaturated oxblood accents and rougher, less reflective steel. Cloth torso and shoulder sleeves use the same material as the underlying sleeves. The silhouette and all authored geometry are preserved.

The facade hides ordinary shoes while rune boots occupy the boot slot, restores them on removal, and retains that state through two-slot equipment changes. Equipment replacement still belongs to the modular controller; no extra GPU resources or disposal ownership were introduced.

## Verification

- `node --check dist/figures.mjs`: exit 0.
- Figure body, equipment and animation suites plus sprint 07 figures, sprint 08 figure and sprint 12 face: 31 tests, 30 pass, 0 failures, 1 existing optional TODO. Exit 0.
- Those checks cover rune gear attachment, preservation through equipment changes, finite animated transforms, front-facing male/female mouth visibility, resource isolation and exactly-once teardown.
- Additional direct male/female lifecycle probe passed: cloth torso/sleeve material identity, hidden ordinary shoes under rune boots, two-slot boot retention, restored shoes on boot removal, repeated cloth application and inert calls after disposal. Exit 0.

## Limits and handoff

No browser, phone, lighting or screenshot acceptance was performed by this agent. Root must verify the current rendered build after refresh; source correctness alone is not visual acceptance. This pass did not change camera, world lighting, combat, campaign or authored modular geometry. It does not add a cel outline shader; restrained graphic form comes from the existing faceted geometry and the adjusted palette.
