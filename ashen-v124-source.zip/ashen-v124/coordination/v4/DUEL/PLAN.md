# Optional duel implementation plan

Goal: deliver a deterministic two-peer duel with explicit mutual consent, readable attack/parry/dash timing, server-owned outcomes, and no dungeon equipment or progression mutation.

Architecture: isolated immutable reducer, authenticated server adapter, display-only presentation, and a lead-owned integration facade. Existing action/UI/server/root files remain owned by their current teams. No servers, commits, publication, or worktrees.

Spec: ../MASTER.md plus DUEL delegation. The user authorized implementation now and scoped file isolation.

- [ ] Simulation worker: dist/duel/simulation.mjs; tests/duel-simulation.test.mjs. Export createDuel({id,peerIds}) and reduceDuel(state,event); 50ms fixed ticks, two separate accepts, countdown, attacks, parry/dash, nonlethal isolated result.
- [ ] Authority worker: dist/duel/authority.mjs; tests/duel-authority.test.mjs. Export createDuelAuthority, applyDuelMessage, advanceDuelAuthority. Authenticate via trusted server peer context; reject spoofed identities/ticks/stale revisions/replays/malformed fields.
- [ ] Readability worker: dist/duel/presentation.mjs; tests/duel-readability.test.mjs. Export getDuelPresentation; truthful authority scope, two consent indicators, visible telegraph phases and gear-safe result.
- [ ] Lead: dist/duel/index.mjs and tests/duel-integration.test.mjs. Compose public exports and UI hooks, renderer snapshot without campaign outcome names, and document exact A/D/root wiring.
- [ ] Run all tests/duel*.test.mjs and relevant action/network suites. Review authority isolation, serializable state, simultaneous strikes, disconnect, and old consent/replay across fresh duel IDs.

Review focus: no client tick/HP injection; no one-peer consent; no shared dungeon references; simultaneous impacts are fair; no online claim without authenticated transport. Integration remains root-owned and must be explicitly distinguished from a locally tested module.
