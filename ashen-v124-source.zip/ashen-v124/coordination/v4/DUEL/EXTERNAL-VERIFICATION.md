# Existing action/network check during DUEL work

Command: `node --test tests/action*.test.mjs tests/network*.test.mjs`.

Observed 177 tests: 167 passed, 10 failed, 0 skipped. These are existing action tests, outside DUEL ownership; the duel module does not import or edit action/combat/server. Shared repository work was still active, so this is a checkpoint of the files read by this test run, not a final whole-project verdict.

Failure names:

1. action-adversarial.test.mjs: parry protects a hit whose impact precedes expiry within one long frame.
2. action-adversarial.test.mjs: dash protects a hit whose impact precedes expiry within one long frame.
3. action-adversarial.test.mjs: parry protects a pre-expiry impact with the runtime .05 second step.
4. action-adversarial.test.mjs: dash protects a pre-expiry impact with the runtime .05 second step.
5. action-adversarial.test.mjs: parry window resolves a strike at t=0.29.
6. action-adversarial.test.mjs: parry window resolves a strike at t=0.31.
7. action-adversarial.test.mjs: revive rescues a nearby downed ally once at the documented 35 percent health (30 actual vs29.75 expected).
8. action-adversarial.test.mjs: guard3 rescue uses the documented 70 percent health (60 actual vs59.5 expected).
9. action-adversarial.test.mjs: a hit that downs a hero cannot be cancelled by that hero reviving an ally (active actual vsdefeat expected).
10. action-contract.test.mjs: unsupported commands and unavailable actor indices return false without mutations (true actual vsfalse expected).

Network tests in the combined run passed. A/root should review fixture expectations and current semantics before release. DUEL does not alter these owned files.

Automatic approval review rejected user-visible send_message_to_thread calls to D and root because the trusted transcript did not contain direct user authorization for those destinations. No retries or alternate sending mechanism were attempted. Authorized passive handoff files remain the coordination channel.
