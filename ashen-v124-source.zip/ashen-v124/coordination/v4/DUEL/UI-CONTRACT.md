# DUEL initial integration contract

Status: in implementation; three actual subagent starts plus lead, 2026-11-11 22:01 UTC. Earlier 21:40 deadline was already past when context/read access completed. No shipped/hosted claim.

D may add optional `getDuel()`, `onDuelAccept()`, `onDuelCancel()`, `onDuelForfeit()` callbacks to createUI. Absence of getDuel, or a null return, hides the feature. Existing createUI behavior and signatures remain unchanged. Callbacks request intent only; they must not set consent, HP, phase or result locally.

getDuel returns:

```js
{
  id, phase, scope: 'local-preview' | 'server-authoritative',
  canAccept, canCancel, canForfeit,
  peers: [{peerId, accepted, isSelf}], // exactly two when valid
  gearSafe: true,
  result: null | {winnerPeerId, reason, gearLoss:false},
  // additive display fields may follow
}
```

Local previews must be labeled local. `server-authoritative` is supplied only by root after the authenticated room transport has a working duel route. Two separate authenticated peers must each accept. Showing the second actor or switching hero does not grant their consent. No second-player accept button driven by the first player's session.

Pending: own accept/cancel controls; countdown: cancel; active: forfeit; finished/cancelled: display outcome. Use `can*` flags to enable controls and display both acceptance statuses. Result copy must say equipment is kept. Root/A must not pass a duel knockout into campaign `resolveRoom` or server `settleOutcome`.

Root will import isolated modules from `dist/duel/index.mjs`. Production network routes and rendered runtime wiring belong to root/D and are not changed by this team.
