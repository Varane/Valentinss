# Isolated deterministic duel simulation

Implementation owner: duel_simulation. Implementation complete; verification evidence below.

## Exact exports

```js
import {createDuel, reduceDuel, TICK_MS, DUEL_RULES} from './duel/simulation.mjs';
let duel = createDuel({id: 'duel-1', peerIds: ['peer-a', 'peer-b']});
duel = reduceDuel(duel, {type: 'accept', peerId: 'peer-a'});
duel = reduceDuel(duel, {type: 'accept', peerId: 'peer-b'});
duel = reduceDuel(duel, {type: 'tick', steps: 60}); // server only; countdown ends
duel = reduceDuel(duel, {type: 'action', peerId: 'peer-a', action: 'move', x: 1, z: 0});
duel = reduceDuel(duel, {type: 'tick', steps: 1});
```

The pure reducer performs no authentication. Only an authenticated authority may supply peer IDs and tick/disconnect events. Invalid events are no-ops with a new independent state; malformed create input throws TypeError. Exactly two distinct, nonempty string peer IDs and a nonempty string duel ID are required (each at most128 characters). Only move consumes x/z; both axes must be finite within [-1,1], with diagonal normalization. A move expires after6 ticks (300ms) unless refreshed by another valid move for that peer. No other peer/action can refresh it. Transport must reject unexpected fields and supply held-input refresh packets.

State: `{id, mode:'duel', phase, tick, time, peerIds, accepted, countdownTicks, players, events, eventSeq, result}`. Phase is pending/countdown/active/finished/cancelled. Accept is pending only; both separate peers must accept. Countdown lasts 60 fixed ticks. Cancel is pending/countdown only and clears both consent flags. Forfeit is countdown/active only. Disconnect cancels pending/countdown, forfeits active, and clears both consent flags. Terminal states ignore further events. Tick takes integer steps 1..200 (default1) and does nothing while pending/terminal. No Date, randomness, dungeon imports or progression calls.

`TICK_MS = 50`. Frozen `DUEL_RULES` has `tickMs, countdownTicks, maxTickSteps, maxHp, damage, attackWindupTicks, attackCooldownTicks, attackReach, attackCost, parryTicks, parryCooldownTicks, parryCost, parryStunTicks, dashTicks, dashCooldownTicks, dashCost, staminaPerTick, moveSpeed, dashSpeed, arenaHalfWidth, arenaHalfDepth, actorRadius, inputTtlTicks`.

Balance: health100, damage25, attack windup6 ticks (300ms), attack cooldown14 ticks (700ms), reach1.9, attack cost24; parry4 ticks (200ms), cooldown14, cost18, attacker stun6; dash4 ticks (200ms) including invulnerability, cooldown20, cost28; stamina regeneration0.5 per tick, move3.6 units/sec, dash10 units/sec. Both actors start x±1.4,z0 facing each other. Arena center bounds x±5.5,z±4.5, no pillars. Actor radius0.35; a symmetric swept two-body collision prevents crossing or overlap without giving priority to peer order. Movement is slowed to35% during windup and stopped while stunned. Facing is locked for a queued attack. Simultaneous strikes resolve from the same tick state and can draw.

Actor renderer fields preserved: `id,name,x,z,yaw,hp,maxHp,damage,defense,skills,weapon,armor,mana,maxMana,stamina,invuln,dash,dx,dz,parry,parryCd,riposte,attackCd,attackAnim,hurt,down,dead,speed`. Normalized blade/cloth, empty skills, defense0; no equipment/profile input is read. Additional fields: `peerId,input:{x,z},inputUntilTick,windup,stun,dashCd,knockedOut,attackAtTick,attackReadyTick,parryUntilTick,parryReadyTick,dashUntilTick,dashReadyTick,stunUntilTick,attackAnimUntilTick,hurtUntilTick`. Deadline fields are integer ticks; renderer timers are derived seconds. Attack resolution occurs after six complete server ticks. Defensive windows include the next four ticks, then expire.

Events are a bounded rolling list (last100), each `{id,type,tick,time,...}`; actor events also contain `actor,peerId,x,z` and targeted events `target,targetPeerId`. Types: consent, countdown, duel-start, windup, swing, hit, parry, dodge, miss, dash, guard, duel-end. Windup exposes `resolveTick` and `windupTicks`; hit exposes `amount`; result is `{mode:'duel',gearLoss:false,winnerPeerId,reason,tick}` with reason cancelled/forfeit/disconnect/knockout/draw. No knockout actor is marked dungeon-dead and no inventory/XP/quest/save state is present.

## Verification

- `node --test tests/duel-simulation.test.mjs` → 18 passed, 0 failed.
- `node --test tests/duel-simulation.test.mjs tests/duel-readability.test.mjs tests/duel-authority.test.mjs` → 55 passed, 0 failed, exit0 (18 simulation, 16 presentation, 21 authority).
- Consent, no premature combat, full 300 ms telegraph, timed/expired parries, finite dash, cooldown/stamina, replay/tick-batch determinism, immutable frozen inputs, 300 ms movement expiry, mirrored movement/attack, symmetric swept-body collision, bounded monotonic events, range evasion, simultaneous draw, normalized gear-safe knockout, cancellation and disconnection covered.
- Cancellation regression was observed failing with stale `accepted.a: true`, then verified passing after the reducer began clearing both flags.
- Broader existing action/network verification was performed by the lead, who reported 167 passing and10 external action failures out of177. See lead-owned `EXTERNAL-VERIFICATION.md`; those action modules are outside this agent's ownership and were not changed.

## Limits and integration notes

These are pure arena and adapter checks, not an online service, browser rendering, mobile or latency verification. The integrator must own the authoritative 50 ms tick scheduler, peer authentication, disconnect delivery, revision protocol and held-movement refresh packets. Do not accept client-supplied ticks. Do not pass a dungeon profile/actor into the arena or send duel results to campaign progression. Use `createDuel` for each new invitation; terminal duels never restart. Render a separate arena without dungeon pillars. Body collision stops both proposed movements at contact and does not implement body sliding. No source outside `dist/duel/simulation.mjs`, `tests/duel-simulation.test.mjs`, and this handoff was edited by this agent.
