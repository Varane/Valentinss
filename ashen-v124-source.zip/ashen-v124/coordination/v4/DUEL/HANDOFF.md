# Optional duel: root / A / D handoff

Status: implementation and focused verification in progress. Three actual subagent launches plus lead (four historical workers); live status is tracked separately in STATUS.json. Existing gameplay, UI, server, and root files have not been edited by this team. Publication and hosted multiplayer have not been performed.

## Entry point

`dist/duel/index.mjs` exports:

- Simulation: `createDuel({id,peerIds})`, `reduceDuel(state,event)`, `TICK_MS=50`, `DUEL_RULES`.
- Server: `createDuelAuthority({id,peerIds})`, `applyDuelMessage(authority,message,{peerId})`, `advanceDuelAuthority(authority,steps=1)`, `disconnectDuelAuthority(authority,peerId)`, `getDuelSnapshot(authority)`.
- Read model: `getDuelPresentation(duel,viewerPeerId,{scope,transport})`, `getDuelUIState(snapshot,viewerPeerId,options)`.
- Root bridge: `getDuelEncounter(duel)`, `createDuelUIHooks({getSnapshot,getPeerId,sendIntent,getTransportStatus,nextSequence?})`.

Reducers and accepted authority transitions return new state; rejected requests and idle server ticks may retain the original authority reference. Public snapshots are detached and allowlisted. The duel has exactly two unique peer IDs and fresh consent per new duel ID. Dungeon profile/equipment/XP are never passed into the simulation; duel actors use a balanced blade/cloth loadout and separate HP. A knockout is a duel result with `gearLoss:false`, never dungeon death.

## D: optional UI callbacks

```js
const hooks=createDuelUIHooks({
  getSnapshot:()=>latestDuelSnapshot, // {duel, revision, sequences}
  getPeerId:()=>authenticatedMemberId,
  sendIntent:message=>duelTransport.send(message),
  getTransportStatus:()=>({
    authenticated:duelTransport.authenticated===true,
    authoritative:duelTransport.duelRouteVerified===true,
  }),
});
const ui=createUI({...existingOptions,
  getDuel:hooks.getDuel,
  onDuelAccept:hooks.onDuelAccept,
  onDuelCancel:hooks.onDuelCancel,
  onDuelForfeit:hooks.onDuelForfeit,
});
```

The transport in this example is an integration requirement, not an existing service supplied by this module. Missing snapshot returns null (hide feature); missing sendIntent disables controls. Views include `peers:[{peerId,accepted,isSelf}]`, `canAccept/canCancel/canForfeit`, phase, RU/EN labels, telegraphs, scope, gearSafe and result. Callbacks submit the current viewer's intent only. They do not mutate consent or predict HP. A pending send blocks duplicate button presses. After success root must adopt the server snapshot. Handle rejected responses by adopting their fresh snapshot and letting the player retry; do not silently turn failures into local consent.

Snapshots expose accepted sequence numbers, allowing remounted hooks to resume above their latest accepted sequence. `nextSequence(duelId)` optionally integrates a persistent transport-owned counter; it must return an increasing safe integer. Failed requests consume only local sequence, which is allowed by the authority.

Default scope is `local-preview`. `server-authoritative` requires explicit transport evidence `{authenticated:true,authoritative:true}` from trusted integration code, never from room code or untrusted snapshot content. A UI label by itself does not establish authentication. The no-loss result is available in both RU and EN.

## D / root: server ownership

Create a new authority only after a server-authenticated room has two members and eligibility for a duel. Keep it in `room.duelAuthority`, separate from `room.encounter` and `room.profile`. Client envelopes contain `{duelId,revision,seq,type}` plus action fields, with no client peer ID. Derive peer ID from the room bearer session. The server is solely responsible for 50ms tick advancement; clients cannot submit tick, disconnect, HP, damage or time.

Persist the returned authority under the existing room compare-and-swap discipline, then broadcast `getDuelSnapshot(authority)`. Serialize ticks and inputs through the same room lock/CAS path. Duel command revision advances on accepted client intents and lifecycle transitions, but remains stable during ordinary movement/combat ticks; this prevents ordinary network latency from invalidating every action. Compare snapshots by `(revision,duel.tick)` and accept newer ticks at equal revision. The room store MUST use a separate storageVersion/CAS revision for every persisted write, including ticks: the duel command revision is not a storage version. Disconnect must call `disconnectDuelAuthority` and persist its result. A new member/duel requires a fresh duel ID and both consents again. Existing HTTP routes have not been changed and currently do not implement this adapter.

Tick example: use a server-owned accumulator; for each elapsed50ms call `advanceDuelAuthority(authority,1)`. Bound catch-up work using existing server policy. Never accept steps from the request body and never let the browser wall clock advance authority. Both clients need prompt snapshots: a 300ms windup cannot be readable through slower polling. Use pushes or approximately50ms delivery for active combat; latency compensation is not implemented. Refresh held movement at least every150–200ms; deterministic movement input expires after300ms. Queue an action that receives local `duel_busy` until the current request finishes; do not dispatch movement requests so often that they starve attack/parry/dash intents. `APPLIED` acknowledges a validated intent envelope; authoritative actor/event state indicates whether cooldown/stamina allowed a combat effect.

## A / root: renderer and game-loop boundary

`getDuelEncounter(duel)` supplies detached player animation fields, events, time, no enemies, `mode:'duel'`, and phases such as `duel-active` / `duel-finished`. These fields are for a separate renderer path. Keep the dungeon battle/profile reference suspended and unchanged; restore that exact dungeon state after the duel. The duel uses a clear rectangular arena without the dungeon pillars.

Do not assign the duel projection to the current root `battle` variable: current `settle()` treats every non-active phase as a campaign outcome. Do not call `action.step`, `action.command`, `syncProfile`, `settleOutcome`, `resolveRoom` or dungeon save synchronization on duel state. UI/input routing in duel mode calls `hooks.sendDuelAction('attack'|'parry'|'dash')` and `hooks.sendDuelAction('move',{x,z})`. Root must stop dungeon AI/combat while duelling. Movement comes from each separate authenticated peer; hero-switch UI cannot create the opponent's consent/actions.

Render `presentation.telegraphs` with direction/arc and remainingMs before impact; show a clear parry/dash cue. Event IDs are monotonic per duel. Consume each `(duel.id,event.id)` once; do not splice server snapshots. Duel event `target` is a player index, so translate it for effects rather than treating it as an enemy index. `duel-end` must open a duel result with equipment-kept copy and return to the suspended dungeon. Never route `duel-end` into dungeon death handling.

## Verification

Focused command: `node --test tests/duel*.test.mjs`.

Lead integration test first failed on the absent index module before implementation. Final counts will be filled after all worker modules arrive and the combined suite is run. Node verification establishes reducer/adaptor behavior only. Browser rendering, active network routes, real two-device latency and hosted deployment remain root/D integration work.
