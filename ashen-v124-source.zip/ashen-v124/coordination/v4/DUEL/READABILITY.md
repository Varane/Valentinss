# Duel presentation and readability

Owner: duel_readability. Owned files are `dist/duel/presentation.mjs`, `tests/duel-readability.test.mjs`, and this handoff. No action, UI, server, publication, or progression changes.

## Public API available now

```js
import {getDuelPresentation} from './duel/presentation.mjs';
const view=getDuelPresentation(duelState,authenticatedViewerPeerId);
// Only a trusted configured transport may supply these flags:
const onlineView=getDuelPresentation(duelState,authenticatedViewerPeerId,{
  scope:'server-authoritative',
  transport:{authenticated:true,authoritative:true},
});
```

`getDuelPresentation` is pure, DOM-free, and never mutates the duel or profile. All returned objects and arrays are detached; raw events and private/server metadata are not returned. It accepts the simulation's `pending/countdown/active/finished/cancelled` state with a nonempty ID, nonnegative integer tick, exactly two unique nonempty peer IDs, and two actor objects that each match one of those peers. Actor array order may differ from peer order; identity is matched by peer ID.

Returned fields:

- `id`, `available`, `phase`, `phaseKey`, `phaseLabel:{ru,en}`, `tick`.
- `countdownMs`, `countdownSeconds` (rounded up to avoid showing zero before the countdown ends).
- `viewer:{peerId,isParticipant,index}`; an unknown/missing viewer has null peer ID, false participant, and index -1.
- `consents:[{peerId,accepted,isViewer,key,label:{ru,en}}, …]` in canonical peer order, plus `bothAccepted`. Consent requires an own boolean `true` entry in `state.accepted`.
- `canAccept`: participant, pending, own acceptance still false. `canCancel`: participant in pending/countdown. `canForfeit`: participant in active. These are UI affordances; the authority must authenticate and validate actions independently. During countdown the UI uses cancel rather than forfeit, although the reducer also accepts forfeit there.
- `scope`, `scopeKey`, `scopeLabel:{ru,en}`. Default is `local-preview`. A scope string, room code, snapshot field, revision, or local consent never proves server authority. Both explicit strict-true trusted transport flags and a requested `server-authoritative` scope are required.
- `gearSafe:true`, `noLoss:{equipmentLost:0,xpLost:0,inventoryLost:0,label:{ru,en}}`. The label states that equipment, XP and inventory are preserved.
- `actors:[{index,id,peerId,name,isViewer,relation,x,z,yaw,hp,maxHp,hpFraction,stamina,windupMs,parryMs,dashMs,stunMs,knockedOut}, …]`. `relation` is self/opponent/spectator. Numbers are finite and health/stamina are bounded for display.
- `telegraphs:[{type:'attack',key,peerId,actor,targetPeerId,remainingMs,resolveTick,isThreat,x,z,yaw,label:{ru,en}}, …]`. These derive from the current attack deadline and fixed 50ms ticks. Stale event history cannot retain a warning after impact or after the duel finishes.
- `result:null` until a terminal outcome exists. Otherwise `{mode:'duel',gearLoss:false,winnerPeerId,reason,outcome,key,label:{ru,en}}`. `outcome` is victory/defeat/draw/cancelled/spectator relative to the viewer; labels include the no-loss statement. Only public scalar outcome fields are projected, so nested server data cannot leak.

Malformed/missing state returns `available:false`, `phase:'unavailable'`, inactive controls, empty consent/actor/telegraph arrays, and null result. Label objects are copied per call; editing returned UI data cannot corrupt later output.

## Readability and fairness guidance

Use two separate visible consent rows. Mark the authenticated viewer explicitly. A single shared accepted checkmark must not imply both players accepted. An accepted player can still cancel before combat begins; unknown viewers receive no controls.

The simulation contract gives an attack 300ms of warning (six 50ms ticks), parry and dash each 200ms (four ticks), and a three-second countdown. Render windup with a stable directional shape plus restrained motion/sound; colour alone is insufficient. Keep the remaining warning visible if another HUD update occurs. Turn off attack warnings at impact and terminal states. `remainingMs` describes simulation time, not a guarantee of network latency.

Parry must be timed near impact: pressing it at the start of the 300ms cue lets the 200ms guard expire before the blow. Parry also checks the front-facing cone (60 degrees either side); normal attack automatically turns toward the opponent, but parry does not. Show the actor's facing or guard direction, and do not treat a positive `parryMs` value as guaranteed protection. Both mirrored peers successfully parry or dash after five warning ticks in the executed tests.

Network polling plus transit time can consume the 300ms warning. Do not label reaction fairness verified for two devices until the real transport is exercised at target latency. The presentation does not extrapolate, compensate latency, or prove a server connection. Independently tested simulation reactions and mirrored peer controls are symmetric; live-device latency remains untested.

The preview's no-loss promise is justified by the isolated duel state: it has normalized equipment and no profile/inventory/XP/quest/save mutation. Integration must keep terminal duel results out of campaign death/reward functions. Display the winner or draw and the explicit no-loss message together, including forfeit, disconnect and cancellation.

## Verification

Test-first baseline: all 10 initial tests failed with an explicit missing-presentation assertion before implementation. An extended unavailable-state regression then reproduced null/duplicate actor and invalid ID/tick acceptance; `isDuelState` was corrected and retested.

The presentation/readability file now contains 16 tests. It covers own consent, invalid viewers, phase controls, prototype consent keys, unavailable states, actor reordering, authority labels, countdown/telegraph expiry, mirrored viewer display, exact no-loss result, input/reference isolation, full real attack warning, mirrored late parry, expired early parry, mirrored reactive dash, and real forfeit/disconnect outcomes. The executed combined `node --test tests/duel-readability.test.mjs tests/duel-simulation.test.mjs` initially passed 30/30 before the simulation owner added four further invariants.

A broad shared-workspace run used PowerShell `$duelTestFiles = rg --files tests -g '*.test.mjs'; node --test --test-concurrency=4 $duelTestFiles`. It completed in 65.8 seconds with **835 total, 792 passed, 30 failed, 2 skipped, 11 TODO**, exit 1. This was an active-workspace snapshot, not a release gate. All 16 readability tests passed. One authority cancellation failure was observed while that owner was working; the simulation owner subsequently reported a fresh 55/55 combined authority/readability/simulation run after clearing terminal consent. External files were not changed by this worker.

No browser, touch-device, server-route, or live network verification is claimed. Production render/route integration remains root/D-owned. The broader suite is not green.
