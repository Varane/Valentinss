# Optional duel authority adapter

Status: implementation and 23 behavioral/security tests written; final verification in progress. This module supplies pure server-side decisions. No HTTP route, deployed service, or two-device session is claimed.

## Frozen integration contract

Import from `dist/duel/authority.mjs`:

- `createDuelAuthority({id,peerIds:[firstPeerId,secondPeerId]})` creates a pending duel with revision `0` and two independent sequence receipts.
- `applyDuelMessage(authority,message,{peerId})` returns `{authority,ok,code,snapshot}`. The `peerId` is supplied by trusted server authentication; a client message cannot choose an actor.
- `advanceDuelAuthority(authority,steps=1)` returns authority after server-owned fixed 50 ms ticks. `steps` must be an integer from 1 through 200.
- `disconnectDuelAuthority(authority,peerId)` applies a trusted transport disconnect. The member must be authenticated by the integration before this call.
- `getDuelSnapshot(authority)` returns `{duel,revision,sequences}`. `duel` is an independent allowlisted public state view. `sequences` maps each public peer ID to its last accepted sequence, initially zero, for reconnect/remount recovery. Receipt fingerprints and authentication secrets are excluded.

Client JSON envelope:

```js
{duelId:'duel-123',revision:0,seq:1,type:'accept'}
{duelId:'duel-123',revision:2,seq:2,type:'action',action:'move',x:0.5,z:-0.5}
```

`type` is exactly `accept`, `cancel`, `forfeit`, or `action`. Action is exactly `attack`, `parry`, `dash`, or `move`. Only `move` accepts required finite `x` and `z` in `[-1,1]`. All unexpected fields are rejected, including `peerId`, `playerId`, `timestamp`, `tick`, `steps`, `damage`, and `hp`. Fields must be own enumerable data properties; inherited properties, getters, hidden keys, and symbols are rejected. Client `tick` and `disconnect` events are rejected. `seq` is a positive safe integer; `revision` is a nonnegative safe integer. The payload identifies the exact duel instance. IDs are nonempty, trimmed strings of at most 128 characters without control characters; `__proto__`, `constructor`, and `prototype` are reserved.

Movement is refreshed at least once per 300 ms while held; the simulation's server-tick deadline stops stale movement. Send `{action:'move',x:0,z:0}` on release/blur. Source movement vectors are normalized by the simulation, never trusted as positions.

Only the two constructor peers may act. Both peers must consent before the countdown and active phase. Accept is pending-only; cancel is pending/countdown-only; forfeit is countdown/active-only; combat/movement is active-only. Valid active intents are accepted even when the simulation's cooldown prevents an effect: acceptance never means a hit occurred.

An accepted cancellation and a trusted disconnect clear both consent flags. Historical consent events may remain in the event list; a terminal phase never accepts fresh consent or resumes a duel.

One command revision is added per accepted client message, trusted disconnect, or server tick batch that changes lifecycle phase (countdown to active, or active to finished). Ordinary ticks preserve this revision so commands in transit remain admissible across network latency. Snapshots are ordered lexicographically by `(revision,duel.tick)`; equal revision with newer tick is a new display state. An identical retry of a peer's latest accepted sequence succeeds without reapplying, before stale-revision rejection. Reusing that sequence with a changed payload, or replaying an older sequence, is rejected. Sequences advance only when accepted. Public snapshots accompany authenticated protocol errors so a client can resynchronize; unauthenticated callers receive no snapshot.

The fingerprint includes the submitted revision. A network retry must resend the identical envelope with its original revision. A rejected revision conflict can be retried using the returned current revision and the same unaccepted sequence. A reconnect can choose `max(localSequence,snapshot.sequences[peerId] ?? 0)+1`. Sequence gaps are accepted; only monotonic increase is required.

Result codes: `APPLIED`, `DUPLICATE`, `UNAUTHORIZED`, `MALFORMED_MESSAGE`, `WRONG_DUEL`, `SEQUENCE_CONFLICT`, `REPLAYED_SEQUENCE`, `REVISION_CONFLICT`, `INVALID_PHASE`, `ALREADY_ACCEPTED`, `CONSENT_REQUIRED`. Rejections return the original authority object and do not consume the sequence. Invalid constructor/stored authority/server tick/disconnect arguments throw. Server revisions cannot exceed the safe integer range.

## Server route responsibilities

The room service must authenticate an opaque bearer/session token and resolve it to the stable member peer ID before invoking this module. Room codes are discovery only. Keep the authority record and receipts server-side. Serialize reads/writes or use compare-and-swap transactions with a **separate storageVersion incremented for every write, including ordinary ticks**. The public command revision is insufficient for persistence CAS because it intentionally stays stable during tick-only changes. The existing room service's independent storageVersion pattern is suitable. Persist each successful returned authority atomically, then return only `{ok,code,snapshot}`. Never return the internal authority envelope.

Suggested response mapping: `UNAUTHORIZED` to HTTP 401; `MALFORMED_MESSAGE` to 400; `WRONG_DUEL` to 404; revision/sequence/phase/consent conflicts to 409; `APPLIED` and `DUPLICATE` to 200. Route membership must be authenticated before exposing even the existence of a duel. Apply the same authentication to snapshot polling.

For an optional `POST /api/rooms/:roomId/duels/:duelId/messages` integration, validate the room membership and duel ownership, enforce a small JSON body limit and request rate limit, and call `applyDuelMessage(storedAuthority,body,{peerId:authenticatedMember.id})`. An external scheduler calls `advanceDuelAuthority`; client elapsed time is never used. On transport disconnect/leave call `disconnectDuelAuthority`, persist, and broadcast the result. Rejoining does not restore old consent or reopen a terminal duel; starting a new duel requires a new duel ID and both peers' consent.

The integration must keep duels separate from campaign death settlement, inventory mutation, and rewards. Duel results always have `gearLoss:false`. Existing `server/action-adapter.mjs` is unchanged: its PvE final-death settlement must not process duel results.

Presentation may label a session server-authoritative only after a real configured/authenticated authority transport exists, using `{scope:'server-authoritative',transport:{authenticated:true,authoritative:true}}`. Locally running this pure module does not establish that transport; the default is `local-preview`.

## Verification

`node --check dist/duel/authority.mjs` passed. Initial test run failed because the new authority module did not yet exist, before implementation. Final `node --test tests/duel-authority.test.mjs` is pending simulation availability. Hosted routes, persistence, transport authentication, deployment, and live two-device testing remain integration work.
