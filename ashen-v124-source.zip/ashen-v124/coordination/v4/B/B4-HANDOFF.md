# B4 — completed environment and integration QA

`dist/world/environment.mjs` exports `createEnvironment(scene,renderer,{mobile=false,reduced=false}={})` returning `{update(dt,time),dispose()}`. B3 may call this directly; renderer may be undefined or a minimal stub and is never mutated.

Local APIs were fixed before launching exactly three subagents: `/root/lighting`, `/root/atmosphere`, `/root/qa`. No recursive spawning. Lead implements environment composition and restoration.

- `createLighting(scene,{mobile,reduced}) -> {update,dispose,lights}` owns its lights and their removal.
- `createAtmosphere(scene,{mobile,reduced}) -> {background,fog,update,dispose}` owns its particle group/resources; it returns fog/background without assigning scene state.
- Environment assigns fog/background and `scene.environment=null`, preserves prior values, and restores each property only while still owned. Nested environments support LIFO and out-of-order teardown.

## Implemented behavior

- Cool Hemisphere fill and Directional key, warm practical points at `[-5.15,2.15,-2.5]` and `[5.15,2.15,3]`. Desktop: four lights, one 1024 directional shadow. Mobile: three lights, no shadows. ACES exposure 1.16 remains root-owned.
- Background `#0b0e12`; linear fog 16..35. One Points draw call, 22 desktop / 9 mobile particles; reduced mode has no particles or practical shimmer. Position buffer at most 264 bytes. No texture downloads, environment-map allocation or large transparent planes.
- Environment restores background/fog/environment by ownership frame. All six disposal orders of three overlapping environments are tested. External state replacement survives teardown. Repeated dispose and update after dispose are no-ops. Invalid dt/time stay finite.
- Node resolver `tests/figures-loader.mjs` maps bare `three` to the existing bundled `dist/lib/three.module.js` (r170).

## Final verification

Lead independently ran from the repo:

```text
node --test --experimental-loader ./tests/figures-loader.mjs ./tests/world-environment.test.mjs ./tests/figures-world-integration.test.mjs
exit 0; tests 12; pass 12; fail 0

node --test --experimental-loader ./tests/figures-loader.mjs ./tests/figures*.test.mjs ./tests/world*.test.mjs
exit 0; tests 43; pass 43; fail 0
```

Nine environment checks cover actual APIs/light budgets, immutable renderer settings, twelve repeated teardown cycles with shadow map/mapPass disposal exactly once, bad inputs, reduced motion, independent external property ownership and nested ownership restoration. Three integration checks add a real room with eight figures on both profiles, repeated/null/unknown equipment changes including rune2h and additive rune_boots, finite combat/death/revival animation without root XZ/yaw changes, and six rebuilds freeing all geometry/material/shadow resources exactly once while preserving foreign objects and actor ownership.

Eight-figure scene has a base renderable draw-call estimate of 379 on both profiles, 33,633 triangles desktop / 33,089 mobile, plus 22/9 points. These are Node geometry/resource counts, not measured GPU render calls or FPS; shadow passes and actual culling are excluded. An earlier broad run had two failures in world-architecture tests (missing campaign/save.mjs and north doorway assertion); both passed in the latest 43/43 run after their owners' changes. B4 did not edit those modules/tests.

The QA agent completed environment tests and loader. Following interruption its resumed task remained pending_init; lead stopped that pending task and completed the missing integration file. Exactly three agents were originally started and none were added. Production modules were available before freeze; final QA recovery/report completed after the deadline.

Lighting agent separately reports exit 0 on bundled Three r170: four mode combinations, finite updates, reduced stability, foreign state preservation, exact shadow disposal, 80 repeated cycles. Atmosphere agent separately reports exit 0: four profiles, 48 creations, 4896 updates and 96 dispose calls, geometry/material disposal once, finite attributes/transforms.

## Root browser QA procedure

Root owns the preview server/browser. On the assembled scene, check faces and silhouettes against the warm points and cool key at ACES1.16; confirm the north exit stays readable. Toggle reduced motion: dust vanishes and shimmer stops. Rebuild the room repeatedly and inspect renderer.info.memory/render counts for a stable plateau after renderer cleanup; mobile should have zero active shadow lights. Check desktop and iPhone viewport performance on the actual renderer, which Node does not measure.

No server/browser, publication or commit was performed. Automatic approval review rejected the requested director-chat status send because authorization for the destination/payload was not recognized; no workaround was attempted. This passive handoff remains available for integration.
