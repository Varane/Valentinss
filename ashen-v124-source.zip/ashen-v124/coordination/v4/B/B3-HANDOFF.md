# B3 — source ready, complete world smoke passes

Exactly three subagents started: `/root/floor`, `/root/props`, `/root/walls`. Lead owns architecture/world orchestration and Node tests. Walls replaces the optional separate test worker under CONTRACT.md.

## Fixed local interfaces

- `createFloor({mobile=false,reduced=false}={}) -> {root:Group,floor:Mesh,dispose()}` from `dist/world/floor.mjs`.
- `createProps(options={}) -> {root:Group,interactables:Array,dispose()}` from `dist/world/props.mjs`.
- `createWalls(options={}) -> {root:Group,exits:Array,dispose()}` from `dist/world/walls.mjs`.
- `createArchitecture(options={}) -> {root,floor,exits,interactables,dispose()}` from `dist/world/architecture.mjs`.
- `createWorld(scene,renderer,options={}) -> {floor,update(dt,time),dispose(),exits,interactables}` composes B4 `createEnvironment(scene,renderer,options)`.

Floor is exact x[-6,6],z[-5,5], top y=0. Pillars use action.mjs PILLARS, physical radius .5; player collision distance .85 includes actor radius .35. North exit at `{x:0,y:0,z:-5}`, width2.2. South side open and east wall low for camera visibility. No camera/renderer changes. Props remain outside active arena; interactables empty unless actual integration supports them.

## Source and scene

All B3 source is on disk. `createWorld` successfully imports B4 environment; real Node create/update/dispose smoke passed including three repeated rooms, frozen renderer stub, invalid time inputs and preservation of unrelated scene objects. No browser/server started.

Floor uses 2 draw calls; walls6; props7; pillars12, total27 static architecture draws (environment, actors and shadow passes excluded). Exact active floor top y=0. Rear pillars2.85 high; ruined near pillars1.05 preserve combat visibility. Physical pillar footprint radius.5, action clearance.85 includes actor radius.35. Rendering is independent of action/rules module imports; a test separately compares obstacle centers.

North/west main faces are z=-5.35,x=-6.35. SOUTH open. EAST cutaway.52 high. North gate actual clearance2.5×2.25, public exit width2.2. Three static burial reliefs outside the floor. All custom deterministic geometry, owned per room, no stock assets or textures. World returns additive root; existing public API unchanged. world.update sanitizes finite time and composes B4 update. Idempotent disposal removes only owned objects/resources.

## Verification

Final verification, Node24.11.1:

```text
node --experimental-loader ./tests/figures-loader.mjs --test tests/world-architecture.test.mjs tests/world-environment.test.mjs tests/figures-body.test.mjs tests/figures-equipment.test.mjs tests/figures-animation.test.mjs
tests40 pass40 fail0 skipped0 duration17416.0703ms
```

All six B3 tests pass, plus B4 environment and B1/B2 body/equipment/animation suites. Exact floor bounds, actual simulation pillar centers/radii, north doorway clearance, no uncollidable arena props, finite mobile geometry/budget, geometry/material/InstancedMesh one-time disposal, independent rooms and complete repeated world smoke are verified. Instance-buffer disposal notifications were added in props and checked by the lead lifecycle test.

Pillar comparison imports the actual pure `dist/combat/movement.mjs` used/re-exported by action, avoiding unrelated campaign initialization. Doorway verification checks per-triangle merged geometry and per-instance bounds. Earlier combined-suite invocation omitted the required Three loader and produced9 import failures; corrected command above passes all40. Only Node's expected experimental-loader deprecation notice remains.

Exactly three workers started at ultra, fork_turns:none, default model; existing workers resumed after interruption, no new or recursive agents. Lead owns architecture/world/tests; subagents own their single files. Actual canonical IDs in B3-STATUS.json.

## Limits

Root owns browser visual QA. Exit data is metadata; runtime/campaign owns progression. No advertised interactable props. All B3 render-time imports exist and the create/update/dispose smoke succeeds. Source frozen after final tests at22:03UTC; three existing agents were stopped to preserve verified files. No B3 implementation blocker remains.
