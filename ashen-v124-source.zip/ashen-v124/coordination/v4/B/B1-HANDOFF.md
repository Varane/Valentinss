# B1 — body / face / palette / public figure composition

Status: SOURCE READY, 2026-11-11 21:59 UTC. Public `dist/figures.mjs` is written and imported successfully by Node. Exactly three subagents started: `/root/body`, `/root/face`, `/root/palette`; lead `/root` implements public orchestration and contract tests. Original agents resumed after interruption; no new agents or recursive workers.

## Fixed local interfaces for B2 / B4

- `createPalette({female,enemy,boss}) -> {materials,dispose}` from `dist/figures/palette.mjs`. Owns per-figure materials; keys required by B contract plus optional face tones.
- `createBody({female,enemy,boss,materials}) -> {root,body,head,joints,arms,legs,torso,weaponSocket,armorGroup,baseHeight,dispose}` from `dist/figures/body.mjs`. Owns body geometries only; supplies exact contracted pivots. Root scale remains one until orchestration applies boss scale 1.13.
- `createFace(head,{female,enemy,boss,materials}) -> {dispose}` from `dist/figures/face.mjs`. Adds face/hair to head anchor; owns only its geometries and nodes.
- Public `makeFigure({female=false,enemy=false,boss=false,weapon='blade',armor='cloth',boots=null}={})` composes the above, then calls B2 `attachEquipment(figure,{weapon,armor,boots,materials})`; assigns `figure.setEquipment=controller.setEquipment`, `figure.animate=createAnimator(figure)`; re-exports B2 `weaponModel` unchanged. `bootsId` is exposed. Two-argument equipment updates retain boots; explicit third `null` removes boots, as implemented by B2.
- Figure has `female,enemy,boss` booleans, all required groups and joints, `materials`, `baseHeight`. Defaults `blade` / `cloth`; explicit `null` preserved.
- `figure.dispose()` is idempotent, calls equipment controller before face/body/palette, and removes its root from its parent. Shared figure materials are disposed only by palette; each module owns a local geometry set. Constructor failure also releases acquired resources.

## Verification

Node v24.11.1. Command (absolute repository path): `node --test --test-isolation=none tests/figures-body.test.mjs`. Local registerHooks resolves bundled Three.js without packages/browser/server.

Final observed run: **8 tests passed, 0 failed, exit 0**, duration 528.4654 ms. Covers complete articulated contract, floor alignment and height, defaults/null/unknown equipment, repeat equipment identity, resource ownership on replacement, all-resource exactly-once teardown, palette independence, finite sparse animation and revival without XZ/yaw mutation. Rune test explicitly created `makeFigure({weapon:'rune2h',boots:'rune_boots'})`, verified IDs and attached weapon, retained boots through two-slot updates, animated finite poses, and checked exactly-once disposal of all live geometry/material resources.

Expanded figures suite: **25 passed, 0 failed**, duration 3969.0535 ms across `figures-animation.test.mjs`, `figures-body.test.mjs`, `figures-equipment.test.mjs`. Command: `node --experimental-loader file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/tests/figures-loader.mjs --test <absolute paths to these three files>`. Initial invocation with raw Windows drive path for loader failed before tests with `ERR_UNSUPPORTED_ESM_URL_SCHEME`; corrected to file URL and suite passed. Node emits the expected experimental-loader deprecation warning; no assertion failures.

Agent verification: palette inline Node exit 0 for 8 variants / 104 independently owned materials, no textures/emission, exactly-once disposal including alias/mutation ownership. Face syntax + lifecycle exit 0 over five variants: 9–13 meshes, 1264–1440 triangles, finite positions/normals, foreign child preservation and zero material disposal. Body syntax exit 0; 17 meshes / 1160 triangles, exact rig pivots, floor at zero.

Source-ready imports: `./figures/body.mjs`, `./figures/face.mjs`, `./figures/palette.mjs`, `./figures/equipment.mjs`, `./figures/animation.mjs`; compatibility re-export from `./figures/equipment-weapons.mjs`. B2 rune IDs are present in equipment controller.

Visual QA remains with root's browser. Restrained palette and angular custom geometry are present; no extra outline pass added by B1 before runnable verification. No claims about phone appearance without browser review.

## Scope

Only B1-owned code/report files. No commits, publishing, server, browser, foreign file modifications or cross-chat messaging.

Outgoing status message to director was rejected by automatic approval review for missing explicit human authorization to message that thread. No retry/workaround. This passive handoff is the integration record.
