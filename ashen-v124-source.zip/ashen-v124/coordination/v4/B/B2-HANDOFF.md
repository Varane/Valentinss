# B2 equipment and animation — verified integration handoff

Verified 2026-11-11 22:01 UTC. All B2 code is in the shared repository and imports through the current B1 public makeFigure. Fresh combined tests: 25 pass, 0 fail, 0 skipped, exit 0.

## Files and workers

Exactly three subagents were actually started, all fork_turns:none, reasoning_effort:ultra, default model. The collaboration API returned canonical identifiers `/root/weapons`, `/root/armor`, `/root/animation`; these are actual tool-returned IDs, not invented UUIDs. No recursive delegation.

- Lead: `dist/figures/equipment.mjs`, additive `dist/figures/equipment-boots.mjs`, `tests/figures-equipment.test.mjs`.
- `/root/weapons`: `dist/figures/equipment-weapons.mjs`.
- `/root/armor`: `dist/figures/equipment-armor.mjs`.
- `/root/animation`: `dist/figures/animation.mjs`, `tests/figures-animation.test.mjs`.

After interruption the live collaboration inventory showed only the lead. No replacement agents were created; lead completed rune2h geometry/animation in the existing B2-owned files and independently verified all delivered modules. Exactly three subagents were started in total.

## Public API

`attachEquipment(figure,{weapon='blade',armor='cloth',boots=null,materials}={})` returns `{setEquipment,dispose}`.

`setEquipment(weaponId,armorId,bootsId)`: omitted/undefined arguments retain the current slot. Explicit null or unknown IDs remove that slot. Existing two-argument callers keep working; terminal death callers must pass `setEquipment(null,null,null)` to clear boots too. Sets `figure.weapon`, `figure.weaponId`, `figure.armorId`, additive `figure.bootsId`. Repeat identical IDs retains the same resources. Disposed controllers are inert, repeated dispose is safe. Reattaching equipment to the same figure disposes the old controller.

Weapons: blade, cleaver, staff, reaper, additive rune2h. Armor: cloth, leather, chain, plate. Boots: additive rune_boots.

`weaponModel(id,materials?)` and `armorModel(id,materials?,figure?)` return Group; invalid IDs return empty Group. `bootsModel(id,materials?)` is exported by equipment-boots.mjs. All resources are tracked by `userData.ownedMaterials` / `ownedGeometries`; borrowed figure materials are preserved. Armor and boots supply `userData.jointAttachments=[{joint,object}]`. Controller installs/removes those parts and de-duplicates disposal, including geometry shared across left/right pieces. Controller disposal precedes B1 body/palette disposal.

`createAnimator(figure)` returns `animate(actorState={},time=0)`. Time is seconds. Animation restores captured local bind transforms each call; it never writes simulation actor or any root transform. Supports simulation speed, attackAnim, parry, hurt, windup, down/dead, revival, missing/non-finite inputs, weapon-dependent swings. Rune2h extends the existing weapon poses with a two-handed attack.

## B1/root integration

B1 now forwards `boots` from makeFigure options into attachEquipment; this public path passed integration tests. Knees are named `knee-1`, `knee1`. Boots are children of those joints, in local lower-shin/foot coordinates. Root forwards profile/simulation boots to makeFigure/setEquipment and clears them with third null on death. Existing imports/API remain valid.

Rune2h uses a muted blue steel blade, simple crossguard and extended grip; its raised two-handed idle pose keeps the tip above the floor. Rune boots use six-sided shin plates and compact foot shapes. Models use broad facets and restrained colors, without texture assets.

No server/browser was launched; visual inspection remains with the root-owned preview. Rune-blue models are authored procedural geometry, without downloaded assets. Equipment factories are render-independent.

## Verification

Use `node --test tests/figures-equipment.test.mjs tests/figures-animation.test.mjs` from the repository, or absolute test paths. Equipment suite registers a local THREE mapping itself. Full B suites may use `node --experimental-loader ./tests/figures-loader.mjs --test tests/figures*.test.mjs tests/world*.test.mjs`.

Fresh command from repository: `node --test tests/figures-equipment.test.mjs tests/figures-animation.test.mjs tests/figures-body.test.mjs`. Result: 25 tests, 25 pass, 0 fail, 0 skipped, exit 0, reported duration 3509.0567ms. This includes 8 B1 body tests, 8 animation tests and 9 B2 equipment tests. Equipment tests exercise 96 loadout changes, same-ID reuse, shoulder/boot attachment cleanup, preserved borrowed materials, null/unknown IDs, controller reattachment, rune blade idle clearance, finite combat/death/revival transforms, and public makeFigure rune gear teardown exactly once.

`node --check` passed with exit 0 for equipment.mjs, equipment-weapons.mjs, equipment-armor.mjs, equipment-boots.mjs and animation.mjs. No remaining B2 code blockers. Visual QA in the actual root-owned renderer remains with the integrator, as required by ownership.

## Coordination limitation

An attempted status message to the director chat was rejected by automatic approval review because it did not recognize explicit trusted user authorization to message that thread. No retry or workaround was attempted. Passive handoff/status files remain available and code work continues.

