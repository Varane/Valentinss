import assert from 'node:assert/strict';
import { register } from 'node:module';
import { writeFile } from 'node:fs/promises';
register(new URL('../../../tests/figures-loader.mjs', import.meta.url));
const T = await import('../../../dist/lib/three.module.js');
const { makeFigure } = await import('../../../dist/figures.mjs');
const { createWorld } = await import('../../../dist/world.mjs');
const metrics = [];
for (const mobile of [false, true]) {
  const scene = new T.Scene();
  const baseline = new T.Color('#123456');
  scene.background = baseline;
  const world = createWorld(scene, undefined, { mobile, reduced: true });
  assert.ok(world.floor?.isMesh);
  const figure = makeFigure({ weapon: 'rune2h', armor: 'chain', boots: 'rune_boots' });
  assert.equal(figure.weaponId, 'rune2h');
  assert.equal(figure.bootsId, 'rune_boots');
  assert.equal(typeof figure.dispose, 'function');
  scene.add(figure.root);
  figure.root.position.set(2, 0, 1);
  figure.root.rotation.y = .7;
  const states = [{ hp: 100, speed: 1 }, { hp: 100, attackAnim: .2 }, { hp: 100, parry: .2 }, { hp: 0, down: 5 }, { hp: 0, dead: true }, { hp: 70, speed: 0 }];
  for (const [i, state] of states.entries()) {
    const before = JSON.stringify(state);
    figure.animate(state, i / 2);
    world.update(.016, i / 2);
    assert.equal(JSON.stringify(state), before);
    assert.deepEqual(figure.root.position.toArray(), [2, 0, 1]);
    assert.equal(figure.root.rotation.y, .7);
    scene.updateMatrixWorld(true);
    scene.traverse(object => assert.ok(object.matrixWorld.elements.every(Number.isFinite), object.name));
  }
  let meshes = 0, triangles = 0;
  scene.traverse(object => {
    if (!object.isMesh) return;
    meshes++;
    triangles += (object.geometry.index?.count ?? object.geometry.attributes.position?.count ?? 0) / 3 * (object.isInstancedMesh ? object.count : 1);
  });
  figure.setEquipment('staff', 'leather');
  assert.equal(figure.bootsId, 'rune_boots');
  figure.setEquipment(null, null, null);
  assert.equal(figure.weapon, null);
  assert.equal(figure.bootsId, null);
  figure.dispose(); figure.dispose();
  world.dispose(); world.dispose();
  assert.equal(scene.children.length, 0);
  assert.equal(scene.background, baseline);
  metrics.push({ mobile, meshes, triangles });
}
const result = { checkedAt: new Date().toISOString(), status: 'pass', checks: ['public imports', 'rune2h and boots', 'finite poses', 'root placement ownership', 'actor immutability', 'equipment preserve/remove', 'idempotent teardown', 'scene restoration'], metrics };
await writeFile(new URL('./DIRECTOR-VERIFY.json', import.meta.url), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result));
