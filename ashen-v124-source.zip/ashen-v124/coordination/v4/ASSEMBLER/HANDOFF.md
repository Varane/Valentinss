# Assembly handoff — frozen for root packaging

Source is ready; no further production changes by assembler after this handoff. Root owns browser verification, packaging and publication. No server, hosting, service worker, commit, push or access settings were changed here.

## Files changed
- dist/action-game.mjs: normalize saved complete/defeat/camp runs before preparing combat; retain actionable loading feedback on WebGL renderer failure; preserve defensive tutorial while showing room subtitle; forward boots at figure creation, stat refresh and final death; forward camera zoom; return false on rejected midbattle restart; save live HP/mana/down/dead state; initialize music scene cues and connect opt-in gesture/toggle/volume/pause callbacks; initialize document translation and locale updates; apply family display names without changing actor IDs.
- dist/campaign/progression.mjs: mage starter staff; preserve survivors' earned inventory/armor when restoring a missing weapon.
- dist/rules.mjs: preserve finite fractional rescue timers (including longer authored timers) during save restoration.
- dist/campaign/choices.mjs: take-supplies grants 25 healing and 10 gold, with matching description, so full-health heroes still receive a concrete consequence.
- dist/i18n.mjs: additive setHeroNames(names) display override. Existing default names remain the standalone API default; actual runtime opts into family names from lore/family.mjs.

Campaign save/death/progression/choices modules arrived during inspection and were preserved. The room objectiveState failure was corrected by an arriving owner update; assembler did not overwrite rooms.mjs.

## Verification
- Final recursive browser import closure: 64 modules, zero missing. Local music/score-data.mjs exists and is included.
- node --check dist/action-game.mjs passed.
- Final rules/campaign/sprint13/sprint14 plus boot/tutorial/zoom/boots/i18n run: 126 tests, 122 pass, 0 fail, 4 pre-existing TODO boots cases also pass. See final-verification.txt. Tests arrived during execution, so earlier totals differ.
- Prior music/i18n/runtime focused run: 77 tests, 70 pass, zero failures, 7 pre-existing TODO cases all passed. See verification.txt.
- Direct family alias check: Russian Даник/Валентин and English Danik/Valentin passed using stable knight/mage IDs.
- Six-room ending, replayed reward protection, death/restart, persistent XP, lost dead gear, fractional rescue time and terminal-save boots execute against actual production modules. Browser rendering/device audio are root checks, not inferred from Node tests.

## Known limits for publication
- Room choice data/logic are tested but chooseRoom is not wired to a playable choice UI. Current runtime plays the default six-room combat arc; do not claim interactive branching decisions.
- Network variable remains null; online room-code co-op is not integrated into this runtime.
- Music is opt-in and only unlocks from a user gesture; root should verify audible output on the target browser/device.
- Generic static text is translated at startup and on language switch; exhaustive English translation coverage is not claimed.
- No visual art/model changes were made by this assembler. Root separately verified desktop and mobile rendering before final alias change.
