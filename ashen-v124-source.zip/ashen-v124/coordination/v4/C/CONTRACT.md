# C campaign implementation plan and file contract

Spec: ../MASTER.md. Authorized implementation now; no new approvals, worktrees, commits or publication. Six short rooms, real consequences, deterministic rewards, legacy profile v2 support. All files below are relative to the shared ashen-room repository. Main handoff by 21:30 UTC; freeze 21:40 UTC on 2026-11-11.

## Canonical story
Campaign id `crimson-ledger` / «Алая перепись». Грим и Векса enter the crypt to destroy a ledger that binds the district's living residents to the Архимясник. Rescue a captive keeper, break the blood machinery, decide whether to erase the debt or take its power. Adult gothic wit, restrained Russian lines. Coherent six-room arc; no copied franchise lore. Room IDs in order: `threshold`, `surgery`, `chapel`, `chains`, `antechamber`, `throne`. Existing Russian ROOM_NAMES may be retained for compatibility. Named flags: `freedPrisoners`, `silencedBell`, `brokenSeal`, `sparedKeeper`, `claimedLedger` (boolean); additional flags allowed only with stable documented names.

## Exclusive file ownership
Director C alone: dist/campaign.mjs; tests/campaign.integration.test.mjs; coordination/v4/C/STATUS.json, HANDOFF.md, CONTRACT.md.
Story worker: dist/campaign/story.mjs (lead); dist/campaign/dialogue.mjs; dist/campaign/quests.mjs; dist/campaign/endings.mjs; tests/campaign.story*.test.mjs; docs/story/story.md; coordination/v4/C/story-HANDOFF.md and story-STATUS.json.
Rooms worker: dist/campaign/rooms.mjs (lead); dist/campaign/encounters.mjs; dist/campaign/choices.mjs; dist/campaign/puzzles.mjs; tests/campaign.rooms*.test.mjs; docs/story/rooms.md; coordination/v4/C/rooms-HANDOFF.md and rooms-STATUS.json.
Balance worker: dist/campaign/balance.mjs (lead); dist/campaign/items.mjs; dist/campaign/skills.mjs; dist/campaign/rewards.mjs; tests/campaign.balance*.test.mjs; docs/story/balance.md; coordination/v4/C/balance-HANDOFF.md and balance-STATUS.json.
Progression worker: dist/rules.mjs (lead); dist/campaign/save.mjs; dist/campaign/death.mjs; dist/campaign/progression.mjs; tests/rules*.test.mjs and tests/campaign.progression*.test.mjs; docs/story/progression.md; coordination/v4/C/progression-HANDOFF.md and progression-STATUS.json.
Each worker lead implements the first file and integrates exactly three subagents, each owning one other production file plus unique test suffix. They must record actual agent IDs, starts and count in their own STATUS JSON. No further recursion. Read others' files freely; edit only owned files. Do not modify existing tests/runtime.test.mjs or action/UI/world files.

## Cross-worker interfaces (keep these exact)
All modules are browser-safe ES modules, pure JSON-compatible state, no DOM/Node dependencies. Functions return fresh data unless documented otherwise. Inputs are never mutated. Invalid optional saved data must safely recover. Preserve original rules public exports and version:2 profile shape.

### Story
`storyFor(roomId, campaign={}) -> {title, subtitle, intro, victory, defeat, exit}` where every value is a short Russian string. Can internally import dialogue/quests/endings modules.
`questFor(campaign={}) -> {id,title,objective,complete}` exported from quests.mjs; id is `crimson-ledger`.
`endingFor(campaign={}, profile={}) -> {id,title,text}` exported from endings.mjs; reflect flags and surviving heroes. All branches must be playable; no requirement for unimplemented NPC interaction.

### Rooms
`ROOMS` array of six authored entries `{id,title,subtitle,objectives:string[],choices:Choice[],...}` and `roomDefinition(roomIndex, campaign={}) -> fresh room object` from rooms.mjs. Index is zero based, clamp safely to 0..5. `enemies` array must be concrete simulation-compatible descriptors: x,z,yaw,hp,maxHp,damage,cooldown,windup:0,stun:0,target:0,attackAnim:0,hurt:0,speed:0,boss optional. All within x[-5.8,5.8],z[-4.8,4.8], off pillar centers. DO NOT import action.mjs.
`choicesFor(roomId,campaign={}) -> Choice[]` and `resolveChoice(campaign,roomId,choiceId) -> {campaign,effects,text}` from choices.mjs. Choice `{id,label,description}`; effects `{enemyHealthMultiplier?:number,enemyDamageMultiplier?:number,heal?:number,gold?:number,xp?:number,items?:string[]}`. Require a legitimate option, apply at most one choice per room, store campaign.choices[roomId]=choiceId; set flags. No profile mutation here. RoomDefinition must apply choice-dependent enemy multipliers and report objective/choice state. Optional puzzle API belongs in puzzles.mjs, documented independently; effects must connect through choices or roomDefinition, not narrative-only.
`encountersFor(roomId,campaign={}) -> enemies[]` from encounters.mjs. Rooms lead must connect puzzles/choices/encounters into roomDefinition. Director does not need to know their internals.

### Balance
`ITEMS` object from items.mjs and `SKILLS`, `BRANCHES` arrays from skills.mjs retain all existing IDs/slots/icons and existing baseline item stat values unless tested. No new gear geometry requirement; use existing weapon/armor IDs. Describe actual action mechanics (stamina based), include explicit legacy mana wording only if needed. Arcane action benefits currently absent: document exact proposed additive action effect in handoff; don't claim implemented until A provides it. `rewardForRoom(roomIndex,campaign={}) -> {xp,gold,items:[itemIdForHero0,itemIdForHero1],heal,mana}` from rewards.mjs. Stable modest progression; earlier rooms must not award final epic gear. `balance.mjs` reexports all these.

### Progression
rules.mjs imports/reexports ITEMS/SKILLS/BRANCHES from ./campaign/balance.mjs when available, retaining all old rule exports/tests. Add safe persistence of `profile.campaign` using save helpers.
`sanitizeCampaign(raw) -> campaign|null` from save.mjs: preserve only valid JSON data for schema `{version:1,id:'crimson-ledger',runId:string,roomIndex:0..5,questId:'crimson-ledger',status:'active'|'complete'|'defeat'|'camp',choices:{[roomId]:choiceId},flags:{[flag]:boolean},resolvedRooms:string[],rewardLedger:string[],history:string[]}`. Limits: choices 6, flags 32, ledger/history 128; runId 80 chars. Preserve unknown simple boolean flags safely; reject prototype keys. Also `serializeProfile(profile) -> string` and `restoreCampaign(raw)` alias if desired. Do not import rules.mjs from save.mjs (avoid cycle).
`applyEncounterOutcome(profile, encounter, result) -> fresh profile` from death.mjs (`victory|defeat|exit`). Copy hero HP/mana from same-ID actors safely; final dead actors lose bag/weapon/armor, keep xp/points/skills. A downed actor on victory is revived with 35% max HP. Party defeat finalizes all heroes. No battle reward here. No imports from rules.mjs (accept optional options.stats if necessary, or calculate via balance module).
`grantRoomReward(profile,reward,rewardKey) -> {profile,applied}` from progression.mjs; reward shape as above. Idempotency persisted at `profile.campaign.rewardLedger`; surviving heroes gain xp, level points and gear; dead heroes must never gain loot or resurrect. Preserve learned skills/xp; clamp valid data and reject unsafe keys. May import balance, must not import rules (avoid cycles). Also `restartProfile(profile) -> fresh profile` restores heroes, starter gear only for gearless/dead heroes, keeps XP/skills/points and all earned gear for survivors; new campaign assigned by director.

## Director facade behavior
Exports createCampaign(profile), roomFor(campaign), resolveRoom(profile,campaign,encounter,result), plus chooseRoom(profile,campaign,choiceId), restartCampaign(profile). createCampaign restores profile.campaign or builds a fresh run. resolveRoom syncs actor outcomes, awards once per run+room, advances roomIndex on victory, final room completes quest, defeat preserves XP and removes dead gear, exit camps only after resolved room. Return `{profile,campaign,rewardText,done}`; profile embeds same campaign. A stale repeated encounter must not clear the next room: bind encounters with `encounter.campaignRoomId` and `encounter.campaignRunId` when prepared; expose `prepareEncounter(encounter,campaign)` if useful. Integration instructions must show this binding.

## Verification steps
- Each production submodule gets focused Node tests for meaningful branching/failure behavior.
- Story: all 6 rooms have coherent objective, choice-related dialogue, ending branches.
- Rooms: choice changes concrete combat or reward state; invalid/duplicate choice rejected; bounded valid enemy positions; solvable puzzle sequence.
- Balance: references valid gear/skill IDs; progression stays monotonic; descriptions correspond to current mechanics.
- Progression: malformed saves, old save v2, replayed reward, downed versus dead, wipe/restart, XP permanence.
- Director: full six-room run, each failure/end branch, stale replay after advancement/reload, choice effects applied once, legacy rules/runtime tests remain green.
No commits. Run existing relevant tests plus new Node suites; record exact totals and limitations.
