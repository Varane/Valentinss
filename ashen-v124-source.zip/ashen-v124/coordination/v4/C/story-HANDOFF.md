# C-STORY — промежуточная передача, проверка ещё идёт

Рабочие файлы команды: `dist/campaign/story.mjs`, `dialogue.mjs`, `quests.mjs`, `endings.mjs`; собственные тесты `tests/campaign.story*.test.mjs`. Директор владеет `dist/campaign.mjs` и вызывает эти функции напрямую.

## Точное API

- `storyFor(roomId, campaign = {})` из `story.mjs` возвращает новый `{title, subtitle, intro, victory, defeat, exit}` со строками на русском. Неизвестная комната восстанавливается в `threshold`. Подзаголовок берётся из `objectiveFor`/`questFor`, четыре вида реплик — из `dialogueFor`. Победный текст `throne` берётся из реального `endingFor({...state,status:'complete'})`; это описание будущей победы, не изменение состояния.
- `dialogueFor(roomId, campaign = {})` из `dialogue.mjs`: новый `{intro,victory,defeat,exit}`.
- `questFor(campaign = {})` из `quests.mjs`: новый `{id:'crimson-ledger',title,objective,complete}`. Только собственное `status === 'complete'` завершает квест.
- `objectiveFor(roomId, campaign = {})` из `quests.mjs`: строка текущей задачи.
- `endingFor(campaign = {}, profile = {})` из `endings.mjs`: новый `{id,title,text}`; фактический финал директор вызывает после применения исхода боя и наград, передавая обновлённый профиль.

Все функции синхронные и браузерные. `story.mjs` не импортирует facade, rules, DOM или Node. Граф зависимостей идёт от story к трём независимым файлам без циклов.

## Уточнение сюжета

В 21:17 UTC получено новое указание директора, передающее пользовательский запрос: Даник (`knight`), Валентин (`mage`), Мама и Гюлин — семейное приключение с гоблинами и рунами. Старый текст CONTRACT с Гримом/Вексой пока не обновлён. Минимальное совместимое решение: сохраняем `crimson-ledger`, шесть room IDs, пять flags и формы API; адаптируем авторские русские реплики и fallback имена. Изменения новых внешних `dist/lore/**` принадлежат отдельному автору.

Сохранённые последствия: `freedPrisoners`, `silencedBell`, `sparedKeeper`, `brokenSeal`, `claimedLedger`; учитываются только настоящие boolean-значения. Story не применяет механические эффекты, их выполняют choices/facade. Без профиля endingFor не должен объявлять гибель партии.

## Исполнители и ограничения

Ровно три успешно запущенных subagent: `/root/story_dialogue`, `/root/story_quests`, `/root/story_endings`; каждый `fork_turns:none`, `reasoning_effort:ultra`, без переопределения модели. Четвёртый исполнитель lead `/root` написал `story.mjs`. Tool сообщает canonical IDs, но не opaque UUID и не runtime model ID; модель Astra запрошена, наследование невозможно независимо проверить.

21:24 UTC: тесты диалогов и заданий — 14 passed; общая проверка пока ожидает появления endings.mjs (ERR_MODULE_NOT_FOUND). Итоговые totals будут добавлены после проверки. `story.mjs` уже импортирует `familyDialogueFor` из существующего `dist/lore/family.mjs` и использует его русские intro/defeat/exit; victory берётся из нашего dialogueFor либо endingFor. Так семейный слой реально показан через прежний API. Выбор языка UI находится вне STORY; исходный lore содержит RU/EN. Автопроверка отклонила отправку автору lore из-за нераспознанного разрешения передавать детали реализации между чатами; отказ не обходился.

Сервер/браузер/публикация/коммиты не запускались. Чужие production-файлы не редактировались.
