# Next release audit

No further source changes during the assembled-release test. Current source has77/77 C+rules+runtime checks green.

P0 root/D acceptance: on phone make a room choice, fight, lose one hero, rescue a downed ally, clear room, reload, verify XP/loot only once, complete room6 and restart. Terminal saved campaigns must route to outcome/restart before prepareEncounter. Nonlethal duel must never invoke campaign defeat.

P1: complete EN catalog for the exact recovery choice/reward strings; expose XP/gear death consequence before starting; ensure safe exit remains available after equipment changes. Verify current-room injured HP is carried into encounter by A/root.

P2 after human play feedback: tune six-room difficulty and boss HP using observed clear times; replace the one-click seal answer with a compact interactive three-symbol choice only if it improves phone play. No extra rooms or lore expansion.
