# C — SOURCE READY, 77/77 tests passed

All campaign dependencies now exist in the shared repository. Do not replace save/death/reward modules with emergency stubs: the working implementation is already installed. C workers should freeze writes; the root assembler owns the next integration step.

## Verified result

Command: `node --test tests/campaign*.test.mjs tests/rules*.test.mjs tests/runtime.test.mjs`
Result: tests 77, pass 77, fail 0, skipped 0, exit 0; duration 2077.5846 ms.
The integration suite imports the real `dist/action.mjs` and completes all six rooms. It checks stale victory after advancement/reload, invalid outcomes, choice effects, final death, downed rescue, restart, exit, legacy v2 migration and separate campaign-key migration. The initially observed eight C failures were corrected; this is the fresh post-fix result.
No browser or publication was performed by C. Root must verify phone controls, visible choices, death overlay and final restart in the assembled app.

## Exact facade exports

From `dist/campaign.mjs`:
- `createCampaign(profile, savedCampaign?)`: restores embedded profile.campaign first, optional old separate key second. A fresh profile with phase camp starts an active campaign. This restores; it does not start a new run after death.
- `roomFor(campaign)`: fresh {id,title,subtitle,objectives,choices,enemies,puzzle,choiceState,objectiveState,story,quest}; completed state adds ending. State.status is authoritative (active/complete/defeat/camp).
- `prepareEncounter(encounter, campaign)`: assign the returned encounter. Supplies the room-specific enemies and campaignRunId/campaignRoomId binding needed by resolveRoom.
- `chooseRoom(profile,campaign,choiceId)`: commits one pre-battle choice; returns {profile,campaign,rewardText,text,effects,done,completed}. Gold/XP/heal/item effects apply once. Rebuild battle from returned profile/campaign. Root must block this while battle.started and set profile.started consistently.
- `resolveRoom(profile,campaign,encounter,result)`: result victory/defeat/exit; returns {profile,campaign,rewardText,done,completed}. Victory advances exactly one room. Room six sets status complete; repeated or stale bound callbacks do not award or advance. Save returned profile and campaign immediately.
- `restartCampaign(profile)`: returns {profile,campaign,...} with a NEW runId, preserved XP/skills/points, surviving earned gear, and starter gear for dead heroes. Use this after defeat/complete/camp. Do not use createCampaign for a new run.

```js
let campaign = createCampaign(profile, savedCampaign);
profile = {...profile,campaign};
let room = roomFor(campaign);
let battle = prepareEncounter(encounter(profile,room),campaign);
// chooseRoom only before battle.started:
({profile,campaign} = chooseRoom(profile,campaign,choiceId));
battle = prepareEncounter(encounter(profile,roomFor(campaign)),campaign);
// after simulation terminal outcome:
({profile,campaign} = resolveRoom(profile,campaign,battle,battle.phase));
// after completed/defeated/camped run:
({profile,campaign} = restartCampaign(profile));
```

## Content and mechanics

Six IDs unchanged: threshold, surgery, chapel, chains, antechamber, throne. Narrative crimson-ledger / Алая перепись; family lore is used by storyFor for intro/defeat/exit. Dialogue and quest APIs remain available. Final narrative responds to claimedLedger, freedPrisoners, silencedBell, sparedKeeper, brokenSeal and dead heroes.
Choices in order: drain-font/break-gate, free-prisoners/take-supplies, silence-bell/ring-bell, spare-keeper/take-keys, break-seal/force-gate, erase-ledger/claim-ledger. They change actual enemy health/damage or resources. The seal solution ash→blood→silence is a compact pre-battle choice, not a free-form spatial puzzle.
Rune sword `rune2h` weapon attack30 drops in room3; `rune_boots` boots defense2 in room4. Rules exposes boots in equipment, stats, save and death. Pass boots to B makeFigure/setEquipment and clear boots in any root death handling. Epic plate/reaper begin rooms5/6. Six-room total base XP580, gold305; five level increases from XP0. Skill copy now reflects A's actual mana+stamina special cost: 35 stamina AND3 mana; arcane1 +3 mana, arcane3 normal action restores2 mana.

## Persistence/death

Keep legacy key ashen-blood-v2. profile version remains2. campaign schema version1, runId plus rewardLedger. Reward IDs contain runId,roomId,action; dead heroes never receive room loot or resurrect. Defeat removes bag/weapon/armor/boots and retains XP/skills/points. Victory revives a downed ally; a final-dead ally remains dead. Starter weapon for mage is staff, knight blade. Surviving inventory is retained even if the weapon slot was empty.

## Actual team and recovery

Exactly four worker chats and twelve successfully started subagents (sixteen worker executors including leads); IDs in STATUS.json and worker STATUS files. Requested ultra accepted; effective runtime reasoning is not introspectable. Story chat explicitly requested Astra.
Repeated global interruptions left pending worker patches unsaved. After the root recovery instruction, C director created only absent modules using exclusive-create writes: items,skills,rewards,save,progression,death,puzzles,choices,encounters,rooms,endings. Existing balance/story/dialogue/quests/rules were preserved. Workers' prewritten tests found eight concrete mismatches; all are now corrected. recovery.cjs is historical recovery tooling, not a runtime import and must not be rerun as a deployment step.

## Remaining integration limits

- Native modules and Node behavior are verified; presentation/mobile/browser behavior belongs to root/D and is not claimed tested here.
- C wrote new short Russian choice/reward strings during recovery; English team must cover them in its existing catalog. RU+EN family lore exists; complete English coverage is not asserted.
- Server authority, cooperative room-code synchronization, PvP loss rules and hosting are outside C. resolveRoom is a campaign outcome reducer, not a network authenticator. Do not call campaign defeat for a nonlethal duel.
- createCampaign restores completion status; on app boot root must show an outcome or call restartCampaign for a terminal saved run before prepareEncounter.
- A direct source-ready message to the root chat was rejected by automatic approval review for lack of recognized destination-message authorization. No resend or indirect message attempt was made. This handoff file is the already-requested production artifact.
