import { readFile } from 'node:fs/promises';

// Verification-only: source is transformed in memory; production files stay untouched.
const original = await readFile(new URL('../../../../../dist/camera-rig.mjs', import.meta.url), 'utf8');
const anchor = "    for (const axis of ['x', 'y', 'z']) {";
const orbit = `    const orbit = initialized && mode === 2
      ? { x: position.x - target.x, z: position.z - target.z } : null;
`;
const correction = `    if (orbit && alpha > 0) {
      const from = Math.atan2(orbit.x, orbit.z);
      const offsetX = next.position.x - next.target.x;
      const offsetZ = next.position.z - next.target.z;
      const to = Math.atan2(offsetX, offsetZ);
      const turn = Math.atan2(Math.sin(to - from), Math.cos(to - from));
      const angle = from + turn * alpha;
      const beforeRadius = Math.hypot(orbit.x, orbit.z);
      const radius = beforeRadius + (Math.hypot(offsetX, offsetZ) - beforeRadius) * alpha;
      position.x = target.x + Math.sin(angle) * radius;
      position.z = target.z + Math.cos(angle) * radius;
    }
`;
if (!original.includes(anchor) || !original.includes('    fov += (next.fov - fov) * alpha;')) {
  throw new Error('Owner camera source changed: re-evaluate candidate anchors');
}
const modified = original.replace(anchor, orbit + anchor)
  .replace('    fov += (next.fov - fov) * alpha;', correction + '    fov += (next.fov - fov) * alpha;')
  .replace("'./combat/camera-math.mjs'", JSON.stringify(new URL('../../../../../dist/combat/camera-math.mjs', import.meta.url).href));
export const { createCameraRig } = await import('data:text/javascript;base64,' + Buffer.from(modified).toString('base64'));
