# Incoming hurt direction — owner A

Actual source hitPlayer emits numeric source and sourceType:enemy. normalizeEffectEvent ignores that numeric source and uses victim direction. Real event regression fails with dx0, expected-1.

Exact minimal three-change proposal: fix-proposal.patch. Production:1pass1fail. Isolated proposal:2pass0fail, evidence candidate.tap. Lead reran both after app/tool reset, finishing interrupted worker final handoff. No production edits.

Apply proposal then run node --test tests/sprint-08-combat.test.mjs. Browser/FPS untested.
