# Sprint08 lead — keyboard control feedback

Owner: D1 (dist/input.mjs). Priority: cosmetic/response, not a combat dispatch failure.

Current-source reproduction: node --test tests/sprint-08-input.test.mjs. Baseline: one pass, one failure (KeyE dispatches parry but corresponding button never gets is-pressed). Shift/R have the same paint predicate.

Exact proposal: input-feedback.patch, a single expression update in paint(). Include heldKeys whose actions mapping equals the control type; keyup and clear already repaint. This preserves native Space-on-button behavior.

Candidate derived from actual source plus this proposal passes both regressions. Existing controls DOM/state suite passed; see existing-controls.tap.

Gate4 source recheck: owner source still contains original predicate; no owner revision yet. No production change applied. New regression is deliberately red while proposal is pending.

Browser appearance and iPhone event behavior not exercised here.
