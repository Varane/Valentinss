import test from 'node:test';
import assert from 'node:assert/strict';
import {createInput} from './candidate-input.mjs';

class Target {
  listeners=new Map(); style={}; disabled=false; tagName='BUTTON';
  values=new Set();
  classList={toggle:(name,on)=>on?this.values.add(name):this.values.delete(name),remove:name=>this.values.delete(name),contains:name=>this.values.has(name)};
  addEventListener(type,fn){if(!this.listeners.has(type))this.listeners.set(type,new Set());this.listeners.get(type).add(fn);}
  removeEventListener(type,fn){this.listeners.get(type)?.delete(fn);}
  emit(type,data={}){const event={type,target:this,cancelable:true,preventDefault(){},...data};for(const fn of this.listeners.get(type)||[])fn(event);}
  closest(){return null;}
}
function setup(){
  const doc=new Target(),win=new Target(),nodes=new Map();
  doc.tagName='HTML';doc.defaultView=win;doc.hidden=false;doc.visibilityState='visible';doc.activeElement=null;
  doc.querySelector=()=>null;doc.getElementById=id=>nodes.get(id)||null;
  for(const id of ['scene','strike','dash','parry','special']){const node=new Target();node.ownerDocument=doc;nodes.set(id,node);}
  const actions=[];
  const input=createInput({canvas:nodes.get('scene'),onAction:type=>actions.push(type)});
  return {doc,win,nodes,input,actions};
}

test('keyboard action feedback: parry, dash and special depress their matching controls until keyup',()=>{
  const f=setup();
  try {
    for(const [code,id,type] of [['KeyE','parry','parry'],['ShiftLeft','dash','dash'],['KeyR','special','special']]){
      f.doc.emit('keydown',{code});
      assert.equal(f.actions.at(-1),type);
      assert.equal(f.nodes.get(id).classList.contains('is-pressed'),true,code+' has no pressed feedback');
      f.doc.emit('keyup',{code});
      assert.equal(f.nodes.get(id).classList.contains('is-pressed'),false);
    }
  } finally {f.input.destroy();}
});

test('attack feedback is immediate and blur clears its held state',()=>{
  const f=setup();
  try {
    f.doc.emit('keydown',{code:'Space'});
    assert.equal(f.nodes.get('strike').classList.contains('is-pressed'),true);
    assert.equal(f.input.attackHeld(),true);
    f.win.emit('blur');
    assert.equal(f.nodes.get('strike').classList.contains('is-pressed'),false);
    assert.equal(f.input.attackHeld(),false);
  } finally {f.input.destroy();}
});
