# Figure animation blocker — exact minimal proposal

Observed 2026-11-11 21:39 UTC. Owner B1 owns `dist/figures.mjs`; B2 owns `dist/figures/animation.mjs`.

The current public facade still uses its inline legacy animate function. During hurt it overwrites simulation-owned `root.rotation.z`: initial -0.04 becomes 0.004176596874555409 at time .23 with hurt .2. Its neutral frame resets that root roll to zero. B2 already supplies a local-pose animator that leaves the root intact.

Apply only if B1 has not already integrated the animator:

```diff
 import * as T from 'three';
+import {createAnimator} from './figures/animation.mjs';
```

Replace the complete block beginning `figure.animate=(state,t)=>{` and ending with its matching `};` (immediately before `return figure;`) with:

```js
  figure.animate=createAnimator(figure);
```

No other lines need modification for this blocker. The current facade's `body`, `head`, and `joints` satisfy the new animator input. This also activates B2's existing finite-value, recovery, and weapon-pose work through the public API.

Run `node --test tests/sprint-08-figure.test.mjs`. First test is production regression and currently fails; second runs the proposed binding against the actual current facade rig, without changing implementation.

No browser, playability, or FPS evidence was gathered.
