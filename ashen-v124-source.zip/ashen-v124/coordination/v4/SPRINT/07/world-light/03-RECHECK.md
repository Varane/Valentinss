# Gate 3 — current-source recheck

2026-11-11 21:40 UTC. No owner lighting revision was required. Re-ran the scoped suite against the current shared source.

Command: `node --experimental-loader ./tests/figures-loader.mjs --test tests/world-environment.test.mjs tests/sprint-07-world-light.test.mjs`

Actual result: 11 tests; 11 pass, 0 fail, 0 skipped, 0 cancelled. Duration 4628.6209ms. Node emits its experimental-loader deprecation warning; no runtime/test error.

SHA256 source hashes sampled with this recheck:

- dist/world.mjs: 23367A452F476F0C0A5059F6B1EF3C12AF93C7EAA4BB7A26FFD2236A245FA51E
- dist/world/environment.mjs: 0A0B339B5814752597A4089F1F6A5AD2BD7F34B990949AA70B0C33EF31BE4362
- dist/world/lighting.mjs: AB52BD02C051E28AAB68D0B23E659C78FEDBB1D97BA1A4C3E1665FC56C4711FB
- dist/world/atmosphere.mjs: 5DD5D9CD5C9FC38D64FDFD6B169FAF01434D1F8D09F7DBD7FC421A34FDAACDBE

This verifies behavior and lifecycle, not rendered visibility, exposure or device frame rate. Root retains visual acceptance.
