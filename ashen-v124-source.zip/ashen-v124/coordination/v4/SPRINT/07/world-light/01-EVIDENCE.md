# Gate 1 — reproduce

Read current MASTER.md, B/STATUS.json, B/HANDOFF.md and dist/world.mjs plus its environment, lighting, atmosphere and architecture dependencies.

Command: `node --experimental-loader ./tests/figures-loader.mjs --test tests/world-environment.test.mjs tests/world-architecture.test.mjs`

Actual result: 15 tests; 13 pass, 2 fail. All 9 lighting/environment cases passed. The two failures are unrelated owner observations:

- tests/world-architecture.test.mjs:52 could not import dist/campaign/save.mjs from dist/rules.mjs (ERR_MODULE_NOT_FOUND).
- tests/world-architecture.test.mjs:97 asserted `crypt-north-arch closes the north doorway`. This is a bounding-box test observation, not independently confirmed geometry obstruction.

Mobile has one hemisphere, one directional and one point light; no mobile shadows. Reduced mode has no dust and suppresses point-light shimmer. No reproduced illumination or environment lifecycle blocker. No browser, server, screenshot or visual acceptance was performed.
