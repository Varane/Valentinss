# Gate 1 — reproducible camera/label mismatch

Owner: root runtime, `dist/action-game.mjs`, function `frame`.

Current frame calls `drawActors()` before `rig.update(...)`. Enemy labels project through the prior camera matrix, then Three's render updates the camera and draws a different view. Moving camera therefore separates labels/telegraphs from their actor anchors. Updating the rig alone before projection is insufficient: camera world/inverse matrices must also be refreshed before `Vector3.project`.

Executable evidence: `node --test tests/sprint-07-camera-labels.test.mjs`. It executes the actual current frame function with the real bundled Three camera and real camera rig. It compares the projected anchor used by labels to the same anchor after render's matrix refresh. Browser, playability and FPS are not tested.

Second test applies the exact proposed one-line replacement in memory and checks the same invariant. No production file is modified by team 07.
