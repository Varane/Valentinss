Cycle 1 evidence candidate: current public figures.mjs line 67 assigns root.rotation.z during hurt/idle. Root is externally owned (actor placement/orientation); local hurt should affect body.rotation.z. Existing modular animation.mjs already respects root ownership, but is not yet wired into current public file. Narrow executable regression added to tests/sprint-07-figures.test.mjs; run result pending.

Cycle 2 minimal current-source patch proposal to B: remove root.rotation.z assignment from head line; after death/standing body.rotation.z branch, apply local additive hurt roll: if (state.hp>0 && state.hurt>0) body.rotation.z += Math.sin(t*55)*.05. This preserves hurt silhouette while leaving root transform untouched, including idle/revive. No material color/exposure retuning proposed without visual evidence.

Classification correction after current runtime review: root runtime sets yaw only. MASTER does not explicitly reserve root roll; ownership statement is in B modular animator comment. This is low-priority optional robustness, NOT a reproduced current gameplay blocker. Regression marked TODO on current source and enabled for the in-memory candidate using SPRINT07_FIGURE_CANDIDATE=1.

No implementation edits made. No visual/browser verification. Material appearance isolation under hurt/death passed. No material/lighting release blocker reproduced.
