Four-cycle bounded audit final

1. Reproduced current source behavior: hurt animation writes root.rotation.z. Initial run: 2 tests, 1 pass, 1 fail. Current runtime only sets yaw, so no present gameplay failure demonstrated. Classified optional contract robustness; current-source assertion is TODO.
2. Exact minimal proposal in PROPOSAL.md: remove root roll assignment, apply hurt roll to local body after death/standing branch. Candidate executes by in-memory source substitution only; implementation untouched.
3. Owner public source revision was not observed during audit. B/HANDOFF remained in progress when inspected. Recheck is limited to current-source material behavior and optional candidate, not owner acceptance.
4. Acceptance: no reproduced figure material/lighting blocker. Hurt/death do not alter another figure material appearance (executable pass). Player/enemy/boss silhouettes and palette/lighting were source-inspected only. Visual acceptance remains root-owned and unclaimed.

Owner action: no required release change from this audit. B may adopt local hurt-roll robustness if desired. Do not block release on optional TODO. Root should visually verify player/enemy/boss under desktop/mobile light with hurt/death poses.

Files: tests/sprint-07-figures.test.mjs and coordination/v4/SPRINT/07/figure-readability/** only. No implementation, browser, server, chat, or commit changes.
