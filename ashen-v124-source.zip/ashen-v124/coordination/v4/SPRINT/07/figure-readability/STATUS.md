Cycle 1 reproduced: node --test tests/sprint-07-figures.test.mjs => 2 tests, 1 pass, 1 fail. Hurt animation mutates externally owned root orientation (public figures.mjs:67). Independent figure material appearance remains unchanged during hurt/death (pass).

Cycle 2 proposal delivered to sprint lead: remove root.rotation.z mutation; apply hurt roll additively to body.rotation.z after death/standing branch. Exact proposal in PROPOSAL.md. Await owner revision for cycle 3 recheck.

Static lighting inspection: world rig supplies broad hemisphere fill intensity 1.35, directional key 2.1, restrained practical variation <=2.4%; material palette has skin/cloth/steel roughness separation. These are source observations, not visual acceptance. No material/exposure retuning proposed without browser evidence.

No implementation, browser, server, or root runtime edits. No visual verification claimed.
