# Cycle 2: source-reference mismatch

Owner: A, `dist/effects.mjs`, `normalizeEffectEvent`.

Real `hitPlayer` events carry `source:0, sourceType:'enemy', target:0, targetType:'player'`. `referencePoint` accepts only objects, so numeric source is ignored and `source` falls back to victim `actor`. Incoming direction is consequently victim yaw, not source-to-target. With enemy at (1,0), victim at (0,0), victim yaw 0, current cue is (dx,dz)=(0,1); expected (-1,0). Impact position itself is correct. This is a directional combat-feedback defect; no visual/FPS claims.

Minimal current-source change: replace the two source/target assignments with:

```js
const source = referencePoint(event.source, encounter) || (event.sourceType && referencePoint({kind:event.sourceType,index:event.source}, encounter)) || actor;
const target = referencePoint(event.target, encounter) || (event.targetType && referencePoint({kind:event.targetType,index:event.target}, encounter)) || (TARGET_EVENTS.has(event.type) ? enemy : actor);
```

This retains structural references and legacy actor/enemy fallback. Only explicit typed numeric references gain behavior. Regression: `node --test tests/sprint-07-effects.test.mjs`. Test uses real `hitPlayer` event production; separate passing candidate checks reduced burst bounds, <=250ms expiry, no lights, terminal disposal and preservation of unrelated scene content. Implementation remains owner A's responsibility.
