# Sprint 07 final evidence

2026-11-11 21:42 UTC. Four bounded cycles: source reproduction, minimal current-source proposal, source recheck plus focused suite, acceptance decision.

Command: `node --test tests/sprint-07-effects.test.mjs tests/effects.test.mjs tests/effects-particles.test.mjs tests/effects-slashes.test.mjs`.

Result: 32 tests, 31 passed, 1 failed. Sole failure: new real `hitPlayer` event regression, incoming enemy at +X requires normalized dx=-1 but actual dx=0. Current source is still unpatched. Existing 30 facade/particle/slash tests pass; new reduced-mode pool/expiry/disposal test passes.

Owner A action: apply exact two-line `sourceType`/`targetType` resolution change in `02-owner-action.md`, rerun the command above. Conditional acceptance: incoming-direction regression green with existing effects suites green. As checked, directional feedback acceptance is blocked; lifecycle/reduced behavior passes. No claimed visual, mobile hardware or FPS verification. Root runtime does pass `reduced` preference to effects; no separate mobile option is in the agreed facade contract.

Only scoped evidence files and `tests/sprint-07-effects.test.mjs` were written. No implementation, browser, server, commit or recursive agent activity.
