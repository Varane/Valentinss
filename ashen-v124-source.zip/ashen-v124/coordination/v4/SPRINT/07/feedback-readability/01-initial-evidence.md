# Sprint 07 combat-feedback readability

Cycle 1 source check, 2026-11-11 21:38 UTC.

Read MASTER, A STATUS/HANDOFF, current effects facade, particle and slash helpers, and existing effects tests. No implementation edits.

Observed: particle capacity clamps at 512 (default 96); slash capacity clamps at 64 (default 16). Particle lifetime <= 0.50 s, slash lifetime <= 0.24 s. Reduced mode divides burst counts by four, limits lifetime to <= 0.21 s, and uses static slash marks at opacity <= 0.25 for <= 0.10 s. Visual effects add no lights. Both helpers detach owned scene objects and release geometry/materials in dispose. Source observations only; no visual or FPS claim.

Next: execute a regression against the actual simulation event shape and verify reduced-mode expiry/disposal from the public facade.
