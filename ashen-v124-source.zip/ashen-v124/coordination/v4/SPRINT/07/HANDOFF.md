# Team 07 — final handoff

Final recheck2026-11-11 21:58 UTC. Live actionable proposal saved21:40; final target21:45 missed. Four actual workers:lead + /root/world_light,/root/figure_readability,/root/feedback_readability. All three children delivered evidence. Only scoped tests and team07 reports written. No implementation, browser, servers, commits or publication.

## Outstanding owner patches

1. ROOT dist/action-game.mjs frame(now): replace
`drawActors();rig.update(dt,battle.players[selected],battle);renderer.render(scene,camera);`
with
`rig.update(dt,battle.players[selected],battle);camera.updateMatrixWorld();drawActors();renderer.render(scene,camera);`

Actual current frame, actual bundled Three and actual rig produce camera/label anchor drift0.14551120533050166NDC. Exact in-memory candidate passes. Tests:sprint-07-camera-labels.test.mjs. Full proposal:CYCLE-2.md.

2. A dist/effects.mjs normalizeEffectEvent: real hitPlayer emits numeric source/target plus sourceType/targetType. Normalizer ignores numeric source, uses victim yaw. Enemy at+X/victim facing+Z yields direction(0,1), expected(-1,0). Replace source/target assignments with:

```js
const source = referencePoint(event.source, encounter) || (event.sourceType && referencePoint({kind:event.sourceType,index:event.source}, encounter)) || actor;
const target = referencePoint(event.target, encounter) || (event.targetType && referencePoint({kind:event.targetType,index:event.target}, encounter)) || (TARGET_EVENTS.has(event.type) ? enemy : actor);
```

Exact proposal:feedback-readability/02-owner-action.md; evidence:feedback-readability/FINAL.md. Candidate verified3/3 event paths:typed incoming,legacy hit,structural references. Production unchanged.

## Final checks

PowerShell at repo root:
```powershell
$sprintTests = @(Get-ChildItem -LiteralPath tests -Filter 'sprint-07*.test.mjs' | ForEach-Object { $_.FullName })
& node --test @sprintTests
```

21:58 UTC:8 tests,5 pass,2 fail,1 TODO; exit1. Only blocking failures are camera-label projection and incoming-damage direction above. Rerun after owner patches.

Lighting focused current-source:11/11 pass (9 existing environment+2 new world lifecycle/mobile/reduced). No illumination patch needed; four gate artifacts in world-light/.

Effects focused suite:32 tests,31 pass,1 fail (new direction regression). Reduced burst bounds,250ms expiry,no light allocation and disposal pass.

Figure material isolation passes. External root-roll preservation is optional robustness only:current runtime controls yaw; MASTER does not reserve roll. Test marked TODO. Optional in-memory candidate2/2 pass. See figure-readability/FINAL.md. No figure release blocker reproduced.

Earlier architecture bounding-box failure is not accepted proof of a closed doorway:combined arch+jamb mesh gives a broad box. Earlier missing campaign/save import not revalidated here.

## Acceptance

Four audit gates complete; production acceptance pending the two owner patches. No browser, scene aesthetic,playability,iPhone or FPS verification claimed. Root owns preview4173 and publication.
