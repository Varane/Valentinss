# Gate 2 — exact minimal root-owned patch

File: `dist/action-game.mjs`, `frame(now)` tail after `world.update` and `fx.update`.

Replace:

```js
drawActors();rig.update(dt,battle.players[selected],battle);renderer.render(scene,camera);
```

With:

```js
rig.update(dt,battle.players[selected],battle);camera.updateMatrixWorld();drawActors();renderer.render(scene,camera);
```

This calculates enemy labels against the same camera world/inverse matrices that Three uses to render the frame. The standalone regression executes the actual frame, actual bundled Three and actual camera rig. Current source: one failing regression, one passing candidate. Reproduction output: `label and rendered anchor differ by 0.14551120533050166 NDC`. Candidate: projection drift below `1e-8`.

Apply only through the root owner. Team 07 does not edit this file. No browser or FPS acceptance claimed.
