# Sprint 03 companion control and rescue acceptance

Completed four bounded cycles by 2026-11-11 21:43 UTC. No production edits.

## Result
No canonical player-control or rescue defect reproduced. Current updateCompanion skips the selected index and every integer index in externalPlayers, honors companionAI === false, and excludes hp-zero/downed and final-dead helpers. Live companions still rescue a downed selected hero. Real revivePlayer resolves equal-distance targets by stable lowest array index. Direct replay of rescue approach plus actual damage resolver was identical and never moved or commanded the selected hero.

## Executable regression
File: tests/sprint-03-companion.test.mjs. Seventeen tests: six direct runnable cases, eleven action-step integration cases.

Command:
`node --test tests/sprint-03-companion.test.mjs tests/action-ai.test.mjs tests/action-damage.test.mjs`

Final observed output: 49 tests, 38 passed, 0 failed, 11 skipped. Existing source AI and damage suites account for 32 passes; this worker adds six source-level passes. Runtime: 3831.8019 ms.

## Explicit limit
Action-step cases cannot currently import action.mjs because rules.mjs imports absent dist/campaign/save.mjs. dist/campaign/rooms.mjs and choices.mjs are also absent at cycle 3 recheck. Integration cases skip only an ERR_MODULE_NOT_FOUND under dist/campaign; unrelated import errors are rethrown. They execute automatically once campaign dependencies exist. Initial non-skipping command reproduced the missing save dependency and had 32 passes plus two import-level failed files (action-integration and sprint regression).

## Minimal patch proposal
None for scoped ownership/rescue behavior: no defect reproduced, so no implementation change warranted. Campaign dependency restoration is outside this worker's scope. AI pursuit/pillar movement issues are separately owned by the lead and are not covered by this acceptance.

## Evidence and boundaries
source-hashes.json records exact ai.mjs, damage.mjs and action.mjs sources used for acceptance. This is canonical state acceptance: encounter sets downed hero hp to zero. No assertions are made about contradictory externally malformed positive-hp/down-positive actor records. Only this directory and tests/sprint-03-companion.test.mjs were written.
