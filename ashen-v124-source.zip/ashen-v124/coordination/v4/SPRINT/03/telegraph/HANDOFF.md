# Sprint 03 — telegraph acceptance

Frozen 2026-11-11 21:42 UTC. Implementation files were read only. Scoped deliverables: `tests/sprint-03-telegraph.test.mjs`, this folder, and `proposal.patch`.

## Current default combat result

No default strike target-lock/range defect reproduced. Direct real AI + damage checks prove a committed swing retains its target and facing, does not hit a nearer teammate after the locked player dodges behind it, and rejects the locked player after that player leaves damage range. Existing `tests/action-ai.test.mjs` and `tests/action-damage.test.mjs`: **32 pass, 0 fail**. Source tracing confirms `action.mjs` subdivides steps to <=1/120 second; player movement precedes enemy strike, and defensive timers decay after strike evaluation.

## Reproduced dormant configuration defect

With enemy `attackRange:3` and a stationary target exactly three units away, AI begins windup and never approaches; damage resolver's normal reach is fixed at 2.25 (boss 2.5), so the enemy repeatedly whiffs. `rg -n attackRange dist --glob '*.mjs'` found only AI's option reader: **no current room descriptor uses this configuration**. This is an additive/configuration defect, not an observed default gameplay blocker.

Smallest proposed fix in `proposal.patch`: clamp AI's configurable engagement/approach distance to the damage resolver's actual reach. This leaves default 1.75 unchanged and avoids expanding damage reach. The lead's separate stop-distance margin can coexist with this upper-bound change.

## Executable evidence

Baseline command: `node --test tests/sprint-03-telegraph.test.mjs` -> **2 pass, 1 fail, 5 skipped**. The failing desired-behavior test is `configured engagement range must approach far enough that its eventual strike can hit`. It fails because player HP remains 100 after two seconds.

Candidate command in PowerShell: `$env:SPRINT_03_TELEGRAPH_CANDIDATE = '1'` then `node --test tests/sprint-03-telegraph.test.mjs` -> **3 pass, 0 fail, 5 skipped**. Candidate mode reads the actual current AI source, asserts the exact original line exists, replaces only the proposed upper-bound expression in memory, and imports that module through a data URL. It never edits implementation. Candidate pass demonstrates the proposal resolves the isolated failure; it is not a production fix claim.

## Blocked integration acceptance

Five integrated regressions cover full .7-second windup with target/facing lock, early outward dash after iframes expire, dash through the attacker within range but outside facing cone, wall-blocked late dash through a long frame, and .8-second frame versus 120 Hz strike timing. They explicitly skip only when action's dependency import reports the missing `dist/campaign/save.mjs`. The initial unguarded integration run reproduced `ERR_MODULE_NOT_FOUND`; no timestep/dash end-to-end acceptance is claimed. These tests automatically run once that owner dependency exists.

## Cycle gates

1. Source read and ownership confirmed; default defensive flow traced.
2. Existing 32 direct tests pass; integration blocker reproduced; deterministic desired range regression added.
3. Current source rechecked; config regression fails; exact minimal candidate passes all three direct checks.
4. Frozen with actionable owner handoff; no implementation/browser/server/commit/publication actions.

Source SHA256 at cycle 3: AI `A6A88ABC6F441139F551D740F5DFC34053544358EF694FAAB816A31DA8DAC4FA`; damage `CCE372BBA8AAD96830B38B9B650711BD3E925E6F9D589836170D070631CD70D7`; action `63096B8BD8815D35C8DD3B666B7B7CC9DAADA425200A02893FD5E937134AC97A`.
