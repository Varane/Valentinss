# Sprint 03 difficulty — campaign opening integration

Scope: actual six-room enemy descriptors through `roomFor` → `encounter(profile,currentRoom)` → `prepareEncounter`, plus opening fairness. No implementation edited.

## Cycle 1 — evidence

Read `MASTER.md`, `C/STATUS.json`, `C/HANDOFF.md`, and `C/CONTRACT.md`. Traced `dist/action-game.mjs:35`, action `makeEnemy`/`encounter`, campaign `prepareEncounter`, and AI configuration consumption. The room contract supplies fully initialized descriptors with `speed:0`; therefore replacement by `prepareEncounter` is not evidence of a speed bug. Actual room descriptors are unavailable while owner files remain absent.

## Cycle 2 — executable check and minimal proposal

Added `tests/sprint-03-difficulty.test.mjs`. This follows the actual runtime call order for every room and its choices, checking HP/maxHP/damage/cooldown, authored movement speed when present, clean transient combat fields, initial separation beyond melee range, and no HP loss in the first 250 ms with companion automation disabled. It does not alter enemy windup/strike or companion internals. The limited opening check does not establish that the full encounter is balanced.

Fresh command: `node --test tests/sprint-03-difficulty.test.mjs`.

Observed 21:41 UTC: exit 1; `ERR_MODULE_NOT_FOUND` for `dist/campaign/save.mjs`, imported by `dist/rules.mjs`. Node reports one file-level failure, zero passing tests. Gameplay assertions have not executed.

Confirmed issue: the actual campaign simulation cannot load its module graph. Minimal fix is for Direction C owners to save their already-owned modules at the exact imported paths, starting with `dist/campaign/save.mjs`. Do not remove the import or add replacement stubs: `rules.mjs` uses its persistence helpers and the facade requires the other campaign modules. No AI tuning is justified by this evidence.

## Cycle 3 — owner revision recheck

Repeated the same test command. At 21:42:49 UTC it again exited 1 with the same missing `dist/campaign/save.mjs` import. No owner revision was available for this dependency. Latest directory snapshot still showed only balance, dialogue, quests, and story modules.

## Cycle 4 — final acceptance

Bounded audit complete at 21:42:49 UTC. Campaign integration acceptance is withheld. Final result: 0 passing, 1 file-level failure; authored room/speed/spawn assertions remain unexecuted. No unsupported difficulty defect or fix is claimed. Deliver missing owner modules, then rerun the supplied regression. No implementation, servers, browser, commits, or publication changed.
