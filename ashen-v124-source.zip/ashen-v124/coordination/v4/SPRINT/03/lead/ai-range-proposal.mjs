// AI decides intent; movement, commands and damage remain owned by their modules.
const finite=Number.isFinite;
const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
const duration=dt=>finite(dt)&&dt>0?Math.min(dt,1):0;
const option=(value,fallback,min,max)=>finite(value)?clamp(value,min,max):fallback;
const timer=value=>finite(value)?Math.max(0,value):0;
const positioned=a=>a&&finite(a.x)&&finite(a.z);
const living=a=>positioned(a)&&finite(a.hp)&&a.hp>0&&!a.dead;
const distance=(a,b)=>Math.hypot(b.x-a.x,b.z-a.z);

function nearest(actor,actors,predicate=living){
  let found=null;
  for(let index=0;index<actors.length;index++){
    const target=actors[index];if(!predicate(target,index))continue;
    const d=distance(actor,target);
    if(finite(d)&&(!found||d<found.distance))found={actor:target,index,distance:d};
  }
  return found;
}

function face(actor,target){
  const dx=target.x-actor.x,dz=target.z-actor.z;
  if(finite(dx)&&finite(dz)&&(dx||dz))actor.yaw=Math.atan2(dx,dz);
}

function approach(actor,target,speed,dt,stop,moveActor){
  const d=distance(actor,target);
  if(!finite(d)||d<=stop||typeof moveActor!=='function')return;
  const travel=Math.min(speed*dt,d-stop),dx=(target.x-actor.x)/d,dz=(target.z-actor.z)/d;
  if(travel<=0||!finite(travel)||!finite(dx)||!finite(dz))return;
  actor.yaw=Math.atan2(dx,dz);actor.dx=dx;actor.dz=dz;
  moveActor(actor,dx*travel,dz*travel);actor.speed=speed/3.6;
}

export function updateEnemies(state,dt,{moveActor,emit,strike}={}){
  dt=duration(dt);
  if(!dt||state?.phase!=='active'||!Array.isArray(state.enemies)||!Array.isArray(state.players))return;
  for(let index=0;index<state.enemies.length;index++){
    const enemy=state.enemies[index];if(!enemy||typeof enemy!=='object')continue;
    enemy.speed=0;
    enemy.hurt=Math.max(0,timer(enemy.hurt)-dt);
    enemy.attackAnim=Math.max(0,timer(enemy.attackAnim)-dt);
    const oldStun=timer(enemy.stun);
    enemy.stun=Math.max(0,oldStun-dt);
    enemy.cooldown=Math.max(0,timer(enemy.cooldown)-dt);
    enemy.windup=timer(enemy.windup);
    if(!living(enemy)){enemy.windup=Math.max(0,enemy.windup-dt);continue;}
    // Stun pauses a committed swing, including the portion of this step still stunned.
    const activeDt=Math.max(0,dt-oldStun);
    if(!activeDt)continue;
    if(enemy.windup>0){
      enemy.windup=Math.max(0,enemy.windup-activeDt);
      if(enemy.windup===0){
        enemy.attackAnim=.3;
        enemy.cooldown=option(enemy.attackCooldown,enemy.boss?1.75:1.55,.5,4);
        if(typeof strike==='function')strike(state,index,emit);
      }
      continue;
    }
    const target=nearest(enemy,state.players);if(!target)continue;
    if(!state.started&&target.distance>3.5)continue;
    state.started=true;
    const range=option(enemy.attackRange,1.75,.8,4.5);
    if(target.distance>range){
      approach(enemy,target.actor,option(enemy.moveSpeed,enemy.boss?1.6:2,.3,4),activeDt,Math.max(0,range-.01),moveActor);
      continue;
    }
    face(enemy,target.actor);
    if(enemy.cooldown>0)continue;
    enemy.target=target.index;
    enemy.windup=option(enemy.windupDuration,enemy.boss?.85:.7,.45,1.5);
    if(typeof emit==='function')emit(state,'windup',{enemy:index,actor:target.index,target:target.index,duration:enemy.windup,x:enemy.x,z:enemy.z,yaw:enemy.yaw});
  }
}

export function updateCompanion(state,dt,selectedIndex,{moveActor,command,emit}={}){
  dt=duration(dt);
  if(!dt||state?.phase!=='active'||state.companionAI===false||!Array.isArray(state.players)||!Array.isArray(state.enemies))return;
  const selected=Number.isInteger(selectedIndex)&&selectedIndex>=0&&selectedIndex<state.players.length?selectedIndex:0;
  const controlled=state.players[selected],external=Array.isArray(state.externalPlayers)?state.externalPlayers:[];
  for(let index=0;index<state.players.length;index++){
    const ally=state.players[index];
    if(index===selected||external.includes(index)||!living(ally))continue;
    ally.speed=0;
    const reach=ally.weapon==='staff'?5:2.25;
    const foe=nearest(ally,state.enemies);
    const down=nearest(ally,state.players,(p,i)=>i!==index&&positioned(p)&&p.hp<=0&&!p.dead&&finite(p.down)&&p.down>0);
    const attack=()=>{
      if(!foe||foe.distance>reach||timer(ally.attackCd)>0||typeof command!=='function')return false;
      face(ally,foe.actor);
      if(!command(state,'attack',index))return false;
      // Lead owns all player timer decay. AI only establishes a gentler cadence.
      ally.attackCd=Math.max(timer(ally.attackCd),.9);return true;
    };
    if(down){
      if(down.distance<=2.5&&typeof command==='function'&&command(state,'revive',index))continue;
      if(foe&&foe.distance<=1.85)attack();
      approach(ally,down.actor,2.8,dt,1.7,moveActor);
      continue;
    }
    if(foe&&(state.started||!living(controlled))){
      if(foe.distance<=reach){attack();}
      else approach(ally,foe.actor,2.8,dt,reach*.85,moveActor);
      continue;
    }
    if(living(controlled))approach(ally,controlled,2.8,dt,1.9,moveActor);
  }
}
