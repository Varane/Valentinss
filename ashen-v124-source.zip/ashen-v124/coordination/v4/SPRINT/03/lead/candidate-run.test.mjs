process.env.SPRINT03_AI_CANDIDATE="file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/coordination/v4/SPRINT/03/lead/ai-pursuit-proposal.mjs";
await import("file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/tests/sprint-03-pursuit.test.mjs");
