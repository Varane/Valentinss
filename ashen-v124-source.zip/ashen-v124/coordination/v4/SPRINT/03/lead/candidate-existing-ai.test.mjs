import test from 'node:test';
import assert from 'node:assert/strict';
import {updateEnemies,updateCompanion} from "file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/coordination/v4/SPRINT/03/lead/ai-pursuit-proposal.mjs";

const player=(x=0,z=0,extra={})=>({x,z,yaw:0,hp:100,dead:false,down:0,speed:0,attackCd:0,invuln:.4,weapon:'blade',...extra});
const enemy=(x=0,z=1,extra={})=>({x,z,yaw:0,hp:100,maxHp:100,damage:10,cooldown:0,windup:0,stun:0,attackAnim:0,hurt:0,target:0,speed:0,...extra});
const state=(extra={})=>({phase:'active',started:true,players:[player(),player(3,0)],enemies:[enemy()],events:[],...extra});
function harness(){
  const moves=[],strikes=[],commands=[],events=[];
  return {moves,strikes,commands,events,moveActor:(actor,x,z)=>{assert.ok(Number.isFinite(x)&&Number.isFinite(z));moves.push({actor,x,z});actor.x+=x;actor.z+=z;return actor;},emit:(s,type,data={})=>events.push({type,...data}),strike:(s,index,emit)=>strikes.push(index),command:(s,type,index)=>{commands.push({type,index});return true;}};
}

test('enemy windup locks nearest living target and facing until one exact strike',()=>{
  const a=state(),h=harness();a.enemies[0].yaw=1;
  updateEnemies(a,1/120,h);const e=a.enemies[0],yaw=e.yaw;
  assert.equal(e.target,0);assert.ok(e.windup>=.6&&e.windup<=.8);
  assert.equal(h.events[0].type,'windup');
  a.players[0].x=8;a.players[1].x=0;a.players[1].z=.5;
  updateEnemies(a,.2,h);assert.equal(e.target,0);assert.equal(e.yaw,yaw);assert.equal(h.moves.length,0);
  e.windup=.025;updateEnemies(a,.02,h);assert.equal(h.strikes.length,0);
  updateEnemies(a,.01,h);assert.deepEqual(h.strikes,[0]);assert.equal(e.windup,0);assert.equal(e.attackAnim,.3);
  assert.ok(e.cooldown>=1.3&&e.cooldown<=1.8);updateEnemies(a,.01,h);assert.deepEqual(h.strikes,[0]);
});

test('nearest target ignores dead/down actors and resolves equal distances stably',()=>{
  const a=state({players:[player(-1,0),player(1,0),player(0,.5,{hp:0,down:9})],enemies:[enemy(0,0)]}),h=harness();
  updateEnemies(a,.01,h);assert.equal(a.enemies[0].target,0);
  a.enemies[0].windup=0;a.enemies[0].cooldown=0;a.players[0].dead=true;
  updateEnemies(a,.01,h);assert.equal(a.enemies[0].target,1);
});

test('enemy aggro starts only after the fight starts or a living player is close',()=>{
  const a=state({started:false,players:[player(0,0)],enemies:[enemy(0,4)]}),h=harness();
  updateEnemies(a,.1,h);assert.equal(h.moves.length,0);assert.equal(a.started,false);
  a.enemies[0].z=3.5;updateEnemies(a,.1,h);assert.equal(a.started,true);assert.equal(h.moves.length,1);
  assert.ok(Math.abs(h.moves[0].z+.2)<1e-9);
});

test('stun prevents strikes, pauses committed windup and expires without double ticking players',()=>{
  const a=state({enemies:[enemy(0,1,{windup:.02,stun:.1,hurt:.2,attackAnim:.2,cooldown:.3})]}),h=harness();
  updateEnemies(a,.05,h);const e=a.enemies[0];
  assert.equal(e.stun,.05);assert.equal(e.windup,.02);assert.equal(h.strikes.length,0);
  assert.ok(Math.abs(e.hurt-.15)<1e-9);assert.ok(Math.abs(e.attackAnim-.15)<1e-9);assert.equal(e.cooldown,.25);
  assert.equal(a.players[0].invuln,.4);
  updateEnemies(a,.06,h);assert.ok(e.windup>0);assert.equal(h.strikes.length,0);
  updateEnemies(a,.02,h);assert.equal(h.strikes.length,1);
});

test('a dead or invalid locked target does not crash or silently retarget the strike',()=>{
  const a=state({enemies:[enemy(0,1,{windup:.01,target:500,yaw:2})]}),h=harness();
  updateEnemies(a,.02,h);assert.deepEqual(h.strikes,[0]);assert.equal(a.enemies[0].target,500);assert.equal(a.enemies[0].yaw,2);
});

test('room enemy options are finite, clamped and distinguish boss timing and speed',()=>{
  const a=state({players:[player()],enemies:[enemy(0,4,{boss:true})]}),h=harness();
  updateEnemies(a,.1,h);assert.ok(Math.abs(h.moves[0].z+.16)<1e-9);
  a.enemies[0].z=1;updateEnemies(a,.01,h);assert.equal(a.enemies[0].windup,.85);
  const b=state({enemies:[enemy(0,1,{windupDuration:Infinity,attackCooldown:Infinity,attackRange:NaN,moveSpeed:NaN})]}),j=harness();
  updateEnemies(b,.01,j);assert.equal(b.enemies[0].windup,.7);
  b.enemies[0].windup=.001;updateEnemies(b,.01,j);assert.ok(Number.isFinite(b.enemies[0].cooldown));
  const c=state({enemies:[enemy(0,1,{windupDuration:-100,attackRange:100,attackCooldown:100})]}),k=harness();
  updateEnemies(c,.01,k);assert.ok(c.enemies[0].windup>=.45);
  c.enemies[0].windup=.001;updateEnemies(c,.01,k);assert.ok(c.enemies[0].cooldown<=4);
});

test('enemy corpses only decay visual timers and never strike or move',()=>{
  const a=state({enemies:[enemy(0,1,{hp:0,windup:.01,stun:.1,cooldown:.2,hurt:.2,attackAnim:.2})]}),h=harness();
  updateEnemies(a,.1,h);assert.equal(h.strikes.length,0);assert.equal(h.moves.length,0);assert.equal(a.enemies[0].hurt,.1);
});

test('companion revives a downed controlled hero without requiring the controlled hero to be alive',()=>{
  const a=state({players:[player(0,0,{hp:0,down:6}),player(1,0)]}),h=harness();
  updateCompanion(a,.01,0,h);assert.deepEqual(h.commands,[{type:'revive',index:1}]);assert.equal(h.moves.length,0);
});

test('distant downed controlled hero takes priority over chasing an enemy',()=>{
  const a=state({players:[player(0,0,{hp:0,down:6}),player(5,0)],enemies:[enemy(5,4)]}),h=harness();
  updateCompanion(a,.1,0,h);assert.equal(h.moves.length,1);assert.ok(h.moves[0].x<0);assert.equal(h.moves[0].z,0);assert.equal(h.commands.length,0);
});

test('rescuing companion can defend itself from an immediate enemy without giving up approach',()=>{
  const a=state({players:[player(0,0,{hp:0,down:6}),player(5,0)],enemies:[enemy(5,1)]}),h=harness();
  updateCompanion(a,.1,0,h);assert.deepEqual(h.commands,[{type:'attack',index:1}]);assert.equal(h.moves.length,1);assert.ok(a.players[1].x<5);
});

test('companion continues combat when selected hero is permanently dead',()=>{
  const a=state({players:[player(0,0,{hp:0,dead:true}),player(0,1)],enemies:[enemy(0,2)]}),h=harness();
  updateCompanion(a,.01,0,h);assert.deepEqual(h.commands,[{type:'attack',index:1}]);assert.ok(a.players[1].attackCd>=.75&&a.players[1].attackCd<=1);
});

test('staff companion uses ranged reach and never decrements player attack cooldown',()=>{
  const a=state({players:[player(0,0),player(0,1,{weapon:'staff'})],enemies:[enemy(0,5.5)]}),h=harness();
  updateCompanion(a,.1,0,h);assert.deepEqual(h.commands,[{type:'attack',index:1}]);assert.equal(h.moves.length,0);
  updateCompanion(a,.1,0,h);assert.equal(h.commands.length,1);assert.equal(a.players[1].attackCd,.9);
});

test('companion follows selected hero before combat and approaches enemies after combat starts',()=>{
  const a=state({started:false,players:[player(0,0),player(5,0)],enemies:[enemy(5,4)]}),h=harness();
  updateCompanion(a,.1,0,h);assert.ok(h.moves[0].x<0);assert.equal(h.moves[0].z,0);
  a.started=true;h.moves.length=0;updateCompanion(a,.1,0,h);assert.ok(h.moves[0].z>0);
});

test('explicit companion disable and external player indices preserve human control',()=>{
  for(const options of [{companionAI:false},{externalPlayers:[1]},{externalPlayers:[0,1]}]){
    const a=state(options),before=structuredClone(a.players),h=harness();updateCompanion(a,.1,0,h);
    assert.deepEqual(a.players,before);assert.equal(h.commands.length,0);assert.equal(h.moves.length,0);
  }
  const a=state({externalPlayers:[0],enemies:[enemy(3,1)]}),h=harness();updateCompanion(a,.1,0,h);assert.equal(h.commands[0]?.index,1);
});

test('zero/invalid dt and inactive phase have no gameplay side effects',()=>{
  for(const dt of [0,-1,NaN,Infinity]){
    const a=state(),before=structuredClone(a),h=harness();updateEnemies(a,dt,h);updateCompanion(a,dt,0,h);
    assert.deepEqual(a,before);assert.equal(h.commands.length+h.moves.length+h.strikes.length+h.events.length,0);
  }
  const a=state({phase:'victory'}),before=structuredClone(a),h=harness();updateEnemies(a,.1,h);updateCompanion(a,.1,0,h);assert.deepEqual(a,before);
});

test('malformed actor coordinates are ignored and valid movement stays bounded for huge dt',()=>{
  const a=state({players:[player(0,0),player(NaN,1)],enemies:[enemy(0,100,{moveSpeed:1e100}),enemy(NaN,0)]}),h=harness();
  updateEnemies(a,1e100,h);updateCompanion(a,1e100,0,h);
  assert.equal(h.moves.length,1);assert.ok(Math.hypot(h.moves[0].x,h.moves[0].z)<=4);
  assert.ok(Number.isFinite(a.enemies[0].x)&&Number.isFinite(a.enemies[0].z));
});
