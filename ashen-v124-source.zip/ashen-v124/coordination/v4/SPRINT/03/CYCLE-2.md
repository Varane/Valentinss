# Sprint 03, cycle 2 — exact proposal

Owner A: `dist/combat/ai.mjs`. Executable regression: `node --test tests/sprint-03-pursuit.test.mjs`.

Two deterministic root causes are isolated using actual AI, movement and damage modules, each running 1440 steps of 1/120 s:

1. Unobstructed hero `(0,-1.6)` and enemy `(0,1.6)` converge to distance `1.7500000000000009`. AI checks `distance > 1.75`, but movement discards the roundoff-sized remaining displacement, so the enemy never winds up. A one-centimetre inner stop margin fixes the control: 5 windups within 12 s.
2. Hero and enemy on opposite radial sides of every pillar stall at distance `2.450000001`; collision correctly blocks straight movement, but AI never tries another direction. Range margin alone does not fix this. A deterministic tangent step only when actual movement is below 25% of requested travel fixes all four pillar scenarios: 5 windups each within 12 s.

Minimal exact proposal: `lead/ai-pursuit.patch` (six changed/added lines in two sites). It is NOT applied to owner source. Isolated candidate is `lead/ai-pursuit-proposal.mjs`; `lead/ai-range-proposal.mjs` contains the first change alone as causal evidence. Candidate result from the same actual simulation is 5/5 scenarios passing. Formal Node test rerun is the next gate.

This is deterministic steering, not a full navigation system. Need retain existing AI tests and run these regressions on an owner revision. Browser playability, rendered cue readability and FPS remain unverified.
