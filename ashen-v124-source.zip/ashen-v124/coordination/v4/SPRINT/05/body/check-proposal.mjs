import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {registerHooks} from 'node:module';
import * as THREE from '../../../../../dist/lib/three.module.js';
registerHooks({resolve(s,c,n){return s==='three'?{url:new URL('../../../../../dist/lib/three.module.js',import.meta.url).href,shortCircuit:true}:n(s,c)}});
const source=await readFile(new URL('../../../../../dist/figures.mjs',import.meta.url),'utf8');
const before='ellipsoid(shin,palette.leather,0,-.43,.045,.065,.07,.14);';
const after='ellipsoid(shin,palette.leather,0,-.45,.045,.065,.09,.14);';
assert.equal(source.split(before).length-1,1,'proposal still applies exactly once');
const {makeFigure}=await import('data:text/javascript;base64,'+Buffer.from(source.replace(before,after)).toString('base64'));
const results=[];
for(const female of [false,true])for(const enemy of [false,true])for(const boss of [false,true]){
 const figure=makeFigure({female,enemy,boss,weapon:null,armor:null});figure.root.updateMatrixWorld(true);
 const soles=[];for(const sign of [-1,1]){const knee=figure.joints['knee'+sign];const boot=new THREE.Box3().setFromObject(knee.children[1]);const shin=new THREE.Box3().setFromObject(knee.children[0]);assert.ok(boot.max.y>=shin.min.y,'ankle overlap retained');const y=new THREE.Box3().setFromObject(knee).min.y;assert.ok(Math.abs(y)<1e-6);soles.push(y);}
 figure.root.traverse(o=>assert.ok([...o.matrixWorld.elements].every(Number.isFinite)));
 results.push({female,enemy,boss,soles});
}
console.log(JSON.stringify({passed:results.length,results},null,2));
