# Sprint05 body review — owner action pending

Scope: body/palette proportions, ground alignment, finite transforms; no production edits.

## Reproducible issue

Current public makeFigure still uses the legacy body in dist/figures.mjs. Source lines39-40 place hipY=.94, knee=-.4, boot center=-.43, boot radiusY=.07, giving a boot sole at +.04m rather than floorY=0. Boss scale1.13 yields +.0452m. This is numeric geometry evidence, not visual evidence.

The authored createBody module already fixes this: hip=.94, knee=-.42, boot minimum=-.52 gives soleY≈1.907e-8. Body+face normal height=1.854m, boss with contracted scale1.13=2.09502m. Eight male/female/enemy/boss combinations have finite transforms and +Z toes.

## Exact proposal

public-boot-grounding.patch changes one current legacy line at dist/figures.mjs:40: boot centerY -.43→-.45 and radiusY .07→.09. This preserves the existing boot topY=.18 while lowering the sole from .04 to 0. Owner composition with the existing grounded authored body supersedes the legacy patch and is preferable when ready. Patch check imports a candidate in memory, leaving production files untouched.

## Verification

- node --test tests/sprint-05-body.test.mjs — 3 tests,2 pass,1 fail. Failure: public boot soleY=0.039999999999999925.
- node coordination/v4/SPRINT/05/body/check-proposal.mjs — exit0; all8 option combinations pass soleY≈0, finite transforms and boot/shin contact against the refined exact one-line proposal.
- node coordination/v4/SPRINT/05/body/probe.mjs — exit0; authored body+face measurements saved in cycle-1-output.json.

Tests intentionally exercise current production modules, not snapshots. The public regression must be rerun after the owner's production revision. No visual/FPS/browser/device claims; no full repository suite run for a proposal-only artifact.

A suspected no-palette fallback-material allocation was disproved: black resolves to null through the skin chain. Its test passes. No material patch is proposed.

## Acceptance

Cycle1 evidence complete. Cycle2 first exact proposal complete. Cycle3 reevaluation found that shifting only the boot down4cm would open a1cm ankle gap; the refined proposal now preserves ankle overlap and passes all8 candidate variants. Cycle4 final production check completed: current production still2pass/1fail, so production acceptance is NOT granted. Refined proposal remains8/8 passed; owner action is required. Final raw output is cycle-4-acceptance.json. Latest status.json names the next finite task; reviewed-source-hashes.json identifies measured sources.
