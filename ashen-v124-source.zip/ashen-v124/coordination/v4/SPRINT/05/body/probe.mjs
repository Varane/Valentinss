import {registerHooks} from 'node:module';
import * as THREE from '../../../../../dist/lib/three.module.js';
registerHooks({resolve(s,c,n){return s==='three'?{url:new URL('../../../../../dist/lib/three.module.js',import.meta.url).href,shortCircuit:true}:n(s,c)}});
const {createBody}=await import('../../../../../dist/figures/body.mjs');
const {createPalette}=await import('../../../../../dist/figures/palette.mjs');
const {createFace}=await import('../../../../../dist/figures/face.mjs');
const results=[];
for(const female of [false,true])for(const enemy of [false,true])for(const boss of [false,true]){
 const palette=createPalette({female,enemy,boss});const rig=createBody({female,enemy,boss,materials:palette.materials});const face=createFace(rig.head,{female,enemy,boss,materials:palette.materials});
 if(boss)rig.root.scale.setScalar(1.13);rig.root.updateMatrixWorld(true);
 const box=new THREE.Box3().setFromObject(rig.root);let bad=[];rig.root.traverse(o=>{if(![...o.position,...o.quaternion,...o.scale,...o.matrixWorld.elements].every(Number.isFinite))bad.push(o.name)});
 const skull=rig.root.getObjectByName('face.skull');const y=(1.67+.025)*(boss?1.13:1);const ray=new THREE.Raycaster(new THREE.Vector3(0,y,1),new THREE.Vector3(0,0,-1)); const hits=ray.intersectObject(skull,false);
 results.push({female,enemy,boss,minY:box.min.y,maxY:box.max.y,width:box.max.x-box.min.x,invalid:bad,skullFrontRayZ:hits[0]?.point.z,skullRayHits:hits.length});face.dispose();rig.dispose();palette.dispose();
}
console.log(JSON.stringify(results,null,2));