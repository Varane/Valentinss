# Face geometry — final acceptance

Accepted the current `dist/figures/face.mjs` in this focused audit. No reproducible face defect found; no production patch proposed or applied.

- Source lines: 62–89 skull/head envelope; 104 nose; 108–109 eyes/irises; 143 mouth; 146 hair cap.
- Current source SHA-256: `fb43351bb5c18d8aacb4de493efc303cdf8d6623c98748c2f6aa0aedb4424180` (unchanged during cycles 2–3).
- Command: `node --test tests/sprint-05-face.test.mjs`
- Latest output: exit 0; tests 3; pass 3; fail 0; duration 10244.1228 ms.
- Eight female/enemy/boss variants: finite position/normal data; valid triangle indices; bounded head and intentional hair lengths; +Z-visible irises/nose/mouth with outward front faces; eye/brow/nose/nostril/mouth vertices remain over the skull silhouette.
- Geometry measurements: irises Z=0.0922000, nose Z=0.1419600, mouth Z=0.097999997. Non-hair maximum width is ±0.1299201, local Y range −0.1400001…0.1760000, depth −0.1080001…0.1430001.

Artifacts: cycle-1-evidence.md; cycle-1-metrics.json; cycle-2-proposal.md; cycle-2-tests.txt; cycle-3-reevaluation.md; cycle-3-reverification.txt; tests/sprint-05-face.test.mjs. Patch path: none; the exact no-change decision is cycle-2-proposal.md.

Limit: Node geometry checks only. No browser/server/screenshot/playability assertion. The public makeFigure composition is separately under lead audit; this acceptance does not prove current runtime selection of the face module.
