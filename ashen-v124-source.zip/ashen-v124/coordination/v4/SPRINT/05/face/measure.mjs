import {registerHooks} from 'node:module';
import * as THREE from '../../../../../dist/lib/three.module.js';
registerHooks({resolve(s,c,n){if(s==='three')return {url:new URL('../../../../../dist/lib/three.module.js',import.meta.url).href,shortCircuit:true};return n(s,c)}});
const {createFace}=await import('../../../../../dist/figures/face.mjs');
const metrics=[];
for(const female of [false,true])for(const enemy of [false,true])for(const boss of [false,true]){
 const head=new THREE.Group(),materials=Object.fromEntries(['skin','enemySkin','black','hair','white','iris','mouth'].map(k=>[k,new THREE.MeshStandardMaterial()]));
 const face=createFace(head,{female,enemy,boss,materials}); head.updateMatrixWorld(true);
 const meshes=[];head.traverse(o=>{if(!o.geometry)return;o.geometry.computeBoundingBox();meshes.push({name:o.name,finite:[...o.geometry.attributes.position.array,...o.geometry.attributes.normal.array].every(Number.isFinite),min:o.geometry.boundingBox.min.toArray(),max:o.geometry.boundingBox.max.toArray()})});
 const rays=[];for(const [label,x,y] of [['leftEye',-.045,.022],['rightEye',.045,.022],['nose',0,-.028],['mouth',0,-.072],['skull',0,.07],['hair',0,.16]]){const hits=new THREE.Raycaster(new THREE.Vector3(x,y,1),new THREE.Vector3(0,0,-1),0,2).intersectObject(head,true);rays.push({label,first:hits[0]?.object.name,z:hits[0]?.point.z,normal:hits[0]?.face.normal.toArray(),hits:hits.slice(0,3).map(h=>[h.object.name,h.point.z])})}
 metrics.push({female,enemy,boss,meshes,rays});face.dispose();Object.values(materials).forEach(m=>m.dispose());
}
console.log(JSON.stringify(metrics,null,2));
