# Cycle 1 — face geometry evidence

Command: `node coordination/v4/SPRINT/05/face/measure.mjs`

Eight female/enemy/boss combinations inspected against actual current `dist/figures/face.mjs`. All position and normal values were finite. +Z frontal rays first hit both irises, nose, mouth, forehead and hair cap as expected. Both iris centers project to Z=0.0922000; nose to 0.1419600; mouth to 0.097999997. No actual defect found in these checks. Bounds are recorded per mesh in cycle-1-metrics.json. No browser, screenshot or playability claim.
