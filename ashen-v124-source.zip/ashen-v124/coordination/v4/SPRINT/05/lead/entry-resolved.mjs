import * as T from "file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/dist/lib/three.module.js";
const palette={skin:new T.MeshStandardMaterial({color:'#c3a18d',roughness:.76}),enemySkin:new T.MeshStandardMaterial({color:'#a0988b',roughness:.88}),leather:new T.MeshStandardMaterial({color:'#22262a',roughness:.58}),pants:new T.MeshStandardMaterial({color:'#191e22',roughness:.83}),red:new T.MeshStandardMaterial({color:'#64272b',roughness:.8}),metal:new T.MeshStandardMaterial({color:'#7c8588',metalness:.8,roughness:.35}),darkMetal:new T.MeshStandardMaterial({color:'#363e43',metalness:.7,roughness:.47}),hair:new T.MeshStandardMaterial({color:'#692e22',roughness:.9}),black:new T.MeshStandardMaterial({color:'#141316',roughness:.9}),white:new T.MeshStandardMaterial({color:'#b4b1a5',roughness:.8})};
function object(geo,mat,parent,x=0,y=0,z=0){const m=new T.Mesh(geo,mat);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;parent.add(m);return m;}
function ellipsoid(parent,mat,x,y,z,sx,sy,sz,segments=20){const m=object(new T.SphereGeometry(1,segments,14),mat,parent,x,y,z);m.scale.set(sx,sy,sz);return m;}
function capsule(parent,mat,length,rt,rb,y){return object(new T.CylinderGeometry(rt,rb,length,16),mat,parent,0,y,0);}
function pivot(parent,x,y,z){const g=new T.Group();g.position.set(x,y,z);parent.add(g);return g;}
function bladeGeometry(){const shape=new T.Shape();shape.moveTo(-.034,0);shape.lineTo(-.045,-.54);shape.lineTo(0,-.76);shape.lineTo(.04,-.54);shape.lineTo(.034,0);shape.closePath();return new T.ExtrudeGeometry(shape,{depth:.018,bevelEnabled:true,bevelThickness:.004,bevelSize:.003,bevelSegments:1,steps:1});}
export function weaponModel(id){const g=new T.Group();g.name=id;
  if(id==='staff'){object(new T.CylinderGeometry(.018,.023,1.5,12),palette.darkMetal,g,0,.12,0);const jewel=object(new T.OctahedronGeometry(.065,0),new T.MeshStandardMaterial({color:'#9c424b',emissive:'#a52d3c',emissiveIntensity:.5,roughness:.3}),g,0,.9,0);jewel.rotation.y=.4;return g;}
  object(new T.CylinderGeometry(.022,.022,.16,12),palette.leather,g,0,-.04,0);
  if(id==='cleaver'||id==='reaper'){object(new T.CylinderGeometry(.019,.025,.73,12),palette.black,g,0,-.3,0);const s=new T.Shape();s.moveTo(-.04,-.35);s.lineTo(.24,-.38);s.quadraticCurveTo(.32,-.6,.19,-.75);s.lineTo(-.04,-.66);s.closePath();const b=object(new T.ExtrudeGeometry(s,{depth:.035,bevelEnabled:true,bevelThickness:.006,bevelSize:.008,bevelSegments:1}),palette.metal,g);if(id==='reaper')b.scale.set(1.3,1.1,1);}
  else {object(bladeGeometry(),palette.metal,g,0,-.16,0);const guard=object(new T.BoxGeometry(.21,.026,.04),palette.darkMetal,g,0,-.14,0);guard.rotation.z=.03;}
  return g;
}
export function makeFigure({female=false,enemy=false,boss=false,weapon='blade',armor='cloth'}={}){
  const root=new T.Group(),body=new T.Group();root.add(body);const joints={};const skin=enemy?palette.enemySkin:palette.skin;
  const torsoPoints=(female?[[.105,.98],[.11,1.08],[.085,1.2],[.13,1.34],[.155,1.42],[.09,1.49]]:[[.14,.98],[.145,1.13],[.17,1.3],[.2,1.42],[.16,1.48],[.08,1.51]]).map(([x,y])=>new T.Vector2(x,y));
  const torso=object(new T.LatheGeometry(torsoPoints,28),enemy?palette.darkMetal:palette.leather,body);torso.scale.z=.73;
  const waist=ellipsoid(body,palette.pants,0,.94,0,female?.145:.17,.14,.115);
  const belt=object(new T.CylinderGeometry(female?.12:.155,female?.12:.155,.045,24),palette.black,body,0,1.055,0);belt.scale.z=.78;
  object(new T.BoxGeometry(.045,.036,.016),palette.metal,body,.01,1.055,.118);
  capsule(body,skin,.1,.055,.065,1.53);
  const head=pivot(body,0,1.67,.012);joints.head=head;
  ellipsoid(head,skin,0,.03,0,.119,.165,.115,28);ellipsoid(head,skin,0,-.063,.012,.089,.082,.09);
  ellipsoid(head,skin,0,-.035,.099,.027,.04,.032,14);
  const noseGeo=new T.BufferGeometry();noseGeo.setAttribute('position',new T.Float32BufferAttribute([-.015,.02,.108,.015,.02,.108,0,-.025,.147,-.015,.02,.108,0,-.025,.147,-.016,-.031,.117,.015,.02,.108,.016,-.031,.117,0,-.025,.147],3));noseGeo.computeVertexNormals();object(noseGeo,skin,head);
  for(const sign of [-1,1]){ellipsoid(head,palette.white,sign*.046,.022,.102,.026,.012,.009,14);ellipsoid(head,palette.black,sign*.046,.022,.111,.009,.01,.004,12);const brow=object(new T.BoxGeometry(.052,.009,.01),palette.black,head,sign*.046,.045,.108);brow.rotation.z=sign*.08;ellipsoid(head,skin,sign*.12,0,0,.018,.036,.022,12);}
  const mouth=object(new T.BoxGeometry(.052,.006,.008),new T.MeshStandardMaterial({color:female?'#713d3c':'#79584f',roughness:.8}),head,0,-.062,.097);mouth.rotation.x=-.12;
  if(enemy){const mask=ellipsoid(head,palette.darkMetal,0,-.008,.087,.103,.137,.047);mask.material=palette.darkMetal;for(const sign of [-1,1])object(new T.BoxGeometry(.042,.013,.014),palette.black,head,sign*.046,.023,.133);}
  else {
    const hair=object(new T.SphereGeometry(.127,24,16,Math.PI*.83,Math.PI*1.34,0,Math.PI*.87),female?palette.hair:palette.black,head);hair.scale.set(1,1.38,1.02);
    const crown=object(new T.SphereGeometry(.128,24,12,0,Math.PI*2,0,.85),female?palette.hair:palette.black,head);crown.scale.y=1.4;
    if(female){for(const s of [-1,1]){const lock=ellipsoid(head,palette.hair,s*.105,-.14,-.045,.036,.19,.044,16);lock.rotation.z=s*-.12;}ellipsoid(head,palette.hair,0,-.12,-.09,.1,.18,.036,20);}
  }
  const legs=[],arms=[];
  for(const s of [-1,1]){
    const hip=pivot(body,s*(female?.087:.105),.94,0);joints[`hip${s}`]=hip;legs.push(hip);
    capsule(hip,palette.pants,.4,female?.075:.09,female?.062:.073,-.2);ellipsoid(hip,palette.pants,0,-.4,0,.065,.065,.064);
    const shin=pivot(hip,0,-.4,0);joints[`knee${s}`]=shin;capsule(shin,palette.pants,.38,.062,.043,-.2);
    ellipsoid(shin,palette.leather,0,-.43,.045,.065,.07,.14);
    const shoulder=pivot(body,s*(female?.17:.23),1.42,0);joints[`shoulder${s}`]=shoulder;arms.push(shoulder);shoulder.rotation.z=s*.1;
    ellipsoid(shoulder,palette.leather,0,-.025,0,.075,.092,.078);capsule(shoulder,enemy?skin:palette.leather,.25,.059,.049,-.15);
    const elbow=pivot(shoulder,0,-.29,0);joints[`elbow${s}`]=elbow;ellipsoid(elbow,skin,0,0,0,.044,.049,.044,16);capsule(elbow,enemy?skin:palette.leather,.23,.047,.034,-.13);
    ellipsoid(elbow,palette.black,0,-.27,.005,.037,.051,.031,16);
  }
  const rightHand=pivot(joints['elbow-1'],0,-.28,0); // camera-right weapon hand on the character's left in world coordinates
  const armorGroup=new T.Group();body.add(armorGroup);
  const figure={root,body,joints,arms,legs,head,weapon:null,armorGroup,female,enemy,baseHeight:1.86};
  function setEquipment(weaponId,armorId){
    if(figure.weapon){rightHand.remove(figure.weapon);figure.weapon.traverse(o=>{if(o.geometry)o.geometry.dispose();});}
    figure.weapon=weaponModel(weaponId);rightHand.add(figure.weapon);figure.weaponId=weaponId;
    while(armorGroup.children.length){const m=armorGroup.children[0];armorGroup.remove(m);m.geometry?.dispose();}
    torso.material=armorId==='leather'?palette.red:palette.leather;
    if(armorId==='chain'||armorId==='plate'||enemy){const plate=object(new T.LatheGeometry(torsoPoints,24),armorId==='plate'?palette.metal:palette.darkMetal,armorGroup);plate.scale.set(1.04,1,.79);for(const s of [-1,1]){const shoulder=ellipsoid(armorGroup,armorId==='plate'?palette.metal:palette.darkMetal,s*(female?.17:.23),1.42,0,.09,.07,.1);}}
    figure.armorId=armorId;
  }
  figure.setEquipment=setEquipment;setEquipment(weapon,armor);
  if(boss)root.scale.setScalar(1.13);
  figure.animate=(state,t)=>{
    const speed=state.speed||0,walk=Math.sin(t*10)*Math.min(1,speed)*.65,attack=state.attackAnim>0?Math.sin((1-state.attackAnim/.42)*Math.PI):0;
    body.position.y=speed>0?Math.abs(Math.sin(t*10))*.026:Math.sin(t*1.7)*.006;
    legs[0].rotation.x=walk;legs[1].rotation.x=-walk;
    joints['knee-1'].rotation.x=Math.max(0,-walk)*.5;joints['knee1'].rotation.x=Math.max(0,walk)*.5;
    arms[0].rotation.x=-walk*.4-.12-attack*2.3;arms[0].rotation.z=-.1+attack*.65;
    arms[1].rotation.x=walk*.4-.18-(state.parry>0?1.3:0);arms[1].rotation.z=.1;
    joints['elbow-1'].rotation.x=-.13-attack*.6;joints['elbow1'].rotation.x=-.2-(state.parry>0?.7:0);
    head.rotation.y=Math.sin(t*.9)*.025;root.rotation.z=state.hurt>0?Math.sin(t*55)*.05:0;
    if(state.hp<=0){body.rotation.z=-1.35;body.position.y=-.25;legs.forEach(l=>l.rotation.x=0);}else body.rotation.z=0;
  };
  return figure;
}
