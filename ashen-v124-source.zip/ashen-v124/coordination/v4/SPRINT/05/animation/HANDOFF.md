# Sprint 05 — animation reinforcement handoff

Outcome: one reproducible module defect, exact patch proposed and verified in a separate candidate; production remains unchanged.

In dist/figures/animation.mjs line 109, cleaver adds -2.45rad to the weapon shoulder, then line 131 adds -1.05rad for parry. With the normal -0.1rad resting offset, animate({hp:100,speed:0,attackAnim:.21,parry:.3},0) produces -3.6000000000000005rad (-206.26 degrees). The action parry branch at dist/action.mjs lines 75–78 allows this overlap.

Patch: coordination/v4/SPRINT/05/animation/guard-swing-priority.patch. Exact change at line 129: only layer guard when swing === 0, matching existing windup priority. Source SHA256: 028e0db8a89b1024a3bf6c01a2fd763281165729b9cf1cc6ae47235e54042b6b.

Executable regression: tests/sprint-05-animation.test.mjs (2 tests). It also sweeps idle/run/attack/hurt/down/dead/revival, including huge/invalid times, finite local and world transforms, head anchor, root placement and revival reset.

Production command: node --test tests/figures-animation.test.mjs tests/sprint-05-animation.test.mjs. Fresh result: exit 1, 9 pass, 1 expected fail. See cycle-03-production-reverify.txt.

Candidate command: set SPRINT_05_ANIMATOR_PATH to the absolute animation.candidate.mjs path, then node --test tests/sprint-05-animation.test.mjs coordination/v4/SPRINT/05/animation/candidate-figures-animation.test.mjs. Remove the environment override after the run.

Fresh candidate result: exit 0, 10 pass, 0 fail. See cycle-04-final-candidate.txt. Candidate suite copy changes only import URLs in the existing 8 tests; assertion bodies are unchanged. Candidate equality to current source plus the one-condition replacement was checked before this run.

Boundary: current dist/figures.mjs does not use createAnimator; it still contains its older inline animator. Owner integration is required before describing this as a live game fix. No production edits, browser, server, commit, push or publish. No visual/FPS/playability claim.

Four cycles completed: evidence; minimal proposal; current-source reevaluation; final candidate acceptance. Acceptance covers proposal evidence only; production adoption remains pending.
