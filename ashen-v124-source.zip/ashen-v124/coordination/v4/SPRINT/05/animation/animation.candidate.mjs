const TAU = Math.PI * 2;
const ATTACK_SECONDS = .42;

const numeric = (value, fallback = 0) => typeof value === 'number' && Number.isFinite(value) ? value : fallback;
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
// Reducing the phase before multiplying also keeps Number.MAX_VALUE finite.
const wave = (time, frequency) => Math.sin((time % (TAU / frequency)) * frequency);

function bindTransform(node) {
  return {
    node,
    position: node.position.clone(),
    rotation: node.rotation.clone(),
    scale: node.scale.clone(),
  };
}

function restoreBind(bind) {
  bind.node.position.copy(bind.position);
  bind.node.rotation.copy(bind.rotation);
  bind.node.scale.copy(bind.scale);
}

function rotate(node, x = 0, y = 0, z = 0) {
  if (!node) return;
  node.rotation.x += x;
  node.rotation.y += y;
  node.rotation.z += z;
}

/**
 * Creates a deterministic local-pose animator for the articulated figure rig.
 * The simulation owns actorState and every root transform. Each call starts at
 * the captured bind pose, including after death/revival or an equipment change.
 */
export function createAnimator(figure) {
  const body = figure.body;
  const joints = figure.joints ?? {};
  const head = figure.head ?? joints.head;
  const leftHip = joints['hip-1'];
  const rightHip = joints.hip1;
  const leftKnee = joints['knee-1'];
  const rightKnee = joints.knee1;
  const weaponArm = joints['shoulder-1'];
  const freeArm = joints.shoulder1;
  const weaponElbow = joints['elbow-1'];
  const freeElbow = joints.elbow1;
  const nodes = new Set([body, head, leftHip, rightHip, leftKnee, rightKnee,
    weaponArm, freeArm, weaponElbow, freeElbow]);
  nodes.delete(undefined);
  nodes.delete(null);
  nodes.delete(figure.root);
  const bind = [...nodes].map(bindTransform);

  return function animate(actorState = {}, time = 0) {
    const state = actorState ?? {};
    const t = numeric(time);
    for (const transform of bind) restoreBind(transform);

    const dead = state.dead === true;
    const fallen = dead || numeric(state.down) > 0 || numeric(state.hp, 1) <= 0;
    if (fallen) {
      // Roll the figure around its own floor-level origin. Raising the local
      // body by a palm keeps the sideways torso/head clear of the floor.
      if (body) body.position.y += dead ? .16 : .17;
      rotate(body, dead ? -.06 : -.12, 0, dead ? -1.5 : -1.42);
      rotate(leftHip, -.12, 0, -.06);
      rotate(rightHip, .15, 0, .08);
      rotate(leftKnee, .24);
      rotate(rightKnee, .38);
      rotate(weaponArm, -.35, 0, -.24);
      rotate(freeArm, -.65, 0, .2);
      rotate(weaponElbow, -.4);
      rotate(freeElbow, -.7);
      rotate(head, .08, dead ? -.18 : .1, .08);
      return;
    }

    // speed is the simulation's movement amplitude (.5 enemy, .7 ally, 1
    // walking, 2 dashing), not meters per second or an animation clock.
    const movement = clamp(numeric(state.speed), 0, 1);
    const stride = wave(t, 10) * .5 * movement;
    const lift = Math.abs(wave(t, 10));
    if (body) body.position.y += lift * .025 * movement + wave(t, 1.7) * .004 * (1 - movement);
    rotate(body, movement * .045, 0, wave(t, 10) * .018 * movement);
    rotate(leftHip, stride);
    rotate(rightHip, -stride);
    rotate(leftKnee, Math.max(0, -stride) * .7);
    rotate(rightKnee, Math.max(0, stride) * .7);
    rotate(weaponArm, -.1 - stride * .38);
    rotate(freeArm, -.14 + stride * .38);
    rotate(weaponElbow, -.14);
    rotate(freeElbow, -.18);
    rotate(head, 0, wave(t, .9) * .018);

    const attackLeft = clamp(numeric(state.attackAnim), 0, ATTACK_SECONDS);
    const swing = attackLeft > 0 ? Math.sin((1 - attackLeft / ATTACK_SECONDS) * Math.PI) : 0;
    if (swing > 0) {
      switch (figure.weaponId) {
        case 'staff':
          rotate(body, .12 * swing, -.18 * swing);
          rotate(weaponArm, -1.35 * swing, .18 * swing, .2 * swing);
          rotate(weaponElbow, -.3 * swing);
          rotate(freeArm, -1.1 * swing, -.2 * swing, -.28 * swing);
          rotate(freeElbow, -.6 * swing);
          break;
        case 'cleaver':
          rotate(body, .18 * swing, -.28 * swing);
          rotate(weaponArm, -2.45 * swing, .12 * swing, -.12 * swing);
          rotate(weaponElbow, -.65 * swing);
          rotate(freeArm, -.4 * swing, 0, .2 * swing);
          break;
        case 'reaper':
          rotate(body, .06 * swing, -.64 * swing);
          rotate(weaponArm, -1.7 * swing, .46 * swing, .55 * swing);
          rotate(weaponElbow, -.45 * swing);
          rotate(freeArm, -.85 * swing, -.2 * swing, -.12 * swing);
          rotate(freeElbow, -.5 * swing);
          break;
        default:
          rotate(body, .08 * swing, -.38 * swing);
          rotate(weaponArm, -2.05 * swing, .22 * swing, .46 * swing);
          rotate(weaponElbow, -.5 * swing);
          rotate(freeArm, -.25 * swing, 0, .12 * swing);
      }
      rotate(head, -.06 * swing, .18 * swing);
    }

    if (numeric(state.parry) > 0 && swing === 0) {
      rotate(body, -.06, -.12);
      rotate(weaponArm, -1.05, .2, .28);
      rotate(weaponElbow, -.62);
      rotate(freeArm, -1.15, -.12, -.16);
      rotate(freeElbow, -.78);
      rotate(head, .06);
    }

    const windup = clamp(numeric(state.windup), 0, 1);
    if (windup > 0 && swing === 0) {
      rotate(body, -.06 * windup, .18 * windup);
      rotate(weaponArm, -.6 * windup, -.14 * windup, -.08 * windup);
      rotate(weaponElbow, -.35 * windup);
    }

    const hurt = clamp(numeric(state.hurt) / .26, 0, 1);
    if (hurt > 0) {
      rotate(body, -.12 * hurt, 0, wave(t, 55) * .055 * hurt);
      rotate(head, .1 * hurt, 0, -.06 * hurt);
      rotate(freeArm, -.18 * hurt);
    }
  };
}
