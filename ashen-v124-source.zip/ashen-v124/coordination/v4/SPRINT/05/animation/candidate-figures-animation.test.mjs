import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/dist/lib/three.module.js';

const { createAnimator } = await import('file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/coordination/v4/SPRINT/05/animation/animation.candidate.mjs').catch(error => {
  assert.fail(`createAnimator must be implemented: ${error.message}`);
});

function rig(weaponId = 'blade') {
  const root = new THREE.Group();
  const body = new THREE.Group();
  const joints = {};
  root.add(body);
  body.position.set(.02, .01, -.03);
  body.rotation.set(.01, -.02, .03);
  for (const side of [-1, 1]) {
    const hip = new THREE.Group();
    const knee = new THREE.Group();
    const shoulder = new THREE.Group();
    const elbow = new THREE.Group();
    hip.position.set(side * .1, .94, 0);
    knee.position.y = -.4;
    shoulder.position.set(side * .23, 1.42, 0);
    shoulder.rotation.z = side * .1;
    elbow.position.y = -.29;
    body.add(hip, shoulder);
    hip.add(knee);
    shoulder.add(elbow);
    joints[`hip${side}`] = hip;
    joints[`knee${side}`] = knee;
    joints[`shoulder${side}`] = shoulder;
    joints[`elbow${side}`] = elbow;
  }
  const head = new THREE.Group();
  head.position.set(0, 1.67, .012);
  body.add(head);
  joints.head = head;
  const weaponSocket = new THREE.Group();
  weaponSocket.position.y = -.28;
  joints['elbow-1'].add(weaponSocket);
  root.position.set(4, .25, -3);
  root.rotation.set(.02, 1.2, -.04);
  root.scale.setScalar(1.13);
  return { root, body, head, joints, weaponSocket, weaponId };
}

function transforms(root) {
  const result = [];
  root.traverse(node => result.push([
    ...node.position.toArray(), ...node.rotation.toArray().slice(0, 3),
    ...node.scale.toArray(), ...node.quaternion.toArray(),
  ]));
  return result;
}

function finite(figure) {
  for (const values of transforms(figure.root)) {
    assert.ok(values.every(Number.isFinite), 'every local transform remains finite');
  }
  figure.root.updateMatrixWorld(true);
  figure.root.traverse(node => assert.ok(node.matrixWorld.elements.every(Number.isFinite)));
}

test('animator accepts empty state and invalid numbers without corrupting the rig', () => {
  const figure = rig();
  const animate = createAnimator(figure);
  for (const state of [undefined, null, {}, { hp: 100 }, {
    speed: NaN, attackAnim: Infinity, parry: -Infinity, hurt: 'bad', hp: NaN,
  }, {
    speed: Number.MAX_VALUE, attackAnim: .2, parry: 1, hurt: .1, hp: 100,
  }, { speed: Symbol('bad'), attackAnim: {}, down: NaN, dead: false }]) {
    for (const time of [undefined, NaN, Infinity, -Infinity, Number.MAX_VALUE, -1, .2]) {
      assert.doesNotThrow(() => animate(state, time));
      finite(figure);
    }
  }
});

test('animation leaves actor state and root placement untouched', () => {
  const figure = rig();
  const rootBefore = transforms(figure.root)[0];
  const actor = Object.freeze({ x: 8, z: -9, yaw: 2, speed: .8, hp: 100, attackAnim: .2, hurt: .1 });
  const actorBefore = { ...actor };
  const animate = createAnimator(figure);
  animate(actor, .6);
  animate(Object.freeze({ hp: 0, dead: true }), .9);
  assert.deepEqual(actor, actorBefore);
  assert.deepEqual(transforms(figure.root)[0], rootBefore);
});

test('walking amplitude follows simulation speed and stops on idle', () => {
  const figure = rig();
  const animate = createAnimator(figure);
  animate({ hp: 100, speed: 0 }, .16);
  const stopped = figure.joints['hip-1'].rotation.x;
  animate({ hp: 100, speed: .2 }, .16);
  const slow = Math.abs(figure.joints['hip-1'].rotation.x - stopped);
  animate({ hp: 100, speed: .8 }, .16);
  const fast = Math.abs(figure.joints['hip-1'].rotation.x - stopped);
  assert.ok(slow > 0);
  assert.ok(fast > slow * 3, 'speed changes stride size rather than merely enabling walking');
  animate({ hp: 100, speed: 0 }, .16);
  assert.equal(figure.joints['hip-1'].rotation.x, stopped);
});

test('repeating a frame never accumulates local offsets', () => {
  const figure = rig();
  const animate = createAnimator(figure);
  const state = { hp: 100, speed: .7, attackAnim: .21, parry: .2, hurt: .2 };
  animate(state, .23);
  const expected = transforms(figure.root);
  for (let i = 0; i < 300; i++) animate(state, .23);
  assert.deepEqual(transforms(figure.root), expected);
});

test('revival recovers the exact idle pose including bind transforms', () => {
  const figure = rig();
  const animate = createAnimator(figure);
  animate({ hp: 100 }, 0);
  const idle = transforms(figure.root);
  animate({ hp: 0, down: 5, hurt: .2 }, .3);
  assert.notDeepEqual(transforms(figure.root), idle);
  finite(figure);
  animate({ hp: 0, down: 0, dead: true }, .6);
  assert.notDeepEqual(transforms(figure.root), idle);
  finite(figure);
  animate({ hp: 40, down: 0, dead: false }, 0);
  assert.deepEqual(transforms(figure.root), idle);
  assert.equal(figure.joints['shoulder-1'].rotation.z, -.1);
  assert.equal(figure.body.position.x, .02);
  assert.equal(figure.body.position.z, -.03);
});

test('guard and hurt produce local poses which clear on the next neutral frame', () => {
  const figure = rig();
  const animate = createAnimator(figure);
  animate({ hp: 100 }, .25);
  const idle = transforms(figure.root);
  animate({ hp: 100, parry: .3 }, .25);
  const guard = transforms(figure.root);
  assert.notDeepEqual(guard, idle);
  animate({ hp: 100, hurt: .2 }, .25);
  assert.notDeepEqual(transforms(figure.root), idle);
  assert.notDeepEqual(transforms(figure.root), guard);
  animate({ hp: 100 }, .25);
  assert.deepEqual(transforms(figure.root), idle);
});

test('equipment changes select distinct attack poses without recreating the animator', () => {
  const figure = rig();
  const animate = createAnimator(figure);
  const poses = [];
  for (const id of ['blade', 'cleaver', 'staff', 'reaper']) {
    figure.weaponId = id;
    animate({ hp: 100, attackAnim: .21 }, .3);
    finite(figure);
    poses.push(JSON.stringify(transforms(figure.root)));
  }
  assert.equal(new Set(poses).size, 4);
  figure.weaponId = null;
  assert.doesNotThrow(() => animate({ hp: 100, attackAnim: .2 }, .3));
  finite(figure);
});

test('animator instances never share a pose or alter the weapon socket bind', () => {
  const first = rig();
  const second = rig();
  const animateFirst = createAnimator(first);
  const animateSecond = createAnimator(second);
  animateSecond({}, 0);
  const secondIdle = transforms(second.root);
  const socketBind = [...first.weaponSocket.position.toArray(), ...first.weaponSocket.rotation.toArray()];
  animateFirst({ hp: 0, dead: true }, 4);
  assert.deepEqual(transforms(second.root), secondIdle);
  assert.deepEqual([...first.weaponSocket.position.toArray(), ...first.weaponSocket.rotation.toArray()], socketBind);
});
