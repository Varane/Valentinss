# Cycle 2 — minimal exact patch proposal

Source: `dist/figures/animation.mjs` SHA256 `028e0db8a89b1024a3bf6c01a2fd763281165729b9cf1cc6ae47235e54042b6b`, line 129.

Change `if (numeric(state.parry) > 0) {` to `if (numeric(state.parry) > 0 && swing === 0) {`. This chooses the active swing articulation over the guard articulation; after the active swing, guard works as before. It follows the existing windup precedence at line 139 and does not alter simulation or actor state.

Patch: `guard-swing-priority.patch`. Standalone source snapshot: `animation.candidate.mjs`. Production source was not edited.

Verification: set `SPRINT_05_ANIMATOR_PATH` to the absolute candidate path; run `node --test tests/sprint-05-animation.test.mjs coordination/v4/SPRINT/05/animation/candidate-figures-animation.test.mjs`. Candidate test copy only replaces import URLs in the existing 8-test suite; no assertion changes. Result: exit 0, 10 pass, 0 fail; full output `cycle-02-candidate-green.txt`.

Regression risk: while a swing pose is active, parry no longer adds raised-arm pose; combat parry remains live. This is a local pose-priority choice for the production owner to accept. No visual claim.
