# Cycle 1 — reproducible overlapping joint pose

Observed 2026-11-11T21:39Z against `dist/figures/animation.mjs` SHA256 `028e0db8a89b1024a3bf6c01a2fd763281165729b9cf1cc6ae47235e54042b6b`.

`animate({hp:100,speed:0,attackAnim:.21,parry:.3},0)` produces weapon shoulder local X rotation `-3.6000000000000005` rad (206.26 degrees). Single cleaver swing is `-.1 - 2.45 = -2.55`; the guard adds another `-1.05`, driving the arm beyond the forward overhead arc and behind the torso. Both states are reachable because `dist/action.mjs` lines 75–78 permits parry when stamina/parryCd/dash allow, and does not clear attackAnim.

`node --test tests/figures-animation.test.mjs`: 8 pass, 0 fail (baseline).
`node --test tests/sprint-05-animation.test.mjs`: 1 pass, 1 expected failure, exit 1. Full output in `cycle-01-red.txt`.

The state-transition sweep covering idle/run/attack/hurt/down/dead/revival passed finite local/world transforms, unchanged head anchor and root placement. No visual, frame rate or playability validation was performed.
