# Gate 2 — current evidence and finite next step

No defensive-input implementation patch is justified yet: createInput callbacks visibly route the same dash/parry strings through runtime perform to command. The executable three-case tests exercise this boundary but cannot currently import the real simulation. Reproduction command: node --test tests/sprint-02-input.test.mjs. Result exit 1 before tests: rules.mjs imports missing dist/campaign/save.mjs.

Minimal fix belongs to C: supply the already-declared campaign/save.mjs module exporting sanitizeCampaign with its intended save semantics; removing the import would hide unfinished save compatibility. Team 02 does not propose replacing persistence with a dummy.

Next finite task: re-read file existence once child findings arrive and rerun the real three-case integration suite. The dash candidate is independently owned by dash worker.
