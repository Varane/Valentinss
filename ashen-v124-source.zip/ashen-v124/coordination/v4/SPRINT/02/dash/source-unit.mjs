import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {normalizeInput, moveActor} from '../../../../../dist/combat/movement.mjs';
const folder = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(folder, '../../../../..');
const source = await fs.readFile(path.join(repo, 'dist/action.mjs'), 'utf8');
const anchor = '  if(dashTime>0){\n    const direction=normalizeInput({x:player.dx,z:player.dz});';
const insertion = '  if(dashTime>0){\n    if(player.dash===.22&&magnitude>.05){player.dx=vector.x/magnitude;player.dz=vector.z/magnitude;player.yaw=Math.atan2(vector.x,vector.z);}\n    const direction=normalizeInput({x:player.dx,z:player.dz});';
function load(text) {
  const finite = text.match(/^const finite=.*;$/m)[0];
  const emit = text.slice(text.indexOf('function emit('), text.indexOf('\nfunction makeEnemy('));
  const command = text.slice(text.indexOf('export function command('), text.indexOf('\nfunction movePlayer(')).replace(/^export /, '');
  const move = text.slice(text.indexOf('function movePlayer('), text.indexOf('\nfunction finish('));
  return new Function('normalizeInput', 'moveActor', finite + '\n' + emit + '\n' + command + '\n' + move + '\nreturn {command,movePlayer};')(normalizeInput, moveActor);
}
const near = (a, b) => assert.ok(Math.abs(a-b) <= 2e-7, a + ' != ' + b);
function fixture() {
  const p = {x:0,z:0,yaw:Math.PI,dx:0,dz:-1,hp:100,dead:false,down:0,stamina:100,invuln:0,dash:0,parry:0,speed:0};
  return {p, state:{phase:'active',players:[p],enemies:[],events:[],time:0,eventSeq:0}};
}
const cases = [
  ['zero input default heading', (api) => {const {p,state}=fixture();api.command(state,'dash',0);api.movePlayer(p,.05,{});near(p.x,0);near(p.z,-.7);}],
  ['same-frame cardinal and yaw', (api) => {const {p,state}=fixture();api.command(state,'dash',0);api.movePlayer(p,.05,{x:1,z:0});near(p.x,.7);near(p.z,0);near(p.yaw,Math.PI/2);}],
  ['same-frame diagonal distance and yaw', (api) => {const {p,state}=fixture();api.command(state,'dash',0);api.movePlayer(p,.05,{x:1,z:1});near(p.x,.7*Math.SQRT1_2);near(p.z,.7*Math.SQRT1_2);near(Math.hypot(p.x,p.z),.7);near(p.yaw,Math.PI/4);}],
  ['remembered diagonal normalized', (api) => {const {p,state}=fixture();Object.assign(p,{dx:1,dz:1,yaw:Math.PI/4});api.command(state,'dash',0);api.movePlayer(p,.05,{});near(p.x,.7*Math.SQRT1_2);near(p.z,.7*Math.SQRT1_2);}],
  ['later input cannot steer', (api) => {const {p,state}=fixture();api.command(state,'dash',0);api.movePlayer(p,.05,{x:1,z:0});p.dash-=.05;api.movePlayer(p,.05,{x:-1,z:0});near(p.x,1.4);near(p.z,0);near(p.yaw,Math.PI/2);}],
  ['all four arena walls', (api) => {for(const [x,z,dx,dz,ex,ez] of [[5.9,0,1,0,6,0],[-5.9,0,-1,0,-6,0],[0,4.9,0,1,0,5],[0,-4.9,0,-1,0,-5]]){const {p,state}=fixture();Object.assign(p,{x,z,dx,dz,yaw:Math.atan2(dx,dz)});api.command(state,'dash',0);api.movePlayer(p,.22,{});near(p.x,ex);near(p.z,ez);}}],
  ['four pillars eight radial approaches', (api) => {for(const [px,pz] of [[-4,-2.5],[4,-2.5],[-4,3],[4,3]])for(let i=0;i<8;i++){const a=i*Math.PI/4,dx=Math.cos(a),dz=Math.sin(a),{p,state}=fixture();Object.assign(p,{x:px-dx*1.3,z:pz-dz*1.3,dx,dz,yaw:Math.atan2(dx,dz)});api.command(state,'dash',0);api.movePlayer(p,.22,{});near(p.x,px-dx*.85);near(p.z,pz-dz*.85);}}],
  ['zero-input start remains locked', (api) => {const {p,state}=fixture();api.command(state,'dash',0);api.movePlayer(p,.05,{});p.dash-=.05;api.movePlayer(p,.05,{x:1,z:0});near(p.x,0);near(p.z,-1.4);}],
];
const records = [];
const proposalNeeded=source.includes(anchor)&&!source.includes('if(player.dashFresh){');
for(const [label,text] of [['current',source],['candidate',proposalNeeded?source.replace(anchor,insertion):source]]) {
  const api=load(text), results=[];
  for(const [name,check] of cases)try{check(api);results.push({name,pass:true});}catch(error){results.push({name,pass:false,error:error.message});}
  records.push({label,pass:results.filter(r=>r.pass).length,fail:results.filter(r=>!r.pass).length,results});
}
const record={time:new Date().toISOString(),command:'node coordination/v4/SPRINT/02/dash/source-unit.mjs',actionSha256:createHash('sha256').update(source).digest('hex'),movementSha256:createHash('sha256').update(await fs.readFile(path.join(repo,'dist/combat/movement.mjs'))).digest('hex'),boundary:'Executes actual extracted command, emit and movePlayer functions with actual imported movement module. Plain actor fixtures; no rule, AI, step, or full-encounter integration claim. Timer decrement between calls models documented step ordering.',patchApplies:proposalNeeded,ownerAlreadyCapturesDashInput:!proposalNeeded,records};
await fs.writeFile(path.join(folder,'gate3-source-unit.json'),JSON.stringify(record,null,2)+'\n');
console.log(JSON.stringify(record));
if(records[1].fail)process.exitCode=1;
