import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
const folder = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(folder, '../../../../..');
const source = await fs.readFile(path.join(repo, 'dist/action.mjs'), 'utf8');
const sha256 = createHash('sha256').update(source).digest('hex');
const anchor = '  if(dashTime>0){\n    const direction=normalizeInput({x:player.dx,z:player.dz});';
const insertion = '  if(dashTime>0){\n    if(player.dash===.22&&magnitude>.05){player.dx=vector.x/magnitude;player.dz=vector.z/magnitude;player.yaw=Math.atan2(vector.x,vector.z);}\n    const direction=normalizeInput({x:player.dx,z:player.dz});';
const candidateSource = source.includes(anchor) && !source.includes('if(player.dashFresh){') ? source.replace(anchor, insertion) : source;
const candidate = path.join(folder, 'action-candidate.mjs');
await fs.writeFile(candidate, candidateSource.replaceAll("from './", "from '../../../../../dist/"));
const checks = [
  {name: 'gate3-current', args: ['--test', 'tests/sprint-02-dash.test.mjs']},
  {name: 'gate3-candidate', args: ['--test', 'tests/sprint-02-dash.test.mjs'], env: {ASHEN_DASH_ACTION_URL: pathToFileURL(candidate).href}},
  {name: 'gate3-movement', args: ['--test', 'tests/action-movement.test.mjs']},
];
for (const check of checks) {
  const result = spawnSync(process.execPath, check.args, {cwd: repo, encoding: 'utf8', env: {...process.env, ...check.env}, timeout: 30000});
  const record = {time: new Date().toISOString(), actionSha256: sha256, command: 'node ' + check.args.join(' '), ...(check.env ? {env: check.env} : {}), exitCode: result.status, stdout: result.stdout, stderr: result.stderr, error: result.error?.message};
  await fs.writeFile(path.join(folder, check.name + '.json'), JSON.stringify(record, null, 2) + '\n');
  const status = JSON.parse(await fs.readFile(path.join(folder, 'status.json'), 'utf8'));
  Object.assign(status, {updatedAt: record.time, gate: 3, percent: 75, state: 'reevaluation_saved', artifact: check.name + '.json', check: record.command, result: 'exit ' + record.exitCode, next: 'Review all gate3 results and write bounded acceptance/handoff by 21:43 UTC.'});
  await fs.writeFile(path.join(folder, 'status.json'), JSON.stringify(status, null, 2) + '\n');
  console.log(JSON.stringify(record));
}
