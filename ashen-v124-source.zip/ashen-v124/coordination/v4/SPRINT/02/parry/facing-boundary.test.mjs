import test from 'node:test';import assert from 'node:assert/strict';import {resolveEnemyStrike} from '../../../../../dist/combat/damage.mjs';
const emit=(s,type,data)=>s.events.push({type,...data});
function s(){return{players:[{x:0,z:0,yaw:0,hp:100,maxHp:100,stamina:80,defense:0,parry:.1,invuln:0}],enemies:[{x:0,z:1,yaw:Math.PI,hp:100,damage:17,target:0}],events:[]};}
test('current damage module accepts exactly sixty degrees and rejects just beyond, both sides',()=>{for(const side of [-1,1])for(const delta of [0,.0001]){const a=s();a.players[0].yaw=side*(Math.PI/3+delta);assert.equal(resolveEnemyStrike(a,0,emit),true);assert.equal(a.events.at(-1).type,delta===0?'parry':'hurt');}});
test('current damage module gives 2.3 second riposte and 1.4 second stun on frontal parry',()=>{const a=s();resolveEnemyStrike(a,0,emit);assert.equal(a.players[0].riposte,2.3);assert.equal(a.enemies[0].stun,1.4);assert.equal(a.players[0].hp,100);});
