# Gate 2 — exact implementation proposal

No patch proposed. Current dist/combat/damage.mjs and dist/combat/skills.mjs passed direct boundaries. The action-level 300 ms cutoff, cooldown expiry and riposte consumption checks are saved in tests/sprint-02-parry.test.mjs, but current dist/rules.mjs imports absent dist/campaign/save.mjs. This prevents dynamic verification through the public action API.

Static observation only: dist/action.mjs currently invokes updateEnemies before decreasing PLAYER_TIMERS. A 301 ms strike may therefore see a positive pre-slice parry timer, extending the 300 ms window by up to one simulation slice. No patch is proposed without a successful actual-module reproduction. No implementation stub or copy was used.
