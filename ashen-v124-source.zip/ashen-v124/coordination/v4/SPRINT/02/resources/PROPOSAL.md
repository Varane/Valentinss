# Resource and action-gating proposal

Gate 2 at 2026-11-11T21:38:48.801Z. **No production patch proposed.**

The current finite encounter-state contract has the required resource checks in dist/action.mjs: dash requires stamina >= 25 and no active dash; parry requires stamina >= 12, no active dash and no positive parry cooldown. Their costs are subtracted only after acceptance. command rejects non-active phase and dead/down/zero-HP actors before branching. Dash clears an active parry while retaining parry cooldown.

Actual dist/combat/damage.mjs tests confirm invulnerability takes precedence over simultaneous parry without stamina refund, stun or riposte, and a successful parry adds 18 stamina with a cap of 100.

The full command verification is pending the owning team's absent dist/campaign/save.mjs dependency. A real import is used in tests/sprint-02-resources.test.mjs; nothing is stubbed. Current result: 2 helper tests pass; 1 action group fails on ERR_MODULE_NOT_FOUND before command tests execute. This does not prove the command cases pass.

No source changes are requested based on blocked tests. Once the dependency exists, rerun node --test tests/sprint-02-resources.test.mjs. If a behavioral assertion fails, send that exact failure to the action owner.

Scope excludes spatial correctness, parry timing/facing, browser behavior and FPS. Non-finite externally injected actor resources are outside this finite valid-state proposal; attackSpec already validates them, defensive command branches do not. No reachable finite-state underflow has been demonstrated.
