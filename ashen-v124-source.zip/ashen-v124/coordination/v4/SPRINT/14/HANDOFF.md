# Team14 — final death/save acceptance

Updated 2026-11-11T22:04:00.028Z. Exactly3 subagents plus lead (4 actual workers), original IDs retained; tool reset interruption resumed same IDs at22:00UTC. Initial5min report sent.21:45 target missed after interruption; bounded stop22:05UTC.

## Final result
Owners restored all campaign dependencies and revised production boot and restoreSave. Lead independently reran all4 team14 files: **26 passed,1 failed,0 skipped,0 TODO (27 total)**. Exact output: final-all.txt. Production files were never edited by team14. This is Node/module and extracted-source runtime evidence, not browser/iPhone/playability/FPS evidence.

    node --test tests/sprint-14-runtime.test.mjs tests/sprint-14-death.test.mjs tests/sprint-14-save.test.mjs tests/sprint-14-campaign.test.mjs

## Four gates
1. Reproduced terminal save boot failures (defeat/complete/camp), fractional timer .25->0 then hp0->1, and actual missing module imports. Historical source/log artifacts retained.
2. Delivered exact boot patch runtime-terminal-save.patch and save/fractional-down.patch, without production mutation.
3. In-memory boot proposal4/4 passed; isolated exact rules red4/1 and green5/0. Re-evaluation then observed actual owner revision: module closure restored; actual boot restarts terminal campaigns; actual rules preserve fractional rescue time.
4. Removed resolved runtime TODO markers and verified current final production against all27 assertions. The remaining45s timer contract case fails; module acceptance is incomplete; no release/playability acceptance asserted.

## Final source evidence
- dist/action-game.mjs SHA256 2bfc3301d378b27858992da8b91026056b0ca013dc874b787a816f2ce67e13a7
- dist/rules.mjs SHA256 90e1814ae4afa9188eb2969d84bcf7c41e94af2250688e567bc56202aca7d756
- Owner boot guard: typeof campaign !== undefined, terminal status invokes existing restartCampaign and saves before spawnRoom.
- Owner down normalization preserves finite fractions within0..30; action permits0..60, but actual gameplay default9 and tested.25/8.75 remain unchanged. Final save worker added45s case: action accepts0..60 but restoreSave clamps45 to30. This is a lower-priority range contract mismatch; ordinary9s rescue and fractions.25/8.75 are fixed. Existing exact save proposal uses max60.

## Checks
Runtime active/defeat/complete/camp boot4/4; actual damage/rescue/native action10/10; native restore/malformed/equipment/final-death/timer6/7; native campaign death/replay/reward/exit/restart6/6. Native campaign checks ensure earned progression persists and rewards cannot repeat across reload or stale callbacks.

## Ownership and limits
Root integrated runtime, Direction C integrated rules/helpers. Team14 wrote only coordination/v4/SPRINT/14 and tests/sprint-14*.test.mjs. Browser4173 and publication remained root-owned. No commit/push/publish/server launch. Exact agent start/stop data are in status.json and available subfolders.

Automatic approval review rejected a repeated update to source chat (destination/disclosure authorization) and campaign agent's later artifact update (repository write authorization). No rejected action was retried or routed through another tool. Existing tests and read-only final verification provide the handoff; campaign agent's rejected final artifact remains unavailable.

Final rerun after worker added native action cases and45s boundary:27 total,26 pass,1 fail. No tests were removed to hide failure. Current unresolved owner action: decide0..60 timer contract and align restoreSave or action; changing Math.min(30,saved.down) to Math.min(60,saved.down) matches the current encounter contract.
