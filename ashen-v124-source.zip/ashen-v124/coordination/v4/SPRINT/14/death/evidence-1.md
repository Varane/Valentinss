# Cycle 1: actual source and execution evidence

Actual start: 2026-11-11 21:38:43 UTC. Read coordination/v4/MASTER.md and C STATUS/HANDOFF. Production files are read-only for this worker.

Read rules.mjs, action.mjs and combat/damage.mjs. The turn-based final-death helper clears hp/down/equipment while retaining XP and skills. Action rescue excludes final-dead players and expiry dispatches one death event. The action constructor preserves finite fractional rescue timers up to 60 seconds.

Actual Node v24.11.1 probe importing rules.mjs and action.mjs exited 1 before execution: ERR_MODULE_NOT_FOUND for dist/campaign/save.mjs imported by rules.mjs. Read of dist/campaign/progression.mjs also failed because it does not exist at this checkpoint.

Candidate defect from actual source, not yet executable: restoreSave uses integer helper num(saved.down,0,1,0). A .4-second remaining rescue window becomes zero. Its following hp expression then clamps saved HP 0 to 1. This changes downed into alive on load. A remaining 8.75-second window is also shortened to 1 second. The proposal will preserve finite action timers with action.mjs's 0..60 bound.

No browser/server, production writes, commits or publishing performed.
