# Reinforcement 14 — death/down/rescue QA final handoff

Actual start: 2026-11-11T21:38:43Z. Actual stop: 2026-11-11T22:04:19.115Z. No production edits, browser/server use, commits, pushes, publishing, or further agents.

Four finite gates persisted: evidence (25%), proposal (50%), current-owner re-evaluation (75%), final handoff (100%). Gate snapshots are gate-1.json through gate-4.json. The first executable import failed on missing campaign/save.mjs; the current owner supplied campaign/save.mjs and progression.mjs, and native imports subsequently succeeded. The target 21:45 handoff was missed during the interrupted tool/update interval; final stop remains before 22:05.

## Verified result

Command: node --test tests/sprint-14-death.test.mjs

Actual Node v24.11.1 result: 10 tests, 10 passed, 0 failed, 0 skipped, exit 0. Exact output: test-output.txt.

Seven cases import the actual standalone combat/damage.mjs. Three cases import native rules.mjs and action.mjs after the missing owner dependencies appeared. No module stubs, VM extraction, or copied production functions are used.

Confirmed: lethal damage opens down=9 without final death; fractional remaining rescue time works; rescue returns 35%/70% HP with protection; timer expiry emits one final death; final-dead rescues reject atomically; downed rescuers cannot rescue; 2.5m boundary; native action expiry; native party wipe creates exactly two deaths and one defeat; native rescue preserves profile independence.

No reproducible action death/down/revive defect found in these cases. No production action patch is proposed.

## Candidate handed to save owner

Initial source restoreSave floored remaining down time through num(saved.down,0,1,0). This could turn .4 into zero and HP zero into one, or 8.75 into one. Parent assigned this to save agent; timer-proposal.patch is an EXACT STRING replacement proposal, not an apply-ready unified diff and not an executed action fix. Its current applicability and save coverage belong to that owner; do not claim this candidate reproduced by this worker. Initial import failure prevented its probe from running.

## Source revision evidence

SHA256 and mtimes for rules/action/damage/campaign dependencies and the focused test are source-hashes.json. Action SHA256: fcfaab8c9fee7d4ef3fe19fcf9ba5f2a10b45deb3dc474ee0b4dc6b1095d7dda. Damage SHA256: cce372bba8aad96830b38b9b650711bd3e925e6f9d589836170d070631cd70d7. Rules SHA256: 90e1814ae4afa9188eb2969d84bcf7c41e94af2250688e567bc56202aca7d756. These are shared-checkout byte hashes, not a Git commit.

## Limits

No browser, rendering, network, end-to-end persistence or full game suite was run by this worker. Gear/XP after final death is owned by rules/campaign/save/runtime and is not inferred from damage actor tests. All writes stayed under coordination/v4/SPRINT/14/death/** and tests/sprint-14-death.test.mjs.

Next finite owner task: integrate/run this focused test alongside current rules/action/campaign suites; independently verify the save-agent timer disposition. This worker is stopped.
