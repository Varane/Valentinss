# Gate 2

Parent reassigned restoreSave validation to the save agent. timer-proposal.patch is only a candidate, handed to parent; it is not an action defect claim.

Seven tests now import the actual standalone combat/damage.mjs. No source copying or dependency stubs. They cover downing, fractional deadline rescue, 35/70 percent HP, final-death expiry, one-time death, atomic rejection, and range boundary. No production action patch is proposed without a demonstrated defect.
