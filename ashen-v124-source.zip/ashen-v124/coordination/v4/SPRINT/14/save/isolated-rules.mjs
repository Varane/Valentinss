// Diagnostic snapshot: exact rules.mjs logic; missing imports supplied from existing balance audit baseline.
const ITEMS={"blade":{"id":"blade","slot":"weapon","icon":"sword","attack":18},"cleaver":{"id":"cleaver","slot":"weapon","icon":"axe","attack":26},"staff":{"id":"staff","slot":"weapon","icon":"flame","attack":22},"reaper":{"id":"reaper","slot":"weapon","icon":"axe","attack":35},"cloth":{"id":"cloth","slot":"armor","icon":"armor","defense":1},"leather":{"id":"leather","slot":"armor","icon":"armor","defense":4},"chain":{"id":"chain","slot":"armor","icon":"armor","defense":7},"plate":{"id":"plate","slot":"armor","icon":"armor","defense":10},"rune2h":{"id":"rune2h","slot":"weapon","icon":"sword","attack":30},"rune_boots":{"id":"rune_boots","slot":"boots","icon":"armor","defense":2}};
const SKILLS=[{"id":"blood1","branch":"blood","icon":"drop","requires":null},{"id":"blood2","branch":"blood","icon":"heart","requires":"blood1"},{"id":"blood3","branch":"blood","icon":"axe","requires":"blood2"},{"id":"guard1","branch":"guard","icon":"armor","requires":null},{"id":"guard2","branch":"guard","icon":"shield","requires":"guard1"},{"id":"guard3","branch":"guard","icon":"revive","requires":"guard2"},{"id":"arcane1","branch":"arcane","icon":"flame","requires":null},{"id":"arcane2","branch":"arcane","icon":"bolt","requires":"arcane1"},{"id":"arcane3","branch":"arcane","icon":"skull","requires":"arcane2"}];
const BRANCHES=[];
const sanitizeCampaign=()=>null;
const restartProfile=()=>{throw Error("outside diagnostic scope");};
export {ITEMS,SKILLS,BRANCHES};
export const ROOM_NAMES=['Костяной порог','Разделочный зал','Часовня голода','Забытые цепи','Преддверие казни','Трон мясника'];
export function level(h){return 1+Math.floor(h.xp/100);}
export function stats(h){const has=id=>h.skills.includes(id);return {attack:(ITEMS[h.weapon]?.attack||12)+(level(h)-1)*2,defense:(ITEMS[h.armor]?.defense||0)+(ITEMS[h.boots]?.defense||0)+(has('guard2')?3:0),maxHp:(h.id==='knight'?100:85)+(level(h)-1)*5+(has('guard1')?20:0),maxMana:6+(has('arcane1')?3:0)};}
function enemy(room){return {name:room===6?'Архимясник':room>3?'Костолом':'Могильный палач',hp:105+room*15,max:105+room*15,attack:13+room*3};}
function hero(id,name,weapon){const h={id,name,xp:0,points:2,skills:[],bag:[weapon,...['blade','cleaver','staff','cloth','leather'].filter(x=>x!==weapon)],weapon,armor:'cloth',boots:null,hp:100,mana:6,potions:2,dead:false,down:0};h.hp=stats(h).maxHp;return h;}
export function createGame(){return {version:2,room:1,phase:'battle',started:false,turn:0,heroes:[hero('knight','Грим','blade'),hero('mage','Векса','staff')],enemy:enemy(1),gold:0,kills:0,log:['Порог склепа пройден. Не теряйте голову. Буквально.'],events:[],seq:0};}
function clone(s){const n=structuredClone(s);n.events=[];n.seq++;return n;}
function log(s,msg){s.log.unshift(msg);s.log=s.log.slice(0,24);}
function event(s,type,data={}){s.events.push({type,...data});}
function safe(s){return s.phase!=='battle'||!s.started;}
function requireSafe(s){if(!safe(s))throw Error('Меняйте снаряжение и навыки до боя или между комнатами.');}
function requireHero(s,i){const h=s.heroes[i];if(!h)throw Error('Герой не найден');if(h.dead)throw Error('Герой погиб. Начните новый поход.');return h;}
export function equip(state,i,id){const s=clone(state);requireSafe(s);const h=requireHero(s,i);if(typeof id!=='string'||!Object.hasOwn(ITEMS,id)||!h.bag.includes(id))throw Error('Этот предмет отсутствует в рюкзаке.');h[ITEMS[id].slot]=id;event(s,'equip',{hero:i});return s;}
export function learn(state,i,id){const s=clone(state);requireSafe(s);const h=requireHero(s,i),skill=SKILLS.find(x=>x.id===id);if(!skill)throw Error('Навык не найден');if(h.skills.includes(id))throw Error('Этот навык уже изучен.');if(skill.requires&&!h.skills.includes(skill.requires))throw Error('Сначала изучите предыдущий навык в этой ветке.');if(h.points<1)throw Error('Не хватает очков навыков. Повышайте уровень.');const old=stats(h);h.skills.push(id);h.points--;const updated=stats(h);h.hp+=updated.maxHp-old.maxHp;h.mana+=updated.maxMana-old.maxMana;event(s,'learn',{hero:i,id});log(s,`${h.name}: изучен навык «${skill.name}».`);return s;}
function die(s,i){const h=s.heroes[i];if(h.dead)return;h.dead=true;h.down=0;h.hp=0;h.bag=[];h.weapon=null;h.armor=null;h.boots=null;log(s,`${h.name} погиб. Вещи потеряны. Опыт и навыки сохранены.`);event(s,'death',{hero:i});}
function award(s){s.phase='cleared';s.kills++;const reward=45+s.room*15;const drops=['chain','cleaver','staff','plate','reaper','plate'];
  for(let i=0;i<s.heroes.length;i++){const h=s.heroes[i];if(h.dead)continue;const oldLevel=level(h),before=stats(h);h.xp+=reward;const gained=level(h)-oldLevel;h.points+=gained;if(gained){h.hp+=stats(h).maxHp-before.maxHp;event(s,'level',{hero:i,level:level(h)});}const item=drops[(s.room-1+i)%drops.length];if(!h.bag.includes(item))h.bag.push(item);h.mana=Math.min(stats(h).maxMana,h.mana+2);if(h.down){h.down=0;h.hp=Math.ceil(stats(h).maxHp*.35);}event(s,'loot',{hero:i,item,xp:reward});}
  s.gold+=20+s.room*10;log(s,`Комната очищена! +${reward} опыта. Добыча в рюкзаке.`);event(s,'victory');
}
export function act(state,type){if(state.phase!=='battle')throw Error('Бой уже завершён.');const s=clone(state);const h=requireHero(s,s.turn);if(h.hp<=0)throw Error('Герой не может действовать.');const st=stats(h),source=s.turn;const has=id=>h.skills.includes(id);let damage=0,guard=false;
  if(type==='attack'||type==='special'){
    if(type==='special'){if(!has('blood3')&&!has('arcane2'))throw Error('Изучите «Кровавый вихрь» или «Алый разряд» в дереве навыков.');if(h.mana<3)throw Error('Не хватает маны. Обычные атаки восстанавливают её.');h.mana-=3;}
    else h.mana=Math.min(st.maxMana,h.mana+(has('arcane3')?2:1));
    damage=Math.round(st.attack*(type==='special'?1.8:1))+(has('blood1')?4:0);s.enemy.hp=Math.max(0,s.enemy.hp-damage);event(s,'hit',{source,target:'enemy',amount:damage,special:type==='special',magic:h.weapon==='staff'});log(s,`${h.name}: ${type==='special'?'особый удар':'атака'} — ${damage} урона.`);
    if(has('blood2'))h.hp=Math.min(st.maxHp,h.hp+Math.ceil(damage*.2));
  }else if(type==='defend'){guard=true;h.mana=Math.min(st.maxMana,h.mana+2);event(s,'guard',{hero:source});log(s,`${h.name} встаёт в защиту и восстанавливает 2 маны.`);}
  else if(type==='potion'){if(h.potions<1)throw Error('Зелья закончились.');if(h.hp>=st.maxHp)throw Error('Здоровье уже полное.');h.potions--;h.hp=Math.min(st.maxHp,h.hp+45);event(s,'heal',{hero:source});log(s,`${h.name} выпивает зелье: +45 здоровья.`);}
  else if(type==='revive'){const target=s.heroes.findIndex(x=>x.hp===0&&x.down>0&&!x.dead);if(target<0)throw Error('Нет товарища, которого можно спасти.');const ally=s.heroes[target];ally.down=0;ally.hp=Math.ceil(stats(ally).maxHp*(has('guard3')?.7:.35));event(s,'revive',{hero:target});log(s,`${h.name} спасает ${ally.name}.`);}
  else throw Error('Неизвестное действие.');
  s.started=true;
  if(s.enemy.hp<=0){award(s);return s;}
  const incoming=Math.max(1,Math.round((s.enemy.attack-st.defense)*(guard?.3:1)));h.hp=Math.max(0,h.hp-incoming);event(s,'hurt',{hero:source,amount:incoming});log(s,`${s.enemy.name}: ${incoming} урона по ${h.name}.`);if(h.hp===0){h.down=2;log(s,`${h.name} повержен. Спасите его следующим ходом!`);}
  const living=s.heroes.filter(x=>x.hp>0&&!x.dead);
  if(!living.length){s.heroes.forEach((_,i)=>die(s,i));s.phase='defeat';event(s,'defeat');return s;}
  s.heroes.forEach((p,i)=>{if(p.down>0){p.down--;if(p.down===0)die(s,i);}});
  const next=(s.turn+1)%2;s.turn=s.heroes[next].hp>0&&!s.heroes[next].dead?next:s.turn;
  return s;
}
export function retreat(state){if(state.phase!=='cleared')throw Error('Выйти можно только после победы в комнате.');const s=clone(state);s.phase='camp';log(s,'Вы вернулись в лагерь. Вся добыча сохранена.');return s;}
export function advance(state){const s=clone(state);if(s.phase==='battle')throw Error('Сначала закончите бой.');if(s.phase==='cleared'&&s.room<6){s.room++;for(const h of s.heroes)if(!h.dead){h.hp=Math.min(stats(h).maxHp,h.hp+15);h.mana=stats(h).maxMana;}}
  else {s.room=1;s.heroes=restartProfile(s).heroes;}
  s.enemy=enemy(s.room);s.phase='battle';s.started=false;s.turn=s.heroes[0].dead?1:0;event(s,'room');log(s,`Комната ${s.room}: ${ROOM_NAMES[s.room-1]}.`);return s;
}
export function restoreSave(raw){try{
  const v=typeof raw==='string'?JSON.parse(raw):raw;if(!v||v.version!==2||!Array.isArray(v.heroes)||v.heroes.length!==2)return createGame();
  const s=createGame(),num=(x,min,max,fallback)=>Number.isFinite(x)?Math.max(min,Math.min(max,Math.floor(x))):fallback;
  s.room=num(v.room,1,6,1);s.phase=['battle','cleared','camp','defeat'].includes(v.phase)?v.phase:'battle';s.started=!!v.started;s.turn=num(v.turn,0,1,0);s.gold=num(v.gold,0,1e7,0);s.kills=num(v.kills,0,1e6,0);s.seq=num(v.seq,0,1e9,0);
  s.heroes=s.heroes.map((base,i)=>{const saved=v.heroes[i];if(!saved||typeof saved!=='object')throw Error();const h={...base};h.xp=num(saved.xp,0,1e6,0);h.skills=[];for(const skill of SKILLS)if(Array.isArray(saved.skills)&&saved.skills.includes(skill.id)&&(!skill.requires||h.skills.includes(skill.requires)))h.skills.push(skill.id);h.points=num(saved.points,0,Math.max(0,2+level(h)-1-h.skills.length),0);h.bag=Array.isArray(saved.bag)?[...new Set(saved.bag.filter(x=>typeof x==='string'&&Object.hasOwn(ITEMS,x)))]:[];h.weapon=h.bag.includes(saved.weapon)&&ITEMS[saved.weapon]?.slot==='weapon'?saved.weapon:null;h.armor=h.bag.includes(saved.armor)&&ITEMS[saved.armor]?.slot==='armor'?saved.armor:null;h.boots=h.bag.includes(saved.boots)&&ITEMS[saved.boots]?.slot==='boots'?saved.boots:null;h.dead=!!saved.dead;h.down=h.dead?0:num(saved.down,0,1,0);h.hp=h.dead||h.down?0:num(saved.hp,1,stats(h).maxHp,stats(h).maxHp);h.mana=num(saved.mana,0,stats(h).maxMana,6);h.potions=num(saved.potions,0,2,0);if(h.dead){h.bag=[];h.weapon=h.armor=h.boots=null;}return h;});
  s.enemy=enemy(s.room);s.enemy.hp=num(v.enemy?.hp,0,s.enemy.max,s.enemy.max);if(s.phase==='battle'&&s.enemy.hp===0)s.phase='cleared';if(s.phase==='battle'){const live=s.heroes.findIndex(h=>h.hp>0&&!h.dead);if(live<0)s.phase='defeat';else if(s.heroes[s.turn].hp<=0||s.heroes[s.turn].dead)s.turn=live;}
  s.log=Array.isArray(v.log)?v.log.filter(x=>typeof x==='string').map(x=>x.slice(0,200)).slice(0,24):s.log;
  // Optional campaign damage must not discard a valid legacy hero save.
  try {const property=Object.getOwnPropertyDescriptor(v,'campaign');const campaign=sanitizeCampaign(property&&'value' in property?property.value:null);if(campaign)s.campaign=campaign;}catch{}
  return s;
}catch{return createGame();}}
