# Team14 save QA final handoff

Stopped: 2026-11-11T22:04:53.432Z. Production files were read only for this agent. Four gates recorded in evidence-01.json, proposal-02.json, reverify-03.json, acceptance-04.json; status.json is final (100% task handoff, not full game acceptance).

## Result

The original real issue is fixed by the owner: down:0.25,hp:0 no longer restores down:0,hp:1; down:8.75 also persists. Native tests verify both. The remaining failing test is a low-priority contract mismatch: action encounter explicitly accepts rescue timers0..60, while current restoreSave caps at30. A synthetic accepted down:45 saves/loads as30. Normal gameplay starts at9 seconds, so that path is unaffected.

Current dist/rules.mjs SHA256: 90e1814ae4afa9188eb2969d84bcf7c41e94af2250688e567bc56202aca7d756.
Initial failing source SHA256: 5ab5e3fedb19f7b356bc03e629dee923528ff37024ad0598f0352cd9db028372.

## Exact proposal

fractional-down.patch is against the current owner source at line52: replace Math.min(30,saved.down) with Math.min(60,saved.down). proposed-rules-native.mjs copies current source with that single behavior change and rewrites relative imports to actual production module URLs. No production changes were made. fractional-down-original.patch preserves the original integer-flooring fix proposal; isolated-rules.mjs is historical diagnostic evidence only.

## Verification

- node --test tests/sprint-14-save.test.mjs: current production6 pass /1 fail (45-second range case, actual30).
- With SPRINT14_RULES_MODULE set to the file URL of proposed-rules-native.mjs, the same focused tests:7 pass /0 fail, exit0.
- node --test tests/rules.test.mjs tests/rules.progression.test.mjs tests/runtime.test.mjs:23 pass /0 fail, exit0.
- Earlier initial source native regression:4 pass /2 fail (.25=>0 and8.75=>1). Initially imports were unavailable because owner helper files were missing; final native runs succeeded after their arrival.
- An intermediate legacy run was18 pass /2 fail (starter gear restart cases); owner subsequently changed the source and the fresh23-test run above passed.

Seven focused tests cover legacy XP/points/gear roundtrip, malformed saves, unknown or wrong-slot equipment, final death progression retention with gear loss, and timers. No browser/server, commit, push, publication or external messaging was used.

## Acceptance / next owner action

The original fractional timer issue is accepted and verified fixed. The45-second test intentionally remains red as a transparent accepted-range contract mismatch. Owner may apply fractional-down.patch and rerun the focused command. No more tests or production work are pending from this agent. Full application acceptance was outside this scope.
