# Cycle1 — terminal save reload

Source action-game SHA256: a20c83be848dbfaa5f0e262a726a1eafc8a00d60027647544748b006a2360fbb
Source campaign SHA256: 480f753185f6f0730a7a49c9d15a33d25d90d82ec95058a9180fb9827a031b86

Actual boot calls spawnRoom unconditionally. Actual prepareEncounter rejects campaign.status !== active. Saved defeat, complete and camp states are restored and passed directly to this call. This evidence is a source-function VM reproduction, not browser evidence. Full module imports are presently blocked by missing campaign dependencies.
