# Sprint 10 progress

Four actual workers started. Lead keyboard regression plus existing input DOM suite: 9 passed / 0 failed.

Two reproducible edge bugs now documented by scoped workers: (1) pointer-held strike remains held if button becomes disabled, (2) pending asynchronous restart can close a newly opened Rooms menu when restart resolves. Tests and exact minimal patch proposals are being saved under touch_release/ and modal_buttons/.

Safe-area worker calculating explicit 320x568 / 568x320 constraints. Browser4173 remains root-owned; no visual/playability/FPS claim. Main implementation untouched. Final handoff target 21:45 UTC.
