# Gate 1 — source geometry

Actual start: 2026-11-11 21:37:33 UTC. Read MASTER.md and D/HANDOFF.md, HANDOFF_D1.md, HANDOFF_D4.md. No implementation writes, browser, server, commits or publication.

Evidence is calculated CSS border boxes, not rendered geometry. CSS uses border-box globally; index has viewport-fit=cover and three normal-flow combat buttons in order dash/strike/parry, plus absolutely positioned special.

320×568, synthetic safe insets top44/right0/bottom34/left0: joystick [12,407,112,507]; dash [134,458,182,506]; strike [189,442,253,506]; parry [260,458,308,506]; special [204,370,252,418]. Minimum joystick-to-dash horizontal gap22px. Normal action gaps7px. Special-to-strike vertical gap24px. All boxes are inside safe bounds [0,44,320,534], all action dimensions≥44px.

568×320, synthetic safe insets top0/right44/bottom21/left44: joystick [58,180,158,280]; dash [308,224,364,280]; strike [373,208,445,280]; parry [454,224,510,280]; special [394,146,442,194]. Minimum joystick-to-dash horizontal gap150px. Normal action gaps9px. Special-to-strike vertical gap14px. All boxes are inside safe bounds [44,0,524,299], all action dimensions≥44px.

These inset values are explicit test assumptions, not device measurements. Arbitrarily large horizontal insets can exhaust available width; no arbitrary-inset support is claimed. Native font metrics, layout, pointer hit testing, header/wrapped labels and real iOS orientation remain browser/device work.
