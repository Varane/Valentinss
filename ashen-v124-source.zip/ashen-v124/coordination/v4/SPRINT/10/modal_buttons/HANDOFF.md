# Sprint 10 modal button acceptance

Actual worker start: 2026-11-11T21:38:52.430Z. Actual stop: 2026-11-11T21:43:59.753Z. No implementation writes, browser/server use, commits or spawned workers.

## Result

Current implementation: 2/4 regression cases pass, 2 fail. Proposed owned candidate: 4/4 pass. Exact owner patch is OWNER-PATCH.diff; it uses zero-context hunks (apply with git apply --unidiff-zero, or copy the six small edits). dist/ui/overlay.mjs needs no change for this reproduced defect.

The existing duplicate-pending-restart guard works; cancel plus repeated close balances pause exactly once and restores opener focus. Destroy during pending restart prevents late completion and duplicate resume.

Latent async-callback contract defect: restart pending → cancel/close → reopen rooms → old restart resolves. It closes the newer menu and emits an unowned resume. A separate case proves an old restart hides a newer outcome. Existing createUI explicitly supports Promise callbacks. Current root action-game.mjs wires a synchronous function restart(), so this async race is not an observed current-release user break.

## Owner action

Increment viewRevision when opening a view, finishing overlay closure, or showing an outcome. Capture it at restart invocation; only close/hide/update on successful completion when that revision is still current. Keep restarting true until the callback settles. Candidate verifies both stale-success paths and existing pause/focus balance.

## Evidence and limits

- tests/sprint-10-modal.test.mjs is an ordinary executable failing regression against current source. Run node --test tests/sprint-10-modal.test.mjs.
- gate-1.tap, gate-3-current.tap, gate-3-candidate.tap, gate-3-evidence.json record actual runs.
- Real UI import was retried at gate 3; missing dist/campaign/save.mjs still blocks import through rules.mjs. real-import-check.txt records it. This is a separate environmental issue. Test visibly uses registerHooks to supply only unrelated RPG data exports; it executes actual UI, overlay, HUD and menu lifecycle code. It does not validate campaign/rules behavior. Remove the fixture dependency hook when that environmental import is restored and use the real createGame fixture.
- owner-candidate-ui.mjs and candidate-test.mjs are separate review artifacts under this worker folder; implementation stayed unchanged. Candidate imports point to real dist/ui dependencies.
- Node fixture models asynchronous dialog close events. No browser layout, physical touch or iPhone focus behavior claimed.

Current UI SHA256: 7f354bc0fc306783095d94382beee8430bdc40b550b326afd448a66b0fa4bc4b. Source unchanged since evidence capture: true.
