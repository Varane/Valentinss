Reproduced bug: delayed successful restart closes a newer menu and hides a newer outcome. Existing restarting flag only prevents concurrent callback invocation.

Exact minimal owner patch: OWNER-PATCH.diff. Add viewRevision increment on open, close callback and showOutcome. Capture revision before invoking restart; apply completion effects only for the captured view revision. overlay.mjs requires no change.

The missing campaign/save.mjs environmental import is separate. tests/sprint-10-modal.test.mjs transparently fixtures unrelated rules data exports using registerHooks; every UI/overlay lifecycle function is the real implementation. No campaign behavior is tested.
