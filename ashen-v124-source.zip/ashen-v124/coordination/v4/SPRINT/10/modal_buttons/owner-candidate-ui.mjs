import {createHUD} from 'file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/dist/ui/hud.mjs';
import {createSkills} from 'file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/dist/ui/skills.mjs';
import {createEquipment} from 'file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/dist/ui/equipment.mjs';
import {createOverlay,createPauseContent,createRoomContent} from 'file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/dist/ui/overlay.mjs';

const MENU_TYPES={gear:'gear',inventory:'gear',equipment:'gear',skills:'skills',talents:'skills',pause:'pause',menu:'pause',rooms:'rooms',room:'rooms',coop:'rooms'};
const TITLES={gear:'Снаряжение',skills:'Созвездия навыков',pause:'Передохнуть',rooms:'Комната на двоих'};

/** UI is a view over root-owned state. Call update from the existing game loop. */
export function createUI(options={}){
  const {
    getProfile=()=>null,getEncounter=()=>null,getSelected=()=>0,
    selectHero=()=>{},onEquip=()=>{},onLearn=()=>{},onRestart=()=>{},
    onCamera=()=>{},onPause=()=>{}
  }=options;
  const doc=globalThis.document;
  if(!doc)throw new Error('Для игрового интерфейса нужен document.');
  const byId=id=>doc.getElementById(id);
  const dialog=byId('overlay');
  if(!dialog)throw new Error('Не найден диалог #overlay.');
  const hud=createHUD({getProfile,getSelected});
  const listeners=[];
  let destroyed=false,paused=false,currentType=null,profileKey='',network=options.network??null;
  let lastEncounter=null,lastSelected=null,restarting=false,viewRevision=0;
  const roots={gear:doc.createElement('div'),skills:doc.createElement('div')};
  const notice=text=>{if(!destroyed)hud.notice(String(text??''));};
  const selected=()=>{
    const heroes=getProfile()?.heroes??[];
    const index=Number(getSelected());
    return Number.isInteger(index)&&index>=0&&index<heroes.length?index:0;
  };
  const report=error=>notice(error instanceof Error?error.message:String(error||'Действие не выполнено.'));
  function setPaused(value){
    if(paused===value)return;
    paused=value;
    try{onPause(value);}catch(error){report(error);}
  }
  function bind(node,type,handler){
    if(!node)return;
    node.addEventListener(type,handler);
    listeners.push(()=>node.removeEventListener(type,handler));
  }
  // Preserve synchronous callbacks while also consuming asynchronous failures.
  function invoke(callback,args=[],after=refresh){
    if(destroyed)return false;
    const finish=result=>{if(result!==false&&!destroyed)after();return result;};
    try{
      const result=callback(...args);
      if(result&&typeof result.then==='function')return Promise.resolve(result).then(finish,error=>{report(error);return false;});
      return finish(result);
    }catch(error){report(error);return false;}
  }
  const skills=createSkills({root:roots.skills,getProfile,getSelected:selected,onLearn:(...args)=>invoke(onLearn,args),notice});
  const equipment=createEquipment({root:roots.gear,getProfile,getSelected:selected,onEquip:(...args)=>invoke(onEquip,args),notice});
  const overlay=createOverlay({root:dialog,onOpen:()=>setPaused(true),onClose:()=>{
    viewRevision++;
    currentType=null;
    profileKey='';
    const selector=byId('hero-selector');
    if(selector)selector.hidden=true;
    setPaused(false);
  }});
  function networkCall(method,...args){
    if(!network||typeof network[method]!=='function'){
      notice('Сетевая комната недоступна: сервер не подключён.');
      return false;
    }
    return invoke(network[method].bind(network),args,()=>{rooms.render();});
  }
  const rooms=createRoomContent({
    getNetwork:()=>network,
    onCreate:()=>networkCall('create',{profile:getProfile()}),
    onJoin:code=>networkCall('join',code),
    onLeave:()=>networkCall('leave'),notice
  });
  const pauseContent=createPauseContent({onResume:()=>close(),onRestart:()=>restart(),onRooms:()=>open('rooms')});

  function renderSelector(){
    const selector=byId('hero-selector');
    if(!selector)return;
    const forHero=currentType==='gear'||currentType==='skills';
    selector.hidden=!forHero;
    if(!forHero)return;
    const profile=getProfile();
    const index=selected();
    const buttons=(profile?.heroes??[]).map((hero,i)=>{
      const button=doc.createElement('button');
      button.type='button';
      button.textContent=hero.name||`Герой ${i+1}`;
      button.classList.toggle('active',i===index);
      button.setAttribute('aria-pressed',String(i===index));
      button.addEventListener('click',()=>invoke(selectHero,[i]));
      return button;
    });
    selector.replaceChildren(...buttons);
    const kicker=byId('overlay-kicker');
    if(kicker)kicker.textContent=currentType==='gear'?'ТОЛЬКО ВЕЩИ ИЗ ВАШЕГО РЮКЗАКА':'КРОВЬ · СТАЛЬ · БЕЗДНА';
  }
  function stateKey(){
    const profile=getProfile();
    let connection='';
    if(currentType==='rooms'){
      try{
        const s=network?.getState?.();
        connection=JSON.stringify([s?.status,s?.available,s?.connected,s?.roomCode,s?.code,s?.room?.code,s?.error,s?.snapshot?.revision,s?.snapshot?.players?.length]);
      }catch{connection='unavailable';}
    }
    return JSON.stringify([selected(),profile?.phase,profile?.started,(profile?.heroes??[]).map(h=>[h.id,h.name,h.xp,h.points,h.skills,h.bag,h.weapon,h.armor,h.dead,h.down]),connection]);
  }
  function refresh(force=true){
    if(destroyed||!currentType)return;
    const key=stateKey();
    if(!force&&key===profileKey)return;
    profileKey=key;
    renderSelector();
    if(currentType==='gear')equipment.render();
    else if(currentType==='skills')skills.render();
    else if(currentType==='rooms')rooms.render();
  }
  function open(type){
    if(destroyed)return false;
    const next=MENU_TYPES[type];
    if(!next)return false;
    viewRevision++;
    currentType=next;
    const content=next==='gear'?roots.gear:next==='skills'?roots.skills:next==='rooms'?rooms.element:pauseContent;
    const kicker=byId('overlay-kicker');
    if(kicker)kicker.textContent=next==='rooms'?'СОВМЕСТНЫЙ ПОХОД':next==='pause'?'КРОВОСКЛЕП':'';
    refresh();
    overlay.open({title:TITLES[next],content,returnFocus:doc.activeElement});
    return true;
  }
  function close(){if(!destroyed)overlay.close();}
  function switchHero(){
    const profile=getProfile();
    const heroes=profile?.heroes??[];
    if(heroes.length<2)return;
    const current=selected();
    const encounter=lastEncounter??getEncounter();
    let next=(current+1)%heroes.length;
    for(let offset=1;offset<=heroes.length;offset++){
      const i=(current+offset)%heroes.length;
      const actor=encounter?.players?.[i];
      if(!heroes[i].dead&&!actor?.dead&&!actor?.down&&(actor?.hp??heroes[i].hp)>0){next=i;break;}
    }
    invoke(selectHero,[next]);
  }
  function restart(){
    if(destroyed||restarting)return false;
    restarting=true;
    const revision=viewRevision;
    const finish=result=>{
      restarting=false;
      if(result!==false&&!destroyed&&revision===viewRevision){
        overlay.close();
        const outcome=byId('outcome');
        if(outcome)outcome.hidden=true;
        if(lastEncounter)hud.update(lastEncounter,selected());
      }
      return result;
    };
    const result=invoke(onRestart,[],()=>{});
    if(result&&typeof result.then==='function')return result.then(finish);
    return finish(result);
  }
  for(const [id,type] of [['inventory','gear'],['talents','skills'],['pause','pause'],['rooms','rooms'],['after-gear','gear']])bind(byId(id),'click',()=>open(type));
  bind(byId('camera'),'click',()=>invoke(onCamera,[],()=>{}));
  bind(byId('switch-hero'),'click',switchHero);
  bind(byId('ally'),'click',switchHero);
  bind(byId('restart'),'click',restart);

  return {
    update(encounter,heroIndex){
      if(destroyed)return;
      lastEncounter=encounter??getEncounter();
      lastSelected=Number.isInteger(heroIndex)?heroIndex:selected();
      hud.update(lastEncounter,lastSelected);
      refresh(false);
    },
    notice,
    showOutcome(outcome){if(!destroyed){viewRevision++;overlay.close();hud.showOutcome(outcome);}},
    open,isOpen:()=>!destroyed&&overlay.isOpen(),close,
    setNetwork(client){if(destroyed)return;network=client??null;if(currentType==='rooms')refresh();},
    destroy(){
      if(destroyed)return;
      destroyed=true;
      for(const unsubscribe of listeners)unsubscribe();
      overlay.destroy();
      setPaused(false);
      skills.destroy();equipment.destroy();rooms.destroy();hud.destroy();
    }
  };
}
