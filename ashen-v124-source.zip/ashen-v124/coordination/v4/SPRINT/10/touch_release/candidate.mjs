import {createControlState, joystickVector} from "file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/dist/ui/input/state.mjs";

const movement = new Set(['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowLeft','ArrowDown','ArrowRight']);
const actions = new Map([['Space','attack'],['ShiftLeft','dash'],['ShiftRight','dash'],['KeyE','parry'],['KeyR','special'],['KeyF','revive']]);
const menus = new Map([['KeyI','gear'],['KeyK','skills'],['Escape','pause']]);
const noop = () => {};

function editable(element) {
  if (!element) return false;
  if (element.isContentEditable || ['INPUT','TEXTAREA','SELECT'].includes(element.tagName)) return true;
  return Boolean(element.closest?.('input, textarea, select, [contenteditable]:not([contenteditable="false"]), [role="textbox"]'));
}

/** Keyboard and combat pointers only; menu clicks belong to createUI. */
export function createInput({canvas,onAction=noop,onMenu=noop,onSwitch=noop,onCamera=noop} = {}) {
  const document = canvas?.ownerDocument || globalThis.document;
  const window = document?.defaultView || globalThis.window;
  const state = createControlState();
  const heldKeys = new Set();
  const pointers = new Map();
  const removers = [];
  const controls = new Map();
  const joystick = document?.getElementById('joystick');
  const stick = document?.getElementById('stick');
  let stickPointer = null;
  let destroyed = false;

  for (const [id,type] of [['strike','attack'],['dash','dash'],['parry','parry'],['special','special'],['rescue-hint','revive'],['revive','revive']]) {
    const element = document?.getElementById(id);
    if (element) controls.set(element,type);
  }
  function listen(target,type,callback,options) {
    if (!target?.addEventListener) return;
    target.addEventListener(type,callback,options);
    removers.push(() => target.removeEventListener(type,callback,options));
  }
  function blocked(event) {
    return destroyed || Boolean(document?.hidden || document?.visibilityState === 'hidden'
      || document?.querySelector('dialog[open]')
      || editable(event?.composedPath?.()[0] || event?.target)
      || editable(document?.activeElement));
  }
  function consume(event) { if (event.cancelable !== false) event.preventDefault?.(); }
  function paint() {
    for (const [element,type] of controls) {
      const pressed = type === 'attack' ? state.attackHeld() : [...pointers.values()].some(p => p.element === element);
      element.classList?.toggle('is-pressed',pressed);
    }
  }
  function releaseCapture(element,id) {
    try { if (element.hasPointerCapture?.(id)) element.releasePointerCapture(id); } catch { /* The browser may already have released it. */ }
  }
  function clear() {
    const captures = [...pointers.entries()];
    pointers.clear();
    stickPointer = null;
    heldKeys.clear();
    state.clear();
    if (stick) stick.style.transform = 'translate(0px, 0px)';
    joystick?.classList?.remove('is-active');
    paint();
    for (const [id,pointer] of captures) releaseCapture(pointer.element,id);
  }
  function canPlay(event) {
    if (blocked(event)) { clear(); return false; }
    for (const [pointerId,{element}] of pointers) {
      if (element.disabled) pointerup({pointerId});
    }
    return true;
  }
  function keydown(event) {
    const code = event.code;
    const known = movement.has(code) || actions.has(code) || menus.has(code) || code === 'KeyQ' || code === 'KeyC';
    if (!known) return;
    if (!canPlay(event)) return;
    // Space belongs to native button activation while a control has keyboard focus.
    if (code === 'Space' && (event.target?.tagName === 'BUTTON' || document?.activeElement?.tagName === 'BUTTON')) {
      clear();
      return;
    }
    if (event.ctrlKey || event.metaKey || event.altKey || event.isComposing) { clear(); return; }
    consume(event);
    if (movement.has(code)) { state.setKey(code,true); heldKeys.add(code); return; }
    if (event.repeat || heldKeys.has(code)) return;
    heldKeys.add(code);
    if (actions.has(code)) {
      if (code === 'Space') state.setKey(code,true);
      paint();
      onAction(actions.get(code));
    } else if (menus.has(code)) {
      clear();
      onMenu(menus.get(code));
    } else if (code === 'KeyQ') onSwitch();
    else if (code === 'KeyC') onCamera();
  }
  function keyup(event) {
    const wasHeld = heldKeys.delete(event.code);
    state.setKey(event.code,false);
    paint();
    if (wasHeld && !blocked(event)) consume(event);
  }
  function capture(element,id) {
    try { element.setPointerCapture?.(id); } catch { /* Global pointerup still clears the pointer. */ }
  }
  function moveStick(event) {
    const rect = joystick.getBoundingClientRect();
    const radius = Math.max(1, Math.min(rect.width,rect.height) * .36);
    const vector = joystickVector(event.clientX - rect.left - rect.width / 2,event.clientY - rect.top - rect.height / 2,radius);
    state.setStick(vector.x,vector.z);
    if (stick) stick.style.transform = `translate(${vector.x * radius}px, ${vector.z * radius}px)`;
  }
  function startStick(event) {
    if (event.button > 0 || event.pointerId == null || !canPlay(event) || stickPointer !== null) return;
    consume(event);
    stickPointer = event.pointerId;
    pointers.set(event.pointerId,{element:joystick,type:'move'});
    capture(joystick,event.pointerId);
    joystick.classList?.add('is-active');
    moveStick(event);
  }
  function startAction(element,type,event) {
    if (event.button > 0 || event.pointerId == null || element.disabled || !canPlay(event) || pointers.has(event.pointerId)) return;
    consume(event);
    pointers.set(event.pointerId,{element,type});
    if (type === 'attack') state.setAttack(`pointer:${event.pointerId}`,true);
    capture(element,event.pointerId);
    paint();
    onAction(type);
  }
  function pointermove(event) {
    if (event.pointerId !== stickPointer) return;
    if (!canPlay(event)) return;
    consume(event);
    moveStick(event);
  }
  function pointerup(event) {
    const pointer = pointers.get(event.pointerId);
    if (!pointer) return;
    pointers.delete(event.pointerId);
    if (event.pointerId === stickPointer) {
      stickPointer = null;
      state.setStick(0,0);
      if (stick) stick.style.transform = 'translate(0px, 0px)';
      joystick?.classList?.remove('is-active');
    }
    if (pointer.type === 'attack') state.setAttack(`pointer:${event.pointerId}`,false);
    paint();
    releaseCapture(pointer.element,event.pointerId);
  }
  function lostCapture(event) {
    // A normal pointerup removes its record before releasing capture.
    pointerup(event);
  }

  listen(document,'keydown',keydown,true);
  listen(document,'keyup',keyup,true);
  listen(document,'pointermove',pointermove,{passive:false});
  listen(document,'pointerup',pointerup,true);
  listen(document,'pointercancel',pointerup,true);
  listen(document,'visibilitychange',() => { if (document.hidden || document.visibilityState === 'hidden') clear(); });
  listen(document,'focusin',event => { if (blocked(event)) clear(); },true);
  listen(window,'blur',clear);
  listen(window,'pagehide',clear);
  listen(joystick,'pointerdown',startStick,{passive:false});
  listen(joystick,'lostpointercapture',lostCapture);
  listen(joystick,'contextmenu',consume);
  for (const [element,type] of controls) {
    listen(element,'pointerdown',event => startAction(element,type,event),{passive:false});
    listen(element,'lostpointercapture',lostCapture);
    listen(element,'contextmenu',consume);
    // Native keyboard/assistive clicks have detail=0. Pointer clicks already fired on pointerdown.
    listen(element,'click',event => {
      if (event.detail !== 0 || element.disabled || !canPlay(event)) return;
      consume(event);
      onAction(type);
    });
  }

  return {
    vector() { return canPlay() ? state.vector() : {x:0,z:0}; },
    attackHeld() { return canPlay() ? state.attackHeld() : false; },
    clear,
    destroy() {
      if (destroyed) return;
      destroyed = true;
      clear();
      for (const remove of removers.splice(0)) remove();
    }
  };
}
