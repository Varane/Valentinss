import test from 'node:test';
import assert from 'node:assert/strict';

class Target {
  listeners = new Map();
  addEventListener(type, fn) { const list = this.listeners.get(type) || new Set(); list.add(fn); this.listeners.set(type, list); }
  removeEventListener(type, fn) { this.listeners.get(type)?.delete(fn); }
  emit(type, init = {}) {
    const event = {type, target:this, cancelable:true, defaultPrevented:false, preventDefault(){this.defaultPrevented=true;}, ...init};
    for (const fn of [...(this.listeners.get(type) || [])]) fn(event);
    return event;
  }
  count() { return [...this.listeners.values()].reduce((n, list) => n + list.size, 0); }
}
class Element extends Target {
  constructor(tagName = 'BUTTON') {
    super(); this.tagName=tagName; this.style={setProperty(name,value){this[name]=value;}};
    const values = new Set(); this.classList={add:x=>values.add(x),remove:x=>values.delete(x),contains:x=>values.has(x),toggle(x,on){on?values.add(x):values.delete(x);}};
    this.captures=new Set(); this.attributes=new Map(); this.isContentEditable=false; this.disabled=false;
  }
  setAttribute(name,value) { this.attributes.set(name,String(value)); }
  getAttribute(name) { return this.attributes.get(name) ?? null; }
  removeAttribute(name) { this.attributes.delete(name); }
  getBoundingClientRect() { return {left:0,top:0,width:120,height:120}; }
  setPointerCapture(id) { this.captures.add(id); }
  releasePointerCapture(id) { this.captures.delete(id); }
  hasPointerCapture(id) { return this.captures.has(id); }
  closest(selector) {
    if (selector.includes('input') && (['INPUT','TEXTAREA','SELECT'].includes(this.tagName) || this.isContentEditable || this.attributes.get('role')==='textbox')) return this;
    return this.parentElement?.closest(selector) || null;
  }
}
async function setup() {
  const {createInput}=await import("file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/coordination/v4/SPRINT/10/touch_release/candidate.mjs");
  const document=new Target(), window=new Target(), nodes=new Map();
  document.defaultView=window; document.hidden=false; document.visibilityState='visible'; document.activeElement=null;
  for (const id of ['scene','joystick','stick','strike','dash','parry','special','rescue-hint','inventory','talents','pause','camera','switch-hero','ally','rooms']) {
    const node=new Element(id==='scene'?'CANVAS':id==='joystick'?'DIV':'BUTTON'); node.ownerDocument=document; nodes.set(id,node);
  }
  document.getElementById=id=>nodes.get(id)||null;
  document.querySelector=selector=>selector==='dialog[open]'&&document.dialogOpen?new Element('DIALOG'):null;
  document.querySelectorAll=selector=>selector==='dialog[open]'&&document.dialogOpen?[new Element('DIALOG')]:[];
  const actions=[],menus=[],switches=[],cameras=[];
  const input=createInput({canvas:nodes.get('scene'),onAction:x=>actions.push(x),onMenu:x=>menus.push(x),onSwitch:()=>switches.push(true),onCamera:()=>cameras.push(true)});
  const key=(type,code,extra={})=>document.emit(type,{code,key:code,...extra});
  const pointer=(id,type,pointerId,extra={})=>nodes.get(id).emit(type,{pointerId,button:0,clientX:60,clientY:60,...extra});
  return {input,document,window,nodes,actions,menus,switches,cameras,key,pointer};
}


for (const end of ['pointerup','pointercancel','lostpointercapture']) {
  test('attack '+end+' releases only its owning contact without redispatch',async()=>{
    const f=await setup();
    try {
      f.pointer('joystick','pointerdown',1,{clientX:105});
      f.pointer('strike','pointerdown',2);
      f.pointer('strike','pointerdown',3);
      const before=f.input.vector();
      assert.equal(f.input.attackHeld(),true);
      const release=id=>end==='lostpointercapture'
        ? f.nodes.get('strike').emit(end,{pointerId:id})
        : f.document.emit(end,{pointerId:id,target:f.nodes.get('scene')});
      release(2);
      assert.equal(f.input.attackHeld(),true,'second attack contact still owns its hold');
      assert.equal(f.nodes.get('strike').captures.has(2),false);
      assert.deepEqual(f.input.vector(),before,'movement finger survives attack release');
      release(3);
      assert.equal(f.input.attackHeld(),false);
      assert.equal(f.nodes.get('strike').classList.contains('is-pressed'),false);
      assert.equal(f.nodes.get('strike').captures.size,0);
      release(3);
      assert.deepEqual(f.actions,['attack','attack'],'release and duplicate release dispatch no actions');
      assert.deepEqual(f.input.vector(),before);
    } finally {f.input.destroy();}
  });
}

test('disabled combat controls reject pointer and assistive activation',async()=>{
  const f=await setup();
  try {
    for (const id of ['strike','dash','parry','special','rescue-hint']) {
      const button=f.nodes.get(id);button.disabled=true;
      f.pointer(id,'pointerdown',2);
      button.emit('click',{detail:0});button.emit('click',{detail:1});
      assert.equal(f.input.attackHeld(),false,id);
      assert.equal(button.captures.size,0,id);
    }
    assert.deepEqual(f.actions,[]);
  } finally {f.input.destroy();}
});

for (const end of ['pointerup','pointercancel','lostpointercapture']) {
  test('disabling an already held attack still permits '+end+' cleanup',async()=>{
    const f=await setup();
    try {
      f.pointer('strike','pointerdown',5);
      const strike=f.nodes.get('strike');strike.disabled=true;
      if(end==='lostpointercapture')strike.emit(end,{pointerId:5});
      else f.document.emit(end,{pointerId:5,target:f.nodes.get('scene')});
      assert.equal(f.input.attackHeld(),false);
      assert.equal(strike.captures.size,0);
      strike.emit('click',{detail:0});
      assert.deepEqual(f.actions,['attack']);
    } finally {f.input.destroy();}
  });
}

test('disabling a held attack drops that source before the runtime reads held state',async()=>{
  const f=await setup();
  try {
    f.pointer('joystick','pointerdown',1,{clientX:105});
    f.pointer('strike','pointerdown',9);
    const before=f.input.vector();
    const strike=f.nodes.get('strike');strike.disabled=true;
    assert.equal(f.input.attackHeld(),false,'disabled strike must not keep auto-attacking');
    assert.equal(strike.captures.size,0);
    assert.equal(strike.classList.contains('is-pressed'),false);
    assert.deepEqual(f.input.vector(),before,'disabling attack does not cancel movement');
    strike.disabled=false;
    assert.equal(f.input.attackHeld(),false,'reenabling cannot revive the old contact');
    assert.deepEqual(f.actions,['attack']);
  } finally {f.input.destroy();}
});
