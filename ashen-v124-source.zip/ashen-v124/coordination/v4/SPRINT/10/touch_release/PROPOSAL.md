# Disabled held attack: minimal owner patch

Evidence: pointerdown on #strike; set strike.disabled=true; input.attackHeld() remains true. Native disabled controls reject new activation, but canPlay() never rechecks the element behind an existing pointer record. The runtime polls attackHeld() each frame.

Apply owner.patch to dist/input.mjs. Before returning playable state, remove only disabled pointer records with the existing pointerup cleanup. The existing cleanup removes the attack source, pressed state, and capture; other pointer and keyboard sources survive. No implementation file was changed by this worker.

Gate 1: actual source 7 pass / 1 fail. Gate 2: isolated exact patch candidate 8 pass / 0 fail. Run node --test tests/sprint-10-touch.test.mjs after owner revision.

Limit: synthetic DOM exercises event/state wiring. It does not establish native iPhone event delivery; root owns browser validation. Current HUD only disables the revive control; this is a defensive control-contract regression for dynamically disabled Strike.
