# Sprint 10 — pointer attack release / cancel / disabled

Actual start: 2026-11-11 21:37:05 UTC.
Actual stop: 2026-11-11T21:43:25.320Z.

## Acceptance

Release/cancel behavior and initially disabled controls are accepted by this bounded check. The dynamically disabled held-attack invariant remains an ordinary failing production regression. No implementation was changed. The exact three-line owner patch is validated in isolation and applies cleanly to the current source.

## Evidence and trigger classification

- Production input SHA256 at gate 3: fee1c40b7e691e26d141bcc4d1a882b20949e6b2ba4c91aed136b9d40076fbe7.
- Repro: pointerdown on enabled #strike; set strike.disabled=true; poll input.attackHeld(). Actual true, expected false. Re-enabling should not revive that old contact.
- Root cause: startAction blocks new disabled controls, but canPlay never rechecks the element associated with a previously stored pointer. Its attack source remains held until an end event.
- Current dist .mjs/.html source inspection found no assignment disabling #strike. dist/index.html:42 starts Strike enabled. dist/ui/hud.mjs:90 disables only rescue hint. dist/action-game.mjs contains no disabled or strike reference. This is a defensive input-contract gap; no present gameplay trigger was established.
- Existing pointerup, pointercancel, and lostpointercapture cleanup pass, including when Strike becomes disabled before the end event. Multiple attack contacts release independently, preserve the joystick, and do not dispatch another action.
- Initially disabled strike/dash/parry/special/rescue controls dispatch no pointer or assistive action and acquire no capture.

## Four gates

1. 25% — gate-1.txt: actual source, 8 tests: 7 pass / 1 fail. Failing regression: disabling a held attack drops that source before the runtime reads held state.
2. 50% — gate-2.txt and owner.patch: exact minimal isolated candidate, 8 pass / 0 fail. Production source untouched. Existing pointerup cleanup is reused from canPlay only for disabled pointer records.
3. 75% — gate-3.txt and runtime-inspection.json: current production source re-evaluated without waiting for owner. Combined input DOM, state, QA1 gesture, and Sprint 10 suite: 40 tests, 39 pass / 1 fail; same sole disabled-held regression.
4. 100% — gate-4.txt: regression syntax valid; git apply --check owner.patch exits 0. Handoff records partial production acceptance and the remaining owner action.

## Commands

Production regression: node --test tests/sprint-10-touch.test.mjs

Relevant production verification: node --test tests/sprint-10-touch.test.mjs tests/input-controls-dom.test.mjs tests/input-controls-state.test.mjs tests/playability/qa1/gestures/gestures.test.mjs

Isolated proposal verification: node --test coordination/v4/SPRINT/10/touch_release/candidate.test.mjs

Patch applicability: git apply --check coordination/v4/SPRINT/10/touch_release/owner.patch

## Owner action and limits

Owner may apply owner.patch, then rerun the production regression and relevant suite. The failing test remains a normal test with no skip/todo/expected-failure marker. Patch and candidate source/tests are evidence artifacts, not a production edit.

Synthetic DOM checks exercise the actual input module and deterministic event/state behavior; they do not prove native iPhone delivery or layout. No server/browser was used, no implementation file was changed, and no commits/pushes were made. Writes are confined to this folder and tests/sprint-10-touch.test.mjs.
