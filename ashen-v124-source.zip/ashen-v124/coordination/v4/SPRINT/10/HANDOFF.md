# Sprint 10 — кнопки и безопасные края

Final audit handoff: 2026-11-11T22:01:07.603Z. Four actual workers launched: lead plus /root/touch_release, /root/modal_buttons, /root/safe_edges. No recursive agents/chats, implementation writes, browser/server use, commits, pushes or publication.

The 21:45 UTC consolidated handoff target was missed during an application interruption. Touch worker completed at 21:43:25 UTC, modal worker at 21:43:59 UTC, safe-edge worker saved gate3 at 21:42:53 UTC. At recovery 21:58 UTC list_agents showed only lead. Lead recovered artifacts and repeated current-source checks. No child was restarted.

## Current acceptance

Audit gates complete; production acceptance has outstanding defects. Latest combined ordinary regression: **18 tests: 15 pass, 3 fail**. FINAL-REGRESSION.tap contains exact output. No failing cases are skipped or todo. The two exact proposed changes apply against current source (git apply --check exit0), and isolated candidates pass **12/12** (FINAL-CANDIDATES.tap). Main implementation is unchanged by this team.

1. **D1, dist/input.mjs: disabled held attack keeps attacking.** Repro: strike pointerdown, set strike.disabled=true, then input.attackHeld() returns true. One ordinary failing regression in tests/sprint-10-touch.test.mjs. Minimal 3-line proposal: touch_release/owner.patch; prune disabled pointer records through existing pointerup() in canPlay(). Eight candidate cases pass. Current runtime/HUD never disables Strike; classify as defensive input contract gap, not observed current-release gameplay failure.
2. **D2, dist/ui.mjs: old async restart completion affects newer UI.** Repro pending restart → cancel/close → open Rooms or show newer outcome → resolve old restart. It closes the newer Rooms menu or hides the newer outcome (two failed regressions). Refreshed proposal against latest locale-aware actual file: **lead/current-ui-owner.patch**. Prefer this standard-context patch over earlier modal_buttons/OWNER-PATCH.diff. It captures a view revision and ignores stale completion UI effects. Four latest candidate cases pass. Current root restart is synchronous, so classify as latent Promise-callback contract defect.
3. **Integration blocker, owner C/root: missing dist/campaign/save.mjs.** Real import of dist/ui.mjs still fails ERR_MODULE_NOT_FOUND through dist/rules.mjs at final check. Exact stderr: REAL-UI-IMPORT.txt. This is independent of button findings. Modal tests visibly stub unrelated rules data exports to execute real UI/overlay/HUD lifecycle; they do not validate rules/campaign or claim production import success.

## Passing checks and limits

Keyboard: three new tests pass; earlier run including six existing DOM controls tests passed9/9. Native Space clears old holds and preserves focused-button activation, nested child focus is safe, modifier/composition edges clear holds.

Safe-edge source geometry: three checks pass. Explicit cases:320x568 with safe top44/bottom34 and568x320 with safe left/right44/bottom21. Joystick/action rectangles are within safe bounds, dimensions≥44px, pairwise nonoverlapping. This arithmetic test reads current CSS/HTML but is not a CSS layout engine, browser hit test or physical iPhone check. No screenshot manifest found by worker.

Latest source SHA256 hashes and timestamp: FINAL-SOURCE-HASHES.json. Latest UI proposal was refreshed and candidate-verified after source locale edits. PATCH-APPLICABILITY.json records exact read-only applicability result.

## Finite owner next step

Review/apply the two small proposals in owned source; restore missing campaign save module; rerun:

    node --test tests/sprint-10-keyboard.test.mjs tests/sprint-10-modal.test.mjs tests/sprint-10-safe-edges.test.mjs tests/sprint-10-touch.test.mjs

After import restoration, remove the modal rules hook fixture and use the real createGame fixture. Browser/mobile acceptance stays root-owned. No browser playability, touch-device, FPS, online or publication claim.

## Four bounded gates

Gate1: source evidence and reproducible failing/passing checks saved immediately per worker.
Gate2: exact minimal proposals, isolated candidates, or no-patch source geometry decision.
Gate3: current owner source re-evaluation, fresh ordinary tests, candidate results.
Gate4: lead acceptance/handoff after interrupted recovery; unresolved defects and integration blocker remain explicit.

## Coordination limitation

First root status message succeeded. Automatic approval review rejected the later message because it did not recognize explicit authorization for that destination/payload. No repeat or bypass; authorized shared handoff files are the result.
