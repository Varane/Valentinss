import test from 'node:test';
import assert from 'node:assert/strict';
// Modal tests isolate unrelated RPG loading: campaign/save.mjs is absent in this checkout.
// Only pause/rooms menus are exercised; all UI and overlay lifecycle code is real.
import {registerHooks} from 'node:module';
const rulesFixtureURL='data:text/javascript,'+encodeURIComponent("export const SKILLS=[],BRANCHES=[],ITEMS={};export const stats=()=>({attack:12,defense:0,maxHp:100,maxMana:6});");
const rulesHook=registerHooks({resolve(specifier,context,nextResolve){if(specifier.endsWith('/rules.mjs'))return {url:rulesFixtureURL,shortCircuit:true};return nextResolve(specifier,context);}});
const {createUI}=await import("file:///C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room/coordination/v4/SPRINT/10/lead/ui-current-candidate.mjs");
rulesHook.deregister();
function createGame(){return {phase:'battle',started:false,heroes:[{id:'knight',name:'Grim',xp:0,points:2,skills:[],bag:[],weapon:'blade',armor:'cloth',hp:100,mana:6,dead:false,down:false},{id:'mage',name:'Vexa',xp:0,points:2,skills:[],bag:[],weapon:'staff',armor:'cloth',hp:85,mana:6,dead:false,down:false}]};}

// DOM boundary only: every UI module and lifecycle callback is the real implementation.
class Node extends EventTarget {
  constructor(tag,doc){super();this.tagName=tag.toUpperCase();this.ownerDocument=doc;this.children=[];this.parentNode=null;this.attributes=new Map();this.style={setProperty(k,v){this[k]=v;}};this.dataset={};this.hidden=false;this.disabled=false;this.open=false;this.isConnected=true;this.tabIndex=/^(BUTTON|INPUT|SELECT|TEXTAREA)$/.test(this.tagName)?0:-1;this.value='';this._text='';const classes=new Set();this.classList={add:(...v)=>v.forEach(x=>classes.add(x)),remove:(...v)=>v.forEach(x=>classes.delete(x)),contains:v=>classes.has(v),toggle:(v,force)=>{const add=force??!classes.has(v);add?classes.add(v):classes.delete(v);return add;}};}
  set textContent(v){this._text=String(v??'');this.children=[];}
  get textContent(){return this._text+this.children.map(x=>x.textContent).join('');}
  set innerHTML(v){this._text=String(v??'');this.children=[];}
  get innerHTML(){return this._text;}
  set className(v){this._className=v;this.classList.add(...String(v).split(/\s+/).filter(Boolean));}
  get className(){return this._className||'';}
  append(...nodes){for(let n of nodes){if(typeof n==='string')n=this.ownerDocument.createTextNode(n);n.parentNode?.removeChild(n);n.parentNode=this;this.children.push(n);}}
  appendChild(n){this.append(n);return n;}
  replaceChildren(...nodes){for(const n of this.children)n.parentNode=null;this.children=[];this._text='';this.append(...nodes);}
  removeChild(n){this.children=this.children.filter(x=>x!==n);n.parentNode=null;return n;}
  remove(){this.parentNode?.removeChild(this);this.isConnected=false;}
  setAttribute(k,v){this.attributes.set(k,String(v));if(k==='id')this.id=String(v);if(k==='open')this.open=true;if(k==='tabindex')this.tabIndex=Number(v);}
  setAttributeNS(_ns,k,v){this.setAttribute(k,v);}
  getAttribute(k){return this.attributes.get(k)??null;}
  hasAttribute(k){return this.attributes.has(k);}
  removeAttribute(k){this.attributes.delete(k);if(k==='open')this.open=false;}
  contains(n){return n===this||this.children.some(c=>c.contains(n));}
  matches(s){if(s.startsWith('#'))return this.id===s.slice(1);if(s===':disabled')return this.disabled;if(s==='dialog[open]')return this.tagName==='DIALOG'&&this.open;if(s.startsWith('.'))return this.classList.contains(s.slice(1));return this.tagName.toLowerCase()===s.split(/[\[:]/)[0];}
  closest(s){return this.matches(s)?this:this.parentNode?.closest(s)||null;}
  querySelectorAll(s){return this.children.flatMap(c=>[...(s.split(',').some(x=>c.matches(x.trim()))?[c]:[]),...c.querySelectorAll(s)]);}
  querySelector(s){return this.querySelectorAll(s)[0]||null;}
  focus(){this.ownerDocument.activeElement=this;}
  click(){if(!this.disabled)this.dispatchEvent(new Event('click',{cancelable:true}));}
  showModal(){this.open=true;this.setAttribute('open','');}
  close(){if(!this.open)return;this.open=false;this.removeAttribute('open');queueMicrotask(()=>this.dispatchEvent(new Event('close')));}
  getBoundingClientRect(){return {left:0,top:0,right:800,bottom:600,width:800,height:600};}
}
function dom(){
  const doc=new EventTarget();doc.createElement=tag=>new Node(tag,doc);doc.createElementNS=(_ns,tag)=>new Node(tag,doc);doc.createTextNode=v=>{const n=new Node('#text',doc);n.textContent=v;return n;};doc.body=new Node('body',doc);doc.documentElement=new Node('html',doc);doc.defaultView=new EventTarget();doc.defaultView.getComputedStyle=()=>({display:'block',visibility:'visible'});doc.getElementById=id=>doc.body.querySelector('#'+id);doc.querySelector=s=>doc.body.querySelector(s);doc.querySelectorAll=s=>doc.body.querySelectorAll(s);doc.activeElement=doc.body;
  const ids=['scene','inventory','talents','pause','camera','switch-hero','ally','restart','after-gear','rooms','notice','outcome','outcome-kicker','outcome-title','outcome-text','hero-name','hero-state','life','endurance','hp-text','stamina-text','ally-name','ally-life','remaining','tutorial','rescue-hint','strike','dash','parry','special','enemy-labels','damage-labels','loading'];
  for(const id of ids){const n=doc.createElement(['inventory','talents','pause','camera','switch-hero','ally','restart','after-gear','rooms','strike','dash','parry','special'].includes(id)?'button':'div');n.id=id;doc.body.append(n);}
  const dialog=doc.createElement('dialog');dialog.id='overlay';doc.body.append(dialog);for(const id of ['close','overlay-kicker','overlay-title','hero-selector','overlay-content']){const n=doc.createElement(id==='close'?'button':'div');n.id=id;dialog.append(n);}
  globalThis.document=doc;globalThis.window=doc.defaultView;return doc;
}
function setup(options={}){const document=dom(),profile=createGame(),pauses=[];let selected=0;const ui=createUI({getProfile:()=>profile,getEncounter:()=>({phase:'active',players:[{hp:100},{hp:85}],enemies:[]}),getSelected:()=>selected,selectHero:i=>{selected=i;},onPause:v=>pauses.push(v),...options});return {document,profile,pauses,ui,selected:()=>selected};}


const settle=async()=>{for(let i=0;i<8;i++)await Promise.resolve();};
function cancel(document){const event=new Event('cancel',{cancelable:true});document.getElementById('overlay').dispatchEvent(event);return event;}
function cleanup(t,f){t.after(()=>f.ui.destroy());return f;}

test('pending restart accepts one activation and cancel plus close resumes exactly once',async t=>{
  let release,calls=0;const pending=new Promise(resolve=>{release=resolve;});
  const f=cleanup(t,setup({onRestart:()=>{calls++;return pending;}}));
  const opener=f.document.getElementById('pause');opener.focus();f.ui.open('pause');
  const restart=f.document.getElementById('restart');restart.click();restart.click();
  assert.equal(calls,1);assert.deepEqual(f.pauses,[true]);
  assert.equal(cancel(f.document).defaultPrevented,true);f.ui.close();f.ui.close();
  assert.deepEqual(f.pauses,[true,false]);assert.equal(f.document.activeElement,opener);
  release(true);await settle();assert.equal(f.ui.isOpen(),false);assert.deepEqual(f.pauses,[true,false]);
});

test('completion of a cancelled restart cannot close a newly opened menu',async t=>{
  let release,calls=0;const pending=new Promise(resolve=>{release=resolve;});
  const f=cleanup(t,setup({onRestart:()=>{calls++;return pending;}}));
  const opener=f.document.getElementById('pause');opener.focus();f.ui.open('pause');
  f.document.getElementById('restart').click();cancel(f.document);f.ui.close();
  const nextOpener=f.document.getElementById('rooms');nextOpener.focus();f.ui.open('rooms');
  assert.deepEqual(f.pauses,[true,false,true]);assert.equal(f.ui.isOpen(),true);
  release(true);await settle();
  assert.equal(calls,1);assert.equal(f.ui.isOpen(),true,'late restart completion closed the newer rooms menu');
  assert.deepEqual(f.pauses,[true,false,true],'late restart completion emitted an unowned resume');
  assert.equal(f.document.getElementById('overlay').contains(f.document.activeElement),true);
  f.ui.close();f.ui.close();await settle();assert.deepEqual(f.pauses,[true,false,true,false]);
  assert.equal(f.document.activeElement,nextOpener);
});

test('destroy during pending restart suppresses late action and extra resume',async t=>{
  let release,calls=0;const pending=new Promise(resolve=>{release=resolve;});
  const f=setup({onRestart:()=>{calls++;return pending;}});t.after(()=>f.ui.destroy());
  f.ui.open('pause');f.document.getElementById('restart').click();f.ui.destroy();f.ui.destroy();
  release(true);await settle();f.document.getElementById('restart').click();
  assert.equal(calls,1);assert.equal(f.ui.isOpen(),false);assert.deepEqual(f.pauses,[true,false]);
});

test('completion of an older restart cannot hide a newer outcome',async t=>{
  let release;const pending=new Promise(resolve=>{release=resolve;});
  const f=cleanup(t,setup({onRestart:()=>pending}));
  f.ui.showOutcome({won:false,title:'Old outcome',text:'Old'});
  f.document.getElementById('restart').click();
  f.ui.showOutcome({won:false,title:'New outcome',text:'New'});
  release(true);await settle();
  assert.equal(f.document.getElementById('outcome').hidden,false,'late restart completion hid newer outcome');
  assert.equal(f.document.getElementById('outcome-title').textContent,'New outcome');
  assert.deepEqual(f.pauses,[]);
});
