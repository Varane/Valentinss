# Team04 lifecycle: exact safe guard proposal

Owner A; file dist/action.mjs. Current SHA256 63096b8bd8815d35c8dd3b666b7b7cc9daada425200a02893fd5e937134ac97a.

Current encounter ignores room.mode, and finish immediately returns victory for enemies:[] even if two players are alive. Duel is not implemented. The minimal safe boundary change is one line at the start of encounter, before reading heroes:

```diff
 export function encounter(profile=createGame(),room){
+  if(room?.mode && room.mode!=='coop')throw new RangeError('Room mode is not supported.');
   const source=Array.isArray(profile?.heroes)?profile.heroes:createGame().heroes;
```

This rejects unsupported explicit modes and preserves undefined/default/cooperative calls. It does not implement PvP. Actual duel release still requires opponent hit rules, winner/draw contract, progression isolation and authenticated mode routing. Tests execute exact current encounter/finish bodies in a VM with explicit test dependencies because current full imports fail on missing campaign/save.mjs. Empty-arena hazard evidence is in cycle-1-lifecycle-probe.json rather than a test locking in a defect.
