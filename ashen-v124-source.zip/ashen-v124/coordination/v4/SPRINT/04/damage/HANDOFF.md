# Team04 damage — final acceptance handoff

Four bounded audit cycles complete. Duel damage acceptance is UNMET. No implementation edits, commits, servers or browser work performed.

## Actual source evidence

- dist/action.mjs:84 constructs targets exclusively from state.enemies. Line 96 calls hitEnemy for every normal/special target. Another player is never eligible, even one unit away.
- encounter currently discards room.mode; the regression's manual state.mode='duel' is requested intent, not a supported fixture contract.
- dist/combat/damage.mjs:33 hitPlayer already applies armor, capped actual damage, hurt and nine-second downing. This low-level helper has no player-origin options/provenance path: line40 only recognizes options.enemy.
- resolveEnemyStrike owns defensive invulnerability/parry checks; no equivalent player-origin resolver or command routing exists. Directly swapping hitEnemy for hitPlayer would bypass defensive handling.
- finish()/empty-enemy victory and settlement belong to lead, explicitly excluded here. No step() called in the damage reproduction.

## Executable test and exact results

Command: `node --test tests/sprint-04-damage.test.mjs`

Current-source rerun: tests3, pass2, fail0, todo1. Exit0 because unmet acceptance is explicitly TODO. The TODO actually fails `AssertionError [ERR_ASSERTION]: nearby duel opponent should be a valid attack target`, actual false, expected true. It is not a success claim.

Passing controls prove PvE ally HP remains unchanged while an enemy takes damage, and actual hitPlayer applies armor/downing. The unmet test proves actual command refuses an attack when only the other player is present.

Exact captured outputs: 02-test-output.txt and 03-retest-output.txt in this folder. Minimal owner patch proposal: 02-owner-proposal.md.

Full `action.mjs` import initially failed ERR_MODULE_NOT_FOUND for dist/campaign/save.mjs via rules.mjs. Test therefore reads exact current command/emit source and executes it with real imported combat/damage and combat/skills helpers plus manually built actor state. This is command-path evidence, not full encounter/runtime integration.

## Cycle 3 fresh source check

No owner damage patch observed. SHA256 at recheck:
- action.mjs: 63096B8BD8815D35C8DD3B666B7B7CC9DAADA425200A02893FD5E937134AC97A
- damage.mjs: CCE372BBA8AAD96830B38B9B650711BD3E925E6F9D589836170D070631CD70D7
- skills.mjs: 8B12D4BCF134552227740439B39AE8BEF41365C5EA07DAB0C4C87B42B6083AC5

## Owner acceptance after implementation

Establish supported explicit duel mode; route nearby other living players through defense-aware player-origin damage with correct events; retain PvE no-friendly-fire behavior. Rerun the TODO without its marker only after a real supported fixture exists. This worker's four-cycle audit gate is100%; duel damage feature acceptance remains0%.

## Lead review clarification

No safe complete PvP patch fits the current combat contract: player-origin defensive resolution, mode construction and lethal/downing lifecycle semantics require an owner decision. The proposal above is an acceptance outline, not a drop-in patch. Do not route naked hitPlayer calls from command. The minimal immediate exact guard is documented by the lead in ../lifecycle/cycle-2-proposal.md.
