# Cycle 2 — exact minimal owner proposal

Observed current source: action.mjs command constructs only state.enemies targets, filters enemy.hp > 0 and calls hitEnemy. encounter does not preserve room.mode. damage.mjs exports hitPlayer for armor/downing, but only resolveEnemyStrike supplies defensive invulnerability/parry checks and enemy-only provenance. No player-origin command path exists.

Minimal owner change (proposal only, not implemented here):
1. Establish explicit additive duel mode on encounter state (e.g. room.mode === 'duel'); retain PvE default.
2. In command, select other living, non-downed players in that mode; retain enemies in PvE. Keep distance, normal/special reach, cooldown/resource and recovery rules. Exclude attacker index.
3. Route duel targets through a player-origin strike resolver that honors target dash invulnerability, facing parry and armor before hitPlayer; emit sourceType:'player', source attacker index, targetType:'player', target victim index. Current hitPlayer options only recognizes enemy provenance.
4. Owner must define duel lethal/downing policy consistently with lifecycle. This worker excludes finish()/settlement.

Do not simply call hitPlayer in the existing enemy loop: it would bypass defensive handling and falsely report enemy-origin damage. No implementation edits are authorized for this worker.

Import limitation: full action import on 2026-11-11 fails ERR_MODULE_NOT_FOUND dist/campaign/save.mjs via rules.mjs. Regression therefore reads the current action source and executes exact command/emit with real damage/skills helpers, plus a manual actor fixture. This does not claim encounter or full runtime integration.

Lead review: no safe complete PvP patch fits current combat contract until mode construction, defense-aware player resolver and lethal/downing semantics are decided. Above is scoped acceptance guidance, not a drop-in patch. Minimal immediate exact guard belongs to ../lifecycle/cycle-2-proposal.md. Naked hitPlayer routing is explicitly rejected.
