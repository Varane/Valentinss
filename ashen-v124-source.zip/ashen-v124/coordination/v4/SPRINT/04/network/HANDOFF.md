# Sprint 04 network handoff

Completed the four bounded diagnostic cycles. No implementation file, commit, server, browser, other chat, or child agent was created or changed. Only this network artifact directory and `tests/sprint-04-network.test.mjs` were written.

## Finding

Explicit `{mode:'duel'}` currently silently creates a cooperative room. The core create signature ignores mode, the browser create signature drops mode before sending, and the HTTP handler forwards only profile. `server/action-adapter.mjs` exposes only the ordinary encounter factory. There is no duel configuration/route or authoritative duel opponent identity in the inspected room envelope or snapshot. Current `members[].playerId -> heroIndex` mapping does preserve two authenticated cooperative slots.

Exact owner change proposal is `PATCH_PROPOSAL.md`: add an `UNSUPPORTED_MODE` 400 guard at browser create, HTTP create and core create, retaining omitted mode / explicit coop behavior. This prevents silent misrouting; it does not implement PvP. No owner patch was observed in the final source reread.

## Executable evidence

From repository root:

```sh
node --test tests/sprint-04-network.test.mjs
```

Cycle 1 full import failed with `ERR_MODULE_NOT_FOUND` for `dist/campaign/save.mjs`, imported by `dist/rules.mjs`. Exact raw output: `cycle-1-test.log`; Node exit 1. This remains a full dependency-graph integration blocker.

Cycles 2 and 3 use the actual current room-core source in a VM with ONLY its action-adapter import replaced by explicit neutral stubs declared in the test. That verifies allocation, authentication and member-slot routing only. The browser test imports the real standalone browser network client directly and uses an in-memory fake fetch response; no browser is opened and no socket is used.

Result: 3 tests, 1 pass, 0 ordinary failures, 2 TODOs; Node exit 0. Both TODO tests actually fail `Missing expected rejection`: unsupported duel requests are not rejected by either tested boundary. Node exit 0 is due to TODO semantics and is not a duel acceptance pass. The passing test confirms distinct host/guest credentials, stable playerId/heroIndex 0 and 1, capacity two, authenticated resume, and room-code bearer rejection.

Current source hashes and focused reread are in `cycle-3-source.txt`; fresh exact output is `cycle-3-test.log`. Earlier successful isolated run output is `cycle-2-test.log`.

## Boundaries and next finite task

No hit mechanics, rewards, UI acceptance, deployed multiplayer or real opponent combat was inspected or verified. Next owner task: apply the three small unsupported-mode guards, remove TODO only once the guards pass, restore the missing campaign dependency, then run the full unmodified import graph and existing network suites. A genuine duel implementation still requires a separate owner-authorized design and authority path.
