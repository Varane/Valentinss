# Team 04 network: unsupported duel request silently enters coop

Cycle 2. Inspected current source on 2026-11-11 at 21:39 UTC. Implementation files remain owner-only and were not edited.

## Concrete blocker

`server/room-core.mjs:20` destructures only `{profile}` in `create`. Calling `service.create({mode:'duel'})` allocates the ordinary cooperative encounter. `server/action-adapter.mjs:5` has only `createServerEncounter=profile=>encounter(profile)`. Neither room envelope nor public snapshot has mode or an authoritative opponent field. Member credentials map to `heroIndex` 0 and 1, which is sufficient for existing coop identity; it does not establish duel opponents.

The same unsupported option disappears earlier at two public boundaries: browser `dist/ui/network-client.mjs:227` destructures only `{profile}` and `worker/index.mjs:119` constructs arguments containing only profile. A core-only rejection cannot catch a duel option already stripped by HTTP or browser.

## Exact minimal safe owner proposal

Until a genuine authoritative duel path exists, reject explicit unsupported modes before allocating a room or sending a request. Preserve omitted mode and explicit `coop` as the current cooperative flow. Do not label this change a PvP implementation.

1. In `server/room-core.mjs`, change the beginning of create from:

```js
async function create({profile}={}){for(let i=0;i<12;i++){
```

to:

```js
async function create({profile,mode='coop'}={}){
  if(mode!=='coop')throw new RoomError(400,'UNSUPPORTED_MODE','Only cooperative rooms are available.');
  for(let i=0;i<12;i++){
```

The remaining existing create body and braces stay in place.

2. In `worker/index.mjs`, inside `if (found.operation === 'create')`, before profile validation, add:

```js
if (body.mode !== undefined && body.mode !== 'coop') {
  throw new HttpError(400, 'UNSUPPORTED_MODE', 'Only cooperative rooms are available.');
}
```

Existing profile-only service argument construction can remain unchanged because this boundary now rejects unsupported modes itself.

3. In `dist/ui/network-client.mjs`, replace create with:

```js
function create({ profile, mode = 'coop' } = {}) {
  if (mode !== 'coop') return Promise.reject(new RoomClientError(
    'UNSUPPORTED_MODE', 'Only cooperative rooms are available.', 400));
  return enter('/create', profile === undefined ? {} : { profile });
}
```

No new route, opponent selection, damage, rewards or UI behavior is proposed here. The three guards are necessary because each boundary currently discards the mode independently.

## Verification

Run `node --test tests/sprint-04-network.test.mjs`. Current unsupported-mode acceptance is deliberately marked TODO `owner fix pending`; TODO failures are evidence of an unresolved gate, not successful duel support. The separate cooperative preservation test checks distinct credentials, stable member-to-hero slots, authenticated resume and rejection of room codes as bearer credentials.
