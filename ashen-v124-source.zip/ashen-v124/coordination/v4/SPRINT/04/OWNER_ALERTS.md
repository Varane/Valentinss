# Team04 owner alerts

A — Duel attack target path absent. See damage/02-owner-proposal.md. Engine boundary currently discards room.mode; empty enemies means victory even with two living players. Exact one-line safety proposal plus in-memory validation: lifecycle/cycle-2-proposal.md and lifecycle/cycle-4-proposal-validation.json.

D — Mode dropped at room create boundaries. See network/PATCH_PROPOSAL.md. Current UI does not advertise duel and is honest about offline play; keep duel disabled until authoritative protocol and A rules exist. See ui/CYCLE-2-PROPOSAL.md.

C / Root — Real action and room-core import fails ERR_MODULE_NOT_FOUND dist/campaign/save.mjs imported by dist/rules.mjs. dist/campaign/progression.mjs was also absent during inventory. Exact trace: lifecycle/cycle-3-import.txt. These are owner implementation dependencies; team04 cannot modify them. This must be rechecked after C finalizes its files before browser/publication acceptance.

No browser, playability, FPS, hosted multiplayer, or publication evidence was produced by team04.
