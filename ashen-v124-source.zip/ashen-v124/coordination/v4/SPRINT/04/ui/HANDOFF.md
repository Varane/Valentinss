# Cycle 4 — final UI duel handoff

Finalized 2026-11-11 21:42 UTC. Review complete; duel feature acceptance remains 0%.

Concrete reproduced blocker: room entry has no duel mode choice. The actual Create control invokes `onCreate()` without a mode; ui.mjs sends only `{profile}` and the public browser client wrapper accepts only profile. Current UI labels do not advertise duel or PvP. Its offline message is honest. This is a missing entry point, not a deceptive-label defect.

Commands and exact results:

- `node --test tests/sprint-04-ui.test.mjs` — 3 tests, 2 pass, 0 fail, 1 TODO; duration 1212.3544 ms.
- `node --test tests/sprint-04-ui.test.mjs tests/input-ui-overlay.test.mjs` — exit 0; 15 tests, 14 pass, 0 fail, 1 TODO; duration 7209.1837 ms.
- Actual source reread and four SHA256 values are preserved in `CYCLE-3-RECHECK.md`. No relevant owner revision was present at that read.

Artifacts in this directory: `CYCLE-1.md`, `CYCLE-2-PROPOSAL.md`, `CYCLE-3-RECHECK.md`, `HANDOFF.md`, `status.json`. Executable bounded test: `tests/sprint-04-ui.test.mjs`.

Exact proposal is in CYCLE-2-PROPOSAL.md. It is conditional future implementation: accessible mode choice; preserve supported mode across callback/client; display authoritative joined mode. Enabling/forwarding duel now is not advised. Immediate unsupported-mode rejection must follow `../network/PATCH_PROPOSAL.md` as confirmed by the lead. Current safe UI retains duel unavailable and existing honest offline messaging.

No implementation edits, commits, servers, browser or FPS claims. No server-mode/target-damage inspection. Test fixture models DOM operations only. TODO is unexecuted acceptance, not a duel pass. All requested four review cycles complete; owner implementation remains outstanding.
