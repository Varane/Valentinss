# Cycle 3 — reread actual files and retest

2026-11-11 21:42 UTC. No owner revision seen in the relevant path at this check. The same blocker remains.

Command: `node --test tests/sprint-04-ui.test.mjs tests/input-ui-overlay.test.mjs`

Result: exit 0; tests 15; pass 14; fail 0; cancelled 0; skipped 0; todo 1; duration 7209.1837 ms. Twelve existing overlay checks passed, two bounded room-entry observations passed, one duel acceptance remains an unexecuted TODO. This is not proof of working PvP.

Command: `rg -n 'MENU_TYPES|onCreate:|СОВМЕСТНЫЙ|function create\(|onCreate\(\)|duel|pvp|дуэл|КОМНАТЫ|локальная игровая' dist/ui.mjs dist/ui/overlay.mjs dist/ui/network-client.mjs dist/index.html`

Actual source evidence:

- `dist/ui.mjs:6`: rooms, room and coop menu aliases; no duel alias.
- `dist/ui.mjs:71`: `onCreate:()=>networkCall('create',{profile:getProfile()})`.
- `dist/ui.mjs:126`: rooms kicker remains СОВМЕСТНЫЙ ПОХОД.
- `dist/ui/overlay.mjs:50`: create invokes `onCreate()` without a mode.
- `dist/ui/network-client.mjs:227`: create destructures only profile and sends only profile.
- `dist/index.html:26`: generic КОМНАТЫ entry; line 29 says локальная игровая комната.

Command: `Get-FileHash -Algorithm SHA256 -LiteralPath 'dist/ui.mjs','dist/ui/overlay.mjs','dist/ui/network-client.mjs','dist/index.html' | Format-List Path,Hash`

SHA256 snapshots:

- dist/ui.mjs: 7F354BC0FC306783095D94382BEEE8430BDC40B550B326AFD448A66B0FA4BC4B
- dist/ui/overlay.mjs: 758F709C4F3B4AF71EF5CCE8CB98340237CF9432F16F46E4D3A6B96621040895
- dist/ui/network-client.mjs: 121D363FDCAC47C16A02B002A03B19187E87564A26FD5AE75FAA49D5290F4EFA
- dist/index.html: 858EC7865B9DA89E12A945674417B8DCB970E0FC0EF61D9CEA69AB2B6B1F738E

Reevaluation: UI absence, not deception. Current fake-DOM reproduction reaches the actual room component. No server mode, target damage, browser, mobile rendering or FPS inspected.
