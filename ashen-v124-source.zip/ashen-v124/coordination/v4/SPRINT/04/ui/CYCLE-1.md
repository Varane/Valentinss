# Cycle 1 — reproduce

2026-11-11 21:39 UTC. Scope: room/duel UI only. Read MASTER and D STATUS/HANDOFF; no implementation files changed.

Source evidence: `dist/ui/overlay.mjs:createRoomContent` renders status, room code, Create, Join and Leave only. `act('create')` invokes `onCreate()` without a mode. `dist/ui.mjs` forwards that action to `network.create({profile:getProfile()})`. Its menu aliases have rooms/room/coop but no duel. `dist/index.html` labels entry as КОМНАТЫ; it does not advertise PvP.

Concrete blocker: the player cannot choose a duel before creating a room, and no mode leaves the room-create UI callback. This is absence of a requested mode, not deceptive duel advertising. Offline messaging explicitly says the server is not connected and local play remains available.

Executable reproduction added at `tests/sprint-04-ui.test.mjs`, using a minimal fake DOM around the actual exported `createRoomContent`. It supplies a synthetic available client advertising both mode names, clicks Create, captures `onCreate()` arguments, and records the absence of mode controls. Acceptance is a pending TODO; no claim of a working duel.

Command: `node --test tests/sprint-04-ui.test.mjs`. Output: 3 tests, pass 2, fail 0, cancelled 0, skipped 0, todo 1; duration 1212.3544 ms. The pending test is unexecuted acceptance, not a passing duel check.
