# Cycle 2 — exact minimal owner proposal

Owner: D (dist/ui.mjs, dist/ui/overlay.mjs, dist/ui/network-client.mjs). Root receives this passive proposal; this worker made no implementation edits. Server protocol support must be confirmed by its owner before enabling the duel option.

Smallest complete UI-to-client change:

1. In `createRoomContent`, create an accessible `select` with `aria-label="Режим комнаты"`, `name="mode"` and options `coop` / `Совместный поход`, `duel` / `Дуэль`. Append it before the room-code input. Keep `duel` disabled until the network owner confirms support; show `Дуэль пока недоступна` while unsupported. Mirror existing input disabling during pending/offline/joined states. This preserves the honest offline state.
2. Change only the create branch of `act`: `onCreate({mode:mode.value})` instead of `onCreate()`. Join and Leave remain unchanged.
3. In `dist/ui.mjs`, change the room callback from `onCreate:()=>networkCall('create',{profile:getProfile()})` to `onCreate:({mode}={mode:'coop'})=>networkCall('create',{profile:getProfile(),mode})`.
4. FUTURE ONLY, conditional on an authoritative duel implementation: in `dist/ui/network-client.mjs`, preserve a validated supported mode in the create request alongside profile. Do not forward an unsupported duel mode now. Immediate client validation/rejection belongs to `coordination/v4/SPRINT/04/network/PATCH_PROPOSAL.md`, whose browser/HTTP/core guard takes precedence. Preserve all auth/revision behavior.
5. Once the server owner's public snapshot-mode field is confirmed, label the joined room with that authoritative mode. Do not infer duel from the local dropdown. No duel label should appear for a room whose mode is unknown.

Required acceptance after owner revision: select Дуэль, click Create, capture exactly one client.create call containing `mode:'duel'` alongside the original profile; confirm actual joined mode displayed from server state. The pending acceptance test must be implemented against that agreed snapshot contract. Until then the recorded gate remains 0%.

Lead review at 21:42 UTC: all enabling/forwarding steps above describe future duel implementation, not an immediate safe patch. The present safe option is to reject unsupported modes and keep duel unavailable. Review completion percentage is tracked separately from duel feature acceptance (0%). No current misleading-label bug exists.

Evidence only, no server-mode or target-damage inspection performed. Current labels are generic rooms/cooperative journey; no deceptive PvP advertising found.
