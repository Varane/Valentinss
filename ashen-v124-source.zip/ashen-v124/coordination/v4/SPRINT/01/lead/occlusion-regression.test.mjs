import test from 'node:test';
import assert from 'node:assert/strict';
const target=process.env.SPRINT_01_DAMAGE_URL || new URL('../../../../../dist/combat/damage.mjs',import.meta.url).href;
const {resolveEnemyStrike}=await import(target);
const emit=(s,type,data)=>s.events.push({type,...data});
test('solid pillar blocks committed enemy strike',()=>{const s={players:[{x:-4.86,z:-2.5,hp:100,maxHp:100,defense:0,invuln:0,parry:0}],enemies:[{x:-3.14,z:-2.5,hp:100,yaw:-Math.PI/2,damage:12,target:0}],events:[]};assert.equal(resolveEnemyStrike(s,0,emit),false);assert.equal(s.players[0].hp,100);assert.equal(s.events.length,0);});

const {command}=await import(process.env.SPRINT_01_ACTION_URL || new URL('./actual-action.mjs',import.meta.url).href);
function fixture(){return {phase:'active',time:0,eventSeq:0,events:[],players:[{x:-4.86,z:-2.5,yaw:Math.PI/2,hp:100,maxHp:100,damage:12,defense:0,skills:[],weapon:'blade',mana:6,maxMana:6,stamina:100,dead:false,down:0,riposte:0,attackCd:0}],enemies:[{x:-3.14,z:-2.5,hp:100,maxHp:100}]};}
test('solid pillar blocks normal player hit',()=>{const s=fixture();assert.equal(command(s,'attack'),true);assert.equal(s.enemies[0].hp,100);assert.equal(s.events.filter(e=>e.type==='hit').length,0);});
test('unobstructed player target remains hittable',()=>{const s=fixture();s.enemies[0].x=-4.86;s.enemies[0].z=-3.5;assert.equal(command(s,'attack'),true);assert.equal(s.enemies[0].hp,88);});
test('blocked nearest target does not prevent hitting an unobstructed in-range target',()=>{const s=fixture();s.enemies.push({x:-4.86,z:-4.5,hp:100,maxHp:100});assert.equal(command(s,'attack'),true);assert.equal(s.enemies[0].hp,100);assert.equal(s.enemies[1].hp,88);});
