import {createGame,stats} from './rules.mjs';
import {PILLARS,moveActor,normalizeInput,clearStrikePath} from './combat/movement.mjs';
import {hitEnemy,resolveEnemyStrike,revivePlayer,tickDowned} from './combat/damage.mjs';
import {updateEnemies,updateCompanion} from './combat/ai.mjs';
import {attackSpec,spendAttack,attackDamage,applyAttackRecovery} from './combat/skills.mjs';

export {PILLARS};
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
const finite=(value,fallback)=>Number.isFinite(value)?value:fallback;
const distance=(a,b)=>Math.hypot(a.x-b.x,a.z-b.z);
const PLAYER_TIMERS=['invuln','dash','parry','parryCd','riposte','attackCd','attackAnim','hurt'];
const MAX_STEP=1/120;
const DEFAULT_ENEMIES=[
  {x:1.8,z:-1.4,hp:85,damage:17,cooldown:1.4},
  {x:-1.7,z:-4.1,hp:70,damage:14,cooldown:2.4},
  {x:3.2,z:-4.1,hp:120,damage:24,cooldown:3.4,boss:true},
];

function emit(state,type,data={}){
  const player=state.players[data.actor];
  const enemy=state.enemies[data.enemy];
  const at=player||enemy;
  const id=Math.max(0,finite(state.eventSeq,0))+1;
  state.eventSeq=id;
  state.events.push({...(at?{x:at.x,z:at.z}:{}),...data,type,id,time:state.time});
  if(state.events.length>100)state.events.splice(0,state.events.length-100);
}

function makeEnemy(source,index){
  const data=source&&typeof source==='object'?source:{};
  const maxHp=clamp(finite(data.maxHp,finite(data.max,finite(data.hp,70))),1,100000);
  const enemy={...data,id:data.id??'enemy-'+index,x:clamp(finite(data.x,(index%3-1)*2),-5.8,5.8),
    z:clamp(finite(data.z,-3.5),-4.8,4.8),yaw:finite(data.yaw,0),
    hp:clamp(finite(data.hp,maxHp),0,maxHp),maxHp,
    damage:clamp(finite(data.damage,finite(data.attack,14)),0,10000),
    cooldown:clamp(finite(data.cooldown,.8+index*.25),0,30),windup:0,stun:0,target:0,
    attackAnim:0,hurt:0,speed:0,boss:!!data.boss};
  if(Number.isFinite(data.speed)&&data.speed>0&&!Number.isFinite(data.moveSpeed))enemy.moveSpeed=data.speed;
  moveActor(enemy,0,0);
  return enemy;
}

/** Creates an independent mutable encounter; profile resources survive room changes. */
export function encounter(profile=createGame(),room){
  const source=Array.isArray(profile?.heroes)?profile.heroes:createGame().heroes;
  const players=source.map((hero,index)=>{
    const h={...hero,skills:Array.isArray(hero.skills)?[...hero.skills]:[]};
    const values=stats(h);
    const maxHp=Math.max(1,finite(values.maxHp,100));
    const maxMana=Math.max(0,finite(values.maxMana,6));
    const dead=!!h.dead;
    const down=dead?0:clamp(finite(h.down,0),0,60);
    const hp=dead||down>0?0:clamp(finite(h.hp,maxHp),0,maxHp);
    return {id:h.id,name:h.name,x:index===0?-2:-3.5,z:index===0?2:2.8,yaw:Math.PI,
      hp,maxHp,damage:Math.max(0,finite(values.attack,12)),defense:Math.max(0,finite(values.defense,0)),
      skills:h.skills,weapon:h.weapon||'blade',armor:h.armor||'cloth',
      mana:clamp(finite(h.mana,maxMana),0,maxMana),maxMana,
      stamina:100,invuln:0,dash:0,dx:0,dz:-1,parry:0,parryCd:0,riposte:0,
      attackCd:0,attackAnim:0,hurt:0,down:hp<=0&&!dead&&down===0?9:down,dead,speed:0};
  });
  const descriptors=Array.isArray(room?.enemies)?room.enemies:DEFAULT_ENEMIES;
  return {phase:'active',time:0,started:false,events:[],eventSeq:0,players,
    enemies:descriptors.map(makeEnemy),companionAI:true,externalPlayers:[],roomId:room?.id??null};
}

export function command(state,type,index=0){
  if(state?.phase!=='active')return false;
  const player=state.players[index];
  if(!player||player.hp<=0||player.dead||player.down>0)return false;
  if(type==='dash'){
    if(player.stamina<25||player.dash>0)return false;
    player.stamina-=25;player.invuln=Math.max(player.invuln,.33);player.dash=.22;player.parry=0;
    emit(state,'dash',{actor:index});return true;
  }
  if(type==='parry'){
    if(player.stamina<12||player.parryCd>0||player.dash>0)return false;
    player.stamina-=12;player.parry=.3;player.parryCd=.65;
    emit(state,'guard',{actor:index});return true;
  }
  if(type==='revive')return revivePlayer(state,index,emit);
  if(type!=='attack'&&type!=='special')return false;
  const spec=attackSpec(player,type);
  if(!spec)return false;
  const targets=state.enemies.map((enemy,enemyIndex)=>({enemy,index:enemyIndex,d:distance(player,enemy)}))
    .filter(target=>target.enemy.hp>0).sort((a,b)=>a.d-b.d||a.index-b.index);
  if(!targets.length||!spendAttack(player,type))return false;
  const nearest=targets[0];
  if(nearest.d<=spec.reach+.5)player.yaw=Math.atan2(nearest.enemy.x-player.x,nearest.enemy.z-player.z);
  const special=type==='special';
  const riposte=player.riposte>0;
  const amount=attackDamage(player,{special,riposte});
  player.attackCd=spec.cooldown;player.attackAnim=spec.animation;state.started=true;
  emit(state,'swing',{actor:index,magic:player.weapon==='staff',special,riposte});
  for(const target of targets){
    if(target.d>spec.reach||!clearStrikePath(player,target.enemy))continue;
    const actual=hitEnemy(state,target.index,amount,{actor:index,magic:player.weapon==='staff',special,riposte},emit);
    applyAttackRecovery(player,actual,{special});
    if(!special)break;
  }
  player.riposte=0;
  return true;
}

function movePlayer(player,dt,input){
  if(!player||player.hp<=0||player.dead||player.down>0)return;
  const vector=normalizeInput(input);
  const magnitude=Math.hypot(vector.x,vector.z);
  const dashTime=Math.min(dt,Math.max(0,player.dash));
  if(dashTime>0){
    const direction=normalizeInput({x:player.dx,z:player.dz});
    moveActor(player,direction.x*dashTime*14,direction.z*dashTime*14);
    player.speed=2;
  }
  if(magnitude>.05&&dashTime<dt){
    player.dx=vector.x/magnitude;player.dz=vector.z/magnitude;
    player.yaw=Math.atan2(vector.x,vector.z);
    moveActor(player,vector.x*(dt-dashTime)*3.6,vector.z*(dt-dashTime)*3.6);
    if(dashTime===0)player.speed=magnitude;
  }
}

function finish(state){
  if(state.enemies.every(enemy=>enemy.hp<=0)){
    state.phase='victory';emit(state,'victory');
  }else if(state.players.every(player=>player.hp<=0||player.dead)){
    state.phase='defeat';
    state.players.forEach((player,index)=>{
      if(!player.dead){player.hp=0;player.down=0;player.dead=true;emit(state,'death',{actor:index});}
    });
    emit(state,'defeat');
  }
}

/** Small simulation slices retain short defensive windows during slow frames. */
export function step(state,dt,input={},index=0){
  if(state?.phase!=='active')return;
  const elapsed=clamp(finite(dt,0),0,1);
  if(elapsed===0){finish(state);return;}
  const count=Math.ceil(elapsed/MAX_STEP),slice=elapsed/count;
  const selected=Number.isInteger(index)&&index>=0&&index<state.players.length?index:0;
  for(let tick=0;tick<count&&state.phase==='active';tick++){
    state.time=finite(state.time,0)+slice;
    for(const player of state.players)player.speed=0;
    movePlayer(state.players[selected],slice,input);
    // Optional per-player vectors let the authoritative room server drive both heroes.
    if(Array.isArray(input?.players))input.players.forEach((vector,actor)=>{
      if(actor!==selected&&vector)movePlayer(state.players[actor],slice,vector);
    });
    updateCompanion(state,slice,selected,{moveActor,command,emit});
    updateEnemies(state,slice,{moveActor,emit,strike:resolveEnemyStrike});
    for(const player of state.players){
      for(const key of PLAYER_TIMERS)player[key]=Math.max(0,finite(player[key],0)-slice);
      if(player.hp>0&&!player.dead)player.stamina=Math.min(100,finite(player.stamina,0)+slice*17);
    }
    tickDowned(state,slice,emit);
    finish(state);
  }
}
