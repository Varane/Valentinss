// Mutable damage/rescue helpers. Simulation time and event IDs belong to action.mjs.
const finite = (value, fallback = 0) => Number.isFinite(value) ? value : fallback;
const positive = value => Math.max(0, finite(value));
const actorAt = (actors, index) => Array.isArray(actors) && Number.isInteger(index) && index >= 0 ? actors[index] : undefined;
const living = actor => !!actor && !actor.dead && Number.isFinite(actor.hp) && actor.hp > 0;
const positioned = actor => actor && Number.isFinite(actor.x) && Number.isFinite(actor.z);
const distance = (a,b) => positioned(a) && positioned(b) ? Math.hypot(a.x-b.x,a.z-b.z) : Infinity;
const point = actor => positioned(actor) ? {x:actor.x,z:actor.z} : {};
const dispatch = (emit,state,type,data) => { if (typeof emit === 'function') emit(state,type,data); };
function facing(actor,target) {
  if (!positioned(actor) || !positioned(target) || !Number.isFinite(actor.yaw)) return false;
  const dx=target.x-actor.x,dz=target.z-actor.z,d=Math.hypot(dx,dz);
  return d < 1e-9 || (Math.sin(actor.yaw)*dx+Math.cos(actor.yaw)*dz)/d >= .5-1e-10;
}
function enemyToPlayer(state,enemyIndex,playerIndex) {
  return {actor:playerIndex,enemy:enemyIndex,source:enemyIndex,target:playerIndex,sourceType:'enemy',targetType:'player',...point(state.players[playerIndex])};
}

export function hitEnemy(state,enemyIndex,amount,options={},emit) {
  const enemy=actorAt(state?.enemies,enemyIndex);
  if (!living(enemy) || !Number.isFinite(amount) || amount <= 0) return 0;
  options=options||{};
  const actual=Math.min(enemy.hp,amount);
  enemy.hp=Math.max(0,enemy.hp-actual);enemy.hurt=.22;
  if(options.riposte)enemy.stun=Math.max(positive(enemy.stun),.45);
  const data={enemy:enemyIndex,target:enemyIndex,targetType:'enemy',amount:actual,magic:!!options.magic,special:!!options.special,riposte:!!options.riposte,finisher:enemy.hp===0,...point(enemy)};
  if(Number.isInteger(options.actor)){data.actor=options.actor;data.source=options.actor;data.sourceType='player';}
  dispatch(emit,state,'hit',data);
  if(enemy.hp===0)dispatch(emit,state,'kill',{...data});
  return actual;
}

export function hitPlayer(state,playerIndex,rawDamage,options={},emit) {
  const player=actorAt(state?.players,playerIndex);
  if(!living(player)||!Number.isFinite(rawDamage)||rawDamage<=0)return 0;
  const actual=Math.min(player.hp,Math.max(2,rawDamage-positive(player.defense)));
  player.hp=Math.max(0,player.hp-actual);player.hurt=.26;
  const data={actor:playerIndex,target:playerIndex,targetType:'player',amount:actual,...point(player)};
  const enemyIndex=options?.enemy;
  if(Number.isInteger(enemyIndex)){data.enemy=enemyIndex;data.source=enemyIndex;data.sourceType='enemy';}
  dispatch(emit,state,'hurt',data);
  if(player.hp===0){player.down=9;dispatch(emit,state,'down',{...data});}
  return actual;
}

export function resolveEnemyStrike(state,enemyIndex,emit) {
  const enemy=actorAt(state?.enemies,enemyIndex);
  if(!living(enemy))return false;
  const playerIndex=enemy.target,player=actorAt(state?.players,playerIndex);
  if(!living(player)||distance(enemy,player)>(enemy.boss?2.5:2.25)||!facing(enemy,player))return false;
  const data=enemyToPlayer(state,enemyIndex,playerIndex);
  if(positive(player.invuln)>0)dispatch(emit,state,'evade',data);
  else if(positive(player.parry)>0&&facing(player,enemy)){
    enemy.stun=Math.max(positive(enemy.stun),1.4);player.riposte=Math.max(positive(player.riposte),2.3);
    player.stamina=Math.min(100,positive(player.stamina)+18);
    dispatch(emit,state,'parry',{...data,source:playerIndex,target:enemyIndex,sourceType:'player',targetType:'enemy'});
  }else hitPlayer(state,playerIndex,enemy.damage,{enemy:enemyIndex},emit);
  return true;
}

export function revivePlayer(state,rescuerIndex,emit) {
  const rescuer=actorAt(state?.players,rescuerIndex);
  if(!living(rescuer)||!positioned(rescuer))return false;
  let targetIndex=-1,nearest=Infinity;
  for(let i=0;i<state.players.length;i++){
    const target=state.players[i];
    if(i===rescuerIndex||!target||target.dead||!Number.isFinite(target.hp)||target.hp>0||positive(target.down)<=0||positive(target.maxHp)<=0)continue;
    const d=distance(rescuer,target);
    if(d<=2.5&&d<nearest){nearest=d;targetIndex=i;}
  }
  if(targetIndex<0)return false;
  const target=state.players[targetIndex],strong=Array.isArray(rescuer.skills)&&rescuer.skills.includes('guard3');
  target.hp=Math.min(target.maxHp,Math.ceil(target.maxHp*(strong?.7:.35)));target.down=0;target.invuln=Math.max(positive(target.invuln),.7);
  dispatch(emit,state,'revive',{actor:targetIndex,source:rescuerIndex,target:targetIndex,sourceType:'player',targetType:'player',...point(target)});
  return true;
}

export function tickDowned(state,dt,emit) {
  if(!Array.isArray(state?.players)||!Number.isFinite(dt)||dt<=0)return;
  for(let i=0;i<state.players.length;i++){
    const player=state.players[i];
    if(!player)continue;
    if(player.dead){player.hp=0;player.down=0;continue;}
    if(positive(player.down)<=0)continue;
    if(player.hp>0){player.down=0;continue;}
    player.down=Math.max(0,player.down-dt);
    if(player.down===0){player.hp=0;player.dead=true;dispatch(emit,state,'death',{actor:i,target:i,targetType:'player',...point(player)});}
  }
}
