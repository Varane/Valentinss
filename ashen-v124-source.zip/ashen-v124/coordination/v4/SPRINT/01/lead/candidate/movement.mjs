// Shared actor-centre collision geometry. The 0.85 clearance preserves the
// original simulation's combined pillar/body collision radius.
export const PILLARS = [[-4, -2.5], [4, -2.5], [-4, 3], [4, 3]];
const RADIUS = 0.85;
const SKIN = 1e-9;
const EPSILON = 1e-12;
const finite = value => Number.isFinite(value) ? value : 0;
const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

/** Keep analog input below unit length and reject nonnumeric/nonfinite axes. */
export function normalizeInput(input) {
  let x = finite(input?.x), z = finite(input?.z);
  const scale = Math.max(Math.abs(x), Math.abs(z));
  if (scale === 0) return { x: 0, z: 0 };
  // Scaling first avoids overflow for finite values near Number.MAX_VALUE.
  const length = Math.hypot(x / scale, z / scale);
  if (scale > 1 / length) {
    x = (x / scale) / length;
    z = (z / scale) / length;
  }
  return { x, z };
}

function repairPosition(actor) {
  actor.x = clamp(finite(actor.x), -6, 6);
  actor.z = clamp(finite(actor.z), -5, 5);
  for (const [px, pz] of PILLARS) {
    const x = actor.x - px, z = actor.z - pz;
    const distance = Math.hypot(x, z);
    if (distance < RADIUS) {
      const nx = distance > EPSILON ? x / distance : 1;
      const nz = distance > EPSILON ? z / distance : 0;
      actor.x = px + nx * (RADIUS + SKIN);
      actor.z = pz + nz * (RADIUS + SKIN);
    }
  }
}

/** Sweep the complete displacement, stop at first contact, then slide.
 * No frame-size substeps are needed: even a long dash cannot cross a pillar.
 * Malformed actor coordinates are repaired; a missing actor is a safe no-op.
 */
export function moveActor(actor, dx, dz) {
  if (!actor || typeof actor !== 'object') return actor;
  repairPosition(actor);
  dx = finite(dx); dz = finite(dz);
  const scale = Math.max(Math.abs(dx), Math.abs(dz));
  if (scale === 0) return actor;
  const length = Math.hypot(dx / scale, dz / scale);
  let ux = (dx / scale) / length, uz = (dz / scale) / length;
  let remaining = Math.min(Number.MAX_VALUE, scale * length);

  // Four separated circles and a convex room require only a few contacts.
  // The bound also prevents an externally malformed request from monopolising
  // a frame. Unconsumed motion is safely discarded if the bound is reached.
  for (let contact = 0; contact < 12 && remaining > EPSILON; contact++) {
    let hit = remaining, nx = 0, nz = 0, blocked = false, pillarHit = false;
    const consider = (distance, normalX, normalZ, pillar = false) => {
      if (distance >= -SKIN && distance <= hit && ux * normalX + uz * normalZ < -EPSILON) {
        hit = Math.max(0, distance); nx = normalX; nz = normalZ; blocked = true; pillarHit = pillar;
      }
    };
    if (ux > 0) consider((6 - actor.x) / ux, -1, 0);
    else if (ux < 0) consider((-6 - actor.x) / ux, 1, 0);
    if (uz > 0) consider((5 - actor.z) / uz, 0, -1);
    else if (uz < 0) consider((-5 - actor.z) / uz, 0, 1);

    for (const [px, pz] of PILLARS) {
      const x = actor.x - px, z = actor.z - pz;
      const along = x * ux + z * uz;
      if (along >= 0) continue;
      const perpendicular = x * uz - z * ux;
      const discriminant = RADIUS * RADIUS - perpendicular * perpendicular;
      if (discriminant < 0) continue;
      const distance = -along - Math.sqrt(discriminant);
      if (distance < -SKIN || distance > hit) continue;
      const hx = x + ux * Math.max(0, distance);
      const hz = z + uz * Math.max(0, distance);
      const normalLength = Math.hypot(hx, hz);
      if (normalLength > EPSILON) consider(distance, hx / normalLength, hz / normalLength, true);
    }

    actor.x += ux * hit;
    actor.z += uz * hit;
    if (!blocked) break;
    actor.x += nx * SKIN;
    actor.z += nz * SKIN;
    const into = ux * nx + uz * nz;
    const tx = ux - nx * into, tz = uz - nz * into;
    const tangentLength = Math.hypot(tx, tz);
    // A radial circle hit can leave a roundoff-sized false tangent. Do not
    // amplify it by a huge requested distance; wall tangents remain exact
    // and must retain even a very small but meaningful second axis.
    if (tangentLength === 0 || (pillarHit && tangentLength <= EPSILON)) break;
    remaining = Math.max(0, remaining - hit) * Math.min(1, tangentLength);
    ux = tx / tangentLength; uz = tz / tangentLength;
  }
  // Remove only final floating-point drift, including exact tangent contacts.
  repairPosition(actor);
  return actor;
}

/** Centre-to-centre visibility against the authored .5-radius solid pillars. */
export function clearStrikePath(a,b){
  if(!a||!b||![a.x,a.z,b.x,b.z].every(Number.isFinite))return false;
  const dx=b.x-a.x,dz=b.z-a.z,lengthSq=dx*dx+dz*dz;
  if(lengthSq===0)return true;
  return !PILLARS.some(([px,pz])=>{
    const t=Math.max(0,Math.min(1,((px-a.x)*dx+(pz-a.z)*dz)/lengthSq));
    return Math.hypot(a.x+t*dx-px,a.z+t*dz-pz)<.5;
  });
}
