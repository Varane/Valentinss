import {readFile} from 'node:fs/promises';
const dist=new URL('../../../../../dist/',import.meta.url);
const data=source=>'data:text/javascript;base64,'+Buffer.from(source).toString('base64');
export async function loadCombat(candidate=false){
  let action=await readFile(new URL('action.mjs',dist),'utf8');
  let ai=await readFile(new URL('combat/ai.mjs',dist),'utf8');
  let damage=await readFile(new URL('combat/damage.mjs',dist),'utf8');
  if(candidate){
    ai=ai.replace('if(enemy.windup>0){','if(enemy.windup>0){\n      const impactOffset=dt-activeDt+enemy.windup;');
    ai=ai.replace('strike(state,index,emit);','strike(state,index,emit,impactOffset);');
    damage=damage.replace('resolveEnemyStrike(state,enemyIndex,emit) {','resolveEnemyStrike(state,enemyIndex,emit,impactOffset=0) {\n  impactOffset=positive(impactOffset);');
    damage=damage.replace('positive(player.invuln)>0','positive(player.invuln)>impactOffset');
    damage=damage.replace('positive(player.parry)>0','positive(player.parry)>impactOffset');
  }
  const damageUrl=data(damage),aiUrl=data(ai);
  action=action.replace("import {createGame,stats} from './rules.mjs';", "const createGame=()=>({heroes:[0,1].map(id=>({id,hp:100,mana:6,skills:[],weapon:'blade',armor:'cloth'}))}); const stats=()=>({maxHp:100,maxMana:6,attack:12,defense:0});");
  action=action.replace("'./combat/damage.mjs'",JSON.stringify(damageUrl)).replace("'./combat/ai.mjs'",JSON.stringify(aiUrl));
  action=action.replaceAll("from './combat/", "from '"+new URL('combat/',dist).href);
  return {...await import(data(action)),damage:await import(damageUrl)};
}
export function fixture(encounter,{windup=.1,stun=0}={}){
  const state=encounter(undefined,{enemies:[{x:0,z:1.2,hp:100,damage:20,cooldown:2}]});
  state.companionAI=false;state.started=true;
  Object.assign(state.players[0],{x:0,z:0,yaw:0,dx:0,dz:0,defense:0});
  Object.assign(state.players[1],{x:5,z:4});
  Object.assign(state.enemies[0],{target:0,yaw:Math.PI,windup,stun});
  return state;
}
