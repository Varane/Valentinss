import {readFile} from 'node:fs/promises';
const action=new URL('../../../../../dist/action.mjs',import.meta.url);
let src=await readFile(action,'utf8');
src=src.replace("import {createGame,stats} from './rules.mjs';", "const createGame=()=>({heroes:[0,1].map(id=>({id,hp:100,mana:6,skills:[],weapon:'blade',armor:'cloth'}))}); const stats=()=>({maxHp:100,maxMana:6,attack:12,defense:0});");
src=src.replaceAll("from './combat/", "from '"+new URL('./combat/',action).href);
const {encounter,command,step}=await import('data:text/javascript;base64,'+Buffer.from(src).toString('base64'));
for (const [kind,impact] of [['parry',.1],['dash',.1],['parry',.301],['dash',.331]]) {
 const s=encounter(undefined,{enemies:[{x:0,z:1.2,hp:100,damage:20,cooldown:2}]});s.companionAI=false;s.started=true;
 Object.assign(s.players[0],{x:0,z:0,yaw:0,dx:0,dz:0,defense:0});Object.assign(s.players[1],{x:5,z:4});
 Object.assign(s.enemies[0],{target:0,yaw:Math.PI,windup:impact});const hp=s.players[0].hp;
 command(s,kind,0);step(s,.34,{},0);console.log(JSON.stringify({kind,impact,hpBefore:hp,hpAfter:s.players[0].hp,events:s.events.map(e=>e.type)}));
}
