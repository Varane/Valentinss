import {encounter,command,step} from '../../../../../dist/action.mjs';
import {createGame} from '../../../../../dist/rules.mjs';
for (const [kind,impact] of [['parry',.1],['dash',.1],['parry',.301],['dash',.331]]) {
 const s=encounter(createGame(),{enemies:[{x:0,z:1.2,hp:100,damage:20,cooldown:2}]});s.companionAI=false;s.started=true;
 Object.assign(s.players[0],{x:0,z:0,yaw:0,dx:0,dz:0,defense:0});Object.assign(s.players[1],{x:5,z:4});
 Object.assign(s.enemies[0],{target:0,yaw:Math.PI,windup:impact});const hp=s.players[0].hp;
 command(s,kind,0);step(s,.34,{},0);console.log(JSON.stringify({kind,impact,hpBefore:hp,hpAfter:s.players[0].hp,events:s.events.map(e=>e.type)}));
}

