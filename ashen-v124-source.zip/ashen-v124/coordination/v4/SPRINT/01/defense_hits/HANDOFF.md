# Defense hit acceptance — owner-fix-needed

Completed the four bounded gates. No production implementation or other tests were written. Acceptance is **not met by current source**: four committed-strike timing regressions remain owner-fix-needed. Proposed patch is verified only in memory.

## Concrete result

Dash grants .33s invulnerability and parry .3s at `dist/action.mjs:72` / `:77`. A committed strike landing at .301s after parry, or .331s after dash, still emits parry/evade and leaves HP100 instead of expected HP80 when `step(state,.34,{})` is used. The same incorrect protection occurs when enemy stun .051s ends within a simulation slice before the committed strike. This is a late-window extension bounded by MAX_STEP=1/120s (8.33ms), **not a long-frame damage regression**.

`dist/action.mjs:150` resolves enemies before player timer decay at `:152`. `dist/combat/ai.mjs:51-56` knows windup impact time but drops the offset. `dist/combat/damage.mjs:46-53` then checks slice-start invuln/parry. Enemy geometry, cancellation, player attack timing, and telegraph behavior were outside scope.

Inside-window .1s impacts correctly parry/evade even in a .34s frame. Down (HP0/down9) and dead (HP0/dead) heroes take no direct or committed-strike damage and emit no hurt; their defensive commands are rejected. Facing-away parry takes damage; dash clears parry and evade takes priority. These checks passed against current source. No claim is made for malformed HP-positive down states.

## Commands and exact acceptance

From repository root:

```powershell
node --test tests/sprint-01-defense-hits.test.mjs
# 11 tests: 5 pass, 4 fail, 2 skipped; failed tests labeled owner-fix-needed.
# The two skips explicitly require the proposed optional impactOffset API.
$env:DEFENSE_CANDIDATE='1'
node --test tests/sprint-01-defense-hits.test.mjs
# 11 tests: 11 pass, 0 fail, 0 skipped.
Remove-Item Env:DEFENSE_CANDIDATE
```

Full outputs: `current-results.txt` and `candidate-results.txt` in this folder. Current failures are the two late-impact checks plus two partial-slice-stun checks. Candidate additionally verifies direct exact-boundary expiry for each defense. Candidate comparisons use strict timer > impactOffset; a three-argument resolver call retains its old immediate-impact semantics.

Native `node coordination/v4/SPRINT/01/defense_hits/repro.mjs` is blocked by `ERR_MODULE_NOT_FOUND: dist/campaign/save.mjs` imported by `dist/rules.mjs`. That unrelated owner dependency was still absent at 21:41:33 UTC. `harness.mjs` loads the actual current action/AI/damage source with only rules createGame/stats replaced by deterministic fixture functions; movement and skill imports stay real. Candidate mode changes only source strings in memory. This isolation and its limitation are explicit; this is not a full production import or browser check.

## Small exact proposal

`proposal.patch` adds one optional fourth argument to resolveEnemyStrike. AI captures `impactOffset=dt-activeDt+oldWindup` before decrementing windup and passes it only when the committed strike resolves. The offset includes a stun ending within this slice. Resolver compares invuln/parry against this offset, defaulting to zero for existing callers. No change to action.mjs is needed. Owner must apply/review and rerun full relevant suites; no implementation was applied here.

## Source evidence

SHA256 read at first gate and unchanged on recheck 2026-11-11T21:41:33Z:

| File | SHA256 |
| --- | --- |
| dist/action.mjs | 63096B8BD8815D35C8DD3B666B7B7CC9DAADA425200A02893FD5E937134AC97A |
| dist/combat/ai.mjs | A6A88ABC6F441139F551D740F5DFC34053544358EF694FAAB816A31DA8DAC4FA |
| dist/combat/damage.mjs | CCE372BBA8AAD96830B38B9B650711BD3E925E6F9D589836170D070631CD70D7 |

No browser, FPS, production integration, or iPhone claim. No server, commit, chat, or subagent was started.
