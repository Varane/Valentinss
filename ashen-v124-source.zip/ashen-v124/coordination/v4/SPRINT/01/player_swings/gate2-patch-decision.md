# Gate 2 — patch decision

No implementation patch is warranted by this bounded check.

Current normal attacks use instantaneous command-time resolution. dist/action.mjs:82-98 obtains attackSpec, spends resources once, sets timers, emits swing, invokes hitEnemy once, and breaks after the first eligible normal-attack target. dist/combat/skills.mjs:9-17 rejects attackCd > 0, costs 12 stamina, grants one mana, defines cooldown .4 seconds and visual animation .42 seconds. dist/action.mjs:151-153 decays these timers; it never reapplies player attack damage from animation time.

No current owner contract reviewed requires a separate authored player startup/active window. The original owner test tests/action.test.mjs explicitly expects nearby enemy HP to decrease synchronously after command(). Changing this to delayed damage would be a new gameplay/API decision and would conflict with that existing expectation. The .02-second animation overlap is therefore recorded, not labeled a defect.

Behavior characterized by executable checks: zero simulated startup; one instantaneous damaging evaluation per accepted normal command; .4-second command recovery; .42-second animation; at most one enemy hit; no damage when a previously missed enemy enters range later; no resource/event mutation from rejected cooldown or low-stamina commands.

No proposed patch; no owner-fix-needed regression.

The focused loader reads current dist/action.mjs, substitutes only the unused rules createGame/stats imports with throwing guards, redirects the original combat imports to their actual file URLs, and executes its command/step exports. It never calls encounter(). The rules dependency tree was temporarily incomplete at first inspection (campaign/save.mjs missing), so native integration is separately rechecked in Gate 3. No implementation files are written.
