import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';

// Scope: execute current action command/step and real combat modules without
// importing the unrelated rules save/progression tree. encounter() is not used.
export async function loadPlayerSwingApi(){
  const actionUrl=new URL('../../../../../dist/action.mjs',import.meta.url);
  const original=await readFile(actionUrl,'utf8');
  const rulesImport="import {createGame,stats} from './rules.mjs';";
  assert.ok(original.includes(rulesImport),'revisit isolated loader if action imports change');
  let source=original.replace(rulesImport,`const createGame=()=>{throw new Error('encounter creation outside focused swing harness')};const stats=createGame;`);
  source=source.replace(/from '(\.\/combat\/[^']+)'/g,(_,relative)=>`from '${new URL(relative,actionUrl).href}'`);
  const api=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
  return {...api,sourceHash:createHash('sha256').update(original).digest('hex')};
}
