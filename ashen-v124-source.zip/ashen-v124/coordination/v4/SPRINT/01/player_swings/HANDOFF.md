# Player swings — Sprint 01 handoff

Completed 2026-11-11 before 21:43 UTC. Scoped writes only: this folder and tests/sprint-01-player-swings.test.mjs. No implementation edit or proposed patch.

## Result

The current API has instantaneous player attack resolution: command('attack') immediately removes HP and emits swing/hit at unchanged simulation time. There is no separate simulated player startup or sustained active phase. The normal command recovery is .4 seconds; its .42-second attackAnim is visual duration and does not cause subsequent hits. A newly eligible command may start while .02 seconds of the preceding animation remains.

This is documented current behavior, not classified as a defect: tests/action.test.mjs:8 explicitly expects damage immediately after command(), and the reviewed MASTER/HANDOFF does not require authored player startup/active durations. No unconditional failing delayed-startup regression was added.

Focused actual-source regression results: 7 passed, 0 failed. The checks establish one hit per normal swing, at most one target, no repeated passive damage while animation runs, cooldown enforcement before .4 seconds and acceptance just after it while animation remains, no lingering hit on a whiff, and unchanged resources/events/state for rejected repeated or low-stamina commands. No at-most-once defect found; no player-swing owner fix required.

## Files and source anchors

- tests/sprint-01-player-swings.test.mjs — executable regressions.
- coordination/v4/SPRINT/01/player_swings/load-action.mjs — focused loader.
- dist/action.mjs:82-98 — preview, spend, timers, swing event, one-shot hit loop; normal attacks break after first eligible target.
- dist/action.mjs:151-153 — timer and stamina updates; no player hit replay.
- dist/combat/skills.mjs:9-18 — cooldown/resource gating and normal cooldown .4 / animation .42.
- dist/combat/damage.mjs:22-32 — hitEnemy removes actual HP once and emits one hit per invocation.
- tests/action.test.mjs:8 — existing immediate-damage API expectation.

Action SHA-256: 63096b8bd8815d35c8dd3b666b7b7cc9daada425200a02893fd5e937134ac97a
Skills SHA-256: 8b12d4bcf134552227740439b39ae8bef41365c5ea07dab0c4c87b42b6083ac5
Damage SHA-256: cce372bba8aad96830b38b9b650711bd3e925e6f9d589836170d070631cd70d7
All six recorded hashes remained unchanged at Gate 3 (see source-hashes.json and gate3-source-recheck.json).

## Actual verification commands and output

Repository working directory: C:/Users/Valen/Documents/Codex/2026-11-11/referenced-chatgpt-conversation-this-is-an/work/ashen-room

Command: node --test tests/sprint-01-player-swings.test.mjs
Gate 1: exit 0, tests 7, pass 7, fail 0, duration_ms 3826.9649 (gate1-test.log).
Gate 3: exit 0, tests 7, pass 7, fail 0, duration_ms 3422.1334 (gate3-focused.log).

Command: node --test tests/action.test.mjs tests/action-skills.test.mjs
Gate 3: exit 1, test files 2, pass 0, fail 2, duration_ms 7556.5899.
Both fail before test bodies: ERR_MODULE_NOT_FOUND dist/campaign/save.mjs imported from dist/rules.mjs. Exact stack/output is in gate3-owner-tests.log. This is an external integration dependency blocker, not a failed player-swing regression. The campaign/rules owner needs to restore the dependency before native integration suites can run.

## Harness limits

The focused loader reads current dist/action.mjs, replaces only its unused createGame/stats rules import with throwing guards, rewrites combat import locations to their actual file URLs, and imports the resulting source in memory. It calls the actual command/step exports and real combat modules. Tests build inert single-player fixtures; encounter() and RPG persistence are not exercised. This avoids falsely reporting the blocked native import as successful integration. It also isolates this check from enemy attacks and companion decisions.

Gate 2 decision is in gate2-patch-decision.md; no implementation patch proposed. Gates 1/2/3 each have immutable result JSON and the final status is status.json. No server, browser, FPS, enemy-windup, parry, or collision-geometry verification is claimed.
