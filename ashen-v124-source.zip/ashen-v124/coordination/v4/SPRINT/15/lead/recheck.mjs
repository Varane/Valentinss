import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
const dir='coordination/v4/SPRINT/15/lead';
const source=fs.readFileSync('dist/action-game.mjs','utf8');
const callbacks='getMusicEnabled:music.getEnabled,getMusicVolume:music.getVolume,setMusicVolume:music.setVolume,setMusicEnabled:value=>{if(value){const unlocking=music.unlock();music.setEnabled(true);void unlocking;}else music.setEnabled(false);},';
const candidate="const music=createMusic({volume:.2});\n"+source.replace('ui=createUI({','ui=createUI({'+callbacks);
fs.writeFileSync(dir+'/candidate-runtime.mjs',candidate);
const statusPath='coordination/v4/SPRINT/15/status.json';
const status=JSON.parse(fs.readFileSync(statusPath,'utf8'));
Object.assign(status,{updatedAt:new Date().toISOString(),cycle:2,percent:50,artifact:dir+'/runtime-music.patch',check:'Exact callback patch against current runtime',result:'Proposed only; main source unchanged',nextFiniteTask:'Run actual and isolated candidate regressions'});
fs.writeFileSync(statusPath,JSON.stringify(status,null,2));
const results=[];
for(const [name,files,extraEnv] of [
  ['actual',['tests/sprint-15-runtime.test.mjs','tests/sprint-15-campaign.test.mjs','tests/sprint-15-music.test.mjs'],{}],
  ['candidate-callback-only',['tests/sprint-15-runtime.test.mjs'],{SPRINT15_RUNTIME:path.resolve(dir+'/candidate-runtime.mjs')}],
]) {
  const run=spawnSync(process.execPath,['--test',...files],{encoding:'utf8',env:{...process.env,...extraEnv},timeout:30000});
  fs.writeFileSync(dir+'/'+name+'.tap',(run.stdout||'')+(run.stderr||''));
  results.push({name,exitCode:run.status,error:run.error?.message,files});
}
const evidence={at:new Date().toISOString(),runtimeSha256:crypto.createHash('sha256').update(source).digest('hex'),missing:['dist/music/score-data.mjs','dist/campaign/save.mjs'].filter(p=>!fs.existsSync(p)),results,candidateLimit:'Only runtime callback boundary verified with inert rendering/audio mocks; candidate is not integrated or a playback test.'};
fs.writeFileSync(dir+'/cycle-3-results.json',JSON.stringify(evidence,null,2));
Object.assign(status,{updatedAt:new Date().toISOString(),cycle:3,percent:75,artifact:dir+'/cycle-3-results.json',check:'Actual owner source and isolated candidate rerun',result:evidence,nextFiniteTask:'Finalize acceptance handoff and record interrupted worker stops'});
fs.writeFileSync(statusPath,JSON.stringify(status,null,2));
console.log(JSON.stringify(evidence,null,2));
