const music=createMusic({volume:.2});
import * as T from 'three';
import {makeFigure} from './figures.mjs';
import {encounter,step,command} from './action.mjs';
import {createWorld} from './world.mjs';
import {createCameraRig} from './camera-rig.mjs';
import {createEffects} from './effects.mjs';
import {createUI} from './ui.mjs';
import {createInput} from './input.mjs';
import {createCampaign,roomFor,prepareEncounter,chooseRoom,resolveRoom,restartCampaign} from './campaign.mjs';
import {restoreSave,stats,level,equip,learn,ITEMS} from './rules.mjs';

const $=id=>document.getElementById(id);
const mobile=innerWidth<701,reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
const PROFILE_KEY='ashen-blood-v2',CAMPAIGN_KEY='ashen-campaign-v4',OPTIONS_KEY='ashen-action-options-v4';
let profile,options={blood:true,sound:true},savedCampaign=null;
try{profile=restoreSave(localStorage.getItem(PROFILE_KEY));try{savedCampaign=JSON.parse(localStorage.getItem(CAMPAIGN_KEY)||'null');}catch{}try{Object.assign(options,JSON.parse(localStorage.getItem(OPTIONS_KEY)||'{}'));}catch{}}catch{profile=restoreSave(null);}
profile.phase='camp';profile.started=false;
let campaign=createCampaign(profile,savedCampaign),selected=0,paused=false,settled=false,ui,input,fx,world,rig,currentRoom;
profile.campaign=campaign;
let battle,figures=[],enemyFigures=[],enemyLabels=[],last=performance.now(),elapsed=0,hudTimer=0,saveTimer=0,destination=null,network=null;
let blood=options.blood!==false,booted=false,storageWarning=false;
const scene=new T.Scene();scene.background=new T.Color('#172329');scene.fog=new T.FogExp2('#172329',.032);
const renderer=new T.WebGLRenderer({canvas:$('scene'),antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio,mobile?1.5:1.8));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.16;
const camera=new T.PerspectiveCamera(mobile?48:42,innerWidth/innerHeight,.1,70);
const figuresRoot=new T.Group();scene.add(figuresRoot);
const raycaster=new T.Raycaster(),mouse=new T.Vector2();

function save(){try{localStorage.setItem(PROFILE_KEY,JSON.stringify(profile));localStorage.setItem(CAMPAIGN_KEY,JSON.stringify(campaign));localStorage.setItem(OPTIONS_KEY,JSON.stringify({...options,blood}));}catch{if(!storageWarning){ui?.notice('Этот браузер не разрешает сохранить прогресс.');storageWarning=true;}}}
function report(text){ui?.notice(text);}
function getRoom(){try{return roomFor(campaign);}catch(error){console.error('Campaign room:',error);throw error;}}
function reviveForRun(){for(const h of profile.heroes){if(h.dead||!h.weapon){h.dead=false;h.down=0;h.bag=['blade','cloth'];h.weapon='blade';h.armor='cloth';}h.hp=stats(h).maxHp;}}
function clearFigures(){for(const f of [...figures,...enemyFigures]){figuresRoot.remove(f.root);if(f.dispose)f.dispose();}figures=[];enemyFigures=[];for(const l of enemyLabels)l.remove();enemyLabels=[];}
function spawnRoom(){
  settled=false;destination=null;currentRoom=getRoom();battle=prepareEncounter(encounter(profile,currentRoom),campaign);
  // Campaign extensions may supply encounter metadata while the simulation owns the actor schema.
  if(currentRoom?.title){const title=document.querySelector('.scene-title>span');if(title)title.textContent=currentRoom.title.toUpperCase();}
  if(currentRoom?.subtitle)$('tutorial')?.querySelector('p')&&( $('tutorial').querySelector('p').textContent=currentRoom.subtitle );
  clearFigures();
  figures=battle.players.map((p,i)=>{const f=makeFigure({female:profile.heroes[i].id==='mage',weapon:p.weapon,armor:p.armor});figuresRoot.add(f.root);return f;});
  enemyFigures=battle.enemies.map((e,i)=>{const f=makeFigure({enemy:true,boss:!!e.boss,weapon:e.boss?'reaper':'blade',armor:e.boss?'plate':'chain'});figuresRoot.add(f.root);const label=document.createElement('div');label.className='enemy-label';label.innerHTML='<span></span><i><b></b></i>';$('enemy-labels').append(label);enemyLabels.push(label);return f;});
  selected=battle.players.findIndex(p=>p.hp>0);if(selected<0)selected=0;
  fx?.clear();$('outcome').hidden=true;$('tutorial')?.classList.remove('faded');ui?.update(battle,selected);save();
}
function updateStats(i){const h=profile.heroes[i],p=battle.players[i],s=stats(h),oldMax=p.maxHp,oldMana=p.maxMana||s.maxMana;p.maxHp=s.maxHp;p.hp=Math.min(s.maxHp,p.hp+Math.max(0,s.maxHp-oldMax));p.damage=s.attack;p.defense=s.defense;p.skills=[...h.skills];p.weapon=h.weapon;p.armor=h.armor;p.maxMana=s.maxMana;p.mana=Math.min(s.maxMana,(p.mana??h.mana??0)+Math.max(0,s.maxMana-oldMana));p.maxStamina=100;p.stamina=Math.min(100,p.stamina);figures[i].setEquipment(p.weapon,p.armor);}
function canPrepare(){return !battle.started||battle.phase!=='active';}
function equipHero(i,id){if(!canPrepare())throw Error('Снаряжение меняется до боя или после зачистки комнаты.');profile.phase='camp';profile.started=false;profile=equip(profile,i,id);updateStats(i);save();return profile;}
function learnSkill(i,id){if(!canPrepare())throw Error('Навыки изучаются до боя или после зачистки комнаты.');profile.phase='camp';profile.started=false;profile=learn(profile,i,id);updateStats(i);save();return profile;}
function switchHero(index=1-selected){if(!battle||battle.players[index]?.hp<=0)return;selected=index;destination=null;input?.clear();ui?.update(battle,selected);}
function perform(type){if(!battle||paused||ui?.isOpen()||battle.phase!=='active')return false;
  if(network?.connected)return network.action(type,selected);
  const success=command(battle,type,selected);
  if(!success&&type==='special'){const p=battle.players[selected];report(p.skills.some(s=>['blood3','arcane2'].includes(s))?'Не хватает выносливости.':'Изучите особый удар в дереве навыков.');}
  if(!success&&type==='revive')report('Подойдите к павшему товарищу ближе.');
  return success;
}
function endIndividualDeath(i){const h=profile.heroes[i];if(h.dead)return;h.dead=true;h.hp=0;h.down=0;h.bag=[];h.weapon=null;h.armor=null;figures[i]?.setEquipment(null,null);report(`${h.name} погиб. Опыт остался, вещи потеряны.`);save();}
function settle(){if(settled||battle.phase==='active')return;settled=true;const won=battle.phase==='victory';
  battle.players.forEach((p,i)=>{profile.heroes[i].hp=Math.max(0,Math.round(p.hp));profile.heroes[i].mana=p.mana;if(p.dead)endIndividualDeath(i);});
  try{const result=resolveRoom(profile,campaign,battle,won?'victory':'defeat');if(result?.profile)profile=result.profile;if(result?.campaign)campaign=result.campaign;save();ui.showOutcome({won,title:won?(result?.done?'Разлом закрыт.':'Комната ваша.'):'В этот раз — вы.',text:result?.rewardText||(won?'Добыча сохранена. Переберите снаряжение перед следующим залом.':'Опыт и навыки сохранены. Вещи погибших потеряны.')});}
  catch(error){console.error('Room resolution:',error);report('Не удалось завершить поход. Прогресс сохранён локально.');ui.showOutcome({won,title:won?'Победа.':'Поход окончен.',text:'Сохранение требует проверки. Перезагрузите страницу, чтобы продолжить.'});}
}
function restart(){paused=false;ui?.close();if(battle.phase==='defeat'||campaign.status==='complete'||campaign.done||campaign.completed){({profile,campaign}=restartCampaign(profile));}else if(battle.phase==='active'){report('Сначала завершите комнату.');return;}spawnRoom();}
function project(v){const p=v.clone().project(camera);return {x:(p.x*.5+.5)*innerWidth,y:(-.5*p.y+.5)*innerHeight,visible:p.z<1&&Math.abs(p.x)<1.4&&Math.abs(p.y)<1.4};}
function floating(text,p,hurt=false){const screen=project(new T.Vector3(p.x,1.7,p.z));const el=document.createElement('b');el.className=`damage-pop ${hurt?'hurt':''}`;el.textContent=text;el.style.left=`${screen.x}px`;el.style.top=`${screen.y}px`;$('damage-labels').append(el);setTimeout(()=>el.remove(),850);}
function processEvents(){const events=battle.events.splice(0);for(const event of events){fx.emit(event,battle);if(event.type==='hit')floating(`−${event.amount}`,battle.enemies[event.enemy]);if(event.type==='hurt')floating(`−${event.amount}`,battle.players[event.actor],true);if(event.type==='parry')report('ПАРИРОВАНИЕ · БЕЙ СЕЙЧАС');if(event.type==='down'){report('Товарищ повержен. Подойдите и нажмите F / «Спасти».');if(event.actor===selected)switchHero();}if(event.type==='death')endIndividualDeath(event.actor);if(event.type==='revive')report('Товарищ снова в бою.');}}
function drawActors(){
  battle.players.forEach((p,i)=>{const f=figures[i];f.root.position.set(p.x,0,p.z);f.root.rotation.y=p.yaw;f.animate(p,elapsed);});
  battle.enemies.forEach((e,i)=>{const f=enemyFigures[i];if(!f)return;f.root.position.set(e.x,0,e.z);f.root.rotation.y=e.yaw;f.animate(e,elapsed);const label=enemyLabels[i],pos=project(new T.Vector3(e.x,e.boss?2.45:2.2,e.z));label.hidden=e.hp<=0||!pos.visible;label.classList.toggle('windup',e.windup>0);label.style.left=`${pos.x}px`;label.style.top=`${pos.y}px`;label.querySelector('span').textContent=e.stun>0?'ОГЛУШЁН':e.windup>0?'ЗАМАХ':e.boss?'НАДСМОТРЩИК':'СТРАЖ';label.querySelector('b').style.width=`${e.hp/e.maxHp*100}%`;});
}
function frame(now){requestAnimationFrame(frame);const dt=Math.min((now-last)/1000,.05);last=now;if(!booted||document.hidden)return;elapsed+=dt;
  if(!paused&&!ui.isOpen()&&battle.phase==='active'){
    let vector=input.vector();
    if(destination&&Math.hypot(vector.x,vector.z)<.1){const p=battle.players[selected],dx=destination.x-p.x,dz=destination.z-p.z,d=Math.hypot(dx,dz);if(d>.18)vector={x:dx/d,z:dz/d};else destination=null;}
    if(network?.connected)network.move(vector,selected,dt);else {if(input.attackHeld())command(battle,'attack',selected);step(battle,dt,vector,selected);}
    if(battle.started)$('tutorial')?.classList.add('faded');processEvents();settle();
  }
  world.update(dt,elapsed);fx.update(dt,elapsed);drawActors();rig.update(dt,battle.players[selected],battle);renderer.render(scene,camera);
  hudTimer+=dt;saveTimer+=dt;if(hudTimer>.08){ui.update(battle,selected);hudTimer=0;const player=battle.players[selected];$('scene').dataset.position=`${player.x.toFixed(2)},${player.z.toFixed(2)}`;$('scene').dataset.phase=battle.phase;$('scene').dataset.health=String(Math.round(player.hp));$('scene').dataset.alive=String(battle.enemies.filter(e=>e.hp>0).length);}
  if(saveTimer>2&&battle.started){saveTimer=0;save();}
}
async function boot(){
  world=createWorld(scene,renderer,{mobile,reduced});rig=createCameraRig(camera,{mobile});fx=createEffects(scene,{reduced,blood});
  spawnRoom();
  ui=createUI({getMusicEnabled:music.getEnabled,getMusicVolume:music.getVolume,setMusicVolume:music.setVolume,setMusicEnabled:value=>{if(value){const unlocking=music.unlock();music.setEnabled(true);void unlocking;}else music.setEnabled(false);},getProfile:()=>profile,getEncounter:()=>battle,getSelected:()=>selected,selectHero:switchHero,onAction:perform,onEquip:equipHero,onLearn:learnSkill,onRestart:restart,onCamera:()=>rig.toggle(),onPause:value=>{paused=!!value;input?.clear();},getBlood:()=>blood,setBlood:value=>{blood=!!value;fx.setBlood(blood);save();}});
  input=createInput({canvas:$('scene'),onAction:perform,onMenu:type=>ui.open(type),onSwitch:()=>switchHero(),onCamera:()=>rig.toggle()});
  rig.update(1,battle.players[selected],battle);drawActors();renderer.render(scene,camera);booted=true;$('loading').hidden=true;requestAnimationFrame(frame);
}
boot().catch(error=>{console.error(error);$('load-text').textContent='Не удалось запустить 3D-комнату. Обновите страницу или попробуйте другой браузер.';});
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);rig?.resize(innerWidth,innerHeight);});
addEventListener('blur',()=>{input?.clear();});
document.addEventListener('visibilitychange',()=>{input?.clear();last=performance.now();});
$('scene').addEventListener('webglcontextlost',e=>{e.preventDefault();paused=true;report('3D-контекст прерван. Обновите страницу.');});
window.addEventListener('beforeunload',save);
if('serviceWorker' in navigator)addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
