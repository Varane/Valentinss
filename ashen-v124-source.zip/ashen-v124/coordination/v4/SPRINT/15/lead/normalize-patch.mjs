import fs from 'node:fs';
const file='dist/action-game.mjs';
const lines=fs.readFileSync(file,'utf8').split('\n');
const callbacks='getMusicEnabled:music.getEnabled,getMusicVolume:music.getVolume,setMusicVolume:music.setVolume,setMusicEnabled:value=>{if(value){const unlocking=music.unlock();music.setEnabled(true);void unlocking;}else music.setEnabled(false);},';
const edits=[
  [lines.findIndex(x=>x.startsWith('import {restoreSave')),x=>[x,"import {createMusic} from './music.mjs';"]],
  [lines.findIndex(x=>x.startsWith('const $=')),x=>[x,'const music=createMusic({volume:.2});']],
  [lines.findIndex(x=>x.includes('ui=createUI({')),x=>[x.replace('ui=createUI({','ui=createUI({'+callbacks).replace('paused=!!value;input?.clear();','paused=!!value;value?music.pause():music.resume();input?.clear();')]],
];
let offset=0;
let patch='--- a/'+file+'\n+++ b/'+file+'\n';
for(const [index,convert] of edits){
  if(index<0)throw Error('Owner source changed: rebase required');
  const replacement=convert(lines[index]);
  patch+='@@ -'+(index+1)+',1 +'+(index+1+offset)+','+replacement.length+' @@\n';
  patch+='-'+lines[index]+'\n'+replacement.map(x=>'+'+x+'\n').join('');
  offset+=replacement.length-1;
}
fs.writeFileSync('coordination/v4/SPRINT/15/lead/runtime-music.patch',patch);
console.log('Saved exact unified patch; implementation unchanged.');
