# Team09 — joystick geometry handoff

Started 2026-11-11 21:36:41 UTC. Final bounded gate 22:03:30 UTC. Four gates saved at 25/50/75/100%; cycle-1.md, cycle-2.json, cycle-3.json and cycle-4.json preserve the evidence. A runtime/tool update interrupted the 21:44 verification return; fresh candidate verification completed 22:03 UTC.

## Findings and exact proposal

`dist/input.mjs` reads current bounding geometry for each pointer move. Offset client coordinates, min-axis radius,12% radial deadzone, analog remapping and clamped touch diagonals already pass. `dist/ui/input/state.mjs` needs no geometry change.

Two root causes remain in production source:

1. `Math.max(1, ...)` creates a one-pixel movement radius after the joystick becomes zero-sized. A captured touch at313.2,430 then produces unit movement (x0.588752759028782) from a0×0 control. Neutral movement is required when geometry has no finite positive size.
2. Cached stick state survives window and visualViewport resize. Holding the right edge leaves x0.9999999999999999 after layout moves; no new pointer sample is needed to observe stale movement. Clearing existing input on those resize events requires a fresh touch and prevents old direction from surviving layout changes.

Exact two-hunk owner proposal: `coordination/v4/SPRINT/09/geometry/input-geometry.patch`. It adds a finite positive geometry guard and binds existing clear() to the two viewport resize signals. It changes no pure vector formula. Clear() intentionally releases all held sources, consistent with existing blur/pagehide behavior.

## Executable evidence

- Current production baseline: `node --test tests/input-controls-state.test.mjs tests/input-controls-dom.test.mjs` =>25tests,25pass,0fail,exit0.
- New production regression: `node --test tests/sprint-09-geometry.test.mjs` =>6tests,3pass,3fail,exit1. Failures are zero-sized geometry and the two resize signals.
- Isolated proposed module: `node coordination/v4/SPRINT/09/geometry/run-candidate.mjs` =>6tests,6pass,0fail,exit0. Permanent output: `candidate-verification.log` in this directory. Runner selects the candidate only for this suite and never resets status.
- `git apply --check --unidiff-zero coordination/v4/SPRINT/09/geometry/input-geometry.patch` =>exit0 against current owner source at22:03 UTC. This command checks applicability and does not apply anything.

Candidate file `input-candidate.mjs` is a copy of current production with the two proposal hunks and its state import relocated for the owned directory. `verify-proposal.mjs` generated the candidate and patch after confirming exact old fragments once each; rerunning it resets worker status to gate2, so use run-candidate.mjs for independent verification.

## Owner acceptance

D1 owner can review and apply the exact patch, then run `node --test tests/sprint-09-geometry.test.mjs tests/input-controls-state.test.mjs tests/input-controls-dom.test.mjs` plus the relevant gesture suite. Production should show6/6 geometry tests after integration. Root should check an actual viewport/orientation change during held movement on browser/phone. Node fake events establish the state transition only; they do not establish physical touch dispatch or device playability.

Only owned geometry artifacts and tests/sprint-09-geometry.test.mjs were written. No main implementation edit, commit, server, browser, publication or recursive agent work occurred. Production integration is pending with its owner.

Verified unchanged production input SHA256: FEE1C40B7E691E26D141BCC4D1A882B20949E6B2BA4C91AED136B9D40076FBE7, matching D1 handoff.
