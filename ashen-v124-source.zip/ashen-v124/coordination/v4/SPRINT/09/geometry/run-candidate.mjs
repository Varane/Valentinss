import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';

const result = spawnSync(process.execPath,['--test','tests/sprint-09-geometry.test.mjs'],{
  cwd:fileURLToPath(new URL('../../../../../',import.meta.url)),
  env:{...process.env,SPRINT09_INPUT_MODULE:new URL('input-candidate.mjs',import.meta.url).href},
  encoding:'utf8',
});
const output = `${result.stdout || ''}${result.stderr || ''}\nexitCode=${result.status}\n`;
writeFileSync(new URL('candidate-verification.log',import.meta.url),output);
process.stdout.write(output);
process.exitCode = result.status ?? 1;
