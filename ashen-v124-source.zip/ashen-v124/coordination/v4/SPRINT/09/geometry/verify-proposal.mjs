import {readFileSync,writeFileSync} from 'node:fs';

const source = readFileSync(new URL('../../../../../dist/input.mjs',import.meta.url),'utf8').replace(/\r\n/g,'\n');
const edits = [
  [
    "  function moveStick(event) {\n    const rect = joystick.getBoundingClientRect();\n    const radius = Math.max(1, Math.min(rect.width,rect.height) * .36);",
    "  function moveStick(event) {\n    const rect = joystick.getBoundingClientRect();\n    if (![rect.left,rect.top,rect.width,rect.height].every(Number.isFinite) || rect.width <= 0 || rect.height <= 0) {\n      state.setStick(0,0);\n      if (stick) stick.style.transform = 'translate(0px, 0px)';\n      return;\n    }\n    const radius = Math.min(rect.width,rect.height) * .36;"
  ],
  [
    "  listen(window,'blur',clear);\n  listen(window,'pagehide',clear);",
    "  listen(window,'blur',clear);\n  listen(window,'pagehide',clear);\n  listen(window,'resize',clear);\n  listen(window?.visualViewport,'resize',clear);"
  ]
];
let proposed = source;
let offset = 0;
let patch = '--- a/dist/input.mjs\n+++ b/dist/input.mjs\n';
for (const [before,after] of edits) {
  if (source.split(before).length !== 2) throw Error('Current input source differs; re-evaluate proposal');
  const oldLines = before.split('\n');
  const newLines = after.split('\n');
  const start = source.slice(0,source.indexOf(before)).split('\n').length;
  patch += `@@ -${start},${oldLines.length} +${start+offset},${newLines.length} @@\n`;
  patch += oldLines.map(line=>'-'+line).join('\n')+'\n';
  patch += newLines.map(line=>'+'+line).join('\n')+'\n';
  offset += newLines.length-oldLines.length;
  proposed = proposed.replace(before,after);
}
proposed = proposed.replace("'./ui/input/state.mjs'","'../../../../../dist/ui/input/state.mjs'");
writeFileSync(new URL('input-candidate.mjs',import.meta.url),proposed);
writeFileSync(new URL('input-geometry.patch',import.meta.url),patch);
const status = {
  worker:'team09 joystick geometry',startedAt:'2026-11-11T21:36:41Z',updatedAt:new Date().toISOString(),
  cycle:2,percent:50,gate:'Exact current-file patch proposal saved',
  artifact:'coordination/v4/SPRINT/09/geometry/input-geometry.patch',
  check:'Node verifier requires each old source fragment to match exactly once; emits candidate only inside owned geometry directory',
  result:'Two focused hunks: guard invisible/invalid joystick bounds; clear existing input on window and visualViewport resize. Pure vector math unchanged.',
  nextFiniteTask:'Run six regression scenarios against isolated candidate, then recheck current owner source',
  limits:'Candidate is not integrated; no main implementation edit or browser/phone claim'
};
writeFileSync(new URL('status.json',import.meta.url),JSON.stringify(status,null,2)+'\n');
writeFileSync(new URL('cycle-2.json',import.meta.url),JSON.stringify(status,null,2)+'\n');
console.log('Exact proposal saved; candidate generated from current input.mjs');
