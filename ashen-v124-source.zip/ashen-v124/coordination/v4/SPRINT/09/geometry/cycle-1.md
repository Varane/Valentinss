# Cycle 1 — reproducible geometry evidence

Start: 2026-11-11 21:36:41 UTC. Check completed: 21:41:52 UTC.

`node --test tests/sprint-09-geometry.test.mjs` => 6 tests, 3 pass, 3 fail, exit 1.

- Offset client coordinates, 12% radial deadzone and half-strength remapping pass.
- Touch diagonal beyond the circle stays normalized and finite.
- A new rectangular bounding box is read on every touch move; radius uses its shorter side.
- A captured touch moving after the control collapses to zero width/height creates unit movement (x 0.588752759028782) because `Math.max(1, ...)` invents a usable one-pixel radius.
- A held stick retains x 0.9999999999999999 after window or visualViewport resize until a new pointer sample or release. A layout change can therefore keep the pre-resize direction active.

Baseline `node --test tests/input-controls-state.test.mjs tests/input-controls-dom.test.mjs`: 25/25 pass, exit 0. The pure vector helper needs no change. Browser and actual phone behavior remain unverified.
