# Lead lifecycle patch decision

Current `dist/input.mjs` SHA256: `FEE1C40B7E691E26D141BCC4D1A882B20949E6B2BA4C91AED136B9D40076FBE7`.

No lifecycle patch requested. `clear()` removes pointer records before releasing captures, clears joystick/keys/attack, and restores visual state. Independent scenarios exercise the synchronous lostpointercapture reentrancy caused by releasing captures and stale pointer events after reopening. All eight passed. `dist/action-game.mjs` currently calls `input?.clear()` inside `onPause`; the frame loop does not consume input while paused.

The D1 historical bug (one pointer cancel clearing all contacts) has already been replaced by per-contact release. Pointer-worker tests separately verify that revision. Do not revert it or replace the owner module with a second input implementation.

Remaining acceptance belongs to root: actual browser touch arbitration and phone reach. Node event doubles do not establish device playability or FPS.
