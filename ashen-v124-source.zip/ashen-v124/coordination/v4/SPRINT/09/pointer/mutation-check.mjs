import {readFile, writeFile, unlink} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';

const rootURL = new URL('../../../../../', import.meta.url);
const root = fileURLToPath(rootURL);
const sourceURL = new URL('dist/input.mjs', rootURL);
const source = await readFile(sourceURL, 'utf8');
const originalHash = createHash('sha256').update(source).digest('hex');
const stateURL = new URL('dist/ui/input/state.mjs', rootURL).href;
const candidates = [
  {name: 'second-owner-guard', from: ' || stickPointer !== null', to: ''},
  {name: 'global-contact-cancel', from: "listen(document,'pointercancel',pointerup,true);", to: "listen(document,'pointercancel',clear,true);"},
];
const results = [];
for (const mutation of candidates) {
  if (!source.includes(mutation.from)) throw new Error(`Mutation anchor missing: ${mutation.name}`);
  const candidateURL = new URL(`candidate-${mutation.name}.mjs`, import.meta.url);
  const candidate = source.replace("'./ui/input/state.mjs'", JSON.stringify(stateURL)).replace(mutation.from, mutation.to);
  await writeFile(candidateURL, candidate);
  try {
    const run = spawnSync(process.execPath, ['--test', 'tests/sprint-09-pointer.test.mjs'], {
      cwd: root,
      env: {...process.env, SPRINT09_POINTER_MODULE: fileURLToPath(candidateURL)},
      encoding: 'utf8',
      timeout: 30000,
    });
    const output = `${run.stdout || ''}${run.stderr || ''}`;
    await writeFile(new URL(`mutation-${mutation.name}.log`, import.meta.url), output);
    if (run.error) throw run.error;
    if (run.status !== 1 || !/AssertionError/.test(output)) throw new Error(`Mutation was not caught by an assertion: ${mutation.name} (exit ${run.status})`);
    results.push({name: mutation.name, exitCode: run.status, caughtByAssertion: true});
  } finally {
    await unlink(candidateURL);
  }
}
const afterHash = createHash('sha256').update(await readFile(sourceURL, 'utf8')).digest('hex');
if (originalHash !== afterHash) throw new Error('Production input changed during mutation run; reevaluate latest source.');
const summary = {checkedAt: new Date().toISOString(), productionSHA256: afterHash, results};
await writeFile(new URL('mutation-results.json', import.meta.url), JSON.stringify(summary, null, 2) + '\n');
const statusURL = new URL('status.json', import.meta.url);
const status = JSON.parse(await readFile(statusURL, 'utf8'));
Object.assign(status, {
  updatedAt: summary.checkedAt,
  cycle: 3,
  percent: 75,
  artifact: 'coordination/v4/SPRINT/09/pointer/mutation-results.json',
  check: 'node coordination/v4/SPRINT/09/pointer/mutation-check.mjs',
  result: 'Both realistic pointer ownership regressions rejected by assertion failures. Production source unchanged; current-source ownership tests are meaningful.',
  nextFiniteTask: 'Run fresh ownership plus lead lifecycle acceptance tests against actual module and write final handoff.',
});
await writeFile(statusURL, JSON.stringify(status, null, 2) + '\n');
console.log(JSON.stringify(summary, null, 2));
