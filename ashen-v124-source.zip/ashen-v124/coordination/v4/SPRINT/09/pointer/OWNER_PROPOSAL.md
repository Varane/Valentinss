# Pointer ownership decision

Current-source decision: no production patch recommended.

The actual `dist/input.mjs` passes all eight focused ownership scenarios in `tests/sprint-09-pointer.test.mjs`. The first contact keeps movement when a second contact presses or moves on the joystick. Unowned pointerup, pointercancel and lostpointercapture do not clear either held thumb. Ending movement preserves attack; ending attack preserves movement. Pointer ID zero works. A released joystick accepts a fresh owner.

The desired minimal fix is already present: `startStick` returns when `stickPointer !== null`; `pointermove` checks equality with the owner; `pointerup` obtains only `pointers.get(event.pointerId)` and returns for an unknown ID; document cancellation delegates to that per-pointer release. D1's 21:35 handoff records the earlier global cancellation fix.

Do not replace document pointercancel with `clear()` and do not remove the second-owner guard. Those two plausible regressions are checked by scoped mutation candidates, without editing production files. A patch for the current requested scenarios would add code without a reproduced defect.

Scope: Node execution of the actual input module with an event-target fixture; no browser or physical-device claim. Blur, menu and destroy belong to the team09 lead. Geometry and CSS reach belong to the other workers.
