# Team09 pointer ownership handoff

Stopped: 2026-11-11T22:02:45Z. Start: 2026-11-11T21:36:42Z. Four bounded cycles saved at 25%, 50%, 75% and 100% in status.json. Runtime/tool update interrupted result delivery after cycle 3; saved artifacts survived and final acceptance was rerun.

Current joystick ownership is accepted for the tested scenarios. No reproducible production defect was found and no production patch is recommended. D1's existing per-contact fix already handles the requested cases. The exact owner recommendation is OWNER_PROPOSAL.md.

Added tests/sprint-09-pointer.test.mjs: eight executable scenarios import the actual dist/input.mjs. They cover a second joystick finger, unrelated pointerup/pointercancel/lostpointercapture, each thumb ending independently, new joystick ownership after release, and pointer ID zero.

Final command: node --test tests/sprint-09-pointer.test.mjs

Result: 8 tests, 8 pass, 0 fail, exit 0. Fresh rerun after the runtime update; duration 3129.041ms. Baseline earlier also passed 8/8.

Sensitivity command: node coordination/v4/SPRINT/09/pointer/mutation-check.mjs

Saved result at 2026-11-11T21:44:14.811Z: removing the second-owner guard fails with AssertionError (exit 1); restoring global pointercancel clearing fails with AssertionError (exit 1). Candidate copies existed only in this worker's owned folder and were removed. Both mutations used the original input source and real state module. Production input SHA256 remained fee1c40b7e691e26d141bcc4d1a882b20949e6b2ba4c91aed136b9d40076fbe7 throughout that check. See mutation-results.json and mutation-*.log.

Lead reported combined sprint acceptance as 28 tests / 25 pass / 3 geometry failures; all eight pointer tests passed. This worker makes no all-sprint success claim. Blur/menu/destroy remained the lead's scope. Geometry/CSS remained the other workers' scope.

Changes are confined to tests/sprint-09-pointer.test.mjs and coordination/v4/SPRINT/09/pointer/**. No production edits, commits, servers, browsers or spawned agents. Verification is Node event-level testing with a small DOM event-target fixture; physical iPhone/browser behavior was not verified.
