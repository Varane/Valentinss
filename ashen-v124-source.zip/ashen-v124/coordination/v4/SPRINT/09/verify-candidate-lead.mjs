import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=new URL('../../../../',import.meta.url);
const source=readFileSync(new URL('dist/input.mjs',root),'utf8').replace(/\r\n/g,'\n');
const candidate=readFileSync(new URL('geometry/input-candidate.mjs',import.meta.url),'utf8').replace(/\r\n/g,'\n');
const oldGeometry='    const radius = Math.max(1, Math.min(rect.width,rect.height) * .36);';
const newGeometry="    if (![rect.left,rect.top,rect.width,rect.height].every(Number.isFinite) || rect.width <= 0 || rect.height <= 0) {\n      state.setStick(0,0);\n      if (stick) stick.style.transform = 'translate(0px, 0px)';\n      return;\n    }\n    const radius = Math.min(rect.width,rect.height) * .36;";
const oldEvents="  listen(window,'pagehide',clear);";
const newEvents="  listen(window,'pagehide',clear);\n  listen(window,'resize',clear);\n  listen(window?.visualViewport,'resize',clear);";
assert.equal(source.split(oldGeometry).length,2,'current geometry fragment must match exactly once');
assert.equal(source.split(oldEvents).length,2,'current event fragment must match exactly once');
const expected=source.replace(oldGeometry,newGeometry).replace(oldEvents,newEvents).replace("'./ui/input/state.mjs'","'../../../../../dist/ui/input/state.mjs'");
assert.equal(candidate,expected,'candidate contains only the reviewed two-hunk proposal plus relocated import');
const directory=new URL('candidate-verification/',import.meta.url);mkdirSync(directory,{recursive:true});
const files=['sprint-09-geometry.test.mjs','sprint-09-lifecycle.test.mjs','sprint-09-pointer.test.mjs','input-controls-dom.test.mjs'];
const targets=[];
for(const file of files){
  const original=readFileSync(new URL('tests/'+file,root),'utf8');
  const patched=original.replaceAll("'../dist/input.mjs'","'../geometry/input-candidate.mjs'");
  assert.notEqual(patched,original,'test must import the reviewed candidate');
  const target=new URL(file,directory);writeFileSync(target,patched);targets.push(fileURLToPath(target));
}
const result=spawnSync(process.execPath,['--test',...targets],{encoding:'utf8'});
writeFileSync(new URL('candidate-verification.log',import.meta.url),(result.stdout||'')+(result.stderr||''));
console.log(result.stdout||'');console.error(result.stderr||'');
console.log('Reviewed candidate exit code:',result.status);
process.exitCode=result.status??1;
