import test from 'node:test';
import assert from 'node:assert/strict';
import {createInput} from '../geometry/input-candidate.mjs';

class Target {
  listeners=new Map();
  addEventListener(type,fn){if(!this.listeners.has(type))this.listeners.set(type,new Set());this.listeners.get(type).add(fn);}
  removeEventListener(type,fn){this.listeners.get(type)?.delete(fn);}
  emit(type,init={}){const e={type,target:this,cancelable:true,preventDefault(){},...init};for(const fn of [...(this.listeners.get(type)||[])])fn(e);return e;}
  get count(){return [...this.listeners.values()].reduce((n,s)=>n+s.size,0);}
}
class Element extends Target {
  constructor(tagName='BUTTON'){super();this.tagName=tagName;this.style={};this.captures=new Set();const classes=new Set();this.classList={add:v=>classes.add(v),remove:v=>classes.delete(v),toggle:(v,on)=>on?classes.add(v):classes.delete(v),contains:v=>classes.has(v)};}
  closest(){return this.tagName==='INPUT'?this:null;}
  getBoundingClientRect(){return {left:20,top:30,width:120,height:120};}
  setPointerCapture(id){this.captures.add(id);}
  hasPointerCapture(id){return this.captures.has(id);}
  releasePointerCapture(id){this.captures.delete(id);this.emit('lostpointercapture',{pointerId:id});}
}
function fixture(onMenu){
  const document=new Target(),window=new Target(),nodes=new Map();
  document.defaultView=window;document.hidden=false;document.visibilityState='visible';document.activeElement=null;
  for(const id of ['scene','joystick','stick','strike','dash','parry','special','rescue-hint']){const n=new Element(id==='scene'?'CANVAS':id==='joystick'?'DIV':'BUTTON');n.ownerDocument=document;nodes.set(id,n);}
  document.getElementById=id=>nodes.get(id)||null;
  document.querySelector=()=>document.dialogOpen?{}:null;
  const actions=[];
  const input=createInput({canvas:nodes.get('scene'),onAction:a=>actions.push(a),onMenu});
  const press=()=>{nodes.get('joystick').emit('pointerdown',{pointerId:11,button:0,clientX:123,clientY:90});nodes.get('strike').emit('pointerdown',{pointerId:22,button:0});document.emit('keydown',{code:'Space'});assert.ok(input.vector().x>0);assert.equal(input.attackHeld(),true);};
  return {document,window,nodes,input,press,actions};
}
function released(f){
  assert.deepEqual(f.input.vector(),{x:0,z:0});assert.equal(f.input.attackHeld(),false);
  assert.equal(f.nodes.get('joystick').captures.size,0);assert.equal(f.nodes.get('strike').captures.size,0);
  assert.equal(f.nodes.get('stick').style.transform,'translate(0px, 0px)');
  assert.equal(f.nodes.get('joystick').classList.contains('is-active'),false);
}

for(const trigger of ['blur','pagehide','hidden','dialog','editable','clear']){
  test(`interrupted two-thumb play: ${trigger} clears captures and stale events cannot resume movement`,()=>{
    const f=fixture();
    try{
      f.press();
      if(trigger==='blur'||trigger==='pagehide')f.window.emit(trigger);
      if(trigger==='hidden'){f.document.hidden=true;f.document.visibilityState='hidden';f.document.emit('visibilitychange');}
      if(trigger==='dialog'){f.document.dialogOpen=true;f.document.emit('focusin');}
      if(trigger==='editable'){f.document.activeElement=new Element('INPUT');f.document.emit('focusin',{target:f.document.activeElement});}
      if(trigger==='clear')f.input.clear();
      released(f);
      f.document.hidden=false;f.document.visibilityState='visible';f.document.dialogOpen=false;f.document.activeElement=null;
      f.document.emit('pointermove',{pointerId:11,clientX:500,clientY:90});
      f.document.emit('keyup',{code:'Space'});f.document.emit('pointerup',{pointerId:22});
      released(f);
      f.nodes.get('joystick').emit('pointerdown',{pointerId:33,button:0,clientX:123,clientY:90});
      assert.ok(f.input.vector().x>0,'a fresh thumb works after recovery');
    }finally{f.input.destroy();}
  });
}
test('opening a menu clears both thumbs before the pause callback runs',()=>{
  let f;const observed=[];f=fixture(menu=>observed.push([menu,f.input.vector(),f.input.attackHeld()]));
  try{f.press();f.document.emit('keydown',{code:'Escape'});assert.deepEqual(observed,[['pause',{x:0,z:0},false]]);released(f);}finally{f.input.destroy();}
});
test('destroy during active capture is reentrant and detaches every input listener',()=>{
  const f=fixture();f.press();const previous=f.actions.length;f.input.destroy();f.input.destroy();released(f);
  assert.equal(f.document.count,0);assert.equal(f.window.count,0);
  for(const node of f.nodes.values())assert.equal(node.count,0);
  f.nodes.get('strike').emit('pointerdown',{pointerId:44,button:0});f.document.emit('keydown',{code:'Space'});
  assert.equal(f.actions.length,previous);released(f);
});
