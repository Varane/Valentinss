import test from 'node:test';
import assert from 'node:assert/strict';
const {createInput} = await import(process.env.SPRINT09_INPUT_MODULE || '../geometry/input-candidate.mjs');

class Target {
  listeners = new Map();
  addEventListener(type, listener) {
    const listeners = this.listeners.get(type) || new Set();
    listeners.add(listener);
    this.listeners.set(type, listeners);
  }
  removeEventListener(type, listener) { this.listeners.get(type)?.delete(listener); }
  emit(type, fields = {}) {
    const event = {type, target:this, cancelable:true, preventDefault(){}, ...fields};
    for (const listener of [...(this.listeners.get(type) || [])]) listener(event);
  }
}

function setup(rect = {left:210, top:370, width:120, height:120}) {
  const document = new Target();
  const window = new Target();
  window.visualViewport = new Target();
  document.defaultView = window;
  document.hidden = false;
  document.visibilityState = 'visible';
  document.querySelector = () => null;
  const nodes = new Map();
  for (const id of ['scene','joystick','stick','strike']) {
    const node = new Target();
    const classes = new Set();
    node.ownerDocument = document;
    node.tagName = id === 'scene' ? 'CANVAS' : id === 'strike' ? 'BUTTON' : 'DIV';
    node.style = {};
    node.classList = {add:x=>classes.add(x),remove:x=>classes.delete(x),toggle:(x,on)=>on?classes.add(x):classes.delete(x)};
    node.getBoundingClientRect = () => ({...rect});
    node.closest = () => null;
    node.setPointerCapture = () => {};
    nodes.set(id,node);
  }
  document.getElementById = id => nodes.get(id) || null;
  const input = createInput({canvas:nodes.get('scene')});
  const pointer = (type,x,y) => (type === 'pointerdown' ? nodes.get('joystick') : document).emit(type,{pointerId:7,button:0,clientX:x,clientY:y});
  return {document,window,nodes,input,pointer,setRect:next=>{rect = next;}};
}

function near(actual, expected) {
  assert.ok(Number.isFinite(actual.x) && Number.isFinite(actual.z));
  assert.ok(Math.abs(actual.x - expected.x) < 1e-10, `x expected ${expected.x}, received ${actual.x}`);
  assert.ok(Math.abs(actual.z - expected.z) < 1e-10, `z expected ${expected.z}, received ${actual.z}`);
}

test('touch client coordinates respect an offset joystick and radial deadzone', () => {
  const f = setup();
  try {
    const radius = 120 * .36;
    f.pointer('pointerdown',270 + radius * .12,430);
    near(f.input.vector(),{x:0,z:0});
    f.pointer('pointermove',270 + radius * .56,430);
    near(f.input.vector(),{x:.5,z:0});
    f.pointer('pointermove',270,430 - radius * .56);
    near(f.input.vector(),{x:0,z:-.5});
  } finally { f.input.destroy(); }
});

test('touch diagonal is limited to unit speed outside the joystick', () => {
  const f = setup();
  try {
    f.pointer('pointerdown',1270,1430);
    const vector = f.input.vector();
    near(vector,{x:Math.SQRT1_2,z:Math.SQRT1_2});
    assert.ok(Math.hypot(vector.x,vector.z) <= 1);
  } finally { f.input.destroy(); }
});

test('each touch move uses the current rectangular bounds and shorter-axis radius', () => {
  const f = setup();
  try {
    f.pointer('pointerdown',270,430);
    f.setRect({left:30,top:80,width:180,height:100});
    f.pointer('pointermove',120,130 + 100 * .36 * .56);
    near(f.input.vector(),{x:0,z:.5});
  } finally { f.input.destroy(); }
});

test('an active touch cannot create movement from a zero-sized joystick', () => {
  const f = setup();
  try {
    f.pointer('pointerdown',313.2,430);
    f.setRect({left:0,top:0,width:0,height:0});
    f.pointer('pointermove',313.2,430);
    near(f.input.vector(),{x:0,z:0});
    assert.equal(f.nodes.get('stick').style.transform,'translate(0px, 0px)');
  } finally { f.input.destroy(); }
});

test('viewport resize clears the held touch before another pointer sample arrives', () => {
  const f = setup();
  try {
    f.pointer('pointerdown',313.2,430);
    assert.ok(f.input.vector().x > .9);
    f.setRect({left:420,top:20,width:100,height:100});
    f.window.emit('resize');
    near(f.input.vector(),{x:0,z:0});
    assert.equal(f.nodes.get('stick').style.transform,'translate(0px, 0px)');
    f.pointer('pointermove',313.2,430);
    near(f.input.vector(),{x:0,z:0});
    f.pointer('pointerdown',470,70);
    near(f.input.vector(),{x:0,z:0});
  } finally { f.input.destroy(); }
});

test('visual viewport resize clears held movement before another sample arrives', () => {
  const f = setup();
  try {
    f.pointer('pointerdown',313.2,430);
    assert.ok(f.input.vector().x > .9);
    f.window.visualViewport.emit('resize');
    near(f.input.vector(),{x:0,z:0});
  } finally { f.input.destroy(); }
});
