import test from 'node:test';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';

// Optional candidate path is used only by the scoped mutation-sensitivity check.
const inputURL = process.env.SPRINT09_POINTER_MODULE
  ? pathToFileURL(process.env.SPRINT09_POINTER_MODULE)
  : new URL('../geometry/input-candidate.mjs', import.meta.url);
const {createInput} = await import(inputURL.href);

class Target {
  listeners = new Map();
  addEventListener(type, callback) {
    if (!this.listeners.has(type)) this.listeners.set(type, new Set());
    this.listeners.get(type).add(callback);
  }
  removeEventListener(type, callback) { this.listeners.get(type)?.delete(callback); }
  emit(type, init = {}) {
    const event = {type, target: this, cancelable: true, preventDefault() {}, ...init};
    for (const callback of [...(this.listeners.get(type) || [])]) callback(event);
  }
}

function fixture(t) {
  const document = new Target();
  const nodes = new Map();
  document.defaultView = new Target();
  document.hidden = false;
  document.visibilityState = 'visible';
  document.activeElement = null;
  document.querySelector = () => null;
  document.getElementById = id => nodes.get(id) || null;
  for (const id of ['scene', 'joystick', 'stick', 'strike']) {
    const element = new Target();
    const classes = new Set();
    const captures = new Set();
    Object.assign(element, {
      ownerDocument: document,
      tagName: id === 'strike' ? 'BUTTON' : 'DIV',
      style: {},
      disabled: false,
      closest: () => null,
      getBoundingClientRect: () => ({left: 0, top: 0, width: 120, height: 120}),
      classList: {
        add: value => classes.add(value),
        remove: value => classes.delete(value),
        toggle: (value, on) => on ? classes.add(value) : classes.delete(value),
      },
      setPointerCapture: id => captures.add(id),
      hasPointerCapture: id => captures.has(id),
      releasePointerCapture: id => captures.delete(id),
    });
    nodes.set(id, element);
  }
  const actions = [];
  const input = createInput({canvas: nodes.get('scene'), onAction: action => actions.push(action)});
  t.after(() => input.destroy());
  const down = (name, pointerId, clientX = 105) => nodes.get(name).emit('pointerdown', {
    pointerId, button: 0, clientX, clientY: 60,
  });
  const move = (pointerId, clientX) => document.emit('pointermove', {
    pointerId, clientX, clientY: 60, target: nodes.get('joystick'),
  });
  const end = (name, type, pointerId) => {
    const target = nodes.get(name);
    (type === 'lostpointercapture' ? target : document).emit(type, {pointerId, target});
  };
  return {input, actions, down, move, end};
}

// Removing the stickPointer ownership guard must break this behavior.
test('second joystick finger cannot take movement or cancel the first finger', t => {
  const f = fixture(t);
  f.down('joystick', 11);
  assert.deepEqual(f.input.vector(), {x: 1, z: 0});
  f.down('joystick', 22, 15);
  f.move(22, 15);
  assert.deepEqual(f.input.vector(), {x: 1, z: 0});
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) {
    f.end('joystick', type, 22);
    assert.deepEqual(f.input.vector(), {x: 1, z: 0}, type);
  }
  f.move(11, 15);
  assert.deepEqual(f.input.vector(), {x: -1, z: 0});
  f.end('joystick', 'pointerup', 11);
  assert.deepEqual(f.input.vector(), {x: 0, z: 0});
});

// Replacing per-pointer release with clear() must break these six cases.
for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) {
  test(`ending attack by ${type} preserves the joystick owner`, t => {
    const f = fixture(t);
    f.down('joystick', 31);
    f.down('strike', 32);
    assert.equal(f.input.attackHeld(), true);
    assert.deepEqual(f.actions, ['attack']);
    f.end('strike', type, 32);
    assert.equal(f.input.attackHeld(), false);
    assert.deepEqual(f.input.vector(), {x: 1, z: 0});
    f.move(31, 15);
    assert.deepEqual(f.input.vector(), {x: -1, z: 0});
  });

  test(`ending joystick by ${type} preserves attack and permits a new owner`, t => {
    const f = fixture(t);
    f.down('joystick', 41);
    f.down('strike', 42);
    f.end('joystick', type, 41);
    assert.deepEqual(f.input.vector(), {x: 0, z: 0});
    assert.equal(f.input.attackHeld(), true);
    f.move(41, 105);
    assert.deepEqual(f.input.vector(), {x: 0, z: 0});
    f.down('joystick', 43, 15);
    assert.deepEqual(f.input.vector(), {x: -1, z: 0});
    f.end('strike', 'pointerup', 42);
    assert.equal(f.input.attackHeld(), false);
    assert.deepEqual(f.input.vector(), {x: -1, z: 0});
  });
}

// Treating pointer ID 0 as falsy, or clearing all pointers on unowned endings,
// must break this behavior.
test('pointer ID zero remains owned through unrelated document endings', t => {
  const f = fixture(t);
  f.down('joystick', 0);
  f.down('strike', 1);
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) {
    f.end('joystick', type, 99);
    assert.deepEqual(f.input.vector(), {x: 1, z: 0}, type);
    assert.equal(f.input.attackHeld(), true, type);
  }
  f.end('joystick', 'pointercancel', 0);
  assert.deepEqual(f.input.vector(), {x: 0, z: 0});
  assert.equal(f.input.attackHeld(), true);
});
