import test from 'node:test';
import assert from 'node:assert/strict';

class Target {
  listeners = new Map();
  addEventListener(type, fn) { const list = this.listeners.get(type) || new Set(); list.add(fn); this.listeners.set(type, list); }
  removeEventListener(type, fn) { this.listeners.get(type)?.delete(fn); }
  emit(type, init = {}) {
    const event = {type, target:this, cancelable:true, defaultPrevented:false, preventDefault(){this.defaultPrevented=true;}, ...init};
    for (const fn of [...(this.listeners.get(type) || [])]) fn(event);
    return event;
  }
  count() { return [...this.listeners.values()].reduce((n, list) => n + list.size, 0); }
}
class Element extends Target {
  constructor(tagName = 'BUTTON') {
    super(); this.tagName=tagName; this.style={setProperty(name,value){this[name]=value;}};
    const values = new Set(); this.classList={add:x=>values.add(x),remove:x=>values.delete(x),contains:x=>values.has(x),toggle(x,on){on?values.add(x):values.delete(x);}};
    this.captures=new Set(); this.attributes=new Map(); this.isContentEditable=false; this.disabled=false;
  }
  setAttribute(name,value) { this.attributes.set(name,String(value)); }
  getAttribute(name) { return this.attributes.get(name) ?? null; }
  removeAttribute(name) { this.attributes.delete(name); }
  getBoundingClientRect() { return {left:0,top:0,width:120,height:120}; }
  setPointerCapture(id) { this.captures.add(id); }
  releasePointerCapture(id) { this.captures.delete(id); }
  hasPointerCapture(id) { return this.captures.has(id); }
  closest(selector) {
    if (selector.includes('input') && (['INPUT','TEXTAREA','SELECT'].includes(this.tagName) || this.isContentEditable || this.attributes.get('role')==='textbox')) return this;
    return this.parentElement?.closest(selector) || null;
  }
}
async function setup() {
  const {createInput}=await import('../geometry/input-candidate.mjs');
  const document=new Target(), window=new Target(), nodes=new Map();
  document.defaultView=window; document.hidden=false; document.visibilityState='visible'; document.activeElement=null;
  for (const id of ['scene','joystick','stick','strike','dash','parry','special','rescue-hint','inventory','talents','pause','camera','switch-hero','ally','rooms']) {
    const node=new Element(id==='scene'?'CANVAS':id==='joystick'?'DIV':'BUTTON'); node.ownerDocument=document; nodes.set(id,node);
  }
  document.getElementById=id=>nodes.get(id)||null;
  document.querySelector=selector=>selector==='dialog[open]'&&document.dialogOpen?new Element('DIALOG'):null;
  document.querySelectorAll=selector=>selector==='dialog[open]'&&document.dialogOpen?[new Element('DIALOG')]:[];
  const actions=[],menus=[],switches=[],cameras=[];
  const input=createInput({canvas:nodes.get('scene'),onAction:x=>actions.push(x),onMenu:x=>menus.push(x),onSwitch:()=>switches.push(true),onCamera:()=>cameras.push(true)});
  const key=(type,code,extra={})=>document.emit(type,{code,key:code,...extra});
  const pointer=(id,type,pointerId,extra={})=>nodes.get(id).emit(type,{pointerId,button:0,clientX:60,clientY:60,...extra});
  return {input,document,window,nodes,actions,menus,switches,cameras,key,pointer};
}

test('desktop controls normalize movement, preserve key edges, and dispatch required actions',async()=>{
  const f=await setup();
  try {
    assert.equal(f.key('keydown','KeyW').defaultPrevented,true); f.key('keydown','ArrowRight');
    assert.ok(Math.abs(Math.hypot(...Object.values(f.input.vector()))-1)<1e-9);
    assert.ok(f.input.vector().x>0&&f.input.vector().z<0);
    f.key('keydown','Space'); f.key('keydown','Space',{repeat:true}); assert.equal(f.input.attackHeld(),true);
    f.key('keyup','Space'); assert.equal(f.input.attackHeld(),false);
    for (const code of ['ShiftLeft','KeyE','KeyR','KeyF']) { f.key('keydown',code); f.key('keyup',code); }
    assert.deepEqual(f.actions,['attack','dash','parry','special','revive']);
    for (const code of ['KeyI','KeyK','Escape']) {f.key('keydown',code);f.key('keyup',code);}
    assert.deepEqual(f.menus,['gear','skills','pause']);
    f.key('keydown','KeyQ'); f.key('keydown','KeyQ',{repeat:true}); assert.equal(f.switches.length,1);
    f.key('keyup','KeyW'); f.key('keyup','ArrowRight'); assert.deepEqual(f.input.vector(),{x:0,z:0});
  } finally {f.input.destroy();}
});

test('joystick and combat use separate pointer IDs and keyboard attack survives a touch release',async()=>{
  const f=await setup();
  try {
    f.pointer('joystick','pointerdown',1,{clientX:105,clientY:60});
    assert.ok(f.input.vector().x>0);
    f.pointer('strike','pointerdown',2); assert.equal(f.input.attackHeld(),true);
    f.key('keydown','Space');
    f.document.emit('pointerup',{pointerId:2,target:f.nodes.get('strike')});
    assert.equal(f.input.attackHeld(),true); assert.ok(f.input.vector().x>0);
    f.key('keyup','Space'); assert.equal(f.input.attackHeld(),false);
    f.document.emit('pointerup',{pointerId:1,target:f.nodes.get('joystick')});
    assert.deepEqual(f.input.vector(),{x:0,z:0});
    f.pointer('dash','pointerdown',3); f.pointer('parry','pointerdown',4); f.pointer('special','pointerdown',5);f.pointer('rescue-hint','pointerdown',6);
    assert.deepEqual(f.actions,['attack','attack','dash','parry','special','revive']);
  } finally {f.input.destroy();}
});

test('blur, hidden visibility and explicit clear release all held controls',async()=>{
  const f=await setup();
  try {
    for (const release of [
      ()=>f.window.emit('blur'),
      ()=>{f.document.hidden=true;f.document.visibilityState='hidden';f.document.emit('visibilitychange');},
      ()=>f.input.clear()
    ]) {
      f.document.hidden=false;f.document.visibilityState='visible';
      f.key('keydown','KeyW');f.key('keydown','Space');f.pointer('strike','pointerdown',2);
      release();
      assert.equal(f.input.attackHeld(),false);assert.deepEqual(f.input.vector(),{x:0,z:0});
      assert.equal(f.nodes.get('strike').captures.size,0);
    }
  } finally {f.input.destroy();}
});

test('typing, contenteditable focus and dialogs suppress gameplay and do not resume old holds',async()=>{
  const f=await setup();
  try {
    f.key('keydown','KeyW');f.key('keydown','Space');
    const field=new Element('INPUT');f.document.activeElement=field;f.document.emit('focusin',{target:field});
    f.key('keydown','KeyR',{target:field});f.pointer('dash','pointerdown',8);
    assert.deepEqual(f.actions,['attack']);assert.equal(f.input.attackHeld(),false);assert.deepEqual(f.input.vector(),{x:0,z:0});
    f.document.activeElement=null;assert.deepEqual(f.input.vector(),{x:0,z:0});
    f.document.dialogOpen=true;f.key('keydown','KeyE');f.pointer('strike','pointerdown',9);assert.deepEqual(f.actions,['attack']);
    f.document.dialogOpen=false;f.key('keydown','ArrowLeft');assert.ok(f.input.vector().x<0);
    const editable=new Element('DIV');editable.isContentEditable=true;f.document.activeElement=editable;
    assert.deepEqual(f.input.vector(),{x:0,z:0});
  } finally {f.input.destroy();}
});

test('combat buttons support assistive activation without duplicating pointer clicks or owning menu clicks',async()=>{
  const f=await setup();
  try {
    f.pointer('dash','pointerdown',1);f.nodes.get('dash').emit('click',{detail:1});
    assert.deepEqual(f.actions,['dash']);
    f.nodes.get('parry').emit('click',{detail:0});assert.deepEqual(f.actions,['dash','parry']);
    for (const id of ['inventory','talents','pause','camera','switch-hero','ally','rooms']) assert.equal(f.nodes.get(id).count(),0,id);
    f.input.destroy();f.input.destroy();
    f.key('keydown','KeyR');f.pointer('strike','pointerdown',2);
    assert.deepEqual(f.actions,['dash','parry']);assert.equal(f.document.count(),0);assert.equal(f.window.count(),0);
    assert.equal(f.input.attackHeld(),false);assert.deepEqual(f.input.vector(),{x:0,z:0});
  } finally {f.input.destroy();}
});

test('Space on a focused menu button preserves native keyboard activation',async()=>{
  const f=await setup();
  try {
    f.document.activeElement=f.nodes.get('inventory');
    const event=f.key('keydown','Space',{target:f.nodes.get('inventory')});
    assert.equal(event.defaultPrevented,false);
    assert.deepEqual(f.actions,[]);
    assert.equal(f.input.attackHeld(),false);
  } finally {f.input.destroy();}
});
