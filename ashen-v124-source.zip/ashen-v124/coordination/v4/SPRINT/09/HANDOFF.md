# Sprint 09 — thumb joystick, owner acceptance pending

Four actual workers started: lead plus exactly three subagents (`/root/pointer_ownership`, `/root/joystick_geometry`, `/root/thumb_reach`). No recursive agents or chats. Ownership preserved: only this coordination folder and tests/sprint-09*.test.mjs written.

## Owner action

Geometry worker reproduced three source-level edge failures in `tests/sprint-09-geometry.test.mjs`: held movement survives window resize, survives visualViewport resize, and a captured thumb over a zero-size joystick produces nonzero movement. Lead independently reproduced all three. D1/root: inspect `geometry/input-geometry.patch`. This adds a geometry guard and window/visualViewport resize clearing. No production fix has been applied by team09.

## Verified current source

Lead independently ran `node --test tests/input-controls-dom.test.mjs tests/input-controls-state.test.mjs tests/playability/qa1/gestures/gestures.test.mjs tests/sprint-09-lifecycle.test.mjs`: **40 pass, 0 fail, exit0**. Input SHA256 `FEE1C40B7E691E26D141BCC4D1A882B20949E6B2BA4C91AED136B9D40076FBE7`.

The new eight lifecycle scenarios cover active joystick plus attack across blur, pagehide, hidden visibility, modal, editable focus, explicit clear, menu opening and destroy. Existing per-contact cancellation fix is present. Root onPause calls input.clear(). No lifecycle patch needed.

Fresh lead combined command: `node --test tests/sprint-09-lifecycle.test.mjs tests/sprint-09-pointer.test.mjs tests/sprint-09-geometry.test.mjs tests/sprint-09-reach.test.mjs` — **28 tests: 25 pass, 3 fail, exit1**. The only failures are the three geometry cases above. Eight pointer ownership scenarios, eight lifecycle scenarios, three normal geometry scenarios and six reach source contracts pass. Red tests are retained intentionally as executable owner acceptance criteria, not advertised as a green release suite.

Lead independently ran `node coordination/v4/SPRINT/09/verify-candidate-lead.mjs` at22:02:31UTC: **28 pass,0 fail,exit0**. The runner asserts the candidate differs from current source only by the reviewed two-hunk patch and relocated import, then runs DOM,geometry,lifecycle,ownership tests against it. Exact output: `candidate-verification.log`. Candidate is not production. This patch has zero context: D1/root must check/apply it with `git apply --check --unidiff-zero coordination/v4/SPRINT/09/geometry/input-geometry.patch` then `git apply --unidiff-zero coordination/v4/SPRINT/09/geometry/input-geometry.patch`, and rerun the current-source sprint suite. Plain git apply rejects this patch's zero-context hunks. No evidence supports an additional pointer/lifecycle/CSS patch.

The planned21:45UTC completed handoff was missed; provisional handoff was saved by observed21:58:30 clock. Lead's four audit gates are complete22:02:31UTC; production fix remains an explicit owner action. Runtime/tool update temporarily reported original child IDs as pending_init; the same IDs resumed, with no replacement agents.

Pointer mutation artifact `pointer/mutation-results.json` records that removing the second-owner guard and restoring global cancellation were both caught by assertions. Reach checks confirm source contracts for safe-area anchors,44px targets and gesture policies; they do not measure physical thumb reach.

## Acceptance limits

Node event doubles and CSS source checks only. No preview server, root browser tab, physical iPhone, FPS, publication, commits or main implementation changes. No screenshot manifest was found by the scoped coordination filename search. Root retains browser and release acceptance.
