# Reach gate 1 — source evidence

Result: clean within the assigned source-only scope. No patch is justified yet.

- `index.html:5` opts into safe-area layout with `viewport-fit=cover` and leaves zoom unrestricted.
- `action.css:7–10` defines all four inset variables. Every explicit joystick `left`/`bottom` anchor adds the matching safe inset (lines 153, 182, 241, 264).
- The 100–112px joystick surface and all explicit combat widths/heights remain at least 44px.
- `action.css:22,58,69,75` suppresses gestures on canvas/combat/joystick/rescue; the dialog retains scrollable overflow.
- `input.mjs:154,161,165` uses non-passive pointer listeners where `preventDefault()` is needed. Pointer identity and geometry are outside this worker scope.

No browser, iPhone, FPS, or hosted verification was performed. Next finite task: execute contract checks on these source requirements.
