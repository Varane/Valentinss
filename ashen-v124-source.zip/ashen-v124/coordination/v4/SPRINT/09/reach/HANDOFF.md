# Sprint 09 — thumb reach source handoff

Accepted within the assigned source-only scope. No source-backed production defect was found; no production patch is proposed.

Artifacts: `tests/sprint-09-reach.test.mjs`, `coordination/v4/SPRINT/09/reach/status.json`, and `cycle-1-evidence.md`. Status records four bounded gates at 25%, 50%, 75%, and 100%.

Final verification: `node --test tests/sprint-09-reach.test.mjs` — **6 passed, 0 failed, exit 0**, freshly rerun at 2026-11-11T22:02:52.454Z. The initial run passed 3/6 because the new test parser mishandled the shared `button,a` rule and nested `var(--gutter)` inside `calc()`; those owned test assumptions were corrected before the green run.

The six contracts check viewport safe insets and available zoom; matching safe-area terms on every explicit joystick anchor; gesture/selectability suppression on combat surfaces with dialog scrolling retained; a 44px target floor; non-intercepting joystick decoration; and non-passive pointer paths with context-menu consumption.

Owner source changes since gate 1: none. Fresh final checks ran on the current files. Source fingerprints are recorded in status.json. No production-source edits, commits, servers, browsers, or spawned children were made. One assigned worker actually started; zero child agents started.

The runtime/tool update interrupted the first final save around 21:44 UTC. This original worker resumed to save the final gate. Actual stop: **2026-11-11T22:02:52.454Z**.

Next finite task for the root browser/device owner: on a notched iPhone in portrait and landscape, hold movement with one thumb while repeatedly attacking with the other; open a dialog and verify scrolling. Record actual device results.

Browser rendering, iPhone behavior, simultaneous touch, FPS, hosted/co-op behavior, and visual usability were not tested by this worker. The checks establish source contracts only. Pointer ownership and layout collision/geometry remain with their assigned owners.
