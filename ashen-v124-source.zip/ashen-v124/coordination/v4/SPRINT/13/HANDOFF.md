# Sprint13 — rooms and rewards

Acceptance: BLOCKED. Four review gates processed; this is not a green gameplay claim. Exactly three successful subagent starts plus lead, four historical workers. Final stop interrupted all three; tool reported pending_init for each. No owner implementation, commit, push, publication or browser modified. Handoff missed21:45 UTC and is finalized at 2026-11-11T22:00:46.180Z.

## Reproducible blockers and owner actions

1. **C, missing authored modules (load blocker).** Fresh inventory at21:59 UTC is only balance.mjs, dialogue.mjs, quests.mjs, story.mjs. campaign.mjs and rules.mjs import absent save.mjs; campaign additionally requires rooms.mjs, choices.mjs, endings.mjs, death.mjs, progression.mjs. Room tests also require encounters.mjs and puzzles.mjs. Existing reward suite requires rewards.mjs. Restore the owners' authored files with current exported contracts; do not substitute placeholder room/reward logic. Exact recovery notes: rooms/owner-recovery.md, rewards/HANDOFF.md, persistence/HANDOFF.md.

2. **Root, terminal saved campaign cannot boot.** action-game.mjs boot() unconditionally calls spawnRoom(); campaign.prepareEncounter rejects non-active status. A restored complete, defeat or camp run therefore rejects boot. Exact small guard is in runtime/PATCH.md. Executable current boot seam gives3 terminal failures; same guard passes in memory. Rendering/UI are stubbed, so this is a boot integration contract test, not browser evidence.

## Verification

Run: node --test tests/sprint-13-rooms.test.mjs tests/sprint-13-rewards.test.mjs tests/sprint-13-persistence.test.mjs tests/sprint-13-runtime.test.mjs

Observed exit1,14 tests,2 passed,12 failed:9 missing-module failures and3 terminal-save boot failures. Passing tests are active-run boot and in-memory proposed boot guard. No reward arithmetic, replay safety, six-room completion or defeat persistence acceptance is possible until production imports load.

The actual runtime SHA256 at final source recheck was a20c83be848dbfaa5f0e262a726a1eafc8a00d60027647544748b006a2360fbb and the proposed guard was absent. Gate snapshots: cycle-1.json through cycle-4.json, with current status.json.

## Acceptance after owner repair

Restore modules, apply a terminal-save boot policy, rerun the exact command. If imports close, the behavior tests exercise six-room sequencing, choice save/rebuild, exact once-only room payouts, stale callbacks, defeat XP/skills and ledger roundtrips. Root then owns actual browser/mobile/hosted verification.

## Coordination limitation

First report sent successfully. Final detailed cross-chat message was rejected by automatic approval review because it considered the payload an unauthorized export of internal project/code status. No retry or workaround attempted. This authorized shared handoff is the final delivery.
