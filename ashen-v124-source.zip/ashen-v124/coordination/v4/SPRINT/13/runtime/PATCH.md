# Root runtime: terminal save blocks boot

Current dist/action-game.mjs boot() calls spawnRoom() unconditionally. createCampaign restores status complete, defeat or camp; dist/campaign.mjs prepareEncounter rejects any non-active status. Reopening a completed/failed/escaped save therefore rejects boot before the loading screen is hidden.

Exact minimal proposal in async function boot(), immediately before spawnRoom():

```js
if(campaign.status!=='active'){
  ({profile,campaign}=restartCampaign(profile));
  save();
}
```

This starts a fresh run while retaining permanent progress through the existing restart contract. Root may instead present a terminal outcome before spawning; either path must avoid preparing an inactive campaign.

Regression: node --test tests/sprint-13-runtime.test.mjs. The test executes the actual boot function with rendering/UI dependencies stubbed and an active-only encounter seam. It does not verify real WebGL, browser storage or playability. The same test also checks the guard in memory without changing owner source.
