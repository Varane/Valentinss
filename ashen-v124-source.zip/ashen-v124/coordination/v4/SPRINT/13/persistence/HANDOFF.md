# Sprint 13 persistence acceptance

Observed 2026-11-11 21:41 UTC. Owner source was read, not changed.

Concrete blocker: production `dist/rules.mjs` imports `./campaign/save.mjs` and `./campaign/progression.mjs`; production `dist/campaign.mjs` also imports `./campaign/death.mjs`. All three files are absent in the live shared repository. `rg --files dist/campaign` lists only story.mjs, quests.mjs, dialogue.mjs and balance.mjs. Rooms/choices dependencies are also outside this worker's ownership.

Executable reproduction: `node --test tests/campaign.integration.test.mjs tests/rules.progression.test.mjs` returns exit 1, 0 pass / 2 fail. Both fail during import with `ERR_MODULE_NOT_FOUND` for `dist/campaign/save.mjs`.

Exact minimal owner repair: restore the C progression owner's three production modules at the existing import paths without changing callers. Required exports are `sanitizeCampaign` from save.mjs, `applyEncounterOutcome` from death.mjs, and `grantRoomReward,restartProfile` from progression.mjs. Sanitization must retain rewardLedger, resolvedRooms, runId and defeat status; final death must retain XP/points/skills and strip equipment; defeat must not call victory grant. No stub implementations are acceptable.

New acceptance regression: `node --test tests/sprint-13-persistence.test.mjs`. Three scenarios exercise actual public campaign/rules/action APIs: earned XP/skills survive defeat while gold/room rewards do not increase; a prior victory ledger survives subsequent defeat and v2 JSON save restore; repeat defeat and stale callback after restart cannot reapply death to the new run. Static source-only checks are not represented as gameplay acceptance.

Acceptance remains blocked until actual missing modules are restored and the new regression executes successfully. No browser, frame-rate, playability, backend or publishing claim is made.
