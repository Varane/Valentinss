# Minimum repair proposal

Actual executable failure is module loading, before reward arithmetic can run. `dist/rules.mjs` imports `dist/campaign/save.mjs`; `dist/campaign.mjs` imports save, death, and progression; balance imports rewards. The observed errors name missing save.mjs and rewards.mjs. Read checks additionally found progression.mjs absent.

The owner must supply the canonical missing implementations at their current imported paths. No safe one-line textual patch can reconstruct persistence and idempotence semantics; removing these imports would disable required behavior. Implementation ownership remains with C. This worker makes no owner implementation edits.

Acceptance command: `node --test tests/sprint-13-rewards.test.mjs tests/campaign.balance.rewards.test.mjs tests/campaign.integration.test.mjs`.
