# Sprint 12 UI — cycle 2

Actual execution: 2026-11-11T21:43:37.339Z. Actual dist/input.mjs executed through a DOM-boundary fixture. No browser/layout engine used.

Regression file: tests/sprint-12-ui.test.mjs. Exit code: 0.

✔ camera shortcut is blocked for the entire equipment-dialog lifetime, then recovers (41.1052ms)
✔ hero shortcut is suppressed in an open inspection/equipment dialog (4.7599ms)
ℹ tests 2
ℹ suites 0
ℹ pass 2
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 4996.75


Camera C and hero Q suppress while ANY dialog is open, then recover. UI header camera is outside native dialog; overlay contains only close/hero-selector/content, with no camera-control path inside gear menu. No proven overlay lifecycle failure found. Lead should preserve modal input suppression. Distinct inspection can use an explicit control/callback outside the dialog; inside-menu inspection additionally needs an in-dialog control.
