# Current-source re-evaluation — 21:59 UTC

Owner revision observed: dist/figures.mjs now imports createBody/createFace/createPalette/attachEquipment/createAnimator, replacing the old monolith. The earlier mouth occlusion report is stale. Fresh real Three raycast tests pass for male and female production figures. Do not apply any old monolithic mouth-position suggestion.

Fresh combined camera+face+runtime run: 7 tests, 5 pass, 2 fail. Failing acceptance tests remain camera orbit crossing the head and missing runtime onZoom callback. These are current source failures; no owner fixes observed. Candidate runtime callback check independently passes (z distance 2.8 → 1.8666666666666665). Main implementation files remain untouched.

Camera candidate refined from yaw-triggered reset to valid-frame-only immediate inspection follow. This retains invalid-dt hold semantics and prevents a stale yaw update from bypassing the fix. Exact owner diff saved in camera/OWNER-PATCH.diff. New invalid-dt regression added to tests/sprint-12-camera.test.mjs. Fresh final run pending.

Agent continuity issue: at 21:58UTC list_agents showed only lead and /root/inspection_ui pending_init; the already-started face/camera agents were no longer in the live tree. No replacements spawned, preserving exactly three starts. Lead completed the remaining source rechecks from saved artifacts. The 21:45 handoff target was missed during an interrupted tool turn; hard stop22:05 remains.
