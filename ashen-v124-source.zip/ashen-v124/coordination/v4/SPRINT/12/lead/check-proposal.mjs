import assert from 'node:assert/strict';
import {bootRuntimeControls} from './runtime-harness.mjs';
const runtime = await bootRuntimeControls(source => {
  const old="onSwitch:()=>switchHero(),onCamera:()=>rig.toggle()});";
  assert.ok(source.includes(old),'Current runtime boot input boundary must match exact patch');
  return source.replace(old,"onSwitch:()=>switchHero(),onCamera:()=>rig.toggle(),onZoom:delta=>rig.zoom(delta)});");
});
assert.equal(typeof runtime.controls.onZoom,'function');
runtime.controls.onCamera();runtime.controls.onCamera();runtime.update();
const before=runtime.camera.position.z;
runtime.controls.onZoom(.5);runtime.update();
assert.ok(runtime.camera.position.z<before);
console.log(JSON.stringify({candidateRuntimeCallback:'PASS',before,after:runtime.camera.position.z,productionEdited:false}));
