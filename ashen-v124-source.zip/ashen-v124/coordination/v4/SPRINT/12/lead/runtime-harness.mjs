import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { createCameraRig } from '../../../../../dist/camera-rig.mjs';
import {placeActor} from '../../../../../dist/render-poses.mjs';
import {localize} from '../../../../../dist/i18n.mjs';
import {Group} from '../../../../../dist/lib/three.module.js';

export async function bootRuntimeControls(transform = value => value) {
  const source = transform(await readFile(new URL('../../../../../dist/action-game.mjs', import.meta.url), 'utf8'));
  const start = source.indexOf('async function boot(){');
  const end = source.indexOf('\nboot().catch', start);
  if (start < 0 || end < 0) throw Error('Runtime boot boundary changed; recheck harness');
  const camera = {aspect:16/9,fov:42,position:{x:0,y:0,z:0},lookAt(x,y,z){this.target={x,y,z};},updateProjectionMatrix(){}};
  const actor = {x:0,z:0,yaw:0};
  let controls, menus;
  const element=()=>({hidden:false,style:{},append(){},setAttribute(){},addEventListener(){}});
  const context = {
    loadAppearanceProfile:async()=>({avatar:'knight',look:{hair:'none',color:'brown'}}),getAppearance:()=>({avatar:'knight',look:{hair:'none',color:'brown'}}),selectAvatar(){},addEventListener(){},
    elapsed:0,placeActor,localize,figures:[{root:new Group(),animate(){}}],enemyFigures:[],options:{tutorialSeen:false},inspectionPaused:false,destination:null,inRoom:()=>false,report(){},document:{createElement:element,body:{append(){},classList:{toggle(){}}}},scene:{},renderer:{render(){}},mobile:false,reduced:false,blood:true,
    camera,createCameraRig,createWorld:()=>({}),createEffects:()=>({}),spawnRoom(){},
    createUI(config){menus=config;return {update(){},setNetwork(){}};},
    createInput(config){controls=config;return {clear(){}};},
    network:{resume:async()=>false},showObjectives(){},profile:{},battle:{players:[actor],enemies:[]},selected:0,
    perform(){},equipHero(){},learnSkill(){},restart(){},switchHero(){},
    requestAnimationFrame(){},frame(){},save(){},
    $(id){return {hidden:false,addEventListener(){},setAttribute(){}};},
  };
  context.enterInvitedRoom=()=>context.network.resume();
  vm.createContext(context);
  await new vm.Script('let world,rig,fx,ui,input,booted,paused;\n'+source.slice(source.indexOf('function drawActors('),source.indexOf('function frame(now)'))+'\n'+source.slice(start,end)+'\nboot();').runInContext(context);
  return {controls,menus,camera,actor,get inspectionPaused(){return context.inspectionPaused;},update(){vm.runInContext('rig.update(10,battle.players[selected],battle)',context);}};
}
