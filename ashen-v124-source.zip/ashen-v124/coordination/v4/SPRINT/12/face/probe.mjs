import {registerHooks} from 'node:module';
import * as THREE from '../../../../../dist/lib/three.module.js';
registerHooks({resolve(specifier,context,nextResolve){
  if(specifier==='three')return {url:new URL('../../../../../dist/lib/three.module.js',import.meta.url).href,shortCircuit:true};
  return nextResolve(specifier,context);
}});
const {makeFigure}=await import('../../../../../dist/figures.mjs');
const {createFace}=await import('../../../../../dist/figures/face.mjs');
const {createPalette}=await import('../../../../../dist/figures/palette.mjs');
function describe(mesh){return {name:mesh.name,type:mesh.geometry?.type,position:mesh.position.toArray(),parameters:mesh.geometry?.parameters};}
function frontHits(head,x,y){
  head.updateWorldMatrix(true,true);
  const from=head.localToWorld(new THREE.Vector3(x,y,1));
  const direction=new THREE.Vector3(0,0,-1).transformDirection(head.matrixWorld);
  return new THREE.Raycaster(from,direction).intersectObject(head,true).slice(0,5).map(hit=>({z:head.worldToLocal(hit.point.clone()).z,...describe(hit.object)}));
}
for(const female of [false,true]){
  const figure=makeFigure({female,weapon:null,armor:null});
  console.log(JSON.stringify({path:'production',female,mouth:frontHits(figure.head,0,-.062),leftEye:frontHits(figure.head,-.046,.022),bounds:new THREE.Box3().setFromObject(figure.head)},null,2));
  // One-variable hypothesis: only move the inline mouth forward 8 mm.
  const mouth=figure.head.children.find(m=>m.geometry?.type==='BoxGeometry'&&m.geometry.parameters.height===.006);
  if(mouth){mouth.position.z+=.008;console.log(JSON.stringify({path:'production-proposed-mouth-z+.008',female,mouth:frontHits(figure.head,0,-.062)},null,2));}
  figure.dispose?.();
  const head=new THREE.Group(),palette=createPalette({female}),face=createFace(head,{female,materials:palette.materials});
  console.log(JSON.stringify({path:'standalone-module',female,mouth:frontHits(head,0,-.072),leftEye:frontHits(head,-.045,.022)},null,2));
  face.dispose();palette.dispose();
}
