# Sprint 12 face geometry audit

Actual start: 2026-11-11 21:37:59 UTC. Scope: read production figure/head/inspection source, run real bundled Three.js geometry checks, propose only a minimal owner patch. No main implementation edits, browser, server, commits, or publication.

Initial source evidence (21:39 UTC):

- `dist/figures.mjs` is still a standalone monolith importing only `three`; the new `dist/figures/face.mjs` and body/equipment modules are not imported by it.
- Production head anchor is `(0,1.67,.012)`, with front +Z, at `dist/figures.mjs:23`.
- Production has overlapping skull/jaw ellipsoids; mouth box is at local `(0,-.062,.097)` with depth `.008`. A real ray test will check whether the jaw covers it from +Z.
- `dist/figures/face.mjs` exports `createFace(head,{female,enemy,boss,materials})`; returns only `dispose()`. Features are named `face.skull`, `face.eyes`, `face.irises`, `face.brows`, `face.mouth`, and `face.hair.*`.
- B STATUS is dated 21:06 UTC and B HANDOFF still says in progress; source/test results below take precedence over planned integration claims.

Verification pending; no visual result is claimed.
