# Sprint 12 — zoom and face inspection

Final audit handoff saved 2026-11-11 22:02:15 UTC. Handoff target21:45UTC was missed during an interrupted tool turn; this is before hard stop22:05UTC. Lead work stops after this saved handoff. Main implementation files were never edited. No commits, publication, competing preview server, or browser use.

## Current acceptance: changes required

Fresh command: `node --test tests/sprint-12-runtime.test.mjs tests/sprint-12-camera.test.mjs tests/sprint-12-face.test.mjs tests/sprint-12-ui.test.mjs`.

**10 tests:8 passed,2 failed,exit1.** Full output: `final-tests.txt`. Two intentional red acceptance regressions document unresolved current implementation issues. They must pass after owners apply changes; do not report this suite as green.

1. **A camera owner: inspection orbit crosses the head on a half-turn.** Current rig smooths camera position along a straight Cartesian chord. For yaw0→PI and two legal runtime dt=ln(2)/16 updates, real THREE camera reaches `[~1.7e-16,1.7,0]`, only .12 from face target, with effectively zero horizontal clearance. Exact minimal patch: `camera/OWNER-PATCH.diff`. Candidate is executed from current source in `tests/sprint-12-camera.test.mjs` and passes both the half-turn and invalid-dt-hold/recovery checks. Tradeoff: inspection turns immediately; tactical damping stays. A later polar orbit can smooth inspection without crossing the face.

2. **Root+D: zoom API has no player input.** `dist/action-game.mjs` boot passes only onCamera to createInput; current input does not accept or invoke onZoom. Runtime regression dynamically executes the actual boot function with real createCameraRig and a camera stub: frontal toggle works; onZoom is undefined. Exact root+D proposal: `lead/OWNER-PATCH.diff` (runtime callback, +/- keys, canvas wheel; preserves editable/dialog isolation). `node coordination/v4/SPRINT/12/lead/check-proposal.mjs` passes the in-memory runtime callback candidate, distance2.8→1.8666666666666665. The D keyboard/wheel part is a proposed source patch and was not executed in a candidate input test. Pinch/mobile zoom remains outside this minimal desktop fix.

## Re-evaluated findings

- **Face owner revision accepted at geometry level:** initial old monolithic face occlusion evidence in face/probe-output.jsonl is stale. Current `dist/figures.mjs` now integrates createBody/createFace. Fresh male and female front-ray mouth tests both pass. Do not apply old mouth coordinate proposals. No rendered face-quality claim.
- **UI modal isolation accepted:** both camera and hero shortcuts are blocked during an open dialog and recover after closing. This is expected behavior. No in-dialog inspection control exists in the checked UI; no modal lifecycle bug was proven. Preserve isolation when adding zoom controls.

## Four finite gates

1. Reproduce: saved first report, actual boot callback failure, real THREE camera failure, face raycast probe and UI event tests.
2. Minimal owner fixes: exact root+D diff and A one-line camera diff; no implementation writes.
3. Owner revision re-evaluation: current modular face passes both raycasts; zoom and camera regressions remain open. Runtime candidate and revised camera candidate validated.
4. Acceptance/handoff: fresh combined10-test run,8pass2fail. Audit complete; feature acceptance blocked on the two owners' fixes and subsequent browser/mobile check by root.

## Actual workers and continuity

Exactly3 successful subagent starts: `/root/face_geometry`, `/root/camera_zoom`, `/root/inspection_ui`; lead executed fourth task (runtime). Requested reasoning=max; effective reasoning introspection unavailable. No recursive chats or replacement agents. At21:58UTC live inventory retained only lead and inspection_ui pending_init; face/camera were absent after interruption. Their exact stop times were not observable. Saved artifacts were retained, and lead completed source re-evaluation and final verification. Inspection agent was instructed to stop after saving its final status.

Only writable scope used: coordination/v4/SPRINT/12/** and tests/sprint-12*.test.mjs. Screenshot manifest was not available at the checked standard path; no browser, playability, FPS, actual iPhone or hosted release verification claimed. Root retains those acceptance gates and publication.
