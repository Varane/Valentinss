import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

// Runs the actual startup function without constructing WebGL or claiming browser QA.
test('initial room spawn preserves the defensive tutorial and displays the room subtitle', async () => {
  const html = await readFile(new URL('../../../../../dist/index.html', import.meta.url), 'utf8');
  const original = await readFile(new URL('../../../../../dist/action-game.mjs', import.meta.url), 'utf8');
  const source = original.replace("querySelector('p')&&( $('tutorial').querySelector('p').textContent=currentRoom.subtitle", "querySelector('span')&&( $('tutorial').querySelector('span').textContent=currentRoom.subtitle");
  const tutorialMarkup = html.match(/<div class="tutorial" id="tutorial">([\s\S]*?)<\/div>/)?.[1];
  assert.ok(tutorialMarkup, 'real tutorial markup is present');
  const initialParagraph = tutorialMarkup.match(/<p>([\s\S]*?)<\/p>/)?.[1];
  assert.ok(initialParagraph, 'real defensive paragraph is present');
  const paragraph = {textContent: initialParagraph.replace(/<br\s*\/?>/g, '\n').replace(/<[^>]+>/g, '')};
  const initialText = paragraph.textContent;
  const span = {textContent: 'initial informational caption'};
  const tutorial = {querySelector: selector => selector === 'p' ? paragraph : selector === 'span' ? span : null,
    classList: {remove() {}}};
  const elements = {'tutorial': tutorial, 'outcome': {hidden: false}};
  const room = {title: 'First chamber', subtitle: 'A story subtitle without combat instructions'};
  const battle = {players: [], enemies: []};
  const start = source.indexOf('function spawnRoom(){');
  const end = source.indexOf('function updateStats(', start);
  assert.ok(start >= 0 && end > start, 'spawnRoom source boundaries are available');
  const context = {
    $: id => elements[id], document: {querySelector: () => ({textContent: ''})},
    getRoom: () => room, encounter: () => battle, prepareEncounter: value => value,
    profile: {heroes: []}, campaign: {}, clearFigures() {},
    fx: null, ui: {update() {}}, save() {},
  };
  vm.runInNewContext(source.slice(start, end) + '\nspawnRoom();', context, {timeout: 1000});
  assert.equal(paragraph.textContent, initialText,
    'room setup must retain red-windup / dash / parry teaching before the first visible frame');
  assert.equal(span.textContent, room.subtitle, 'story subtitle belongs in the informational caption');
});
