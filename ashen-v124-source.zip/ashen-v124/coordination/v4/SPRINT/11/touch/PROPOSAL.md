# Touch onboarding — concrete owner proposal

Observed 2026-11-11T21:39:52.856Z. Worker start 2026-11-11T21:39:15.429Z (first successful source access); 1 worker, 0 children, 0 browser/server starts.

Finding: dist/index.html gives the first-minute defensive instruction in #tutorial p (red windup; dash/parry). On initial boot, spawnRoom() runs before loading disappears and replaces that p.textContent with currentRoom.subtitle. Thus the defensive instruction is removed before the first visible frame, for rooms with subtitles. Movement/action labels map correctly by source inspection; orientation and physical phone layout are unverified.

Owner: ROOT, dist/action-game.mjs. Minimal proposal: in spawnRoom(), target #tutorial span instead of #tutorial p when assigning currentRoom.subtitle (both querySelector occurrences). Retain the tactical paragraph; reuse the existing informational span for story subtitle. No new UI or simulation changes.

Regression: tests/sprint-11-touch.test.mjs executes the actual spawnRoom function extracted from the runtime with a deterministic DOM fixture seeded from real index.html. It asserts the tactical instruction survives spawn and the room subtitle is displayed in the informational span. Browser not used.
