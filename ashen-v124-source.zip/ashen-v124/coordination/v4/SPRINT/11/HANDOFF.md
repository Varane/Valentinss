# Team 11 — onboarding in one minute

**LATEST OWNER REVISION22:03UTC — supersedes historical findings below:** `node --test tests/sprint-11*.test.mjs` now runs7 tests,6pass/1fail, exit1. Actual tutorial preservation, renderer failure feedback and campaign import are all VERIFIED FIXED by owners. Only P3 camera shortcut metadata remains at index.html:24; use `keyboard/cycle-2-proposal.patch`. The combined `OWNER-PATCHES.diff` is stale for its runtime hunks and MUST NOT be applied wholesale. All content below records the earlier22:00 evidence. Root received successful22:03 update. No browser verification claimed.

Audit complete; product acceptance remains RED. Actual verification at 22:00 UTC: `node --test tests/sprint-11*.test.mjs` ran **7 tests: 3 pass, 4 fail**. No main implementation files were edited. Root received the first report through a successful authorized message at 21:41 UTC and an updated report after resumption at 21:58 UTC.

## Exact actions for owners

| Priority | Owner / location | Reproduction | Minimal action |
|---|---|---|---|
| P1 | C / `dist/campaign.mjs:1` | Real dynamic import throws `ERR_MODULE_NOT_FOUND`, missing `dist/campaign/rooms.mjs` | Supply the C-owned missing module exporting `roomDefinition`; rerun actual import and objective test. The dependency chain must close before launch can be accepted. No invented replacement data is proposed. |
| P2 | ROOT / `dist/action-game.mjs:38` | Actual `spawnRoom()` overwrites the tactical paragraph before loading hides | Apply `touch/OWNER-PATCH.diff`: change both subtitle-assignment selectors from `p` to `span`. Existing room objective remains displayed in the informational span while red-windup/dash/parry teaching survives. |
| P2 | ROOT / `dist/action-game.mjs:23` | Force WebGLRenderer constructor to throw; loading text stays “Собираем комнату…” | Apply `lead/OWNER-PATCH.diff`: show the existing actionable startup error message around the top-level renderer constructor, then retain the real error. |
| P3 | D / `dist/index.html:24` | Real KeyC invokes camera callback; button has no shortcut metadata | Apply `keyboard/cycle-2-proposal.patch`: add `aria-keyshortcuts="C"` and `title="Сменить ракурс · C"`. |

The two ROOT proposals were separately verified against current actual source **in memory only**: startup candidate 1/1 passes, tutorial candidate 1/1 passes. Keyboard worker verified exact one-line proposal applicability and ran 11 relevant tests, 10 pass/1 fail for current missing metadata. Owner implementation still has all three original lines as of the 22:00:21 UTC source reread.

## Acceptance evidence and limits

- Real combat/menu input callbacks pass the keyboard mapping regression.
- Opening objective says to defeat the entrance guards. The real extracted `validateOutcome` guard rejects living enemies, accepts all defeated enemies with a surviving hero, and rejects no-survivor victory. These two objective checks pass; no objective/victory mismatch was reproduced.
- The campaign module import is a separate actual integration failure. Source guard extraction does not count as campaign integration success.
- Test source execution replaces DOM/WebGL boundaries. No browser, screenshot, physical phone, playability, multiplayer, performance or FPS acceptance is claimed. Root owns browser4173; it was not touched.
- All four failures are intentional red acceptance regressions, not claims that the product is fixed. Root/owners must apply the proposed revisions then rerun the tests.

## Four bounded gates and actual workers

1. Evidence: original lead plus exactly three real subagents started; concrete callback, tutorial and constructor-error reproductions recorded.
2. Minimal fixes: exact proposals saved without implementation edits; no speculative feature work.
3. Revision verification: current source reread; candidate checks pass in memory, actual acceptance remains red.
4. Handoff: this file, ACCEPTANCE.json and final status record unresolved owners and stop state.

Actual child IDs: `/root/keyboard_onboarding`, `/root/touch_onboarding`, `/root/objective_onboarding`. Keyboard completed its four gates at 21:43:18 UTC. Touch reached 75% before interruption; objective reported actual source evidence but had no persisted status at interruption. An environment/tools update interrupted work around 21:43; the next observed clock was 21:58 and all original children were absent from the live inventory. No replacements or recursive agents/chats were started. Lead finished the bounded touch/objective acceptance evidence afterward. Handoff target21:45 was missed during that interruption; final handoff22:01 is before22:05 hard stop.

All writes are scoped to `coordination/v4/SPRINT/11/**` and `tests/sprint-11*.test.mjs`. No commits, pushes, publication or implementation mutations.
