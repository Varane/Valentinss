# Cycle 1 — evidence

Started 2026-11-11T21:36Z; evidence captured 2026-11-11T21:39:59.036Z.

Actual dist/input.mjs dispatches KeyC to onCamera(); root action-game.mjs wires onCamera to rig.toggle(). Camera index.html button displays ◉ with title="Сменить ракурс" and no aria-keyshortcuts. Neither the visible keyboard-hint nor canvas aria-label mentions C. Other advertised combat/menu keys match source.

No browser use or implementation writes. A Node callback/markup regression is now saved.
