# Keyboard onboarding audit

Audit stopped 2026-11-11T21:43:18.099Z. Four gates complete.

P3: C works as a camera shortcut (input.mjs:91; runtime callback action-game.mjs:86), but index.html:24 camera button has neither C tooltip hint nor aria-keyshortcuts. The visible keyboard hint also omits C. No incorrect advertised combat/menu key was reproduced.

Minimal owner patch is cycle-2-proposal.patch (one index.html line). It applies exactly once and passes proposed markup assertions in memory. This worker did not edit implementation.

New regression: tests/sprint-11-keyboard.test.mjs. Combined command node --test tests/sprint-11-keyboard.test.mjs tests/input-controls-dom.test.mjs tests/sprint-10-keyboard.test.mjs: 11 tests, 10 pass, 1 expected fail, exit1. Actual input callback assertions pass; failing assertion identifies undisclosed C shortcut.

Status100 means audit complete. Product acceptance remains pending owner implementation then rerun. No browser/server/device verification claimed. Actual test-run observations and source hashes are saved beside this file.
