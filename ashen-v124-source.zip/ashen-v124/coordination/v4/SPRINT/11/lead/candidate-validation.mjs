import {readFile} from 'node:fs/promises';

const testUrl = new URL('../../../../../tests/sprint-11-startup.test.mjs', import.meta.url);
const runtimeUrl = new URL('../../../../../dist/action-game.mjs', import.meta.url);
const before = "const renderer=new T.WebGLRenderer({canvas:$('scene'),antialias:true,powerPreference:'high-performance'});";
const after = "const renderer=(()=>{try{return new T.WebGLRenderer({canvas:$('scene'),antialias:true,powerPreference:'high-performance'});}catch(error){$('load-text').textContent='Не удалось запустить 3D-комнату. Обновите страницу или попробуйте другой браузер.';throw error;}})();";
const actual = await readFile(runtimeUrl, 'utf8');
if (!actual.includes(before)) throw new Error('Owner revision changed: reevaluate candidate against actual source');
let candidateTest = await readFile(testUrl, 'utf8');
candidateTest = candidateTest.replace("new URL('../dist/action-game.mjs', import.meta.url)", `new URL(${JSON.stringify(runtimeUrl.href)})`);
candidateTest = candidateTest.replace("(await readFile(runtimeUrl, 'utf8')).replace", `(await readFile(runtimeUrl, 'utf8')).replace(${JSON.stringify(before)}, ${JSON.stringify(after)}).replace`);
console.log('Candidate-only run: actual runtime patched in memory; no production files changed.');
await import('data:text/javascript;base64,' + Buffer.from(candidateTest).toString('base64'));
