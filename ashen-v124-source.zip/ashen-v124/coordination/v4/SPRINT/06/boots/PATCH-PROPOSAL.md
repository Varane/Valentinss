# Boots contract owner proposal

Recorded 2026-11-11 21:42 UTC. Scope: rules/save/equipment UI only. No implementation edits made.

Canonical data declares `rune_boots`, `slot: 'boots'`, defense 2 (`dist/campaign/balance.mjs` baseline). `dist/rules.mjs` has additive `boots: null`, includes boots in defense, equips by item slot, clears boots on legacy final death, and validates boots ownership plus slot during restore. `dist/ui/equipment.mjs` uses item.slot for current/projected values and dispatches `(heroIndex, itemId)` explicitly.

## C owner: restore public dependency graph first

`node --test tests/rules.progression.test.mjs tests/input-ui-equipment.test.mjs` failed both files before any assertions: `ERR_MODULE_NOT_FOUND dist/campaign/save.mjs` imported by rules.mjs. At cycle 2, `dist/campaign/items.mjs` and `dist/campaign/progression.mjs` are also absent. Required patch is to deliver those existing declared modules with their owner contracts; this audit does not invent substitute persistence behavior.

## D owner: include boots in UI refresh fingerprint

In `dist/ui.mjs`, function `stateKey`, change the hero row suffix:

```js
// before
h.weapon,h.armor,h.dead,h.down
// after
h.weapon,h.armor,h.boots,h.dead,h.down
```

Why: an authoritative/profile restore replacement changing only hero.boots retains every existing fingerprint field. `update()` calls `refresh(false)`, so the visible equipment defense remains stale. Local onEquip callbacks force refresh and do not hit this path. This is an integration refresh issue, not evidence that local boots equip fails.

`tests/sprint-06-boots.test.mjs` exercises actual public modules: immutable two-hero equip/save preservation; old-save compatibility; wrong-slot/unowned rejection; selected hero inventory/projection; exact `(1, 'rune_boots')` callback and stale hero protection; and the boots-only facade refresh expectation. Known refresh regression is TODO-labelled until owner patch/re-evaluation. At cycle 2 import failure prevents execution; it is not a passing result.

Root runtime/figure boots propagation is independently owned by team06 lead and excluded from this proposal.
