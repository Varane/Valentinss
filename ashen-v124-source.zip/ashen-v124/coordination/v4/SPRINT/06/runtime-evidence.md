# Team06 runtime seam — cycle1

Actual lead work: inspect `dist/action-game.mjs` runtime function bodies against an equipped profile fixture. No production file edited.

At first inspection the runtime's `spawnRoom` only gives `weapon` and `armor` to `makeFigure`; `updateStats` copies those same slots and calls `setEquipment` with two arguments. `endIndividualDeath` clears weapon/armor but leaves `hero.boots` equipped in the profile until another layer normalizes it, and calls two-argument `setEquipment(null,null)`, which preserves boots in the modular equipment controller.

The regression executes the actual production `updateStats` and `endIndividualDeath` function bodies in a narrow VM context. It uses a profile fixture with the two rune items equipped and a stats collaborator. Initial attempt importing real rules was blocked by missing `dist/campaign/save.mjs` at 21:39 UTC, so this test isolates the runtime boundary; separate agents own rules integration. It does not claim browser validation. Known failures are TODO-labelled so the shared full suite remains runnable; TODO failures are evidence of open bugs, not passes.

Command: `node --test tests/sprint-06-runtime.test.mjs`.

Ownership: root owns `action-game.mjs`; B owns public figure support; A owns actor schema if boots is to be exposed there. Proposed runtime patch is a review artifact only.
