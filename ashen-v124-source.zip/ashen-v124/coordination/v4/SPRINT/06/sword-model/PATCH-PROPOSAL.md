# Rune sword: bounded owner patch proposal

Cycle 2. This file proposes code only. No implementation files were edited by this worker.

The public facade at SHA256 `81709f814e55cafead7cf09ca2c4dc2371ff525a10bc81d7bc9f82a6629dfae0` returns the ordinary blade for `rune2h`. The modular factory at `a382d1d1aacde0db6a2783eb8c899e94c726b3886af04cdccd5937bf687723b6` excludes `rune2h`, so its group is empty even though the controller reports `weaponId='rune2h'`. Both failures are executable in `tests/sprint-06-sword-model.test.mjs`.

## 1. B2 owner: equipment-weapons.mjs

Add `'rune2h'` to `IDS`. Add the following material entry:

```js
rune: { color: '#4f9bce', emissive: '#245f91', emissiveIntensity: 0.5, metalness: 0.35, roughness: 0.4 },
```

Add this branch before the final `return group`. Existing `grip`, `rod`, `box`, `profile` helpers own all resources:

```js
if (equipmentId === 'rune2h') {
  grip(-0.12, 0.19);
  mesh('rune-pommel', new THREE.OctahedronGeometry(0.045, 0), 'darkMetal', 0, 0.235);
  box('rune-crossguard', 'darkMetal', 0.30, 0.035, 0.055, 0, -0.16);
  rod('rune-collar', 'darkMetal', -0.205, -0.17, 0.033);
  const shape = new THREE.Shape();
  shape.moveTo(-0.04, -0.20);
  shape.lineTo(-0.055, -0.88);
  shape.lineTo(0, -1.13);
  shape.lineTo(0.055, -0.88);
  shape.lineTo(0.04, -0.20);
  shape.closePath();
  profile('rune-steel-blade', shape, 0.032);
  for (const y of [-0.37, -0.54, -0.71]) {
    for (const z of [-0.019, 0.019]) {
      const mark = box('rune-mark', 'rune', 0.012, 0.055, 0.004, 0, y, z);
      mark.rotation.z = 0.45;
    }
  }
}
```

This is a concrete minimal authored geometry option. An owner-authored distinct rune sword branch with matching ownership metadata satisfies the same regression tests.

## 2. B1 owner: public figures.mjs

Route the existing public facade through already implemented B2 controller. These edits can be applied to the legacy body without replacing B1's concurrent body/face work:

```js
import { weaponModel as buildWeapon } from './figures/equipment-weapons.mjs';
import { attachEquipment } from './figures/equipment.mjs';
```

Replace the entire local `weaponModel` implementation with:

```js
export function weaponModel(id) { return buildWeapon(id, palette); }
```

Add `boots=null` to `makeFigure` options. Add `weaponSocket:rightHand` and `boss` to the returned `figure` object. Replace the old local `setEquipment` function and its initialization with:

```js
const equipment = attachEquipment(figure, {weapon, armor, boots, materials: palette});
figure.setEquipment = (...slots) => {
  equipment.setEquipment(...slots);
  torso.material = figure.armorId === 'leather' ? palette.red : palette.leather;
};
figure.setEquipment();
```

In B1's planned `figure.dispose`, call `equipment.dispose()` before body/face/palette disposal. Existing module-level palette is shared, so a legacy facade must avoid disposing that shared palette from one figure. Prefer B1's per-figure palette during their integration. B2's existing animator supports rune2h; B1's facade should forward to `createAnimator(figure)` once the animator integration lands.

## 3. C owner: rules import dependency

The observed rules revision imports `./campaign/save.mjs`, which was absent during both initial probes. Restore/add the intended owner module or coordinate the import revision before final runtime acceptance. This is independent from the rune visual patch.

## Recheck command

`node --test tests/sprint-06-sword-model.test.mjs`

Six tests exercise actual imports, finite geometry/transforms, distinct rune geometry, the public constructor, public three-slot equipment swapping, and retained/disposed modular resources. No browser or server was launched.
