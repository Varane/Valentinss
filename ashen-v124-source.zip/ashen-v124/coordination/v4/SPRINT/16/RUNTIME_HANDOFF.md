# Sprint16 runtime acceptance — root owner action

Source inspected: dist/action-game.mjs, dist/ui/network-client.mjs, dist/sw.js, docs/network/API.md at approximately21:43UTC. Three actual child agents separately check auth, consistency and delivery; lead is fourth worker. No browser, preview server, publication or main source changes.

P1 current blocker: root runtime declares network=null and never assigns it, imports no createRoomClient and calls no ui.setNetwork. Its network branches expect action/move/connected while the delivered client exports sendInput/getState/onSnapshot. Online rooms are not integrated into the game. This is independent of whether backend Node tests pass.

P1 latent authority violation: settle() unconditionally calls local resolveRoom/save. Once snapshots are connected, an online victory would award local progression unless settlement is isolated. perform/frame use network.connected as a field; createRoomClient exposes getState().connected, not a connected property.

Minimal safe release proposal against current root source: keep this release explicitly local/offline until the room client adapter is implemented and verified. Do not advertise or enable create/join in UI on this runtime. Complete network integration requires (1) import/createRoomClient with configured endpoint, (2) ui.setNetwork(client), (3) adopt onSnapshot encounter/profile and authenticated members.heroIndex without saving over local profile, (4) dispatch bounded sendInput, (5) gate local command/step/rewards for the entire retained room session, including reconnecting, (6) release session only after confirmed leave/expiry. A bare assignment network=createRoomClient is not compatible with current branches.

Exact minimum authority guard proposal for settle(), pending a session adapter: prepend `if(network?.getState?.().roomId || network?.connected)return;` before changing settled or profile. Equivalent guards are needed on local save/death and reconnect fallback; this isolated guard alone does not provide working multiplayer.

Executable evidence: node --test tests/sprint-16-runtime.test.mjs. The first two tests are expected red on inspected runtime and are release gates, not accepted failures. Third executes actual service-worker fetch handler and checks room API bypass. No browser/playability/FPS/device/hosted multiplayer claim.
