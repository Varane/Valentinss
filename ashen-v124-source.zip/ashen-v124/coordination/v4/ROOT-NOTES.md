# Root integration notes

`dist/action-game.mjs` now exists and imports the exact public APIs in MASTER. Read it rather than guessing how the host calls your modules. It is root-owned; don't edit it. UI is created after encounter/models, so getEncounter() is available at createUI time. UI callbacks onEquip/onLearn return the updated profile synchronously and may throw a user-facing Error. A screenshot-ready first assembled scene is needed early enough to correct visual problems.

World: owns all scene lighting and environment; root only sets fog/background, ACES exposure1.16 and shadow renderer. No second canvas/camera/render loop.

Simulation: root calls step at max dt=.05, command for actions, drains state.events with splice(0) each frame. Hero death events permanently clear only that hero's bag/equipped items; final resolveRoom handles end-of-room reward/quest progression. Please identify if campaign resolveRoom duplicates or disagrees with individual death handling. Simulation can accept additive second room config parameter to encounter(profile,roomConfig); root passes it.

UI: root additionally supplies getBlood()/setBlood(bool). Pause must freeze battle through onPause and isOpen. Input owns stick/keyboard/buttons and sends actions; avoid registering duplicate button action handlers in UI and input. UI may add optional showStory(room,onChoice)/roomChanged(room) for meaningful campaign choices. Coordinate exact optional API via handoff, preserve base API.

Campaign: need exact handling for room choices/puzzles and a safe schema for restoring saved campaign. createCampaign(profile,savedCampaign) is invoked with optional saved data; extra argument can be ignored only if you provide another restore API. Root calls roomFor(campaign) before encounter(profile,room). It expects resolveRoom returns advanced or completed campaign; on restart after victory it spawns roomFor(campaign) immediately. Hero terminal death clears items immediately (root event handling); campaign must not restore them or award lost gear to dead heroes. End-of-campaign flag done/completed must be explicit.

Network: root currently has a `network` adapter slot but local rendering runs. Need browser client adapter API and any required room UI integration by handoff. Aim getSnapshot/onState, create/join room, action/move, own player slot, connected flag, reconnect. Root does not publish before coherent verification. Hosting manifest changes/build are root-owned.

Do not add more planning/approval gates. The actual user requested full implementation during the hour. Main handoffs targeted21:30UTC; freeze21:40; integration deadline21:51.
