# Movement solver handoff

Owner: movement-camera / movement_solver. Only production/test edits: dist/combat/movement.mjs and tests/action-movement.test.mjs.

## Integration

Import { PILLARS, moveActor, normalizeInput } from './combat/movement.mjs' in dist/action.mjs. No imports/dependencies in movement.mjs, and no action.mjs import cycle.

- PILLARS = [[-4,-2.5],[4,-2.5],[-4,3],[4,3]].
- moveActor(actor, dx, dz) mutates actor.x/z only and returns the original actor. Free movement preserves the requested displacement. Collision uses the legacy combined pillar/body radius 0.85. Actor-centre floor bounds are x[-6,6], z[-5,5]. Walls/circles remove only inward movement and retain tangential sliding. Swept ray-circle intersections stop large displacements at their entry contact; no distance-based substep loop.
- normalizeInput(input) returns a fresh finite {x,z}; analog magnitudes <=1 are preserved, greater lengths normalized without overflow. Invalid axes (including NaN/Infinity, strings, symbols, BigInt, objects) become 0 independently.
- Missing/non-object actor is a no-op returning the same input. Invalid actor x/z become 0; out-of-room positions are clamped. An actor already inside a pillar is pushed to its surface, using +X deterministically at its exact centre.

## Bounded cost and numerical choices

Maximum 12 swept contacts per call, each with 4 pillar tests and up to 2 relevant outer walls; initial/final repair each inspect 4 pillars. Unconsumed displacement is discarded safely if the contact limit is reached. This bound is independent of requested travel distance and applies to huge finite displacements. It is not a frame-rate benchmark.

Contact skin 1e-9 avoids repeated contact jitter. Motion below 1e-12 is discarded. A circle's radial-hit tangent <=1e-12 is treated as numerical roundoff so huge displacements cannot amplify it; wall tangent components retain any nonzero length, covering tiny relative axes whose absolute displacement is significant.

## Verification

Final focused command: node --test tests/action-movement.test.mjs
Actual result: 12 tests, 12 pass, 0 fail; exit 0. The suite covers actor identity/free movement, analog normalization including MAX_VALUE, invalid input, four room walls and move-away, pillar dash entry stops, oblique slide, centre overlap repair/idempotence, huge finite movement with tiny relative axes, all 4 pillars approached along 32 directions each, and 4000 deterministic sequential movement calls asserting finite bounds and non-overlap.

Two regression cycles were reproduced red then green: preserving a significant tiny-relative wall axis, and suppressing a false floating-point tangent after an exactly radial huge dash. The latter initially produced x=-5.999999999 instead of -4.833667488342746; the circle/wall tangent distinction fixes it without weakening the test.

No browser, preview server, publication, git changes, external dependencies or other production files were touched. No actor-vs-actor collision or navigation/pathfinding is introduced by this module.

Additional shared action-suite run at 21:26 UTC: node --test tests/action*.test.mjs (11 files enumerated explicitly). Result45 pass,7 file-level failures, exit1; movement12/12 and camera1/1 pass. Failing files: action-adversarial, action-contract, action-fuzz, action-integration, action-performance, action-skills, action.test. Shared production modules were still evolving during this run; no foreign files were changed.
