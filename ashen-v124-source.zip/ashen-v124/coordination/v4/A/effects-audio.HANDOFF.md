# Effects and combat audio handoff

Status at 2026-11-11 22:08 UTC: all three production submodules exist, imports resolve, and the complete requested verification passed: 55 tests, 55 pass, 0 fail. Ready for root integration. No production effect changes remain pending.

## Executors

Exactly four actual executors: lead `/root`, children `/root/particles`, `/root/slashes`, `/root/audio`. All three children accepted `reasoning_effort: ultra`, `fork_turns: none`, no model override. No child was authorized to delegate. Exact starts and files are in `effects-audio.STATUS.json`.

The session was globally interrupted. Existing slash/audio workers were resumed with `followup_task`, without replacements or additional starts. At the final live-agent check only lead `/root` remained listed; child implementation status below is based on actual files and independently rerun tests, not a claim that the children are still running.

## Root integration

`dist/effects.mjs` exports `createEffects(scene, {reduced, blood})`. Required methods are `emit(event, encounter)`, `update(dt,time)`, `setBlood(bool)`, `clear()`, `dispose()`. Root's existing `events.splice(0)` loop and `update(dt,elapsed)` need no changes. Effects use the existing local Three module, no packages or external assets, no lights, renderer or scene-wide mutation.

Optional additions: options `sound` (default true), `eventTarget`, `contextFactory`, `particleCapacity` (96 default), `slashCapacity` (16 default); methods `setReduced(bool)`, `setSound(bool)`, `unlockAudio()`, `stats()`. `unlockAudio()` is only an optional hook for an existing gesture handler; automatic gesture listeners live in the audio child. To honor the stored sound preference at boot, root may pass `{reduced,blood,sound:options.sound}`. Sound effects are short combat cues only; music remains owned by the separate music lead.

`normalizeEffectEvent(event,encounter)` is an additive named export returning a finite normalized cue or null for unsupported input. It accepts legacy `actor`/`enemy` indices, player IDs, explicit event `x/y/z`, structural `source`/`target` references, and numeric `source`/`target` accompanied by `sourceType`/`targetType`. Hit/kill/windup resolve at the enemy; hurt resolves at the player. Known events: swing, hit, hurt, parry, guard, dash, evade, kill, down, death, revive, victory, defeat, windup.

Repeated event IDs are suppressed in a bounded 256-entry set; repeated legacy event objects use a WeakSet. A different encounter object resets previous effects and allows IDs to restart. `clear()` empties active cues and resets this history; `dispose()` is idempotent and releases only owned resources. Calls after disposal are safe no-ops.

## Verified submodules

- `dist/combat/effects/particles.mjs`: `createParticleEffects(scene,{reduced=false,blood=true,capacity=96})` returns `{emit,update,setBlood,setReduced,clear,dispose,stats}`. One instanced tetrahedron pool, restrained oxblood fragments and neutral sparks, no lights. Capacity is sanitized and capped at 512. Disabling blood immediately removes existing blood. Reduced mode reduces count and motion; changing reduced mode clears existing bursts. 11/11 tests passed.
- `dist/combat/effects/slashes.mjs`: `createSlashEffects(scene,{reduced=false,capacity=16})` returns `{emit,update,setReduced,clear,dispose,stats}`. Five prebuilt authored BufferGeometries and fixed Mesh/material pool (cap 64). Swing ribbons and compact parry/guard/windup marks expire within .24 seconds; reduced marks are static, .1 seconds, low opacity. No lights or external assets. 11/11 tests passed.
- `dist/combat/effects/audio.mjs`: `createAudioEffects({reduced=false,enabled=true,eventTarget=globalThis.window,contextFactory})` returns `{emit,update,setEnabled,unlock,clear,dispose,stats}`. Lazy original WebAudio synthesis, maximum 12 concurrent voices, event/cooldown/token throttling, short combat cues only, no ambient or music loop. Native contexts are owned; injected raw contexts are shared and left open. Factory results `{context,owned:true}` opt into closing that context. Gesture listeners, voice nodes, pending resume/factory completion and rejected close are handled by cleanup. 16/16 tests passed.

## Final narrow repair and verification

Read `coordination/v4/SPRINT/08/combat/fix-proposal.patch`. At the resumed 22:06 inspection, `dist/effects.mjs` already contained the exact proposed numeric-reference changes. Accepted the current implementation without applying a duplicate patch. The real `hitPlayer` regression now proves that enemy at x=1 hitting player at x=0 yields cue dx=-1,dz=0, with legacy dash direction preserved.

Reproduced both audio failures. Their cause was the test context's source classifier: `type` simultaneously held the mock node category and the writable oscillator waveform. Production legitimately assigned `triangle`/`sine`, after which the test's `sources` getter omitted those nodes. Minimal repair in `tests/effects-audio.test.mjs` adds stable `nodeType` metadata and classifies sources by it. No SFX production changes or new features were required. The initial broad command also had an argument-splat invocation error; the final explicit-file command below avoids it.

Initial development red command: `node --test tests/effects.test.mjs` exited 1 because the integration module did not yet exist. Final focused command `node --test tests/effects-audio.test.mjs`: exit 0, 16 pass, 0 fail.

Final complete command (2026-11-11 22:08 UTC):

```text
node --test tests/effects.test.mjs tests/effects-contract.test.mjs tests/effects-particles.test.mjs tests/effects-slashes.test.mjs tests/effects-audio.test.mjs tests/sprint-08-combat.test.mjs tests/action-integration.test.mjs
```

Exit 0: **55 tests, 55 pass, 0 fail, 0 skipped**. Counts: lead integration 8, independent effects contract 6, particles 11, slashes 11, audio 16, SPRINT08 2, director integration 1 (three-room lifecycle). This validates finite transforms, browser-free creation, history replay, room changes, bounded bursts/voices, reduced motion, blood/mute controls, incoming hit direction and owned resource disposal. No broader repository-suite result is claimed.

## Limits

No browser rendering or native speaker listening has been performed by this worker; root owns the single preview server and browser. Node tests prove resource and lifecycle behavior, not visual appearance, perceived audio mix or phone FPS. No preview server, publication, commits, worktrees, music files or root runtime files were changed. No remaining blocker in the effects/audio scope.
