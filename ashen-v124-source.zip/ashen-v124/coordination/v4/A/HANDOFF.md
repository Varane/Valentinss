# A — Engine & Action handoff

Status at 20:59 UTC: active implementation; this is the early integration contract, not a completion claim. Four worker chats are active at ultra reasoning; real IDs and confirmed worker counts are tracked in STATUS.json.

## Public integration

Preserved: `encounter(profile)`, `step(state,dt,{x,z},selectedIndex)`, `command(state,type,index)` from `dist/action.mjs`, and `PILLARS`. Additive optional encounter room argument is planned; final exact behavior will be documented below when verified. All MASTER player/enemy fields remain supported. Event objects will retain legacy actor/enemy indices and gain monotonic id plus simulation time.

Planned exports (worker implementation in progress):

```js
import {encounter,step,command,PILLARS} from './action.mjs';
import {createEffects} from './effects.mjs';
import {createCameraRig} from './camera-rig.mjs';
const fx = createEffects(scene,{reduced:false,blood:true});
const rig = createCameraRig(camera,{mobile:false});
// Simulation: step(encounter,dt,input.vector(),selected).
// Dispatch each newly emitted event once: fx.emit(event,encounter).
// Animation: fx.update(dt,elapsed); rig.update(dt,encounter.players[selected],encounter).
// Resize: rig.resize(width,height); switch view: rig.toggle().
// Teardown: fx.dispose().
```

Effects owns visual/audio resources only. It does not mutate simulation or run a second loop. Camera owns camera transforms, not renderer/world/actor creation. New modules use bundled Three rather than installing dependencies.

## RPG alignment notes

Additive `mana,maxMana` player fields are requested for existing skill semantics: specials cost 3 mana; normal attacks recover 1 mana or 2 with arcane3; arcane1 grants +3 max mana. Revive normal 35%, guard3 70%. Actual implementation and test status pending. Hero dead/down state must survive encounter creation; profile reward/death persistence is direction C-owned.

## Verification

Baseline before edits: `node --test tests/action.test.mjs tests/rules.test.mjs tests/runtime.test.mjs` → 19 passed, 0 failed. New production modules and combined direction suites remain pending. Browser and actual iPhone checks are root-owned and have not been performed by A.

## Worker reports

- combat-ai.HANDOFF.md — simulation and skill mechanics (pending).
- movement-camera.HANDOFF.md — collision and camera (pending).
- effects-audio.HANDOFF.md — visual/audio lifecycle (pending).
- adversarial-qa.HANDOFF.md — replay/invariant/performance/API checks (pending).
