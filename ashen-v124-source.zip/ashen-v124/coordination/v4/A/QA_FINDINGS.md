# Adversarial QA findings

Updated 2026-11-11 21:30 UTC. Lead owns this file; production remains read-only.

## Fresh integrated result

Command: node --test tests/action-adversarial.test.mjs tests/action-contract.test.mjs
Result: 32 tests, 31 pass, 1 fail, 0 skipped, exit 1. All 23 adversarial scenario tests pass. The remaining contract case expects command(state,'parry',undefined) to reject, although the integrated API now has index=0. This is an additive default, not a mandated rejection; contract owner is correcting that case while retaining real invalid indices -1/99/NaN.

## Confirmed baseline defects, now covered by passing regressions

1. Defense windows: old step(.35) expired parry/dash before resolving an impact at .1, causing hp84 instead of100. Integrated tests cover long frames, partitioning, normal .05 runtime steps near expiry (.29 parry/.32 dash), and actual parry success/failure at .29/.31. All pass after fixtures face actors toward each other.
2. Source death and health: old encounter recreated hp100/deadfalse from hp0/deadtrue, or healed hp17. Integrated tests preserve final-dead/wounded actors and reject their commands; pass.
3. Revive: old40% differed from declared35%. Integrated behavior uses ceil(maxHp*.35), guard3 ceil(maxHp*.7), matching rules.mjs. Both pass.
4. Pillar tunnelling: old movement crossed pillar(-4,-2.5) in one dt1 frame. Integrated regression passes.
5. NaN dt: old simulation time/timers became NaN. Integrated finite-state checks pass for NaN/Infinity/-Infinity/-1.

## Test corrections, not production defects

The first integrated run had 9 scenario failures from outdated duel fixtures: enemy yaw0 aimed away from the hero, player yawPi did not face the enemy, companion AI interfered with isolated rescue/defeat, and expected revive health omitted existing integer rounding. Fixture now explicitly disables companionAI and faces actors correctly; expectations use rules semantics. None of these failures was hidden with skip or broad catches.

## Transitional build blockers observed

At21:20-21:26 imports temporarily failed for combat/ai.mjs, combat/skills.mjs, campaign/balance.mjs and campaign/save.mjs while owners wrote modules. Those are historical integration observations, not current behavioral defects: latest32 tests imported successfully.

## Remaining scope

Fuzz, performance and effects contract agents maintain independent reports under adversarial-*.REPORT.md. Final combined result will be appended after their fresh runs. Node simulation tests do not establish browser rendering, sound audibility, network authority, mobile interaction or absolute FPS.
