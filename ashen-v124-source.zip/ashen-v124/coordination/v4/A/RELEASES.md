# Release queue for direction A

Human steering at 21:21 UTC: public release 2.0 first, independent audits feed 3.0 while the user tests 2.0, then 4.0 from feedback. Internal paths remain coordination/v4. Existing worker hierarchy only. Root owns immutable tested release snapshots, integration and presentation/publication. Do not overwrite root's tested releases.

## Release 2.0 gate — freeze 21:40, presentation gate 21:51 UTC

P0: every action/effects/camera import resolves; normal movement, attack, dodge, parry and rescue work; existing source health/death persists; mana matches RPG descriptions; camera exposes a useful portrait combat frame and a direct close facial inspection mode; touch wiring belongs to D/root. Audio remains gesture-safe with short SFX only. New modules must not require a dependency install or second loop.

P0 verification: baseline API tests, adversarial timing/NaN/collision regressions, event-drain lifecycle, camera and effects cleanup. Browser/device appearance and end-to-end onboarding are root/independent-QA gates. Do not call Node timing a phone FPS measurement.

## Release 3.0 audit queue

After root snapshots 2.0, independently assess attack cadence/AI pressure, portrait combat target visibility, inspection return-to-combat clarity, action-to-effect alignment and bounded cleanup over repeated rooms. Record concrete reproducible findings with severity and evidence. Implement only assigned improvements in source after the root confirms its snapshot and handoff window; root owns promotion into 3.0.

## Release 4.0 feedback queue

Use actual user feedback plus remaining independent QA. Prioritize phone control/camera defects and incorrect combat outcomes before cosmetic effects. Final improvement window 22:05 UTC. Ready modules go promptly to root; do not wait for an open-ended audit.

## Operational note

At 21:18 UTC combat-ai and adversarial-qa had interrupted/notLoaded turns. Existing chats were explicitly resumed at 21:19–21:21. Worker leads must report real resumed subagent availability, and may not silently count interrupted agents as currently running. Lifetime starts remain 12 confirmed; no new workers were requested.
