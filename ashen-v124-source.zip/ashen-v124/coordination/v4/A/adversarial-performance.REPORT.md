# Performance QA — current handoff

Owner: adversarial-qa performance subagent. Production read-only. Only `tests/action-performance.test.mjs` and this report were written. No extra agents, servers, worktrees, commits or publication.

## Delivered tests

`tests/action-performance.test.mjs` uses the public `encounter`, `step`, `command` and documented mutable encounter state.

- 72,000 active seeded frames across seeds `0x62d92a17`, `0x8e2017bf`, `0x1405c0de`: durable HP fixtures retain live combat/AI instead of spending the run in terminal no-ops. Checks finite actor state, constant entity-array lengths, eviction of the original event, and retained history at most 2,048 (a deliberately generous regression guard, not an asserted engine limit).
- 12,000 additional seeded frames using the runtime consumer's `events.splice(0)` drain. Every consumed event must have a safe integer ID larger than the previous consumed ID, including across empty buffers.
- 50,000 repeated held-attack commands during one cooldown: all reject without HP/stamina/history mutation, and without repeatedly scanning the enemy array. Array reads are observed with a transparent Proxy, rather than inferred from a clock.
- Huge input and dt matrix: `dt=0,1,1e12,Number.MAX_VALUE,Infinity`, diagonal inputs of magnitude `1e300` and `Number.MAX_VALUE`; 16 calls per combination in a separate Node process. Checks finite state and that traversal work does not grow with dt magnitude versus `dt=1`. A 30-second child-process watchdog only terminates hangs; it is not an FPS or throughput assertion.
- Room workloads of 16, 64 and 256 enemy descriptors for 64 frames using the actual `encounter(profile,{enemies})` API. Reports actual enemy counts, array reads and retained events; broad structural guard allows sorting and bounded substeps. Explicitly skips if the actual room API is absent rather than pretending ignored arguments create a stress workload.

## Verification history

All commands executed from:

```text
C:\Users\Valen\Documents\Codex\2026-11-11\referenced-chatgpt-conversation-this-is-an\work\ashen-room
```

Node reported `v24.11.1`.

### Initial implementation, before action integration

```text
node --test tests/action-performance.test.mjs
```

Result: 4 tests; 1 pass, 2 fail, 1 skip (exit 1).

- Held attack: passed, 50,000 rejected commands, only 1 observed enemy-array read including the final assertion, retained events 2.
- Huge-input confirmed defect in the old action implementation: a `Number.MAX_VALUE` diagonal produced infinite player speed, even at dt=0. Large dt itself terminated; ordinary `1e300` diagonal cases used 212–268 enemy-array reads across 16 calls.
- The initial soak's `accepted > 1000` coverage assertion was too strict for stamina-limited actions. This was a test-fixture assertion, not a production defect; corrected to `accepted > 100` while retaining `rejected > 1000`. The tests still require thousands of active frames and event eviction.
- Room workload skipped honestly because that version had no room API.

### Integration milestone, approximately 21:20 UTC

```text
Get-FileHash -Algorithm SHA256 -LiteralPath dist/action.mjs
node --test tests/action-performance.test.mjs
```

Observed action SHA256: `63096B8BD8815D35C8DD3B666B7B7CC9DAADA425200A02893FD5E937134AC97A`.

Test loading failed with `ERR_MODULE_NOT_FOUND` for `dist/combat/ai.mjs`. The new action already contained the real room API, event IDs and bounded 1/120-second simulation slices; this is a transient concurrent-build failure.

### Next milestone, approximately 21:24 UTC

```text
node --test tests/action-performance.test.mjs
```

Test loading failed with `ERR_MODULE_NOT_FOUND` for `dist/campaign/balance.mjs` imported by the concurrently edited `dist/rules.mjs`. `dist/combat/ai.mjs` and `skills.mjs` were now present. No performance test body ran in this attempt.

## Limits

These checks measure observable retained history, entity counts, target traversal and termination. They do not measure total JavaScript allocations, GC behavior, browser rendering, GPU work, device FPS, or online two-player latency. State fixtures increase HP to keep a long live simulation; they do not claim normal campaign balance. Whole-engine complexity cannot be proved from enemy-array reads alone because sorting operates on derived arrays.

Latest combined verification command is running; final results will be appended below. At this checkpoint, green status is not claimed.
