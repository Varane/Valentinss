# Movement and camera — integration handoff

Production ready for integration. Updated 2026-11-11 after the Sprint08 inspection-orbit correction. Lead owned `dist/camera-rig.mjs`; exactly three subagents were launched, all with accepted `reasoning_effort: ultra`, no fallback: `/root/movement_solver`, `/root/camera_math`, `/root/camera_audit`. Lead plus these three equals four executors. No additional agents were created for Sprint08.

## Camera API

`import { createCameraRig } from './camera-rig.mjs'`

`createCameraRig(camera, { mobile = false } = {})` returns:

- `update(dt, actor, encounter)`: first frame snaps to the actor; later frames use exponential damping at rate8. Reads actor.x/z/yaw, retains last finite values, and accepts the root's current call signature. Invalid/nonpositive dt holds the current view. No WebGL dependency in the rig.
- `toggle()`: cycles0 combat overhead →1 closer tactical →2 frontal face inspection →0. Returns the selected mode and resets zoom to1 each time.
- `resize(width,height)`: valid positive finite dimensions update camera.aspect and projection immediately; pose distance converges on subsequent updates. Invalid dimensions are ignored.
- `setZoom(value)`: sets the distance multiplier, clamped0.65..3;1 is default and larger values bring the camera closer. Invalid values retain the current zoom. Returns the current multiplier; changes take effect on the next update.
- `zoom(delta)`: adds a finite delta to the multiplier, with the same clamp; returns the multiplier. `zoom(0)` reads the current multiplier.
- `combatView()`: selects mode0 and resets zoom1, returning0. The next update smoothly returns to combat framing.

Existing `action-game.mjs` calls work unchanged. The existing camera button reaches inspection after two toggles and returns to combat on the third. Optional pinch wiring may use `rig.setZoom(rig.zoom(0) * pinchRatio)`; additive gesture input may call `rig.zoom(delta)`. UI/input/runtime files were not changed by this worker.

Mode2 aims at head height1.58 with its frontal offset derived from actor.yaw (figure forward is+Z). Combat modes retain fixed yaw regardless of actor facing or enemy lifecycle. Portrait framing increases distance to preserve a useful horizontal region. Pure math exports are `cameraPose(actor,{mobile,mode,aspect,encounter,zoom}) -> {position:{x,y,z},target:{x,y,z},fov}` and `smoothingAlpha(dt,rate=8) -> [0,1]` from `dist/combat/camera-math.mjs`.

## Sprint08 production correction

Reviewed `coordination/v4/SPRINT/08/camera/proposal.patch` and adapted its azimuth/radius interpolation to the current rig. The current production file also contained an immediate inspection snap; this was replaced with smooth orbit interpolation. During an inspection half-turn, the camera follows the shortest horizontal angular arc and interpolates the radius separately, preserving clearance around the head instead of interpolating a chord through it. Eye/target height, FOV, actor tracking and combat damping retain exponential interpolation.

Fresh required verification command:

```text
node --test tests/action-camera.test.mjs tests/sprint-08-camera.test.mjs
tests19; pass19; fail0; cancelled0; skipped0; todo0
duration_ms789.0478; exit0
```

An additional direct regression asserted that yaw0→PI with dt=log(2)/8 reaches a quarter-circle point at radius2.8. It failed against the previous immediate-snap implementation, then passed after this patch (`inspection quarter-arc regression PASS`, exit0). This verifies smooth motion as well as retained clearance.

The19 durable tests cover pure finite math, invalid input, fake cameras, first-frame placement, damped tracking,30/120Hz equivalence, resize/projection, zoom and combat reset, real THREE.PerspectiveCamera framing at16:9 and390:844, frontal inspection at yaw0/PI2/PI, half-turn clearance and return after three toggles. These tests do not create a renderer or require WebGL.

## Movement API

`dist/combat/movement.mjs` has no dependencies or action.mjs import cycle:

- `PILLARS = [[-4,-2.5],[4,-2.5],[-4,3],[4,3]]`.
- `moveActor(actor,dx,dz)` changes only x/z, returns actor, repairs malformed coordinates and existing overlap, sweeps full displacement against radius0.85 pillars and floor bounds x[-6,6],z[-5,5], then slides along contacts.
- `normalizeInput(input)` returns fresh finite{x,z}; preserves analog magnitude below1, normalizes larger magnitudes without overflow and ignores invalid axes independently.

Movement uses at most12 contacts per call, discarding any unconsumed movement after that bound. It includes no actor-versus-actor collision or pathfinding. A huge radial collision's floating-point tangent is suppressed while meaningful tiny-relative wall movement is preserved.

Verified earlier by the lead: `node --test tests/action-movement.test.mjs tests/action-camera.test.mjs` passed13/13 at the initial one-camera-test stage after the radial-contact fix. Movement-only final subagent run passed12/12, including128 radial approaches and4000 seeded moves; see `movement-solver.HANDOFF.md` for details. The final Sprint08 change touches camera-rig only.

## Scope and limits

Only this worker's allocated production/tests and reports were changed. No worktrees, commits, publication, competing server or browser tabs. Real Three projection was checked; visual occlusion by room geometry and physical iPhone rendering remain root integration checks. No claim that the whole shared project is green: an earlier whole-suite run during parallel construction encountered missing foreign modules (combat AI/skills, campaign balance/rooms/endings and effects audio/slashes) and the subsequently fixed movement regression. Those results are historical integration observations, not a current release verdict.
