# Adversarial QA handoff

Substantive handoff 2026-11-11 21:30 UTC; final verification update follows before21:40 freeze.

Exactly four executors: lead /root plus /root/fuzz_invariants, /root/performance, /root/public_contracts. Three actual spawn_agent calls used fork_turns:none, reasoning_effort:ultra, default model; no rejection/fallback, no further delegation. IDs and scope are in adversarial-qa.STATUS.json.

Production exports: none added or modified. Production read-only throughout. No worktree, commit, preview server, publication or other-owner edits.

Delivered tests:
- tests/action-adversarial.test.mjs (lead):23 scenarios; defense windows including dt.05 and coarse/fine frames, revive35%/guard3 with integer rounding, range/final-dead rejection, down expiry, preserved profile death/health, terminal victory/defeat, fatal-hit rescue rejection, swept pillar movement, nonfinite/negative dt.
- tests/action-fuzz.test.mjs: seeded invariants/replay, invalid and huge input, event drain and two-player controls where supported. See adversarial-fuzz.REPORT.md.
- tests/action-performance.test.mjs: bounded event history/work, long seeded runs and drain path; no absolute FPS threshold. See adversarial-performance.REPORT.md.
- tests/action-contract.test.mjs and tests/effects-contract.test.mjs: retained public actor fields, independent state, events and lifecycle, real local Three. See adversarial-contracts.REPORT.md.

Fresh lead command: node --test tests/action-adversarial.test.mjs tests/action-contract.test.mjs
Result:32 tests,31 pass,1 fail,0 skipped,exit1. All23 scenario tests pass. Remaining case is undefined selected index, where integrated command defaults to hero0; requested correction to remove this unmandated rejection from contract tests. Real invalid index checks remain.

QA_FINDINGS.md separates reproduced baseline defects, current results and temporary missing-module imports. Old failures for source resurrection/heal, defense timing,40% revive, tunnelling and NaN dt are covered by currently passing scenario regressions.

Known limits: browser/UI/audio/network/mobile end-to-end is outside this Node-only scope. Wall-clock test durations on this shared host are diagnostics, not FPS evidence. Full-suite status must be assessed from final run, not historical baseline output.
