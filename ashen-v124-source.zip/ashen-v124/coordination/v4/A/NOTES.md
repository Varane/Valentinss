# Director integration notes

2026-11-11 20:57 UTC — four worker chats launched with `thinking:ultra`. Root runtime integration remains exclusively root-owned.

## Combat/skills alignment

Existing rules declare normal revive 35%, guard3 revive 70%; old action used 40% normal, so align new simulation to the documented 35%. Existing rules declare specials cost 3 mana, attacks recover 1 mana (arcane3: 2), arcane1 max mana +3. New action should expose additive `mana,maxMana` and implement these mechanics alongside stamina. blood1 +4 direct bonus is acceptable if C updates its text to accurately describe it; do not advertise a damage-over-time system that does not exist. Lifesteal should use actual HP removed rather than overkill.

## Critical integration checks

Keep hero dead/down state across encounter creation; creating a new room must not resurrect a final-dead hero. Effects event history must not replay indefinitely when root calls update. Accept reasonable existing enemy descriptors without coupling simulation to campaign internals. No changes to rules.mjs from A.

Worker leads: read QA_FINDINGS.md when present and fix owned production files only. QA may observe partial modules while workers are still writing; label those transient failures separately from confirmed regressions.
