# Four finite release gates

Scope: three active workers plus root; no additional chats, publication or commits by this controller. Only the three blocker groups below are release work. Existing historical reports are leads, not current proof.

## 1. Boot and import closure — assembler

- Actual `action.mjs` import initially failed because `campaign/save.mjs` was missing. New dependencies are now arriving; verify the current graph once before downstream suites.
- Actual runtime source with renderer boundary fixture leaves loading unchanged if `WebGLRenderer` throws before `boot().catch`.
- Saved campaign statuses `defeat`, `complete`, `camp` throw in `prepareEncounter` during boot. Active campaign path passes the narrow runtime harness.
- Verification: `tests/sprint-control-release.test.mjs`, `tests/sprint-11-startup.test.mjs`, `tests/sprint-14-runtime.test.mjs`.

## 2. Phone controls and combat clarity — assembler / root

- 25 input state/DOM tests passed; portrait 320×568 and landscape 568×320 source boxes respect safe edges and minimum targets. This is not phone or browser evidence.
- `spawnRoom` writes story subtitle to the defensive tutorial paragraph, erasing the dash/parry lesson. Put story caption in the informational span.
- Incoming enemy hurt effect resolves integer source through player collection; expected direction dx=-1 becomes 0. The exact minimal proposal is executable in `sprint-08-combat`.
- Verification: `tests/input-controls-dom.test.mjs`, `tests/input-controls-state.test.mjs`, `tests/sprint-11-touch.test.mjs`, `tests/sprint-08-combat.test.mjs`, `tests/sprint-09-reach.test.mjs`, `tests/sprint-10-safe-edges.test.mjs`.

## 3. Visual and equipment coherence — art facade; assembler / root integration

- Model equipment/socket/disposal checks and both mouth-visibility checks passed.
- Inspection half-turn currently interpolates camera through the hero: horizontal clearance approximately 0, aim distance 0.12. Exact isolated proposal passes in `sprint-12-camera`.
- Runtime spawn, update and final death omit the supported boots slot. Forward all three equipment slots and clear all three on death.
- Verification: `tests/figures-equipment.test.mjs`, `tests/sprint-12-face.test.mjs`, `tests/sprint-12-camera.test.mjs`, strict `tests/sprint-06-runtime.test.mjs`; rune/boots rules tests only after gate 1.

## 4. Release evidence — root

- Root owns actual browser boot, portrait/landscape control exercise, combat outcome, gear change, reload and final visible screenshots.
- Root chooses release networking scope. Current runtime has no room-client integration; backend/unit success alone cannot establish multiplayer.
- Current service worker still lists v3 entry/assets. Root must verify fresh release delivery and stale-cache behavior before publication.
- Record hashes plus exact passing commands and final preview URL; do not claim physical Safari/iPhone, FPS or online multiplayer without that evidence.

Initial decision: HOLD until all current gates have fresh proof. Do not repeatedly execute tests blocked by a missing dependency. Do not turn old TODOs into accepted passes.
