# Music integration — modules verified, 22:04 UTC

Music team owns `dist/music.mjs`, `dist/music/**`, `tests/music*.test.mjs`, `docs/music/**`. Lead plus exactly three subagents were launched. All modules now exist and 28 music tests pass. The original deadline was missed: tool execution was interrupted, the score catalog was missing at the integration check, and lead finished it after recovery. No commit, publish, hosting or other-team file edits.

## Stable integration contract

`import {createMusic} from './music.mjs';`

`createMusic({volume:.2})` returns `{unlock,setScene,setEnabled,getEnabled,setVolume,pause,resume,dispose}` and optional `getVolume()`.

- `unlock()` returns a Promise and must be invoked directly inside a user-gesture handler. Construction, scene requests and enabling alone must never construct an AudioContext.
- Music defaults disabled; an existing saved enabled preference may restore the choice but playback still needs gesture unlock. Own preference key `krovosklep-music-v1` is separate from game saves.
- `setScene(cue)` accepts `sanctuary`, `exploration`, `danger`, `combat`, `boss`, `discovery`, `victory`, `defeat`. Repeating the same cue is harmless and does not restart it.
- `setVolume(number)` uses the range 0–1. Recommended starting volume .2. Pause/hidden tab/menu should call `pause()`, then `resume()` when gameplay resumes.
- All music is locally synthesized from transcribed public-domain scores. No copyrighted recording, downloaded soundfont, external playback dependency or background network request.

## Root / D integration pattern

Create one music instance in root-owned runtime, not one per room. Supply D optional callbacks `getMusicEnabled`, `setMusicEnabled`, `getMusicVolume`, `setMusicVolume`. In enabling callback, call `const unlocking=music.unlock(); music.setEnabled(true); void unlocking;` synchronously inside the UI click/change handler. Disable calls `music.setEnabled(false)`.

Call `music.setScene(...)` on meaningful scene/state transitions, and pause whenever simulation/menu/visibility pauses. Unlock on user gesture again if the browser needs it after interruption. Dispose on teardown.

The dependency-free classifier `musicCueFor({encounter,campaign,room,event})` is ready in `dist/music/cues.mjs`; direct cue strings remain supported. Event cues discovery/victory/defeat should not be overwritten every animation frame.

## Delivered catalog and verification

`dist/music/score-data.mjs` exports three frozen SCORES: `grieg-mountain-king` (Grieg piano arrangement bars 2–9, disclosed octave lift), `satie-gymnopedie-1` (bars 5–12, all three voices), and `bach-cello-prelude` (BWV1007 bars 1–4 in disclosed source register). Each has exact numeric MIDI pitches/quarter-beat timing and source metadata. Source LilyPond files are retained under `docs/music/sources/` and primary-source URLs/edition details are in `docs/music/PROVENANCE.md`.

Final cue mapping: sanctuary/discovery/victory/defeat use Satie; exploration/combat use Bach; danger/boss use Grieg. Exploration has 48-second quiet gaps, sanctuary 28, combat 20, boss 8. Danger, discovery and outcomes play once. No invented harmony or third-party recording is used.

Verified command: `node --test tests/music.test.mjs tests/music-data.test.mjs tests/music-provenance.test.mjs` — exit 0, 28 passed, 0 failed. Tests cover gesture gating, saved preferences, storage denial, scene cancellation, pause/mute, disposal races, bounded resources, cue priorities and source-derived musical invariants. `docs/music/QA.md` records the browser/iPhone listening checklist and limits.

Read-only integration check at 22:05 UTC confirmed root's `action-game.mjs` imports and constructs createMusic, selects scenes via musicCueFor, supplies pause/settings callbacks to UI, and unlocks on pointer/keyboard gestures; UI passes these callbacks to its pause content. These edits were made by the owning teams. Actual browser sound and iPhone listening still need verification; this source inspection is not a claim of end-to-end audio or publication success.
