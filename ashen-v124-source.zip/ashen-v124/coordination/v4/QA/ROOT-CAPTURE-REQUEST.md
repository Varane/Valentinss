# Root browser handoff request

QA will not control root browser/server/port 4173. Please use current assembled build and record timestamp, viewport, browser, screenshot path, errors, and actual observations in this folder or outputs/milestones/latest.json.

Highest-priority capture sequence:

1. Fresh session at 390x844, immediately after loading; then 15 seconds and 60 seconds. Record hint visibility, combat state and obvious obstruction. Do not wipe a real save: use isolated browser storage/context where available.
2. At 375x667 and 844x390: scene/HUD screenshot, equipment open, skills open, pause/room-code panel. Include whether page/dialog scroll works and close/primary buttons remain visible.
3. At 390x844: move while holding attack, add dash or parry, cancel/release pointer; check no stuck walking/attack. Screenshot cannot prove this: include observed interaction outcome.
4. Face inspection: open equipment, trigger inspection/camera zoom, capture closest view and record how user discovers it.
5. One encounter from start to outcome on phone if available; record device/browser and rough time, problems, frame pacing. Otherwise label viewport-only.
6. Two clients create/join/reconnect if backend available; otherwise explicitly report untested/unavailable.

Screenshots alone do not prove physical iPhone playability. Pending evidence is a release hold, not a failure inferred from lack of access.
