# Mobile playability release gates

QA director started 2026-11-11 21:15 UTC. Deadline 21:51 UTC. Ownership: tests/playability/** and coordination/v4/QA/** only. Two worker chats, each one lead and three subagents; total target exactly eight testers. Director coordinates and verifies rather than adding a ninth tester.

## Evidence labels

- SOURCE: observed in current source; browser behavior not established.
- MODULE: executed against current modules in Node; no rendered/device claim.
- BROWSER: actual current build observed in browser; record viewport, time and screenshot.
- PHONE: physical phone interaction; record device/browser, orientation and time.
- UNTESTED: no qualifying evidence. A passing test count does not clear a UX gate.

## Required gates

1. First minute: enter without confusion, understand movement and attack, dismiss or outgrow brief hints without occlusion; survive and complete one encounter.
2. Touch: move and attack simultaneously, dash/parry while moving, release/cancel/background resumes without stuck input, reachable visible actions.
3. Combat: enemy threat and hit confirmation distinguishable, health/downed/death and rescue understood, beginner can complete first encounter.
4. Inspection: discover equipment/skills and return to action; inspect character face with a genuinely useful zoom.
5. Layout: no critical clipping/overlap at 375x667 and 390x844 portrait or 844x390 landscape; safe-area edges clear.
6. Cooperation: two independent clients enter via code, see synchronized movement/combat, reconnect without duplicate rewards or lost role; unavailable backend is stated honestly.
7. Accessibility/performance: usable focus, readable contrast/text, reduced motion settings effective, no fatal startup errors, sustained play measured on target phone.
8. Persistence: refresh/restart/death retains intended progression; no accidental reset to make QA pass.

Release stays HOLD while any reproducible P0/P1 is open or required phone flows lack evidence. Desktop viewport screenshots can clear layout observations only, not physical thumb reach or iOS gesture behavior.

## Progress reporting

Report distinct denominators: roster confirmed/8, scope reports delivered/8, required gate evidence complete/8, P0/P1 fixed+retested/open. Never convert source-only coverage or number of tests into overall product-readiness percentage.

## Finding format

ID; priority; owner; evidence label; build timestamp/hash; device/viewport; reproducible steps; expected; actual; evidence path/line; screenshot path (or pending); proposed owner action; retest result.
