# Sequential release audit plan

Human steering received 2026-11-11 21:21 UTC: present playable public 2.0 first, independent audit informs 3.0 during user testing, then 4.0 follows actual feedback. No new recursive teams. First freeze 21:40, gate 21:51, improvement window to 22:05 UTC.

1. Before 2.0 snapshot, resolve assembly blockers and reproduced phone P0/P1. Root captures current browser flows; QA records exact evidence level. Root owns snapshot/publication and sends every ready product for presentation.
2. Preserve 2.0 source/screenshot identity. All further findings identify whether observed on tested 2.0 snapshot or moving working tree. Do not relabel later code evidence as proof about 2.0.
3. 3.0 priority order: stuck/blocked touch controls and inaccessible overlays; broken first-minute/victory/restart flow; face inspection discoverability; two-client recovery; performance/readability. Cosmetic refinements follow these gates.
4. Existing testers retest their own reported failures after owners land changes. No new workers. Save each original reproduction and its fix verification; avoid erasing failed evidence.
5. 4.0 plan must incorporate actual user feedback. No invented acceptance or assumed successful phone play. When feedback is absent, prepare a concise prioritized audit handoff and keep untested gates explicit.

Root integration owns all runtime and release changes. QA owns reports and executable repros only.
