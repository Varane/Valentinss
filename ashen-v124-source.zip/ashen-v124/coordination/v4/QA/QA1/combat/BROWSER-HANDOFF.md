# Combat browser handoff — QA1 tester 2/4

Evidence as of 2026-11-11 21:27 UTC: source + Node modules only. Browser screenshots and physical phone evidence are PENDING. Do not clear the phone-combat gate from these checks.

Run against the root-owned current build and browser. Do not launch a second server. Required targets: 375×667 and 390×844 portrait; 844×390 landscape; desktop 1440×900. Preserve the existing save first; use a clean isolated browser context for a fresh profile, not a user's saved profile.

## Root-ready interaction sequence

1. Enter fresh first room. Capture loaded canvas and full HUD immediately. Read the tutorial: does it actually teach movement, held attack, red windup, dash and facing parry? Record room title, language, viewport, device/browser, timestamp, and build hash. Screenshot: combat-01-first-room.png.
2. Wait 10 seconds without controls. Verify no unexplained damage/death and whether required teaching remains discoverable. Capture after waiting. Screenshot: combat-02-before-input.png. The source HUD fades tutorial after encounter.time > 10, even if the player has not acted.
3. On phone, keep left thumb on joystick; use right thumb to hold Strike. Approach nearest enemy. Record selected health, ally health, enemy count, and completion time. Confirm attack continues while moving, and releasing either finger releases only its own action. Capture actual motion/hit feedback. Screenshot: combat-03-moving-attack.png.
4. Approach without attacking until an enemy commits a red windup. Verify the enemy silhouette/label and strike direction are visible above controls. Normal source window is .7s, boss .85s. React once with Dash during the last .25s. Record HP before/after, visible evade feedback and whether dash direction followed joystick. Screenshot: combat-04-dash.png.
5. Face the enemy; trigger Parry near impact. Expected: no HP loss, a distinguishable parry cue, stunned enemy and clear prompt to counterattack. Repeat while moving away/facing away: source parry requires facing within 60 degrees, so teaching/feedback must explain why it fails. Screenshot: combat-05-parry.png. Do not call timing/facing usable from Node alone.
6. Reach low stamina by attacking/dashing. Attempt Parry and Dash. Expected: an understandable insufficient-stamina state or feedback; player can distinguish rejection from an accepted defensive move. Current source only provides explicit command failure notices for special/revive; verify actual buttons/status before filing.
7. If a hero is downed, verify automatic switch is obvious, rescue button is reachable and countdown visible; move within 2.5m and tap rescue. Confirm ally returns with ceil(35% max HP), e.g. 30/85, and the 9s rescue window is fair under phone interaction. Screenshot: combat-06-rescue.png.
8. Complete first encounter using ordinary movement + held Strike before learning skills/equipping gear. Record whether a beginner can understand victory and proceed. Repeat after one intentional mistake, then landscape. Screenshot: combat-07-victory.png. Synthetic bot victory is supporting balance evidence only.

## Evidence capture checklist

For every failure: exact steps; expected/actual; target viewport/device/orientation; first/current HP; timestamp; source hash; screenshot path. Label BROWSER for desktop emulation and PHONE only for a real handset. Capture .scene-title, #tutorial, #hero-state, #hp-text, #stamina-text, #remaining, #notice, #rescue-hint and #scene.dataset when present. No screenshots were produced by this tester.

## Suggested root browser read-only snapshot

Use normal DOM inspection to record bounding rectangles and visible text for #joystick, #strike, #dash, #parry, #special, .vitals and every .enemy-label. Confirm each required action is unobscured and at least 44×44 CSS pixels; verify active windup remains visible during simultaneous touch. Buttons' source dimensions alone cannot prove thumb reach or iOS pointer behavior.
