# QA1 initial handoff — release 2.0 gate / 3.0 audit feed

Updated 2026-11-11 21:25 UTC. Exactly four actual testers: lead /root, /root/onboarding, /root/combat, /root/camera_face. No additional agents/chats. Owned paths only: tests/playability/qa1/** and coordination/v4/QA/QA1/**. Production files unchanged by QA1.

## Actionable finding now: QA1-G01 — P1 per-contact cancellation interrupts the other thumb

Evidence level: EXECUTED MODULE using actual dist/input.mjs and a minimal DOM event harness. Browser and real-phone evidence are pending. No screenshot exists from QA1.

Target: iPhone Safari, portrait 390×844 CSS px (also 375×667 and landscape 844×390 requested). Severity P1 risk during combat if a contact loses capture/cancels; frequency on Safari is not established.

Steps: (1) hold left joystick right with pointer 1; (2) hold Strike with pointer 2; (3) cancel pointer 2 or lose its pointer capture while pointer 1 stays down; (4) move pointer 1 without lifting it.

Expected: Strike releases and the still-held joystick keeps moving. Actual module: vector becomes {x:0,z:0}; clear() releases BOTH captures and sets stickPointer=null. Moving pointer1 cannot restore movement until it is lifted/repressed. Even pointercancel for unowned pointer99 clears both held controls. Normal attack pointerup and attack→dash transitions preserve joystick correctly; blur/modal clear correctly.

Evidence: coordination/v4/QA/QA1/gestures/module-evidence.json (captured 21:24:20 UTC; input SHA256 recorded). Repro checks: node --test tests/playability/qa1/gestures/gestures.test.mjs. Per-contact expectations G01/G02/G03 are intentionally red against current code; 4 baseline cases are green in direct execution. Source: dist/input.mjs lostCapture() and document pointercancel binding. Request D/input owner use per-contact release for pointercancel/lostpointercapture, keeping clear() for blur/pagehide/hidden/modal/destroy.

## Current startup gate (onboarding tester)

Actual module imports at ~21:25 UTC report missing ui/skills.mjs, campaign/balance.mjs, campaign/rooms.mjs. Shared tree still changing, so these are current P0 integration blockers to RETEST before freeze, not final missing-feature claims. Exact per-tester report/checks follow in onboarding/.

## Other priority probes

Camera tester: source currently exposes fixed tactical angle toggle only, no face-inspection/zoom mode. Executed numeric framing and exact report pending in camera-face/. Need root screenshot at 390×844 of each camera mode and any inspection workflow.

Combat tester: source spawnRoom() overwrites tutorial combat paragraph with room.subtitle. Tutorial later fades when battle.started; first-minute instruction readability/retention needs root browser verification. Current normal/boss telegraph timings .7/.85 sec, parry .3 sec, source only until simulation report lands.

## Root browser/phone request

Root owns server/browser. Please capture fresh startup after module graph is complete at 390×844 and 844×390; record build timestamp, current viewport and console failure if any. For two thumbs, hold joystick while tapping/releasing Strike, Dash, Parry; then force one-contact pointercancel/lostcapture separately and record movement before/after. A synthetic PointerEvent run establishes browser-handler behavior only, not Safari gesture frequency or real-phone ergonomics. Actual phone check must use a phone and say model/iOS/Safari/orientation.

For face inspection, open gear and toggle camera; capture closest actual face view and return to combat. For onboarding, fresh storage only in a dedicated test profile: capture at0,5,15 seconds and after first movement. Do not erase user saves.

## Gates / counts

7 lead module scenarios executed directly; 4 satisfy expectation and 3 expose the same cancellation family. Four role reports planned; three child reports in progress. Browser checks performed: 0. Real-phone checks performed: 0. Thumb-reach judgment and face visual quality are BLOCKED pending root browser/real-phone evidence. No completion percentage.
