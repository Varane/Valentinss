# Priority audit — public release 2.0

Updated 2026-11-11 21:23 UTC. Source folder remains coordination/v4. Current decision HOLD pending integration and browser/phone evidence. Exactly eight testers confirmed by QA1/STATUS.json and QA2/STATUS.json. No production files modified by QA.

## QA-BOOT-001 — P0 current assembly cannot import combat

- Owner: A, root integration.
- Evidence: MODULE, executed 21:21 UTC against shared working tree, Node v24.11.1 on Windows. Browser not tested; applies to all viewport sizes if same missing asset is served.
- Reproduction: from repository run `node --test tests/playability/runtime-room-settlement.test.mjs`.
- Expected: real action/campaign modules load; test can execute.
- Actual: ERR_MODULE_NOT_FOUND for dist/combat/damage.mjs imported by dist/action.mjs. One test file failed before its case executed.
- Screenshot: pending root capture; terminal evidence recorded here. This is an in-progress assembly blocker, not a claim that a published release has this defect.
- Action: A completes/publishes owned module into shared tree; root reruns import/runtime checks before snapshot.
- Retest: pending.

## QA-FLOW-001 — P1 victory settlement binding mismatch

- Owner: root integration, C contract.
- Evidence: SOURCE at 21:20 UTC. MODULE reproduction currently blocked by QA-BOOT-001; not yet a confirmed rendered symptom.
- Reproduction path: fresh profile; runtime spawnRoom creates battle via encounter(profile,currentRoom); win first fight; settle calls resolveRoom.
- Expected: XP/loot saved, campaign advances, next room available.
- Actual source boundary: campaign validateOutcome requires campaignRunId and campaignRoomId from prepareEncounter; current runtime imports neither prepareEncounter nor binds the metadata. The catch displays fallback outcome and does not advance campaign.
- Artifact: tests/playability/runtime-room-settlement.test.mjs executes actual runtime spawnRoom/settle declarations with real action/campaign modules; rendering-only collaborators are minimal fakes.
- Screenshot: pending root browser first-victory capture.
- Action: wire documented C preparation API; rerun actual runtime fixture and browser victory-to-next-room.
- Retest: pending.

## Evidence missing at this milestone

No physical phone interaction or current-build browser capture has been supplied to QA. The eight scope audits are underway. Read ROOT-CAPTURE-REQUEST.md for a bounded capture sequence.
