# D4 independent network QA

Agent: `/root/d4_network_qa`. Model: inherited default, exact identifier not exposed. Requested/accepted reasoning effort: `ultra` per D4 worker status. No recursive agents or chats.

Updated: 2026-11-11 21:01 UTC. Status: waiting for D3's real API; no passing placeholder tests or skipped tests added.

## Current evidence

- Read `coordination/v4/MASTER.md`, `coordination/v4/D/CONTRACTS.md` and existing Node test style.
- At 20:59 UTC, `docs/network/API.md`, `server/`, `worker/` and `dist/ui/network-client.mjs` did not exist. D3-specific tests/handoffs were absent.
- Node is available at `C:/Program Files/nodejs/node.exe`.
- No server, browser, publish, Git or implementation mutation performed.

## Pending adversarial checks against final D3 API

1. Create/join issue distinct opaque credentials. Room code alone, missing token, wrong token, and a token from a different room cannot authorize protected reads/inputs/leave.
2. Exactly two player slots; repeated join/request retries cannot create a third player, replace another player's identity or allocate unbounded participants.
3. Duplicate input/action request and repeated sequence preserve idempotency. Duplicate leave/reward/room transition cannot multiply side effects.
4. Stale expected revision is rejected or safely reconciled without rollback; invalid/future sequence and nonfinite/out-of-bounds movement cannot corrupt state.
5. A disconnected client can reconnect with its credential; resume cannot impersonate the other slot; leave/disconnect semantics are truthful and recoverable.
6. Browser helper uses bearer credentials separately from displayed room code, does not send stale input after destroy/leave, and reports missing backend as unavailable.

Tests will import real modules or invoke the actual Worker handler in-process using Node Fetch APIs. This avoids competing servers. Any unavailable production binding will be reported as an explicit limitation, not hidden by mocks that replace the authoritative behavior under test.

## Verification

No network test run yet: implementation and final API were absent at the first inspection. This is a real dependency blocker, not evidence of a multiplayer pass.
