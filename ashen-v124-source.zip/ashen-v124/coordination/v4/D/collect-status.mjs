import { readFile, writeFile, readdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const directory = path.dirname(fileURLToPath(import.meta.url));
const statusPath = path.join(directory, 'STATUS.json');
const status = JSON.parse(await readFile(statusPath, 'utf8'));
for (const worker of status.workers) {
  try {
    const report = JSON.parse(await readFile(path.join(directory, 'WORKER_STATUS_' + worker.id + '.json'), 'utf8'));
    const agents = report.agents ?? report.subagents ?? [];
    worker.confirmedSubagents = report.successfulSubagentStarts ?? agents.filter(a => a.agentId).length;
    worker.agentIds = agents.map(a => a.agentId ?? a.id).filter(Boolean);
    worker.status = report.milestone ?? report.status ?? 'report received';
    worker.report = 'WORKER_STATUS_' + worker.id + '.json';
    worker.blockers = report.blockers ?? [];
    worker.runtimeNote = report.runtimeNote ?? report.runtimeLimitation ?? report.limitations ?? null;
  } catch (error) {
    if (error.code !== 'ENOENT') worker.reportError = error.message;
  }
}
status.updatedAt = new Date().toISOString();
status.confirmedSubagentsStarted = status.workers.reduce((n,w) => n + w.confirmedSubagents, 0);
status.confirmedExecutors = status.workerLeadsStarted + status.confirmedSubagentsStarted;
status.executionCountMeaning = 'Historical successful starts, not current live concurrency.';
status.runtimeInterruption = 'Application restart interrupted work; D1 and D2 confirmed their three children were no longer listed. Leads resumed without replacements. Other live child counts are not independently established.';
status.confirmedLiveSubagents = null;
status.subagentStatus = status.confirmedSubagentsStarted === 12 ? 'All twelve original child launches confirmed with IDs. Current live count unknown after application restart.' : 'Factual worker reports collected; remaining launches unconfirmed.';
status.blockers = status.workers.flatMap(w => (w.blockers ?? []).map(reason => w.id + ': ' + reason));
try {
  status.verification = JSON.parse(await readFile(path.join(directory,'verification-latest.json'),'utf8'));
  status.phase = status.verification.exitCode === 0 ? 'verified_modules_handoff' : 'integration_verification_pending';
} catch {}
status.releaseCycle = {firstLabel:'2.0',freeze:'2026-11-11T21:40:00Z',firstGate:'2026-11-11T21:51:00Z',improvementWindow:'2026-11-11T22:05:00Z',owner:'root'};
status.availableReports = (await readdir(directory)).filter(n => n.startsWith('HANDOFF'));
try { status.finalNarrowVerification = JSON.parse(await readFile(path.join(directory,'verification-narrow-final.json'),'utf8')); } catch {}
await writeFile(statusPath, JSON.stringify(status, null, 2) + '\n');
console.log(JSON.stringify({updatedAt:status.updatedAt,workerChats:status.workerThreadCount,confirmedSubagents:status.confirmedSubagentsStarted,confirmedExecutors:status.confirmedExecutors,workers:status.workers.map(({id,status,confirmedSubagents,agentIds,blockers})=>({id,status,confirmedSubagents,agentIds,blockers}))}, null, 2));
