import { readdir, readFile, writeFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import path from 'node:path';
const directory = path.dirname(fileURLToPath(import.meta.url));
const repo = path.resolve(directory, '../../..');
const tests = (await readdir(path.join(repo, 'tests'))).filter(name => /^(input|network|sprint-(09|10|11)).*\.test\.mjs$/.test(name)).map(name => 'tests/' + name);
for (const name of await readdir(path.join(repo, 'worker')).catch(() => [])) if (name.endsWith('.test.mjs')) tests.push('worker/' + name);
tests.push('tests/playability/qa1/gestures/gestures.test.mjs');
const result = spawnSync(process.execPath, ['--test', '--test-concurrency=1', ...tests], {cwd:repo, encoding:'utf8', maxBuffer:16*1024*1024});
const output = (result.stdout ?? '') + (result.stderr ?? '');
await writeFile(path.join(directory, 'verification-latest.log'), output);
const hashes = {};
for (const name of ['dist/input.mjs','dist/ui.mjs','dist/ui/network-client.mjs','dist/ui/hud.mjs','dist/index.html','dist/action.css']) {
  try { hashes[name] = createHash('sha256').update(await readFile(path.join(repo,name))).digest('hex'); } catch { hashes[name] = null; }
}
const report = {at:new Date().toISOString(),command:'node coordination/v4/D/verify-direction.mjs',files:tests,exitCode:result.status,error:result.error?.message,hashes,summary:output.split(/\r?\n/).filter(line=>/^ℹ (tests|pass|fail|cancelled|skipped|duration)/.test(line))};
await writeFile(path.join(directory, 'verification-latest.json'), JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
if(result.status!==0) console.log(output.split(/\r?\n/).slice(-100).join('\n'));
process.exitCode = result.status ?? 1;
