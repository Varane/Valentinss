# D1 — input and HUD

Status at 21:35 UTC: D1 implementation complete. Fresh D1 and independent QA1 gesture verification: 41 tests, 41 pass, 0 fail. Three subagents successfully started with requested ultra accepted; factual identifiers and model visibility are in WORKER_STATUS_D1.json. After the application restart, list_agents returned only /root; no children were recreated. All saved child work was reviewed and finished by the lead.

## Immediate public contracts for D2 and root

`dist/ui/hud.mjs` exports `createHUD({getProfile,getSelected})`, returning `update(encounter,selected)`, `notice(text)`, `showOutcome({won,title,text})`, `destroy()`. D2 imports `createHUD` from `./ui/hud.mjs`. HUD is display-only: no click listeners, profile mutations or frame loop.

`dist/input.mjs` exports `createInput({canvas,onAction,onMenu,onSwitch,onCamera})`, returning `vector():{x,z}`, `attackHeld():boolean`, `clear()`, `destroy()`. Input exclusively owns keyboard, #joystick and combat pointer controls #strike/#dash/#parry/#special plus revive (#rescue-hint button, optionally #revive). It does not bind menu clicks.

D2 owns clicks on inventory/talents/pause/camera/switch-hero/ally/restart/after-gear/close and the new `#rooms` button. `#rooms` opens the room UI, whose content is supplied by D2; D1 makes no online availability claim. All original IDs and script `./action-game.mjs?v=4` are preserved.

Pure state API in `dist/ui/input/state.mjs`: `normalizeVector(x,z)`, `joystickVector(dx,dy,radius,deadzone=.12)`, `createControlState()` with setKey/setStick/setAttack/vector/attackHeld/clear. DOM event wiring remains in dist/input.mjs.

Input suppresses gameplay while a form field has focus or an open dialog exists. Blur/pagehide/hidden visibility/modal/destroy clear all input. Pointercancel and unexpected lostpointercapture release only the owning contact, preserving other held thumbs and keyboard sources. Unowned pointer cancellation is inert. Normal pointerup outside controls releases correctly through document capture. Root already calls clear() when pausing.

Keyboard: WASD/arrows move; Space attack; Shift dash; E parry; R special; F revive; Q switch; I gear; K skills; Escape pause; additive C camera. Held attack combines independent pointer IDs and Space. Repeated keydown cannot retrigger one-shot actions. Native Space on a focused button is preserved, and combat buttons accept native keyboard/assistive click detail=0 while ignoring duplicate pointer click detail>0.

HUD statically imports localize/heroName from ../i18n.mjs. Canonical names follow actor.id and leave saved hero.name untouched. Dynamic status, health/stamina labels, remaining enemies, rescue and outcome labels are bilingual; supplied notice/outcome text uses the localization bridge and safe textContent. D2/root updates redraw the current locale; HUD has no action listeners or animation loop. Rescue button is enabled only when revival is available in range; informational down/far messages remain visible and disabled.

## Verification

Command: `node --test tests/input-controls-dom.test.mjs tests/input-controls-state.test.mjs tests/input-hud.test.mjs tests/playability/qa1/gestures/gestures.test.mjs` — fresh 41/41 pass, 0 fail, exit0 at21:34 UTC. This includes 6 DOM,19 state,9 HUD,7 independent QA1 scenarios. QA1-G01/G02/G03 are green after replacing global contact cancellation with per-contact release.

Broader command: `node --test tests/input*.test.mjs` — 61 tests,58 pass,3 fail. All three failures are import-time errors for missing dist/campaign/save.mjs imported by rules.mjs; affected files tests/input-ui-equipment.test.mjs, tests/input-ui-skills.test.mjs, tests/input-ui.test.mjs. This is outside D1 ownership and needs the C owner/root to restore its module then rerun. No D1 tests failed.

Scoped git diff --check exit0, only normal LF/CRLF warning for index.html. No preview servers or browser tabs started. No physical phone or browser layout validation claimed.

Final syntax checks at21:38 UTC: node --check passed dist/input.mjs, dist/ui/input/state.mjs, dist/ui/hud.mjs, tests/input-controls-dom.test.mjs and tests/input-hud.test.mjs.

Full project command node --test tests/*.test.mjs was additionally attempted. It was explicitly interrupted at21:38 after external failures and a prolonged period without new output, so this is INCOMPLETE and must not be reported as a passing full suite. Observed import errors: missing campaign/save.mjs (action-adversarial, action-contract, action-fuzz, action-integration, action-performance, action-skills, action, campaign.integration, effects-contract); missing campaign/items.mjs (campaign.balance.audit); missing campaign/rewards.mjs (campaign.balance.rewards); missing campaign/rooms.mjs (campaign.rooms); missing campaign/endings.mjs (campaign.story). Two observed audio assertion failures: "duplicate IDs and high frequency repeated cues are suppressed" and "concurrent voices never exceed twelve and stolen voices stop/disconnect". These paths belong to other teams; no edits were made to them. Root should rerun after shared modules settle.

Verified SHA256:
- dist/input.mjs: FEE1C40B7E691E26D141BCC4D1A882B20949E6B2BA4C91AED136B9D40076FBE7
- dist/ui/hud.mjs: 7C0BEDC22BF09430D8AD100B821DF164783CC49E853E65D531344531EE39DF2F

Cross-chat status send was rejected by automatic approval review for absent trusted messaging authorization; passive files remain the reporting channel originally requested. No retry or alternate messaging mechanism was used.

Markup includes #rooms and button #rescue-hint, original IDs preserved, root script version v4 unchanged. Styles now use safe-area insets, 44px minimum controls, explicit portrait and shallow-landscape breakpoints, readable body/gear text, room-form/room-status/room-actions and existing constellation classes. Visual browser validation belongs to root; D1 has not claimed an iPhone device test.

The two full-run audio assertion failures were located in tests/effects-audio.test.mjs. Final re-read hashes at21:39 match the verified hashes above. D1 source frozen; coordination report complete.
