# Release cycle — direction D

Root steering 2026-11-11 21:23 UTC: first playable public label 2.0, freeze 21:40, first release gate 21:51; subsequent 3.0 and 4.0 use independent audit and user feedback through 22:05. Root alone snapshots, integrates and publishes releases. Internal coordination/v4 path is unchanged.

## Current blocker and recovery

An application restart interrupted active work. All twelve originally requested child agents were successfully started at ultra, but D1 and D2 subsequently report child agents no longer listed, and some source writes did not complete. Leads are finishing their owned modules themselves; no replacement hierarchy is created. Started count is historical evidence, not a claim that sixteen agents are still currently running.

Some worker-to-worker messages were rejected by automatic approval review because it did not recognize direct human authorization in the delegated context. Direction D can relay needed contracts and the teams can continue via shared files. This does not block local implementation.

## 2.0 required gates

- Working input + UI imports, joystick/attack simultaneous gestures, no held-input leak across dialogs or visibility changes.
- Useful skill constellation and equipment callbacks from actual profile data; pause balanced.
- Offline room label until a configured endpoint passes actual two-client integration.
- UI language and music controls use supplied independent module APIs without save mutation.
- Real tests and deployable source before handoff; no hosted multiplayer claim from Node checks.

## 3.0 audit targets

Independent tests/playability findings first: thumb overlap in landscape/portrait, restore focus, small text, modal command leakage, room reconnect and stale revisions. Fix reproduced P0/P1 before cosmetic additions.

## 4.0 feedback targets

Use concrete user feedback from root. Preserve snapshot 2.0 and successful mechanics, make bounded changes, rerun affected gameplay/network cases, deliver to root for presentation. No extra planning hierarchy.
