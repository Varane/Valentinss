# D — implementation boundaries and shared contracts

Created 2026-11-11 20:56 UTC. MASTER.md is authoritative. Four worker chats created with thinking:ultra and the default model. No extra chats or recursive subagents.

## File ownership

- D1: dist/input.mjs; dist/ui/input/**; dist/ui/hud.mjs; dist/index.html; dist/action.css; tests/input-controls*.test.mjs; tests/input-hud*.test.mjs.
- D2: dist/ui.mjs; dist/ui/skills.mjs; dist/ui/equipment.mjs; dist/ui/overlay.mjs; dist/ui/ui-utils.mjs; tests/input-ui*.test.mjs.
- D3: worker/**; server/**; drizzle/**; dist/ui/network-client.mjs; dist/ui/network/**; tests/network-core*.test.mjs; tests/network-client*.test.mjs; docs/network/API.md.
- D4: scripts/build-coop.mjs; docs/network/HANDOFF.md; docs/network/DEPLOYMENT.md; docs/network/QA.md; dist/ui/accessibility.mjs; tests/network-qa*.test.mjs; tests/input-accessibility*.test.mjs.
- Director D: coordination/v4/D/STATUS.json, CONTRACTS.md, HANDOFF.md; review notes and integration tests under coordination/v4/D/.
- Each worker writes its own WORKER_STATUS_Dn.json and HANDOFF_Dn.md here, plus agent reports named with its Dn prefix. Never overwrite another team's reports.

## Input / UI responsibility

D1 input owns joystick and combat-button pointer events, keyboard. Keyboard: WASD/arrows move, Space attack, Shift dash, E parry, R special, F revive, Q switch, I inventory, K skills, Escape pause. Gameplay input clears on blur/visibility/pointercancel and does not run in forms or open dialog.

D2 UI owns click listeners for inventory, talents, pause, camera, switch-hero, ally, restart, after-gear, close, rooms. No duplicate combat click binding. Input onMenu opens UI; UI onPause tells root to suspend gameplay.

D1 HUD exports createHUD({getProfile,getSelected}) from dist/ui/hud.mjs returning update(encounter,selected), notice(text), showOutcome({won,title,text}), destroy(). It only renders existing DOM, binds no action/menu/switch buttons, and runs no simulation loop. D2 createUI composes it and exports the exact MASTER API. D2 may add setNetwork(client) and optional network option, but must retain the base API.

D1 retains current DOM IDs, adds a minimal rooms affordance (id rooms) and styles existing gear/constellation components. D2 reads current rules dynamically and does not mutate progression itself. Root's callbacks perform mutations.

## Network provisional API (D3 must document any final deviation immediately)

Browser module dist/ui/network-client.mjs:
createRoomClient({baseUrl,onSnapshot,onStatus,fetchImpl?,storage?}) returns create({profile?}), join(code), resume(), sendInput({x,z,actions,seq?}), poll(), leave(), getState(), destroy().
Async operations; unset baseUrl is visibly unavailable. getState supplies connectivity and authoritative snapshot. Inputs express intent only. Server owns combat, movement bounds, rewards and revisions. Code is separate from opaque authorization tokens; never put token in displayed room code.

Proposed HTTP: POST /api/rooms/create; POST /api/rooms/join; POST /api/rooms/:id/input; GET /api/rooms/:id/state; POST /api/rooms/:id/leave. Bearer token for protected room operations. D3 final docs/network/API.md is definitive.

D4 accessibility exports createAccessibility({root?,storage?}) -> getSettings(),setSetting(name,value),subscribe(fn),destroy(). It may persist user preferences but does not touch profile. D2 can integrate this once ready, or root can use it separately.

## Milestones / evidence

By 21:00 UTC publish WORKER_STATUS_Dn.json with exactly three factual agent IDs and four disjoint assignments. If unavailable, record real tool restriction and actual count. Aim working exports by 21:15, substantive handoff by 21:25. Director handoff 21:30, freeze 21:40, integration 21:51 UTC. No hosting/publishing/access changes, no root server/browser use, no commits. Tests must cover actual behavior and failures. Do not equate generated UI markup or unhosted network code with tested multiplayer service.
