# D — UX, coop and delivery

## Final D source checkpoint — 2026-11-11 22:03 UTC

**All D public modules are present. Integration is NOT release-ready while rules.mjs imports absent C-owned campaign/save.mjs.** Fresh director run21:59:100 tests,95 passed,5 failed,0 skipped. All5 failures are that missing external module: equipment, skills, UI facade, network core, and one HTTP conflict test. Worker source now exists and its remaining HTTP tests plus all5 SQLite-backed D1 tests pass.

Final cooperative adapter reviewed: A input.players is used in one20ms tick, companionAI=false, externalPlayers=[0,1]; old index=-1 fallback/manual movement removed. Immediate step(dt=0) settles final kills. Browser client20/20 and D1 input/HUD/independent gesture41/41 were verified. Hosted two-player play, full multiplayer campaign and physical iPhone remain unverified/unimplemented as specified below.

UI now exposes RU/EN in pause and blood/music/volume callbacks (getBlood/setBlood/getMusicEnabled/setMusicEnabled/getMusicVolume/setMusicVolume). Director additionally fixed irreversible DOM translation: new dist/ui/localization.mjs preserves source text/aria attributes across RU→EN→RU, recognizes live text changes, skips scripts/styles, and UI refreshes static body labels plus HUD on language changes. Observed red tests3/3, then green. Fresh command node --test tests/input-ui-localization.test.mjs tests/input-ui-overlay.test.mjs tests/input-hud.test.mjs at22:02:25 passed,0 failed. No reload/profile mutation.

Static staging command node scripts/build-coop.mjs --mode static --out work/d-director-static-2200 exited0, copied64 assets/1,158,148bytes, onlineDeployed:false. This snapshot predates the final localization helper; it is staging evidence, not proof of a runnable graph or a final deployment. Root must rebuild the current source after closing C imports. No Worker build or hosted claim is made.

Direct status messaging to root was rejected at21:59 by automatic approval review for unrecognized direct authorization. No bypass was attempted; this originally requested passive handoff contains the current evidence. Root alone integrates/publishes; no root/C/A/B files were changed by D director.

Remaining integration limits: optional showStory/duel consent UI is not in the inspected D UI facade; root/duel team must integrate their final API. Full campaign/gear/skill server routes are not implemented, online service is unconfigured. HANDOFF_D2 was still absent after interruption; the actual UI source and tests above supersede its stale worker status.

## Current checkpoint — 2026-11-11 21:38 UTC

Working sources now include input/HUD, UI facade and skill/equipment/dialog modules, accessibility, network client/core/local-server, and staging build adapter. No whole-direction green claim is made yet.

**Evidence:** director's fresh network-client suite passed 20/20 after two fixes: equal-revision snapshots now reach rendering, and the final 409 snapshot updates state before the sole retry gives up. Full direction run at21:35: 100 tests,85 passed,15 failed,0 skipped. Failures were absent C-owned dist/campaign/save.mjs (UI/skills/equipment/core imports) and absent D Worker source after interruption. Reports with hashes: verification-latest.json and verification-latest.log. Reproduce with node coordination/v4/D/verify-direction.mjs.

**Real concurrency:** exactly4 chats and12 child launches were verified with IDs,16 historical executor starts. Application restart removed children from D1/D2 live lists and lost unfinished writes. Leads resumed themselves, no replacement hierarchy. STATUS counts successful starts, not present live concurrency. Some worker-to-worker messages were rejected by automatic approval review; file coordination continued.

**Input/UI:** MASTER public signatures preserved. Input owns keyboard/joystick/combat/rescue. UI owns menu/switch/restart clicks, no second simulation or silent profile mutation. UI adds setNetwork(client) and open('rooms'). D1 handles independently reproduced focused-button Space and pointercancel ownership defects. UI language/music/story additions remain D2 work; consult final HANDOFF_D2.md before relying on optional extensions.

**Client:** createRoomClient({baseUrl,onSnapshot,onStatus,fetchImpl?,storage?}) from dist/ui/network-client.mjs. Methods create({profile?}),join(code),resume(),sendInput({x,z,actions,seq?}),poll(),leave(),getState(),destroy(). baseUrl is prefix before /api/rooms; '/' is same origin, absent means unavailable. Root must adopt server snapshot/assigned hero, throttle intents and stop local authority while connected. Client public state never exposes bearer tokens.

**Server:** server/room-core.mjs exports RoomError,MemoryRoomStore,createRoomService({store?,now?,randomBytes?}); server/local-server.mjs is importable and starts only on explicit CLI invocation. Browser profile grants cosmetic names only. Capacity two, separate bearer, CAS revisions and sequence idempotency. Current gameplay covers one authoritative encounter; full server campaign/equip/learn routes are not implemented.

**Critical A/D boundary:** A step currently clamps index=-1 to zero. D3 initial fallback needed replacement. A now supports input.players and companionAI=false. D3 instructed to disable companionAI, set externalPlayers=[0,1], call one step(enc,dt,{x:v0.x,z:v0.z,players:[v0,v1]},0), and remove extra manual movement. Verify final D3 source/tests before declaring correct coop.

**Build/accessibility:** createAccessibility({root?,storage?}) has getSettings/setSetting/subscribe/destroy for reducedMotion/blood/inputHints; its12 tests passed independently. scripts/build-coop.mjs stages to a fresh repo work/ directory. Command: node scripts/build-coop.mjs --mode static --out work/UNIQUE_DIRECTORY. Worker mode needs actual worker/index.mjs and esbuild. Exact deployment/D1 instructions live in docs/network/HANDOFF.md and DEPLOYMENT.md. Source hosting manifest, SW and audience remain root-owned.

**Release limits:** Worker/D1 source was missing in21:35 check and D3 is restoring it. Online is unconfigured/unverified; no preview/API server started, no publication, access change or commit by D. After missing modules arrive, rerun direction suite; actual browser/iPhone and two-client hosted tests remain root gates. API responses must bypass SW cache. Release-cycle plan is RELEASE-CYCLE.md.

## Earlier integration contract (superseded where noted above)

Status: implementation in progress, 2026-11-11 21:03 UTC. This is an early integration contract, not a completion claim.

Four working chats are created; IDs and factual child counts are in STATUS.json. File boundaries and internal dependencies are in CONTRACTS.md. Each worker provides HANDOFF_D1.md through HANDOFF_D4.md here. The final substantive handoff is due by 21:30 UTC.

## Root integration contracts

- Import createInput from dist/input.mjs; use the exact MASTER signature. Input owns keyboard, joystick and combat pointer buttons. UI owns menu/switch/restart clicks.
- Import createUI from dist/ui.mjs; use the exact MASTER signature. UI composes display-only createHUD from dist/ui/hud.mjs. UI mutations go through root callbacks. UI has no second simulation loop.
- Planned additive UI network API: setNetwork(client), open('rooms'). D2 will confirm final behavior.
- Planned browser network entry: createRoomClient from dist/ui/network-client.mjs. Exact final protocol is docs/network/API.md; absent endpoint must remain visibly offline.
- D4 supplies scripts/build-coop.mjs, deployment metadata instructions and docs/network/HANDOFF.md. Existing static hosting manifest remains root-owned and unchanged by D.

## Review gates

1. Input: multitouch move+attack, cancel/blur/visibility clearing, editable-focus and dialog isolation, normalized movement, no duplicate menu/combat handlers.
2. UI: callbacks use selected hero and actual item/skill IDs; profile is not silently mutated; modal pause and focus restore are balanced; small viewports preserve controls.
3. Network: two clients, bearer token separate from room code, unauthorized reads/writes rejected, capacity two, server-owned positions/damage/rewards, bounded elapsed time, stale revision and replay idempotency, reconnect preserves identity, no secrets in public snapshots.
4. Build: actual worker artifact imports close, D1 migration instructions fit supported Sites binding contract, no source manifest or audience mutation, static assets served by the built worker.
5. Verification: run relevant Node suites on final files and report counts. Browser/iPhone/hosted tests require root and are not implied by Node success.

## Limitations already known

The current Site manifest is static and owner-private. D supplies working source and local verification. A hosted two-player session cannot be claimed before root configures and deploys a Worker with D1 and verifies it across two clients. No publish/access changes or commits are authorized for this direction.
