import bpy, math, random, os, json, hashlib
from mathutils import Vector
bpy.context.preferences.filepaths.save_version=0
ROOT='/workspace/ashen'; OUT=ROOT+'/dist/art-assets'; SRC=ROOT+'/art-source'; random.seed(7421)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for x in list(bpy.data.materials): bpy.data.materials.remove(x)
def pos(x,h,z):return(x,-z,h)
def group(name):
 o=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(o);return o
roots={n:group(n)for n in ['fountain','inn','paving']}; parts=[]
def image(name,kind,color):
 n=128;im=bpy.data.images.new(name,width=n,height=n);pixels=[]
 for y in range(n):
  for x in range(n):
   u=x/n;v=y/n;grain=math.sin(2*math.pi*(u*5+v*3))*.035+math.cos(2*math.pi*(u*13-v*7))*.016+math.sin(2*math.pi*(u*31+v*17))*.007
   if kind=='wood':grain+=math.sin(2*math.pi*(u*16+.13*math.sin(v*math.pi*2)))*.07
   if kind=='plaster':grain*=.55
   if name.endswith('rough'):c=[min(.98,max(.1,.78+grain))]*3
   elif name.endswith('normal'):
    c=[.5+math.sin(2*math.pi*(u*13+v*7))*.035,.5+math.cos(2*math.pi*(u*5-v*11))*.035,1]
   else:c=[max(0,min(1,a*(1+grain)))for a in color]
   pixels.extend([*c,1])
 im.pixels=pixels;im.filepath_raw=SRC+'/river-square/'+name+'.png';im.file_format='PNG';im.save();im.pack();return im
mats={}
def material(name,color,kind=None,rough=.8,metal=0):
 m=bpy.data.materials.new(name);m.use_nodes=True;b=m.node_tree.nodes.get('Principled BSDF');b.inputs['Base Color'].default_value=(*color,1);b.inputs['Roughness'].default_value=rough;b.inputs['Metallic'].default_value=metal
 if kind:
  for channel in ['base','rough','normal']:
   im=image(name+'-'+channel,kind,color);n=m.node_tree.nodes.new('ShaderNodeTexImage');n.image=im
   if channel!='base':im.colorspace_settings.name='Non-Color'
   if channel=='base':m.node_tree.links.new(n.outputs['Color'],b.inputs['Base Color'])
   elif channel=='rough':m.node_tree.links.new(n.outputs['Color'],b.inputs['Roughness'])
   else:
    norm=m.node_tree.nodes.new('ShaderNodeNormalMap');norm.inputs['Strength'].default_value=.45;m.node_tree.links.new(n.outputs['Color'],norm.inputs['Color']);m.node_tree.links.new(norm.outputs['Normal'],b.inputs['Normal'])
 mats[name]=m;return m
stone=material('willow limestone',(.58,.55,.47),'stone');plaster=material('limewash',(.73,.67,.55),'plaster');oak=material('old oak',(.24,.18,.115),'wood');roof=material('slate tiles',(.18,.24,.255),rough=.9);dark=material('door recess',(.06,.085,.075));glass=material('warm amber glass',(.48,.27,.09),rough=.28);glass.node_tree.nodes.get('Principled BSDF').inputs['Emission Color'].default_value=(.5,.19,.025,1);glass.node_tree.nodes.get('Principled BSDF').inputs['Emission Strength'].default_value=.55
water=material('fountain water',(.19,.32,.32),rough=.16,metal=.15)
def finish(o,name,mat,parent,bevel=0):
 o.name=name;o.data.materials.append(mat);o.parent=roots[parent];parts.append(o)
 if bevel:
  mod=o.modifiers.new('soft worn edges','BEVEL');mod.width=bevel;mod.segments=2;bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=mod.name)
 for f in o.data.polygons:f.use_smooth=True
 return o
def box(name,loc,scale,mat,parent,bevel=.025):
 bpy.ops.mesh.primitive_cube_add(size=1,location=pos(*loc));o=bpy.context.object;o.scale=(scale[0],scale[2],scale[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,mat,parent,bevel)
def sphere(name,loc,scale,mat,parent,segments=20,rings=12):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=rings,location=pos(*loc));o=bpy.context.object;o.scale=(scale[0],scale[2],scale[1]);bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return finish(o,name,mat,parent)
def lathe(name,profile,mat,parent,segments=64):
 verts=[];faces=[]
 for r,h in profile:
  for j in range(segments):a=2*math.pi*j/segments;verts.append((r*math.cos(a),r*math.sin(a),h))
 for i in range(len(profile)-1):
  for j in range(segments):a=i*segments+j;b=i*segments+(j+1)%segments;faces.append((a,b,b+segments,a+segments))
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new(name,mesh);bpy.context.collection.objects.link(o);return finish(o,name,mat,parent)
def tube(name,points,radius,mat,parent):
 c=bpy.data.curves.new(name,'CURVE');c.dimensions='3D';c.resolution_u=8;c.bevel_depth=radius;c.bevel_resolution=2;s=c.splines.new('BEZIER');s.bezier_points.add(len(points)-1)
 for b,p in zip(s.bezier_points,points):b.co=pos(*p);b.handle_left_type=b.handle_right_type='AUTO'
 o=bpy.data.objects.new(name,c);bpy.context.collection.objects.link(o);bpy.context.view_layer.objects.active=o;o.select_set(True);bpy.ops.object.convert(target='MESH');o=bpy.context.object;return finish(o,name,mat,parent)
# Fountain stays inside authoritative r=2.6m footprint. Bowl profile includes inner lip.
lathe('basin carved rim',[(0,.06),(2.22,.06),(2.35,.16),(2.35,.28),(2.17,.35),(2.14,.72),(2.27,.79),(2.27,.91),(2.08,.95),(1.98,.83),(1.98,.4),(.55,.4)],stone,'fountain')
lathe('water surface',[(.48,.64),(2.03,.64)],water,'fountain')
lathe('central turned column',[(.5,.35),(.58,.48),(.53,.61),(.28,.77),(.22,1.38),(.40,1.51),(.53,1.59),(.54,1.69),(.28,1.74),(.22,2.0),(.42,2.12),(.42,2.22)],stone,'fountain',48)
# scalloped relief and practical spouts, joined into same stone draw.
for j in range(24):
 a=j*math.pi/12;r=2.18;sphere('rim relief', (r*math.cos(a),.53,r*math.sin(a)),(.035,.15,.035),stone,'fountain',8,6)
for j in range(4):
 a=j*math.pi/2;r=.48
 sphere('spout stone', (r*math.cos(a),1.52,r*math.sin(a)),(.12,.09,.12),stone,'fountain',12,8)
 points=[]
 for k in range(9):
  t=k/8;rr=.49+1.22*t;h=1.56+.32*t-1.18*t*t;points.append((rr*math.cos(a),h,rr*math.sin(a)))
 tube('water arc',points,.014,water,'fountain')
# Original heron carving with a continuous neck path and folded wing mass.
sphere('heron body',(0,2.55,0),(.24,.43,.33),stone,'fountain',24,16)
tube('heron neck',[(0,2.7,0),(.02,2.95,-.07),(.04,3.16,-.02),(.04,3.25,.12)],.085,stone,'fountain')
sphere('heron head',(.04,3.24,.13),(.105,.12,.18),stone,'fountain',20,12)
# beak faces +Z in game; narrow closed stone wedge.
box('heron beak',(.04,3.22,.36),(.07,.055,.28),stone,'fountain',.01)
for side in [-1,1]:sphere('folded carved wing',(side*.17,2.54,-.03),(.105,.33,.25),stone,'fountain',16,12)
# Inn footprint x[-16.5,-7.5], z[-13,-5]. Front approaches positive z, door atx-12.
box('inn plaster shell',(-12,2.15,-9),(8.1,4.3,7.15),plaster,'inn',.10)
box('stone plinth',(-12,.31,-9),(8.35,.62,7.45),stone,'inn',.06)
# Ground front door is a real visible recess, shell does not physically create a new collision.
box('deep entry',(-12,1.2,-5.395),(1.62,2.4,.12),dark,'inn',.10)
box('oak entry door',(-12,1.1,-5.31),(1.25,2.14,.10),oak,'inn',.06)
for x in [-12.78,-11.22]:box('entry jamb',(x,1.25,-5.25),(.16,2.5,.24),stone,'inn',.04)
box('entry lintel',(-12,2.51,-5.25),(1.75,.22,.26),stone,'inn',.06)
for i in range(2):box('worn threshold',(-12,.10+i*.12,-5.25-i*.18),(1.8,.2+i*.20,.34),stone,'inn',.04)
# Timber structure tied to corners and floors, decorative braces do not obscure access.
for x in [-16.03,-14.15,-9.85,-7.97]:box('oak upright',(x,2.27,-5.39),(.19,4.1,.21),oak,'inn',.025)
for h in [.74,2.93,4.13]:box('front oak beam',(-12,h,-5.37),(8.14,.20,.25),oak,'inn',.025)
for z in [-12.51,-9,-5.49]:
 for x in [-16.08,-7.92]:box('side uprights',(x,2.27,z),(.20,4.1,.20),oak,'inn',.025)
# Five windows with genuine depth, oak frames and diamond lattice.
for x,h in [(-14.9,1.85),(-9.1,1.85),(-14.9,3.55),(-12,3.55),(-9.1,3.55)]:
 box('window recess',(x,h,-5.43),(1.05,1.02,.10),dark,'inn',.025)
 box('amber window',(x,h,-5.34),(.84,.82,.06),glass,'inn',.02)
 for side in [-1,1]:
  box('window side',(x+side*.49,h,-5.27),(.10,1.10,.14),oak,'inn',.02)
  box('window sill',(x,h+side*.51,-5.27),(1.10,.10,.18),oak,'inn',.02)
 box('window mullion',(x,h,-5.24),(.055,.85,.09),oak,'inn',.01)
 for off in [-.20,.20]:
  b=box('window lead',(x+off,h,-5.22),(.025,.95,.025),oak,'inn',0);b.rotation_euler[1]=.35
# Roof gable triangles, slate thick roof slopes. all withinfootprint xwidth8.8 zdepth7.9.
verts=[pos(-16.35,4.2,-12.8),pos(-7.65,4.2,-12.8),pos(-12,6.4,-12.8),pos(-16.35,4.2,-5.2),pos(-7.65,4.2,-5.2),pos(-12,6.4,-5.2)];faces=[(0,1,2),(3,5,4),(0,3,4,1),(0,2,5,3),(1,4,5,2)]
mesh=bpy.data.meshes.new('gable');mesh.from_pydata(verts,[],faces);mesh.update();ob=bpy.data.objects.new('gable plaster',mesh);bpy.context.collection.objects.link(ob);finish(ob,'gable plaster',plaster,'inn')
# rows of tiles gives intentional silhouette and micro shadowing without individual draws.
for side in [-1,1]:
 for row in range(11):
  t=(row+.5)/11;x=-12+side*(.17+4.18*t);h=6.42-2.1*t
  for col in range(12):
   z=-12.72+(col+.5)*7.44/12
   b=box('individual slate tile',(x,h,z),(.47,.075,.68),roof,'inn',.018);b.rotation_euler[1]=side*math.atan2(2.1,4.18)
box('chimney',(-14.9,5.55,-10.7),(.62,2.4,.70),stone,'inn',.04)
# restrained willow sign hung on facade; leaf relief reads at gameplay scale.
box('sign bracket',(-10.55,2.80,-5.22),(.08,.09,.40),oak,'inn',.01)
box('willow inn sign',(-10.55,2.35,-5.13),(.64,.63,.10),oak,'inn',.06)
tube('willow trunk',[(-10.55,2.1,-5.06),(-10.55,2.50,-5.06)],.018,stone,'inn')
for side in [-1,1]:tube('willow relief',[(-10.55,2.49,-5.06),(-10.55+side*.18,2.37,-5.06),(-10.55+side*.20,2.18,-5.06)],.012,stone,'inn')
# Compact fan of hand-set paving around fountain, does not replace otherdistricts.
for row in range(-6,7):
 for col in range(-6,7):
  x=col*.85+(row%2)*.4;z=row*.72
  if math.hypot(x,z)<2.58 or math.hypot(x,z)>5.5:continue
  box('square stone paver',(x,-.018+random.uniform(-.007,.007),z),(.81,.055,.68),stone,'paving',.035)
# Merge by group/material: preserve names and sparse runtime draw units, unwrap intentional atlas.
merged=[]
for parent in roots.values():
 for material in list(mats.values()):
  objs=[o for o in list(bpy.data.objects) if o.type=='MESH' and o.parent==parent and o.data.materials and o.data.materials[0]==material]
  if not objs:continue
  bpy.ops.object.select_all(action='DESELECT')
  for o in objs:o.select_set(True)
  bpy.context.view_layer.objects.active=objs[0];bpy.ops.object.join();o=bpy.context.object;o.name=parent.name+'__'+material.name.replace(' ','_')
  bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
  bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=math.radians(66),island_margin=.015);bpy.ops.object.mode_set(mode='OBJECT');merged.append(o)
# Real mesh AO bake for each textured draw group, packed into original .blend and GLB.
bpy.context.scene.render.engine='CYCLES';bpy.context.scene.cycles.samples=8
for o in merged:
 m=o.data.materials[0]
 if not any(n.type=='TEX_IMAGE' for n in m.node_tree.nodes):continue
 m=m.copy();m.name=o.name+'_PBR';o.data.materials[0]=m
 ao=bpy.data.images.new(o.name+'_AO',width=128,height=128);ao.colorspace_settings.name='Non-Color'
 node=m.node_tree.nodes.new('ShaderNodeTexImage');node.image=ao;m.node_tree.nodes.active=node
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
 try:bpy.ops.object.bake(type='AO',margin=2)
 except Exception as e:print('AO bake warning',e)
 ao.filepath_raw=SRC+'/river-square/'+o.name+'_AO.png';ao.file_format='PNG';ao.save();ao.pack()
 settings=bpy.data.node_groups.get('glTF Material Output')
 if not settings:
  settings=bpy.data.node_groups.new('glTF Material Output','ShaderNodeTree');settings.interface.new_socket(name='Occlusion',in_out='INPUT',socket_type='NodeSocketFloat')
 gn=m.node_tree.nodes.new('ShaderNodeGroup');gn.node_tree=settings;m.node_tree.links.new(node.outputs['Color'],gn.inputs['Occlusion'])
# Mobile authoring LOD: collapse tiny bevel facets while keeping seam UVs and material boundaries.
for o in merged:
 bpy.context.view_layer.objects.active=o
 mod=o.modifiers.new('mobile authored LOD','DECIMATE');mod.ratio=.32
 bpy.ops.object.modifier_apply(modifier=mod.name)
# Compact metadata. Export no lights/camera. Runtime supplies its ownlighting.
scene=bpy.context.scene;scene['asset_provenance']='Original authored by OpenAI assistant for ASHEN; no third-party geometry/textures.'
scene['units']='metres; glTF +Y up; group positions already world-space game coordinates';scene.unit_settings.system='METRIC'
bpy.ops.wm.save_as_mainfile(filepath=SRC+'/river-square.blend')
bpy.ops.export_scene.gltf(filepath=OUT+'/river-square.glb',export_format='GLB',export_yup=True,export_cameras=False,export_lights=False,export_animations=False,export_image_format='AUTO')
tri=sum(sum(len(p.vertices)-2 for p in o.data.polygons)for o in merged)
meta={'id':'river-square','version':1,'source':'art-source/river-square.blend','generator':'art-source/river-square/build_square.py','url':'/art-assets/river-square.glb','groups':['fountain','inn','paving'],'triangles':tri,'meshDrawGroups':len(merged),'materials':len({o.data.materials[0].name for o in merged}),'bytes':os.path.getsize(OUT+'/river-square.glb'),'sha256':hashlib.sha256(open(OUT+'/river-square.glb','rb').read()).hexdigest(),'unitScale':1,'upAxis':'+Y','forwardAxis':'+Z','license':'CC0-1.0','provenance':'Original generated geometry and authored texture maps; no third-party source assets','coordinates':{'fountain':{'x':0,'z':0,'maxRadius':2.35},'inn':{'x':-12,'z':-9,'footprint':[9,8]},'paving':{'x':0,'z':0,'maxRadius':6}},'maps':'128px original UV base/normal/roughness + actual mesh-baked AO on5 textured draw groups'}
open(OUT+'/river-square.asset.json','w').write(json.dumps(meta,indent=2));print(json.dumps(meta))

# Post-export proof reads actual glTF POSITION vertices through node transforms.
import subprocess
subprocess.run(["python",SRC+"/river-square/verify_export.py"],check=True)
