import json,struct,math,pathlib
root=pathlib.Path('/workspace/ashen');d=(root/'dist/art-assets/river-square.glb').read_bytes();n=struct.unpack_from('<I',d,12)[0];g=json.loads(d[20:20+n]);bin_offset=20+n+8;bounds={}
def transform(p,node):
 s=node.get('scale',[1,1,1]);p=[a*b for a,b in zip(p,s)];x,y,z,w=node.get('rotation',[0,0,0,1]);vx,vy,vz=p;tx=2*(y*vz-z*vy);ty=2*(z*vx-x*vz);tz=2*(x*vy-y*vx);p=[vx+w*tx+y*tz-z*ty,vy+w*ty+z*tx-x*tz,vz+w*tz+x*ty-y*tx];return[a+b for a,b in zip(p,node.get('translation',[0,0,0]))]
def rec(i,parents=[]):
 node=g['nodes'][i];out=[]
 if'mesh'in node:
  for prim in g['meshes'][node['mesh']]['primitives']:
   a=g['accessors'][prim['attributes']['POSITION']];v=g['bufferViews'][a['bufferView']];base=bin_offset+v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',12)
   for j in range(a['count']):
    p=struct.unpack_from('<fff',d,base+j*stride)
    for t in [node,*parents]:p=transform(p,t)
    assert all(math.isfinite(x)for x in p);out.append(p)
 for c in node.get('children',[]):out+=rec(c,[node,*parents])
 return out
for i,node in enumerate(g['nodes']):
 if node.get('name')in['inn','fountain','paving']:
  points=rec(i);bounds[node['name']]={'min':[round(min(p[j]for p in points),5)for j in range(3)],'max':[round(max(p[j]for p in points),5)for j in range(3)]}
assert bounds['fountain']['min'][0]>=-2.6 and bounds['fountain']['max'][0]<=2.6
assert bounds['inn']['min'][0]>=-16.5 and bounds['inn']['max'][0]<=-7.5
assert bounds['inn']['min'][2]>=-13 and bounds['inn']['max'][2]<=-5
p=root/'dist/art-assets/river-square.asset.json';m=json.loads(p.read_text());m['bounds']=bounds;m['coordinates']['paving']['maxRadius']=6;m['maps']='128px original UV base/normal/roughness + actual mesh-baked AO on5 textured draw groups';p.write_text(json.dumps(m,indent=2));print(json.dumps(bounds,indent=2));print('Verified finite world vertices and authoritative footprint containment.')
