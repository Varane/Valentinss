import bpy,math
from mathutils import Vector
bpy.ops.wm.open_mainfile(filepath='/workspace/ashen/art-source/river-square.blend')
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=12;scene.cycles.use_denoising=False;scene.render.resolution_x=1152;scene.render.resolution_y=768;scene.render.resolution_percentage=100
bpy.ops.mesh.primitive_plane_add(size=70,location=(-5,2,-.09));o=bpy.context.object;m=bpy.data.materials.new('preview ground');m.diffuse_color=(.28,.31,.26,1);o.data.materials.append(m)
world=scene.world;world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.58,.67,.75,1);world.node_tree.nodes['Background'].inputs[1].default_value=.6
bpy.ops.object.light_add(type='AREA',location=(-3,-9,15));l=bpy.context.object;l.data.energy=2000;l.data.shape='DISK';l.data.size=8
bpy.ops.object.camera_add(location=(12,-20,13));camera=bpy.context.object;camera.rotation_euler=(Vector((-5,4,1.2))-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=28;scene.camera=camera
scene.render.filepath='/workspace/ashen/art-source/river-square/asset-preview.png';bpy.ops.render.render(write_still=True)
