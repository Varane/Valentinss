"""Kvak v2 assembly. Artist modules own anatomy/clothes/surfaces; this owns rig/export.
Prototype output is NOT approved for publication until source visual review.
Run: blender -b --python art-source/kvak/build_kvak_v2.py
"""
import bpy, os, sys, math, json, gzip, hashlib
from pathlib import Path
from mathutils import Vector, Matrix, Euler, Quaternion
ROOT=Path(__file__).resolve().parents[2];SRC=Path(__file__).parent;OUT=ROOT/'dist/art-assets/kvak';EXPORTS=SRC/'exports-v2';TEX=SRC/'textures-v2'
for p in[OUT,EXPORTS,TEX]:p.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(SRC))
import anatomy_parts,clothing_parts,surface_materials
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
materials=surface_materials.build_materials(str(TEX));anatomy=anatomy_parts.build_anatomy(materials)
assert isinstance(anatomy,dict)and anatomy.get('skin')and anatomy.get('landmarks')
landmarks=anatomy['landmarks'];bones={}
for name,item in landmarks.items():
 if isinstance(item,dict):
  if 'head'not in item or'tail'not in item:continue
  bones[name]=(tuple(item['head']),tuple(item['tail']),item.get('parent'))
 elif isinstance(item,(list,tuple))and len(item)==3:bones[name]=(tuple(item[0]),tuple(item[1]),item[2])
assert {'Hips','Spine2','Head','LeftHand','RightHand','LeftFoot','RightFoot'}<=set(bones)
clothes=clothing_parts.build_clothing(materials,landmarks)
meshes=list(dict.fromkeys(anatomy['objects']+clothes))
for ob in meshes:
 bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob
 if ob.type=='CURVE':bpy.ops.object.convert(target='MESH')
 assert ob.type=='MESH',ob.name
 bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
 # UVs are a delivery requirement, not inferred from procedural source shader nodes.
 if not ob.data.uv_layers:
  bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=1.1519,island_margin=.012);bpy.ops.object.mode_set(mode='OBJECT')
 if ob.data.color_attributes.get('Col'):
  ob.data.color_attributes.active_color=ob.data.color_attributes['Col'];ob.data.color_attributes.render_color_index=ob.data.color_attributes.find('Col')
 for poly in ob.data.polygons:poly.use_smooth=True

skin=anatomy['skin'];face=anatomy.get('facialAnchors',{})
headbase=Vector(bones['Head'][0]);headtip=Vector(bones['Head'][1]);mouth=Vector(face.get('mouthCenter',(0,-.28,headtip.z-.19)))
eyeL=Vector(face.get('eye.L',(-.25,-.16,headtip.z+.13)));eyeR=Vector(face.get('eye.R',(.25,-.16,headtip.z+.13)))
# Facial targets remain modest anatomical deformations. No fake screenshot overlays.
facial=[]
for ob in anatomy['objects']:
 if ob==skin or ob.get('bind_region')=='Head':
  facial.append(ob);bpy.context.view_layer.objects.active=ob
  if ob.data.shape_keys:continue
  ob.shape_key_add(name='Basis')
  for expression in['Smile','Frown','Surprise','BlinkLeft','BlinkRight']:
   key=ob.shape_key_add(name=expression)
   for v in key.data:
    x,y,z=v.co
    if expression in['Smile','Frown','Surprise']:
     mask=max(0,1-abs(z-mouth.z)/.085)*max(0,1-abs(y-mouth.y)/.14)*max(0,1-abs(x)/.40)
     if expression=='Surprise':v.co.z+=(z-mouth.z)*mask*.6;v.co.x-=x*mask*.08
     else:v.co.z+=(1 if expression=='Smile'else-1)*.045*(abs(x)/.31)**1.3*mask
    else:
     eye=eyeL if expression=='BlinkLeft'else eyeR
     mask=max(0,1-abs(x-eye.x)/.19)*max(0,1-abs(y-eye.y)/.20)*max(0,1-abs(z-eye.z)/.18)
     if 'lid'in ob.name.lower()or ob==skin:v.co.z-=.11*mask*max(0,min(1,(z-eye.z+.04)/.10))
     elif 'eye'in ob.name.lower()or'iris'in ob.name.lower()or'pupil'in ob.name.lower():v.co.z=eye.z+(z-eye.z)*(1-mask*.9)

armdata=bpy.data.armatures.new('KvakRig');rig=bpy.data.objects.new('KvakRig',armdata);bpy.context.collection.objects.link(rig);bpy.context.view_layer.objects.active=rig;bpy.ops.object.select_all(action='DESELECT');rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
for name,(head,tail,parent)in bones.items():
 b=armdata.edit_bones.new(name);b.head=head;b.tail=tail
for name,(_,_,parent)in bones.items():
 if parent:armdata.edit_bones[name].parent=armdata.edit_bones[parent]
bpy.ops.object.mode_set(mode='OBJECT')
def distance(p,a,b):
 d=b-a;t=max(0,min(1,(p-a).dot(d)/max(1e-8,d.length_squared)));return(p-(a+d*t)).length
for ob in meshes:
 groups={n:ob.vertex_groups.new(name=n)for n in bones};region=ob.get('bind_region','AUTO');role=ob.get('clothing_role','')
 if role in['bag','vest','cape','shirt']and not('Arm'in region or'Hand'in region):region='Spine2'
 for v in ob.data.vertices:
  p=v.co;x,y,z=p;side='Left'if x<0 else'Right'
  if role=='trousers':candidates=['Hips',side+'UpLeg']
  elif region in bones:candidates=[region]
  elif z>headbase.z+.12:candidates=['Head']
  elif (abs(x)>.34 or abs(x)>.28 and y<-.08) and z>.35:candidates=[side+s for s in['Arm','ForeArm','Hand']]+(['Spine2']if abs(x)<.36 else[])
  elif z<bones['Hips'][1][2]-.04:candidates=[side+s for s in['UpLeg','Leg','Foot']]+(['Hips']if z>bones['Hips'][0][2]-.05 else[])
  else:candidates=['Hips','Spine2','Head']
  near=sorted((distance(p,Vector(bones[n][0]),Vector(bones[n][1])),n)for n in candidates)[:2];weights=[1/max(.018,d)**4 for d,n in near];total=sum(weights)
  for w,(_,n)in zip(weights,near):groups[n].add([v.index],w/total,'REPLACE')
 mod=ob.modifiers.new('Kvak skin binding','ARMATURE');mod.object=rig;ob.parent=rig
# WORLD rest frame identity; exporter changes coordinatebasis byconjugation.
socket_specs=anatomy.get('sockets',{})
fallback={'socket.head':{'bone':'Head','position_world':list(headtip)},'socket.hair':{'bone':'Head','position_world':[headtip.x,headtip.y,headtip.z+.11]},'socket.hand.L':{'bone':'LeftHand','position_world':bones['LeftHand'][1]},'socket.hand.R':{'bone':'RightHand','position_world':bones['RightHand'][1]},'socket.outfit':{'bone':'Spine2','position_world':bones['Spine2'][1]}}
for name,default in fallback.items():
 spec=socket_specs.get(name,default);bone=spec.get('bone',default['bone']);position=spec.get('position_world',default['position_world']);e=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(e);e.empty_display_size=.04;e.parent=rig;e.parent_type='BONE';e.parent_bone=bone;bpy.context.view_layer.update();e.matrix_world=Matrix.Translation(Vector(position))
# Original in-place locomotion and gesture clips. Clips do not move world coordinates.
scene=bpy.context.scene;scene.render.fps=30
for name,length in[('idle',90),('walk',30),('turn',36),('wave',60)]:
 rig.animation_data_create();action=bpy.data.actions.new(name);rig.animation_data.action=action
 for frame in range(1,length+1,3):
  phase=(frame-1)/length*2*math.pi
  for pb in rig.pose.bones:pb.rotation_mode='QUATERNION';pb.rotation_euler=(0,0,0);pb.rotation_quaternion=(1,0,0,0);pb.location=(0,0,0)
  rig.pose.bones['Spine2'].rotation_euler[0]=.012*math.sin(phase)
  if name=='walk':
   for side,sign in[('Left',1),('Right',-1)]:
    rig.pose.bones[side+'UpLeg'].rotation_euler[0]=math.sin(phase)*.38*sign;rig.pose.bones[side+'Leg'].rotation_euler[0]=max(0,-math.sin(phase)*sign)*.52;rig.pose.bones[side+'Foot'].rotation_euler[0]=-math.sin(phase)*.14*sign;rig.pose.bones[side+'Arm'].rotation_euler[0]=-math.sin(phase)*.22*sign
   rig.pose.bones['Hips'].location.z=abs(math.sin(phase))*.012
  elif name=='turn':rig.pose.bones['Head'].rotation_euler[1]=math.sin(phase)*.28;rig.pose.bones['Spine2'].rotation_euler[1]=math.sin(phase)*.08
  elif name=='wave':
   env=math.sin(math.pi*(frame-1)/length)**.5;rig.pose.bones['Spine2'].rotation_euler=(0,0,0)
   qa=rig.data.bones['LeftArm'].matrix_local.to_quaternion();qf=rig.data.bones['LeftForeArm'].matrix_local.to_quaternion();a=Vector(bones['LeftArm'][1])-Vector(bones['LeftArm'][0]);f=Vector(bones['LeftForeArm'][1])-Vector(bones['LeftForeArm'][0]);ident=Quaternion((1,0,0,0));da=ident.slerp(a.normalized().rotation_difference(Vector((-.85,-.12,.55)).normalized()),env);df=ident.slerp(f.normalized().rotation_difference(Vector((-.12,-.12,.985)).normalized()),env)
   rig.pose.bones['LeftArm'].rotation_mode='QUATERNION';rig.pose.bones['LeftArm'].rotation_quaternion=qa.inverted()@da@qa;rig.pose.bones['LeftForeArm'].rotation_mode='QUATERNION';rig.pose.bones['LeftForeArm'].rotation_quaternion=qf.inverted()@da.inverted()@df@qf;rig.pose.bones['LeftHand'].rotation_euler[1]=math.sin(phase*3)*.22*env
  for pb in rig.pose.bones:
   if not(name=='wave'and pb.name in['LeftArm','LeftForeArm']):pb.rotation_quaternion=pb.rotation_euler.to_quaternion()
   pb.keyframe_insert('rotation_quaternion',frame=frame,group=pb.name);pb.keyframe_insert('location',frame=frame,group=pb.name)
 track=rig.animation_data.nla_tracks.new();track.name=name;track.strips.new(name,1,action)
rig.animation_data.action=None
for pb in rig.pose.bones:pb.rotation_euler=(0,0,0);pb.rotation_quaternion=(1,0,0,0);pb.location=(0,0,0)
scene.frame_set(1)
# Source studio review only: not a game screenshot, phone profile or approval.
scene.render.engine='CYCLES';scene.cycles.samples=48;scene.cycles.use_denoising=False;scene.world.color=(.10,.115,.12);scene.render.resolution_x=1200;scene.render.resolution_y=1200;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX'
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.005));floor=bpy.context.object;floor.name='SOURCE_ONLY floor';floor_mat=bpy.data.materials.new('Source studio floor');floor_mat.diffuse_color=(.10,.115,.12,1);floor.data.materials.append(floor_mat)
def aim(o,point):o.rotation_euler=(Vector(point)-o.location).to_track_quat('-Z','Y').to_euler()
for name,position,power,size in[('key',(-3,-4,5),420,4),('fill',(3,-1,3),130,3),('rim',(1,3,4),260,3)]:
 bpy.ops.object.light_add(type='AREA',location=position);lamp=bpy.context.object;lamp.name='SOURCE_ONLY '+name;lamp.data.energy=power;lamp.data.shape='DISK';lamp.data.size=size;aim(lamp,(0,0,.9))
bpy.ops.object.camera_add(location=(2.5,-4.5,2.1));cam=bpy.context.object;cam.name='SOURCE_ONLY source camera';cam.data.type='ORTHO';cam.data.ortho_scale=2.1;aim(cam,(0,0,.94));scene.camera=cam
bpy.ops.wm.save_as_mainfile(filepath=str(SRC/'kvak-v2.blend'))
exports=[]
for lod,ratio in[(0,1),(1,.42),(2,.13)]:
 clones=[]
 if lod==0:objects=meshes
 else:
  for src in meshes:
   ob=src.copy();ob.data=src.data.copy();bpy.context.collection.objects.link(ob);clones.append(ob);bpy.context.view_layer.objects.active=ob
   if ob.data.shape_keys:ob.shape_key_clear()
   dec=ob.modifiers.new('LOD simplification','DECIMATE');dec.ratio=ratio;bpy.ops.object.modifier_apply(modifier=dec.name)
  objects=clones
 bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
 for ob in objects:ob.select_set(True)
 for ob in bpy.data.objects:
  if ob.name.startswith('socket.'):ob.select_set(True)
 path=(OUT if lod==0 else EXPORTS)/f'kvak-lod{lod}.glb';bpy.ops.export_scene.gltf(filepath=str(path),export_format='GLB',use_selection=True,export_animations=True,export_nla_strips=True,export_materials='EXPORT',export_yup=True,export_apply=False,export_texcoords=True,export_normals=True,export_skins=True,export_morph=True,export_morph_normal=False,export_vertex_color='ACTIVE',export_all_vertex_colors=False)
 binary=path.read_bytes();exports.append({'lod':lod,'sourceArtifact':str(path.relative_to(ROOT)),'runtime':lod==0,'url':'/art-assets/kvak/kvak-lod0.glb'if lod==0 else None,'triangles':sum(sum(len(p.vertices)-2 for p in ob.data.polygons)for ob in objects),'bytes':len(binary),'gzipBytes':len(gzip.compress(binary)),'sha256':hashlib.sha256(binary).hexdigest()})
 for ob in clones:bpy.data.objects.remove(ob,do_unlink=True)
manifest={'id':'kvak-original-v2-candidate','approval':'NOT_APPROVED_SOURCE_REVIEW_REQUIRED','source':'art-source/kvak/kvak-v2.blend','build':'art-source/kvak/build_kvak_v2.py','authorship':'Original ASHEN artist modules: anatomy, clothing, surfaces and rig assembly','license':'Original project geometry/textures/rig/animations; no external ripped assets','forwardAxis':'+Z','upAxis':'+Y','unitScale':1,'skeleton':list(bones),'sockets':list(fallback),'animations':['idle','walk','turn','wave'],'morphs':['Smile','Frown','Surprise','BlinkLeft','BlinkRight'],'lods':exports,'materials':len({m for o in meshes for m in o.data.materials}),'notes':anatomy.get('notes',[]),'blenderSockets':{o.name:list(o.matrix_world.translation)for o in bpy.data.objects if o.name.startswith('socket.')},'sourceBounds':{'min':[min((o.matrix_world@v.co)[a]for o in meshes for v in o.data.vertices)for a in range(3)],'max':[max((o.matrix_world@v.co)[a]for o in meshes for v in o.data.vertices)for a in range(3)]}}
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));scene.render.filepath=str(SRC/'kvak-v2-source-preview.png');
if os.environ.get('KVAK_SKIP_PREVIEW')!='1':bpy.ops.render.render(write_still=True)
print('KVAK_V2',json.dumps(exports))
