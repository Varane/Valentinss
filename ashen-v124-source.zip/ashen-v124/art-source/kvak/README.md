# Kvak artist production workspace

Current target: `build_kvak_v2.py`, consuming original anatomy/clothing/surface artist modules. All final coordinates are Blender Z-up, -Y forward, meters. No old piecewise height transformation remains.

Build: `blender -b --python art-source/kvak/build_kvak_v2.py`.
Structural validation: `python art-source/kvak/validate_kvak_v2.py`.

V2 is a candidate, never automatically approved. Source preview is an offline Blender review, not a game screenshot or evidence of phone performance. Main runtime keeps its old Kvak until visual approval.

`rejected-v1/` contains the first rejected attempt and is not an approved runtime resource. Its archive exists to prevent accidental repetition or unsupported claims. V2 must materially improve anatomy, paws, clear clothing and material distinction before phase completion.
