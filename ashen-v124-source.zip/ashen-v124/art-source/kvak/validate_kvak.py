# Compatibility entry point for the current candidate validator.
from pathlib import Path
exec(compile(Path(__file__).with_name('validate_kvak_v2.py').read_text(),str(Path(__file__).with_name('validate_kvak_v2.py')),'exec'))
