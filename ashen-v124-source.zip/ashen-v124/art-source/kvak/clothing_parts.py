"""Original tailored clothing for Kvak v2.

Blender Z-up/-Y-forward, metres. No scene reset, export or height transform.
Call build_clothing(materials, landmarks) before armature weighting.
All returned objects are meshes with `bind_region` and `clothing_role`.
"""
import bpy
import math
from mathutils import Vector
from math import sin, cos, pi


def build_clothing(materials, landmarks=None):
    landmarks = landmarks or {}
    measurements = landmarks.get('measurements', {}) if isinstance(landmarks, dict) else {}
    objects = []

    def head(name, default):
        value = landmarks.get(name) if isinstance(landmarks, dict) else None
        if isinstance(value, dict):
            return Vector(value.get('head', default))
        if isinstance(value, (tuple, list)) and len(value) >= 2:
            try:
                return Vector(value[0])
            except (TypeError, ValueError):
                pass
        return Vector(default)

    shoulder = head('RightArm', (.30, 0, 1.18))
    shoulder_z = shoulder.z
    shoulder_x = abs(shoulder.x)
    waist_z = float(measurements.get('waist_z', shoulder_z - .37))
    neck_z = float(measurements.get('neck_z', shoulder_z + .10))
    chest_z = float(measurements.get('chest_z', shoulder_z - .19))
    hip_z = float(measurements.get('hip_z', waist_z - .11))
    chest_rx = float(measurements.get('chest_rx', max(.245, shoulder_x - .03)))
    chest_ry = float(measurements.get('chest_ry', .20))
    waist_rx = float(measurements.get('waist_rx', chest_rx - .025))
    waist_ry = float(measurements.get('waist_ry', .19))
    namespace = 'Kvak tailored | '

    def material(role):
        fallback = materials.get('cloth') or materials.get('linen')
        alias={'bag':'leather','trousers':'linen','bronze':'metal'}.get(role,role)
        return materials.get(role) or materials.get(alias) or materials.get('cloth') or fallback

    def finish(name, verts, faces, role, bind='AUTO', thickness=0, bevel=0):
        mesh = bpy.data.meshes.new(namespace + name)
        mesh.from_pydata(verts, [], faces)
        mesh.update()
        semantic='bag' if any(k in name.lower() for k in ['satchel','carrying strap']) else 'breeches' if 'breeches' in name.lower() else 'cape' if 'cape' in name.lower() else 'shirt' if role=='linen' or 'sleeve' in name.lower() or 'collar' in name.lower() or 'cuff' in name.lower() else 'vest'
        obj = bpy.data.objects.new('garment_'+semantic+'__'+name.replace(' ','_'), mesh)
        bpy.context.collection.objects.link(obj)
        m = material(role)
        if m is not None:
            obj.data.materials.append(m)
        obj['bind_region'] = bind
        obj['clothing_role'] = 'trousers' if semantic=='breeches' else semantic
        obj['surface_role'] = role
        for polygon in obj.data.polygons:
            polygon.use_smooth = True
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        if thickness:
            solid = obj.modifiers.new('Real garment edge thickness', 'SOLIDIFY')
            solid.thickness = thickness
            solid.offset = 0
            solid.use_even_offset = True
            bpy.ops.object.modifier_apply(modifier=solid.name)
        if bevel:
            edge = obj.modifiers.new('Supple rounded garment edges', 'BEVEL')
            edge.width = bevel
            edge.segments = 2
            edge.limit_method = 'ANGLE'
            bpy.ops.object.modifier_apply(modifier=edge.name)
        obj.select_set(False)
        objects.append(obj)
        return obj

    def loft(name, profiles, role, bind='Spine2', count=40, gap=0, thickness=.006, ripple=.0):
        # Elliptical pattern panels. Profiles are (z, rx, ry, front_gap_angle).
        vertices, faces = [], []
        closed = not gap and not any(len(p) > 3 and p[3] for p in profiles)
        ring_count = count if closed else count + 1
        for k, p in enumerate(profiles):
            z, rx, ry = p[:3]
            opening = p[3] if len(p) > 3 else gap
            for j in range(ring_count):
                a = (2*pi*j/count) if closed else opening + (2*pi-2*opening)*j/count
                fold = ripple * sin(a*7 + k*.7) * (.35 + .65*sin(pi*k/max(1,len(profiles)-1)))
                vertices.append((sin(a)*(rx+fold), .012-cos(a)*(ry+fold), z))
        for k in range(len(profiles)-1):
            for j in range(count):
                nj = (j+1) % ring_count
                a=k*ring_count+j
                faces.append((a, k*ring_count+nj, (k+1)*ring_count+nj, a+ring_count))
        return finish(name, vertices, faces, role, bind, thickness=thickness)

    def ribbon(name, points, width, role, bind='Spine2', thickness=.003):
        # Flat-cut strips with finite width, not round ropes masquerading as cloth.
        vertices=[]
        for i, p in enumerate(points):
            p=Vector(p)
            tangent=Vector(points[min(i+1,len(points)-1)])-Vector(points[max(i-1,0)])
            normal=tangent.cross(Vector((0,-1,0)))
            if normal.length < .0001:
                normal=Vector((1,0,0))
            normal.normalize()
            vertices.extend([p-normal*width*.5,p+normal*width*.5])
        faces=[(i*2,i*2+1,i*2+3,i*2+2) for i in range(len(points)-1)]
        return finish(name, vertices, faces, role, bind, thickness=thickness)

    def tube(name, points, radius, role, bind='Spine2', sides=5):
        vertices=[]
        for i, p in enumerate(points):
            p=Vector(p)
            tangent=Vector(points[min(i+1,len(points)-1)])-Vector(points[max(i-1,0)])
            tangent.normalize()
            normal=tangent.cross(Vector((0,-1,0)))
            if normal.length < .001:
                normal=tangent.cross(Vector((1,0,0)))
            normal.normalize();bitangent=tangent.cross(normal).normalized()
            for j in range(sides):
                a=j*2*pi/sides
                vertices.append(p+(normal*cos(a)+bitangent*sin(a))*radius)
        faces=[]
        for i in range(len(points)-1):
            for j in range(sides):
                faces.append((i*sides+j,i*sides+(j+1)%sides,(i+1)*sides+(j+1)%sides,(i+1)*sides+j))
        return finish(name, vertices, faces, role, bind)

    def rounded_box(name, center, half, role, bind='Spine2', bevel=.01):
        x,y,z=center;rx,ry,rz=half
        vertices=[(x+sx*rx,y+sy*ry,z+sz*rz) for sz in [-1,1] for sy in [-1,1] for sx in [-1,1]]
        faces=[(0,1,3,2),(4,6,7,5),(0,4,5,1),(2,3,7,6),(0,2,6,4),(1,5,7,3)]
        return finish(name,vertices,faces,role,bind,bevel=bevel)

    # Linen is actually visible at the shirt opening, sleeves and lower hem.
    shirt_profiles=[
        (waist_z-.035,waist_rx+.075,waist_ry+.065),
        (waist_z+.055,waist_rx+.043,waist_ry+.035),
        (chest_z,chest_rx+.027,chest_ry+.025),
        (shoulder_z-.025,chest_rx+.025,chest_ry+.025),
        (neck_z-.04,.248,.202),
    ]
    loft('unbleached linen shirt',shirt_profiles,'linen',ripple=.0035)
    # A small standing collar, with two cut-and-folded lapels; no ambiguous scarf torus.
    loft('linen stand collar',[(neck_z-.065,.245,.202),(neck_z+.005,.232,.190)],'linen',count=32,gap=.18,thickness=.008)
    for side in [-1,1]:
        verts=[(side*.025,-.195,neck_z-.008),(side*.165,-.174,neck_z-.025),(side*.158,-.244,neck_z-.155),(side*.035,-.228,neck_z-.100)]
        finish('folded linen collar '+str(side),verts,[(0,1,2,3)],'linen',thickness=.009)
        tube('collar stitched edge '+str(side),[verts[0],verts[3],verts[2]],.0025,'linen')

    # Upper sleeves follow the real shoulder/elbow axis; their rolled cuffs end above the elbow.
    for side,label in [(-1,'Left'),(1,'Right')]:
        a=head(label+'Arm',(side*.30,0,1.18))
        elbow=head(label+'ForeArm',(side*.42,-.03,.90))
        direction=(elbow-a).normalized()
        u=direction.cross(Vector((0,1,0))).normalized()
        v=direction.cross(u).normalized()
        length=(elbow-a).length
        sleeves=[];faces=[];sides=20
        # Relaxed linen shoulder and gathered fabric immediately above the roll.
        rings=[(-.035,.120),(.02,.132),(.10,.130),(.20,.109),(length-.018,.096)]
        for k,(distance,rad) in enumerate(rings):
            p=a+direction*distance
            for j in range(sides):
                angle=j*2*pi/sides
                fold=.004*sin(angle*7+k*.5)
                sleeves.append(p+u*cos(angle)*(rad+fold)+v*sin(angle)*(rad*.88+fold))
        for k in range(len(rings)-1):
            for j in range(sides):faces.append((k*sides+j,k*sides+(j+1)%sides,(k+1)*sides+(j+1)%sides,(k+1)*sides+j))
        finish(label+' rolled linen sleeve',sleeves,faces,'linen',label+'Arm',thickness=.006)
        # Two narrow faceted rolls read as folded cloth, rather than balloon cuffs.
        for roll,(dist,rad) in enumerate([(length-.043,.103),(length-.012,.104)]):
            p=a+direction*dist
            verts=[];quads=[]
            for k in range(6):
                phi=k*2*pi/6
                for j in range(sides):
                    angle=j*2*pi/sides
                    radial=rad+.011*cos(phi)
                    verts.append(p+direction*(.011*sin(phi))+u*cos(angle)*radial+v*sin(angle)*radial*.88)
            for k in range(6):
                for j in range(sides):quads.append((k*sides+j,k*sides+(j+1)%sides,((k+1)%6)*sides+(j+1)%sides,((k+1)%6)*sides+j))
            finish(label+' folded cuff '+str(roll),verts,quads,'linen',label+'Arm')

    # Fitted waistcoat: buttoned lower front, V opening, rounded but clearly cut edges.
    vest_profiles=[
        (waist_z+.012,waist_rx+.073,waist_ry+.060,.022),
        (waist_z+.085,waist_rx+.055,waist_ry+.052,.024),
        (chest_z-.025,chest_rx+.044,chest_ry+.041,.034),
        (shoulder_z-.055,chest_rx+.035,chest_ry+.038,.28),
        (shoulder_z+.005,chest_rx+.026,chest_ry+.034,.63),
    ]
    loft('charcoal leather waistcoat',vest_profiles,'leather',count=36,thickness=.009,ripple=.001)
    # Welt seams describe tailoring; keep fine stitches for texture, not hundreds of meshes.
    for side in [-1,1]:
        pts=[]
        for z,rx,ry,opening in vest_profiles:
            pts.append((side*sin(opening)*rx,-cos(opening)*ry-.003,z))
        tube('rolled waistcoat front edge '+str(side),pts,.004,'leather')
        hem=[]
        z,rx,ry,_=vest_profiles[0]
        for j in range(17):
            angle=side*(.03+(pi-.03)*j/16)
            hem.append((sin(angle)*rx,.012-cos(angle)*ry,z+.008))
        tube('waistcoat lower seam '+str(side),hem,.003,'leather')
        # A proper small pocket, held close to the body, with a distinct flap and welt.
        px=side*(waist_rx*.62);pz=waist_z+.105
        front_y=.012-(waist_ry+.052)*math.sqrt(max(.1,1-(px/(waist_rx+.06))**2))
        rounded_box('waistcoat pocket '+str(side),(px,front_y-.010,pz),(.070,.012,.048),'leather',bevel=.005)
        ribbon('pocket welt '+str(side),[(px-.068,front_y-.026,pz+.040),(px+.068,front_y-.026,pz+.040)],.012,'leather')
    # Three little closure buttons. They sit ON the overlapping leather edge.
    for i,z in enumerate([waist_z+.065,waist_z+.145,waist_z+.225]):
        button_y=-(waist_ry+.056)
        verts=[];faces=[];sides=14
        radius=.014 if i!=1 else .019
        for k in [-1,1]:
            for j in range(sides):
                a=j*2*pi/sides;verts.append((.012+cos(a)*radius,button_y+k*.004,z+sin(a)*radius))
        for j in range(sides):faces.append((j,(j+1)%sides,sides+(j+1)%sides,sides+j))
        faces.append(tuple(range(sides-1,-1,-1)));faces.append(tuple(range(sides,sides*2)))
        finish('antique bronze closure '+str(i+1),verts,faces,'bronze')
        # Two dark stitch holes make the large middle button readable without a jewel look.
        if i==1:
            for dx in [-.005,.005]:
                rounded_box('button stitch hole',(.012+dx,button_y-.0046,z),(.0017,.001,.0034),'leather',bevel=0)

    # Short asymmetrical shoulder cape: matte teal distinct from both shirt and vest.
    vertices=[];faces=[];count=32
    cape_rings=[(shoulder_z+.055,.315,.235),(shoulder_z+.015,.360,.255),(shoulder_z-.085,.365,.265),(waist_z+.020,.380,.285),(waist_z-.045,.395,.292)]
    for k,(z,rx,ry) in enumerate(cape_rings):
        for j in range(count+1):
            a=1.25+(2*pi-1.25-.60)*j/count
            fold=.007*sin(a*6+.5)*k/(len(cape_rings)-1)
            zz=z-(.012*sin(a*5+.6) if k==len(cape_rings)-1 else 0)
            vertices.append((sin(a)*(rx+fold),.038-cos(a)*(ry+fold),zz))
    for k in range(len(cape_rings)-1):
        for j in range(count):
            a=k*(count+1)+j;faces.append((a,a+1,a+count+2,a+count+1))
    finish('muted teal shoulder cape',vertices,faces,'cape','Spine2',thickness=.006)
    for edge in [0,count]:
        tube('cape bound front edge '+str(edge),[vertices[k*(count+1)+edge] for k in range(len(cape_rings))],.0045,'cape')
    tube('cape sewn lower hem',vertices[-(count+1):],.0035,'cape')

    # Messenger bag: a real body, separate flap, one buckle, and a continuous cross-body strap.
    bag_material='bag'
    bag_x=-waist_rx-.115;bag_y=.090;bag_z=waist_z-.075
    rounded_box('messenger satchel body',(bag_x,bag_y,bag_z),(.115,.065,.140),bag_material,'Hips',bevel=.022)
    # Folded flap follows the rounded bag top to the front, rather than a floating sphere.
    flap=[(bag_x-.119,bag_y+.040,bag_z+.140),(bag_x+.119,bag_y+.040,bag_z+.140),(bag_x-.122,bag_y-.064,bag_z+.100),(bag_x+.122,bag_y-.064,bag_z+.100),(bag_x-.106,bag_y-.078,bag_z-.006),(bag_x+.106,bag_y-.078,bag_z-.006)]
    finish('satchel folded front flap',flap,[(0,1,3,2),(2,3,5,4)],bag_material,'Hips',thickness=.008)
    strap_points=[(.205,.172,shoulder_z+.025),(.165,-.105,shoulder_z+.030),(.115,-.245,shoulder_z-.075),(.012,-.274,chest_z-.015),(-.115,-.263,waist_z+.100),(bag_x+.075,-.160,bag_z+.130),(bag_x+.055,bag_y-.075,bag_z+.060)]
    ribbon('cross body leather carrying strap',strap_points,.036,bag_material,'AUTO',thickness=.006)
    # One front closure tongue and a low-key brass rectangular buckle.
    rounded_box('satchel closure tongue',(bag_x,bag_y-.084,bag_z-.005),(.025,.006,.068),bag_material,'Hips',bevel=.004)
    for xoff in [-.030,.030]:rounded_box('satchel buckle upright',(bag_x+xoff,bag_y-.094,bag_z+.004),(.004,.004,.032),'bronze','Hips',bevel=.002)
    for zoff in [-.032,.032]:rounded_box('satchel buckle crossbar',(bag_x,bag_y-.094,bag_z+.004+zoff),(.030,.004,.004),'bronze','Hips',bevel=.002)
    rounded_box('satchel buckle tongue',(bag_x,bag_y-.100,bag_z+.005),(.003,.003,.027),'bronze','Hips',bevel=.001)

    # One genuinely bifurcated breeches surface, open at waist and both cuffs.
    # Shared crotch vertices give a continuous tailored Y junction without intersecting shells.
    vertices=[];faces=[];n=32
    pants_waist=waist_z+.015;upper_z=hip_z-.020
    hip_rx=waist_rx+.085;hip_ry=waist_ry+.055
    for z,rx,ry in [(pants_waist,waist_rx+.047,waist_ry+.038),(upper_z,hip_rx,hip_ry)]:
        for j in range(n):
            a=j*2*pi/n;vertices.append((sin(a)*rx,.030-cos(a)*ry,z))
    for j in range(n):faces.append((j,(j+1)%n,n+(j+1)%n,n+j))
    crotch_z=hip_z-.190
    back=len(vertices);vertices.append((0,.145,crotch_z+.018))
    mid=len(vertices);vertices.append((0,.035,crotch_z))
    front=len(vertices);vertices.append((0,-.085,crotch_z+.018))
    right=[n+j for j in range(17)]+[back,mid,front]
    left=[n+j for j in range(16,32)]+[n]+[front,mid,back]
    for side,label,upper in [(1,'Right',right),(-1,'Left',left)]:
        previous=upper
        # Cuffs are above the frog knee, leaving long visible shins and natural feet.
        knee=head(label+'Leg',(side*.25,.07,.36))
        cuff_z=knee.z+.105
        for k,t in enumerate([.52,1.]):
            ring=[]
            for j in range(20):
                if j<=16:a=j*pi/16
                else:a=pi+(j-16)*pi/4
                if side<0:a+=pi
                cuff=Vector((side*.195+sin(a)*.137,.055-cos(a)*.170,cuff_z))
                position=Vector(vertices[upper[j]]).lerp(cuff,t)
                ring.append(len(vertices));vertices.append(position)
            for j in range(20):faces.append((previous[j],previous[(j+1)%20],ring[(j+1)%20],ring[j]))
            previous=ring
        cuff_points=[vertices[i] for i in previous]+[vertices[previous[0]]]
        tube(label+' breeches turned cuff',cuff_points,.011,'trousers',label+'UpLeg',sides=8)
    pants_role='trousers'
    finish('tailored cropped breeches',vertices,[tuple(reversed(f)) for f in faces],pants_role,'AUTO',thickness=.005)
    # One dark waistband, separate from the linen hem.
    loft('breeches waistband',[(pants_waist-.025,waist_rx+.053,waist_ry+.043),(pants_waist+.012,waist_rx+.053,waist_ry+.043)],pants_role,'Hips',count=36,thickness=.006)

    # UVs are an actual part of the source/export contract for baked material maps.
    for obj in objects:
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True);bpy.context.view_layer.objects.active=obj
        if obj.data.polygons:
            bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.uv.smart_project(angle_limit=1.1519,island_margin=.018)
            bpy.ops.object.mode_set(mode='OBJECT')
            uv=obj.data.uv_layers.active
            uv.name='UVMap'
            # Two material atlases: shirt/trousers share matte weave; vest/bag share leather.
            if obj['surface_role'] in ['linen','trousers','leather','bag']:
                right=obj['clothing_role'] in ['bag','trousers']
                start=.52 if right else .02
                for item in uv.data:item.uv.x=start+item.uv.x*.46
        obj.select_set(False)
    return objects
