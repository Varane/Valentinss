# Compatibility entry point for the production art build.
from pathlib import Path
exec(compile(Path(__file__).with_name('build_kvak_v2.py').read_text(),str(Path(__file__).with_name('build_kvak_v2.py')),'exec'))
