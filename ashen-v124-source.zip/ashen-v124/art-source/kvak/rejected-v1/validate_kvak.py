"""Validate exported Kvak GLBs without Blender or external Python packages."""
import json, struct, math, hashlib, gzip
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
m=json.loads((ROOT/'dist/art-assets/kvak/manifest.json').read_text())
for lod in m['lods']:
 p=ROOT/lod['sourceArtifact'];raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==lod['sha256']
 magic,version,length=struct.unpack_from('<III',raw);assert magic==0x46546c67 and version==2 and length==len(raw)
 jl,jt=struct.unpack_from('<II',raw,12);assert jt==0x4e4f534a;doc=json.loads(raw[20:20+jl]);bl,bt=struct.unpack_from('<II',raw,20+jl);assert bt==0x004e4942;binary=raw[28+jl:28+jl+bl]
 sizes={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16};formats={5120:'b',5121:'B',5122:'h',5123:'H',5125:'I',5126:'f'}
 def values(index):
  a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];fmt='<'+formats[a['componentType']]*sizes[a['type']];size=struct.calcsize(fmt);start=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size)
  return[struct.unpack_from(fmt,binary,start+i*stride)for i in range(a['count'])]
 names={n.get('name')for n in doc['nodes']};assert set(m['skeleton'])<=names;assert set(m['sockets'])<=names
 assert {a['name']for a in doc['animations']}==set(m['animations']);assert len(doc['materials'])==3
 joints=len(doc['skins'][0]['joints']);triangles=0;morph_names=set()
 for mesh in doc['meshes']:
  morph_names.update(mesh.get('extras',{}).get('targetNames',[]))
  for prim in mesh['primitives']:
   attrs=prim['attributes'];positions=values(attrs['POSITION']);assert positions and all(math.isfinite(n)for p in positions for n in p)
   indices=values(prim['indices']);assert all(0<=v[0]<len(positions)for v in indices);triangles+=len(indices)//3
   assert all(all(0<=j<joints for j in js)for js in values(attrs['JOINTS_0']))
   assert all(abs(sum(ws)-1)<.002 for ws in values(attrs['WEIGHTS_0']))
 assert triangles>0
 if lod['lod']==0:assert set(m['morphs'])<=morph_names;assert len(gzip.compress(raw))<680000;assert triangles<35000
 else:assert not morph_names
 assert all(not im.get('uri','').startswith(('http:','https:'))for im in doc.get('images',[]))
 print(f"LOD{lod['lod']}: {triangles} triangles, {len(raw)} bytes, {len(gzip.compress(raw))} gzip; finite geometry, skeleton, weights, clips, morphs and SHA256 verified")
