"""Original ASHEN Kvak v1. Blender 4.3.2, meters, -Y forward -> glTF +Z.
Rebuild: blender -b --python art-source/kvak/build_kvak.py
No downloaded mesh, texture, rig or animation is used.
"""
import bpy, math, os, json, hashlib
from mathutils import Vector
from math import sin,cos,pi
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'../..')); OUT=os.path.join(ROOT,'dist/art-assets/kvak'); SRC=os.path.dirname(__file__);LOD_OUT=os.path.join(SRC,'exports');os.makedirs(LOD_OUT,exist_ok=True)
os.makedirs(OUT,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for data in list(bpy.data.materials):bpy.data.materials.remove(data)

def mat(name,color,rough=.6):
 m=bpy.data.materials.new(name);m.diffuse_color=(*color,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough;return m
skin=mat('Kvak | olive skin',(0.25,.34,.17),.52);cloth=mat('Kvak | linen and leather',(1,1,1),.8);eyesmat=mat('Kvak | eyes',(1,1,1),.2)
for m in [skin,cloth,eyesmat]:
 n=m.node_tree.nodes.new('ShaderNodeVertexColor');n.layer_name='Col';m.node_tree.links.new(n.outputs['Color'],m.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])
# One small reusable pore normal map; generated, never external.
import numpy as np
s=256; yy,xx=np.mgrid[0:s,0:s]; height=.36*np.sin(xx*1.37+np.sin(yy*.31))+.22*np.cos(yy*1.83+xx*.43)+.1*np.sin(xx*.37+yy*.61)
gx=np.gradient(height,axis=1)*.06;gy=np.gradient(height,axis=0)*.06; normal=np.stack([-gx,-gy,np.ones_like(gx)],axis=-1);normal/=np.linalg.norm(normal,axis=-1,keepdims=True);rgba=np.ones((s,s,4));rgba[:,:,:3]=normal*.5+.5
im=bpy.data.images.new('Kvak original pore normal',width=s,height=s);im.pixels=rgba.astype('float32').reshape(-1);im.colorspace_settings.name='Non-Color';im.filepath_raw=os.path.join(OUT,'kvak-pore-normal.png');im.file_format='PNG';im.save();im.pack()
tex=skin.node_tree.nodes.new('ShaderNodeTexImage');tex.image=im;normalnode=skin.node_tree.nodes.new('ShaderNodeNormalMap');normalnode.inputs['Strength'].default_value=0;skin.node_tree.links.new(tex.outputs['Color'],normalnode.inputs['Color']);skin.node_tree.links.new(normalnode.outputs['Normal'],skin.node_tree.nodes.get('Principled BSDF').inputs['Normal'])

def smooth(o):
 for p in o.data.polygons:p.use_smooth=True
 return o

def ball(name,loc,scale,material=None,segments=20,rings=12):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=rings,location=loc);o=bpy.context.object;o.name=name;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);smooth(o)
 if material:o.data.materials.append(material)
 return o
parts=[]
def volume(name,loc,scale):
 o=ball(name,loc,scale);parts.append(o);return o
volume('body',(0,.015,.78),(.33,.25,.45));volume('neck',(0,-.015,1.11),(.31,.24,.25));volume('head',(0,-.04,1.35),(.47,.31,.25));volume('jaw',(0,-.13,1.23),(.37,.29,.13))
for side in [-1,1]:
 volume('cheek',(side*.32,-.12,1.3),(.22,.27,.18));volume('orbital brow',(side*.295,-.10,1.54),(.205,.22,.19))
 volume('shoulder',(side*.35,.015,1.04),(.16,.17,.19));volume('upper arm',(side*.46,-.01,.90),(.105,.13,.25));volume('elbow',(side*.49,-.07,.76),(.10,.12,.115));volume('forearm',(side*.50,-.10,.66),(.092,.115,.20));volume('palm',(side*.51,-.14,.50),(.11,.14,.075))
 for i in range(3):
  x=side*(.51+(i-1)*.075);y=-.24-(.05 if i==1 else 0)
  volume('finger',(x,y,.485),(.029,.12,.026));volume('finger pad',(x,y-.085,.485),(.039,.039,.027))
 volume('thumb',(side*.40,-.17,.51),(.065,.04,.034));volume('hip',(side*.24,.07,.42),(.21,.22,.24));volume('shin',(side*.30,.015,.25),(.10,.11,.20));volume('ankle',(side*.30,-.04,.12),(.10,.14,.10));volume('webbed foot',(side*.30,-.20,.075),(.18,.26,.065))
 for i in range(3):volume('toe pad',(side*.30+(i-1)*.13,-.36-(.05 if i==1 else 0),.065),(.07,.10,.042))
# Truly continuous anatomical surface, including hands and feet. Not a hierarchy of spheres.
bpy.ops.object.select_all(action='DESELECT')
for o in parts:o.select_set(True)
bpy.context.view_layer.objects.active=parts[0];bpy.ops.object.join();body=bpy.context.object;body.name='KvakSkin';bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
rem=body.modifiers.new('continuous anatomical surface','REMESH');rem.mode='VOXEL';rem.voxel_size=.031;rem.use_smooth_shade=True;bpy.ops.object.modifier_apply(modifier=rem.name)
sm=body.modifiers.new('skin relaxation','SMOOTH');sm.factor=.65;sm.iterations=4;bpy.ops.object.modifier_apply(modifier=sm.name)
# Jaw crease: actual recessed mouth, with dark oral membrane behind the lips.
cutter=ball('mouth cut',(0,-.345,1.265),(.28,.11,.021),segments=32,rings=10)
bpy.context.view_layer.objects.active=body;bo=body.modifiers.new('sculpted lip opening','BOOLEAN');bo.operation='DIFFERENCE';bo.object=cutter;bpy.ops.object.modifier_apply(modifier=bo.name);bpy.data.objects.remove(cutter,do_unlink=True)
for v in body.data.vertices:
 x,y,z=v.co;mask=max(0,1-abs(z-1.27)/.09)*max(0,min(1,(-y-.22)*8));v.co.z+=.038*(min(1,abs(x)/.28)**1.4)*mask
body.data.materials.append(skin);smooth(body)
# UVs are present for the skin normal map. Material color is authored by anatomical masks.
bpy.context.view_layer.objects.active=body;body.select_set(True);bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=1.1519,island_margin=.015);bpy.ops.object.mode_set(mode='OBJECT')

def colors(o,color=None):
 attr=o.data.color_attributes.new(name='Col',type='FLOAT_COLOR',domain='POINT')
 for v in o.data.vertices:
  x,y,z=v.co
  if color:c=color
  else:
   belly=max(0,min(1,(-y-.02)*5))*max(0,1-abs(z-.80)/.55)
   throat=max(0,min(1,(-y-.12)*6))*max(0,1-abs(z-1.18)/.17)
   pale=max(belly,throat)*.72
   pore=.025*sin(x*91+z*67)*sin(y*79-z*43)+.035*sin(x*17+z*19)*sin(y*27)
   c=(.24+pale*.36+pore,.34+pale*.26+pore,.17+pale*.18+pore*.6)
  attr.data[v.index].color=(*c,1)
colors(body)
meshes=[body]
def colored(name,loc,scale,color,material=eyesmat):
 o=ball(name,loc,scale,material,20,12);colors(o,color);meshes.append(o);return o
# Sclera is warm, wet, anatomically inset. Horizontal pupils remain a frog's pupils.
for side in [-1,1]:
 colored('Eye.'+('L'if side<0 else'R'),(side*.295,-.263,1.545),(.145,.105,.14),(.48,.45,.25))
 colored('Iris.'+('L'if side<0 else'R'),(side*.295,-.351,1.55),(.102,.023,.103),(.34,.23,.055))
 colored('Pupil.'+('L'if side<0 else'R'),(side*.295,-.371,1.55),(.087,.012,.031),(.018,.032,.025))
 colored('Nostril',(side*.105,-.345,1.355),(.018,.009,.011),(.06,.09,.042),skin)
oral=colored('Mouth lining',(0,-.300,1.262),(.269,.019,.022),(.055,.067,.042),skin)
for v in oral.data.vertices:v.co.z+=.038*(min(1,abs(v.co.x)/.28)**1.4)
for side in [-1,1]:
 curve=bpy.data.curves.new('Upper eyelid sculpt','CURVE');curve.dimensions='3D';curve.bevel_depth=.021;curve.bevel_resolution=3;sp=curve.splines.new('POLY');sp.points.add(20)
 for j,p in enumerate(sp.points):
  a=pi*j/20;p.co=(side*.295+cos(a)*.143,-.309,1.545+sin(a)*.135,1)
 ob=bpy.data.objects.new('Upper lid.'+('L'if side<0 else'R'),curve);bpy.context.collection.objects.link(ob);bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.convert(target='MESH');ob=bpy.context.object;ob.data.materials.append(skin);colors(ob,(.24,.34,.17));meshes.append(ob)
# Real thin-walled vest panels: open neckline, front split and edge piping.
def vest_mesh():
 verts=[];faces=[];rings=[(.58,.31,.23),(.70,.35,.265),(.90,.34,.26),(1.08,.30,.235)];n=40
 for z,rx,ry in rings:
  for j in range(n+1):
   a=.32+(2*pi-.64)*j/n;verts.append((sin(a)*rx,-cos(a)*ry,z))
 for k in range(len(rings)-1):
  for j in range(n):
   a=k*(n+1)+j;faces.append((a,a+1,a+n+2,a+n+1))
 mesh=bpy.data.meshes.new('Tailored vest panel mesh');mesh.from_pydata(verts,[],faces);mesh.update();o=bpy.data.objects.new('Courier leather vest',mesh);bpy.context.collection.objects.link(o);o.data.materials.append(cloth);colors(o,(.18,.125,.075));smooth(o);bpy.context.view_layer.objects.active=o
 so=o.modifiers.new('leather thickness','SOLIDIFY');so.thickness=.012;bpy.ops.object.modifier_apply(modifier=so.name);be=o.modifiers.new('rounded stitched edges','BEVEL');be.width=.008;be.segments=2;bpy.ops.object.modifier_apply(modifier=be.name);meshes.append(o);return o
vest=vest_mesh()
# Scarf and practical soft satchel. Small bronze fastening, restrained palette.
colored('Linen neckerchief',(0,.015,1.115),(.325,.255,.042),(.43,.35,.25),cloth)
colored('Satchel',(-.34,.16,.64),(.14,.10,.19),(.16,.105,.06),cloth)
colored('Satchel flap',(-.34,.247,.71),(.14,.025,.11),(.20,.135,.075),cloth)
colored('Bronze fastening',(.10,-.291,.87),(.025,.009,.035),(.53,.38,.16),eyesmat)
# Add stitched front edging as actual narrow geometry, skin-safe.
for side in [-1,1]:
 curve=bpy.data.curves.new('Vest seam','CURVE');curve.dimensions='3D';curve.bevel_depth=.004;curve.bevel_resolution=2;sp=curve.splines.new('POLY');sp.points.add(3)
 for p,(z,rx,ry) in zip(sp.points,[(.59,.31,.23),(.70,.35,.265),(.90,.34,.26),(1.07,.30,.235)]):p.co=(side*sin(.32)*rx,-cos(.32)*ry-.01,z,1)
 ob=bpy.data.objects.new('Vest rolled edge',curve);bpy.context.collection.objects.link(ob);bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.context.view_layer.objects.active=ob;bpy.ops.object.convert(target='MESH');ob=bpy.context.object;ob.data.materials.append(cloth);colors(ob,(.42,.31,.18));meshes.append(ob)
# Muted short travelling cape, with an open front and an irregular sewn hem.
verts=[];faces=[];n=40
for k,(z,rx,ry) in enumerate([(1.13,.35,.27),(.98,.43,.30),(.63,.42,.30)]):
 for j in range(n+1):
  a=.85+(2*pi-1.7)*j/n;zz=z-(.02*sin(j*2.1) if k==2 else 0);verts.append((sin(a)*rx,-cos(a)*ry+.02,zz))
for k in range(2):
 for j in range(n):
  a=k*(n+1)+j;faces.append((a,a+1,a+n+2,a+n+1))
me=bpy.data.meshes.new('Short cape tailored panels');me.from_pydata(verts,[],faces);me.update();cape=bpy.data.objects.new('Kvak muted teal travelling cape',me);bpy.context.collection.objects.link(cape);cape.data.materials.append(cloth);colors(cape,(.14,.25,.245));smooth(cape);bpy.context.view_layer.objects.active=cape;so=cape.modifiers.new('Cape thickness','SOLIDIFY');so.thickness=.009;bpy.ops.object.modifier_apply(modifier=so.name);meshes.append(cape)
# One continuous trouser surface with genuinely cut waist/cuffs, avoiding intersecting primitive caps.
pp=[ball('Pants waist',(0,.025,.54),(.425,.31,.18))]
for side in [-1,1]:pp.append(ball('Pants leg',(side*.24,.055,.405),(.232,.245,.24)))
bpy.ops.object.select_all(action='DESELECT')
for o in pp:o.select_set(True)
bpy.context.view_layer.objects.active=pp[0];bpy.ops.object.join();pants=bpy.context.object;pants.name='Charcoal breeches';bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
mod=pants.modifiers.new('Tailored continuous trousers','REMESH');mod.mode='VOXEL';mod.voxel_size=.035;mod.use_smooth_shade=True;bpy.ops.object.modifier_apply(modifier=mod.name);sm=pants.modifiers.new('Soft fabric silhouette','SMOOTH');sm.factor=.6;sm.iterations=3;bpy.ops.object.modifier_apply(modifier=sm.name)
import bmesh
bm=bmesh.new();bm.from_mesh(pants.data)
for z,normal in [(.285,(0,0,1)),(.625,(0,0,-1))]:bmesh.ops.bisect_plane(bm,geom=list(bm.verts)+list(bm.edges)+list(bm.faces),plane_co=(0,0,z),plane_no=normal,clear_inner=True,clear_outer=False)
bm.to_mesh(pants.data);bm.free();pants.data.materials.append(cloth);colors(pants,(.12,.13,.115));smooth(pants);meshes.append(pants)
# Basic expressive facial morphs on the continuous skin, not swapped mouth meshes.
bpy.context.view_layer.objects.active=body;body.shape_key_add(name='Basis')
for name in ['Smile','Frown','Surprise','BlinkLeft','BlinkRight']:
 key=body.shape_key_add(name=name)
 for v in key.data:
  x,y,z=v.co
  if name in ['Smile','Frown']:
   mask=max(0,1-abs(z-1.27)/.08)*max(0,min(1,(-y-.22)*8));v.co.z+=(1 if name=='Smile' else-1)*.035*(abs(x)/.28)**1.3*mask
  elif name=='Surprise':
   mask=max(0,1-abs(z-1.27)/.07)*max(0,min(1,(-y-.23)*8));v.co.z+=(z-1.27)*mask*.55
  else:
   side=-1 if name=='BlinkLeft' else 1;mask=max(0,1-abs(x-side*.295)/.19)*max(0,1-abs(z-1.60)/.18)*max(0,min(1,(-y-.17)*12));v.co.z-=mask*.08
# Rig in meters, rest pose same as mesh. Named logical sockets are exported as empties.
armdata=bpy.data.armatures.new('KvakRig');rig=bpy.data.objects.new('KvakRig',armdata);bpy.context.collection.objects.link(rig);bpy.context.view_layer.objects.active=rig;rig.select_set(True);bpy.ops.object.mode_set(mode='EDIT')
bone_specs={
 'Hips':((0,0,.38),(0,0,.67),None),'Spine2':((0,0,.67),(0,0,1.04),'Hips'),'Head':((0,0,1.04),(0,-.04,1.52),'Spine2'),
 'LeftArm':((-.35,.015,1.04),(-.49,-.07,.76),'Spine2'),'LeftForeArm':((-.49,-.07,.76),(-.51,-.14,.51),'LeftArm'),'LeftHand':((-.51,-.14,.51),(-.51,-.29,.485),'LeftForeArm'),
 'RightArm':((.35,.015,1.04),(.49,-.07,.76),'Spine2'),'RightForeArm':((.49,-.07,.76),(.51,-.14,.51),'RightArm'),'RightHand':((.51,-.14,.51),(.51,-.29,.485),'RightForeArm'),
 'LeftUpLeg':((-.24,.07,.45),(-.30,.015,.25),'Hips'),'LeftLeg':((-.30,.015,.25),(-.30,-.04,.12),'LeftUpLeg'),'LeftFoot':((-.30,-.04,.12),(-.30,-.36,.065),'LeftLeg'),
 'RightUpLeg':((.24,.07,.45),(.30,.015,.25),'Hips'),'RightLeg':((.30,.015,.25),(.30,-.04,.12),'RightUpLeg'),'RightFoot':((.30,-.04,.12),(.30,-.36,.065),'RightLeg')}
def height(z):return z*1.12 if z<=1.1 else 1.232+(z-1.1)*.88
for name,(head,tail,parent) in list(bone_specs.items()):bone_specs[name]=((head[0],head[1],height(head[2])),(tail[0],tail[1],height(tail[2])),parent)
for name,(head,tail,parent) in bone_specs.items():
 b=armdata.edit_bones.new(name);b.head=head;b.tail=tail
 if parent:b.parent=armdata.edit_bones[parent]
bpy.ops.object.mode_set(mode='OBJECT')
def segment_distance(p,a,b):
 d=b-a;t=max(0,min(1,(p-a).dot(d)/d.length_squared));return(p-(a+d*t)).length
for ob in meshes:
 bpy.context.view_layer.objects.active=ob;bpy.ops.object.select_all(action='DESELECT');ob.select_set(True);bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
 for v in ob.data.vertices:v.co.z=height(v.co.z)
 if ob.data.shape_keys:
  for key in ob.data.shape_keys.key_blocks:
   for v in key.data:v.co.z=height(v.co.z)
 groups={name:ob.vertex_groups.new(name=name)for name in bone_specs}
 for v in ob.data.vertices:
  p=v.co;x,y,z=p;z=z/1.12 if z<=1.232 else 1.1+(z-1.232)/.88
  if ob!=body:
   if 'sleeve' in ob.name:candidates=[('Left'if x<0 else'Right')+'Arm']
   elif 'breeches' in ob.name:candidates=[('Left'if x<0 else'Right')+'UpLeg','Hips']
   else:candidates=['Head'] if z>1.20 else['Spine2','Hips']
  elif z>1.13:candidates=['Head','Spine2'] if z<1.21 else['Head']
  elif abs(x)>.36 and z>.44:candidates=[('Left'if x<0 else'Right')+n for n in ['Arm','ForeArm','Hand']]
  elif z<.50:candidates=[('Left'if x<0 else'Right')+n for n in ['UpLeg','Leg','Foot']]+(['Hips']if z>.35 else[])
  else:candidates=['Hips','Spine2']
  distances=sorted([(segment_distance(p,Vector(bone_specs[n][0]),Vector(bone_specs[n][1])),n)for n in candidates])[:2];weights=[1/max(.015,d)**4 for d,n in distances];total=sum(weights)
  for w,(d,n) in zip(weights,distances):groups[n].add([v.index],w/total,'REPLACE')
 mod=ob.modifiers.new('Kvak skin binding','ARMATURE');mod.object=rig;ob.parent=rig
for name,bone,offset in [('socket.head','Head',(0,0,.08)),('socket.hair','Head',(0,0,.10)),('socket.hand.R','RightHand',(0,0,0)),('socket.hand.L','LeftHand',(0,0,0)),('socket.outfit','Spine2',(0,0,0))]:
 e=bpy.data.objects.new(name,None);bpy.context.collection.objects.link(e);e.parent=rig;e.parent_type='BONE';e.parent_bone=bone;e.location=offset;e.empty_display_size=.05
# Frame-based animations. In-place walk: actor controller owns world movement.
bpy.context.scene.render.fps=30
for name,length in [('idle',60),('walk',30),('turn',24),('wave',48)]:
 rig.animation_data_create();action=bpy.data.actions.new(name);rig.animation_data.action=action
 for frame in range(1,length+1,3):
  phase=(frame-1)/length*2*pi
  for pb in rig.pose.bones:pb.rotation_mode='XYZ';pb.rotation_euler=(0,0,0);pb.location=(0,0,0)
  rig.pose.bones['Spine2'].rotation_euler[0]=.025*sin(phase)
  if name=='walk':
   for side,sign in [('Left',1),('Right',-1)]:
    rig.pose.bones[side+'UpLeg'].rotation_euler[0]=sin(phase)*.32*sign;rig.pose.bones[side+'Leg'].rotation_euler[0]=max(0,-sin(phase)*sign)*.40;rig.pose.bones[side+'Arm'].rotation_euler[0]=-sin(phase)*.25*sign
   rig.pose.bones['Hips'].location.z=abs(sin(phase))*.015
  if name=='turn':rig.pose.bones['Head'].rotation_euler[1]=sin(phase)*.35;rig.pose.bones['Spine2'].rotation_euler[1]=sin(phase)*.12
  if name=='wave':
   envelope=sin(pi*(frame-1)/length)**.5;rig.pose.bones['LeftArm'].rotation_euler[1]=-.22*envelope;rig.pose.bones['LeftArm'].rotation_euler[2]=-1.95*envelope;rig.pose.bones['LeftForeArm'].rotation_euler[0]=.35*envelope;rig.pose.bones['LeftHand'].rotation_euler[1]=sin(phase*3)*.25*envelope
  for pb in rig.pose.bones:
   pb.keyframe_insert('rotation_euler',frame=frame,group=pb.name);pb.keyframe_insert('location',frame=frame,group=pb.name)
 track=rig.animation_data.nla_tracks.new();track.name=name;track.strips.new(name,1,action)
rig.animation_data.action=None
for pb in rig.pose.bones:pb.rotation_euler=(0,0,0);pb.location=(0,0,0)
bpy.context.scene.frame_set(1)
# Studio is source-only and excluded from GLB selection.
scene=bpy.context.scene;scene.world.color=(.12,.13,.11);scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.render.resolution_x=960;scene.render.resolution_y=960;scene.render.resolution_percentage=100
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.005));ground=bpy.context.object;ground.name='SOURCE_ONLY floor';ground.data.materials.append(mat('Studio floor',(.12,.145,.14),.9))
def area(name,loc,power,size):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;o.rotation_euler=(Vector((0,0,.8))-o.location).to_track_quat('-Z','Y').to_euler()
area('SOURCE_ONLY key',(-3,-4,5),500,4);area('SOURCE_ONLY fill',(3,-1,3),180,3);area('SOURCE_ONLY rim',(1,3,4),350,3)
bpy.ops.object.camera_add(location=(2.7,-4.4,2.2));cam=bpy.context.object;cam.name='SOURCE_ONLY portrait camera';cam.rotation_euler=(Vector((0,0,.85))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=2.10;scene.camera=cam;scene.view_settings.view_transform='AgX'
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(SRC,'kvak.blend'))
# Export LODs from the same artist source; skin morphs retained at LOD0.
exports=[]
for lod,ratio in [(0,1),(1,.40),(2,.12)]:
 clones=[]
 if lod==0:objects=meshes
 else:
  for src in meshes:
   ob=src.copy();ob.data=src.data.copy();bpy.context.collection.objects.link(ob);clones.append(ob)
   if ob.data.shape_keys:
    bpy.context.view_layer.objects.active=ob;ob.shape_key_clear()
   bpy.context.view_layer.objects.active=ob;d=ob.modifiers.new('LOD simplification','DECIMATE');d.ratio=ratio;bpy.ops.object.modifier_apply(modifier=d.name)
  objects=clones
 bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
 for ob in objects:ob.select_set(True)
 for ob in bpy.data.objects:
  if ob.name.startswith('socket.'):ob.select_set(True)
 path=os.path.join(OUT if lod==0 else LOD_OUT,f'kvak-lod{lod}.glb');bpy.ops.export_scene.gltf(filepath=path,export_format='GLB',use_selection=True,export_animations=True,export_nla_strips=True,export_materials='EXPORT',export_yup=True,export_apply=False,export_texcoords=True,export_normals=True,export_skins=True,export_morph=True,export_morph_normal=False)
 tris=sum(sum(len(p.vertices)-2 for p in ob.data.polygons)for ob in objects);exports.append({'lod':lod,'file':os.path.basename(path),'runtime':lod==0,'url':'/art-assets/kvak/'+os.path.basename(path) if lod==0 else None,'sourceArtifact':os.path.relpath(path,ROOT),'triangles':tris,'bytes':os.path.getsize(path),'gzipBytes':len(__import__('gzip').compress(open(path,'rb').read())),'sha256':hashlib.sha256(open(path,'rb').read()).hexdigest()})
 for ob in clones:bpy.data.objects.remove(ob,do_unlink=True)
# Source render is an offline asset review, never claimed to be a game screenshot.
scene.render.filepath=os.path.join(SRC,'kvak-source-preview.png');bpy.ops.render.render(write_still=True)
manifest={'id':'kvak-original-v1','source':'art-source/kvak/kvak.blend','build':'art-source/kvak/build_kvak.py','license':'Original project asset; no third-party geometry or textures','authorship':'ASHEN original asset authored with Blender Python in this repository','blender':bpy.app.version_string,'unitScale':1,'forwardAxis':'+Z','heightMeters':1.81,'runtimeGLB':'/art-assets/kvak/kvak-lod0.glb','materials':3,'skeleton':list(bone_specs),'sockets':['socket.head','socket.hair','socket.hand.R','socket.hand.L','socket.outfit'],'animations':['idle','walk','turn','wave'],'morphs':['Smile','Frown','Surprise','BlinkLeft','BlinkRight'],'lods':exports,'notes':['Continuous voxel-remeshed skin, not detached sphere joints.','LOD1/2 retain skinning, but facial morphs intentionally omitted.','Runtime adapter and actual game/phone visual verification still required.']}
manifest['blenderSockets']={o.name:list(o.matrix_world.translation)for o in bpy.data.objects if o.name.startswith('socket.')};manifest['sourceBounds']={'min':[min((o.matrix_world@v.co)[axis]for o in meshes for v in o.data.vertices)for axis in range(3)],'max':[max((o.matrix_world@v.co)[axis]for o in meshes for v in o.data.vertices)for axis in range(3)]};open(os.path.join(OUT,'manifest.json'),'w').write(json.dumps(manifest,ensure_ascii=False,indent=2));print('KVAK_EXPORT',json.dumps(exports))
