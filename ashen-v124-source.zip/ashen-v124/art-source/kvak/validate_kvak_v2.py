"""Structural glTF acceptance checks. Does NOT stand in for visual/device review."""
import json,struct,math,hashlib,gzip
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
m=json.loads((ROOT/'dist/art-assets/kvak/manifest.json').read_text())
def identity():return[[float(i==j)for j in range(4)]for i in range(4)]
def multiply(a,b):return[[sum(a[i][k]*b[k][j]for k in range(4))for j in range(4)]for i in range(4)]
def compose(node):
 if'matrix'in node:return[[node['matrix'][j*4+i]for j in range(4)]for i in range(4)]
 x,y,z,w=node.get('rotation',[0,0,0,1]);r=[[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w),0],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w),0],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y),0],[0,0,0,1]]
 scale=node.get('scale',[1,1,1]);t=node.get('translation',[0,0,0])
 for i in range(3):
  for j in range(3):r[i][j]*=scale[j]
  r[i][3]=t[i]
 return r
for lod in m['lods']:
 p=ROOT/lod['sourceArtifact'];raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==lod['sha256'];magic,version,length=struct.unpack_from('<III',raw);assert magic==0x46546c67 and version==2 and length==len(raw)
 jl,jt=struct.unpack_from('<II',raw,12);assert jt==0x4e4f534a;doc=json.loads(raw[20:20+jl]);bl,bt=struct.unpack_from('<II',raw,20+jl);assert bt==0x004e4942;binary=raw[28+jl:28+jl+bl]
 sizes={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16};formats={5120:'b',5121:'B',5122:'h',5123:'H',5125:'I',5126:'f'}
 def values(index):
  a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];fmt='<'+formats[a['componentType']]*sizes[a['type']];size=struct.calcsize(fmt);start=v.get('byteOffset',0)+a.get('byteOffset',0);stride=v.get('byteStride',size)
  return[struct.unpack_from(fmt,binary,start+i*stride)for i in range(a['count'])]
 names={n.get('name')for n in doc['nodes']};assert set(m['skeleton'])<=names;assert set(m['sockets'])<=names;assert {a['name']for a in doc['animations']}==set(m['animations'])
 parent={child:i for i,node in enumerate(doc['nodes'])for child in node.get('children',[])};cache={}
 def world(index):
  if index not in cache:cache[index]=multiply(world(parent[index])if index in parent else identity(),compose(doc['nodes'][index]))
  return cache[index]
 for index,node in enumerate(doc['nodes']):
  if node.get('name')in m['sockets']:
   matrix=world(index);assert all(abs(matrix[i][j]-float(i==j))<.002 for i in range(3)for j in range(3)),(node['name'],'wrong bind orientation',matrix)
 joints=len(doc['skins'][0]['joints']);triangles=0;morph_names=set()
 for mesh in doc['meshes']:
  morph_names.update(mesh.get('extras',{}).get('targetNames',[]))
  for prim in mesh['primitives']:
   a=prim['attributes'];positions=values(a['POSITION']);assert positions and all(math.isfinite(n)for p in positions for n in p);assert 'TEXCOORD_0'in a
   indices=values(prim['indices']);assert all(0<=v[0]<len(positions)for v in indices);triangles+=len(indices)//3
   assert all(all(0<=j<joints for j in js)for js in values(a['JOINTS_0']))
   assert all(abs(sum(ws)-1)<.002 for ws in values(a['WEIGHTS_0']))
 if lod['lod']==0:assert set(m['morphs'])<=morph_names
 else:assert not morph_names
 # Semantic bindings cannot let a waving arm pull a torso strap or bag into spikes.
 for ni,node in enumerate(doc['nodes']):
  if'mesh'not in node or'skin'not in node:continue
  name=node.get('name','');skin=doc['skins'][node['skin']];joint_names=[doc['nodes'][j]['name']for j in skin['joints']]
  rigid_torso=name.startswith(('garment_bag','garment_vest','garment_cape'))or(name.startswith('garment_shirt')and not any(k in name.lower()for k in['sleeve','cuff']))
  for prim in doc['meshes'][node['mesh']]['primitives']:
   attrs=prim['attributes'];js=values(attrs['JOINTS_0']);ws=values(attrs['WEIGHTS_0']);ps=values(attrs['POSITION']);matrix=world(ni)
   for point,inds,weights in zip(ps,js,ws):
    actual={joint_names[j]:w for j,w in zip(inds,weights)if w>1e-5}
    if rigid_torso:assert not any('Arm'in n or'Hand'in n for n in actual),(name,actual)
    if name=='KvakSkin':
     x,y,z=[sum(matrix[i][j]*point[j]for j in range(3))+matrix[i][3]for i in range(3)]
     if abs(x)>.37 and .40<y<.82:assert not any('Leg'in n or'Foot'in n for n in actual),('hand/forearm bound to legs',point,actual)
 assert all(not im.get('uri','').startswith(('http:','https:'))for im in doc.get('images',[]))
 print(f"LOD{lod['lod']}: {triangles} tris, {len(raw)} bytes/{len(gzip.compress(raw))} gzip; SHA/weights/UV/clips/morphs/identity bind sockets PASS")
print('Visual/device acceptance and publication approval remain separate.')
