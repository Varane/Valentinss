"""Original Kvak v2 anatomy. Blender Z-up, -Y forward, metres.
No scene reset, save, export or third-party data. Import build_anatomy(materials).
"""
import bpy, math
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from math import sin, cos, pi, sqrt

LANDMARKS={
 'Hips':((0,.025,.70),(0,.005,.89),None),
 'Spine2':((0,.005,.89),(0,-.005,1.22),'Hips'),
 'Head':((0,-.005,1.22),(0,-.035,1.64),'Spine2'),
 'LeftArm':((-.30,0,1.18),(-.42,-.03,.90),'Spine2'),
 'LeftForeArm':((-.42,-.03,.90),(-.45,-.10,.64),'LeftArm'),
 'LeftHand':((-.45,-.10,.64),(-.45,-.16,.44),'LeftForeArm'),
 'RightArm':((.30,0,1.18),(.42,-.03,.90),'Spine2'),
 'RightForeArm':((.42,-.03,.90),(.45,-.10,.64),'RightArm'),
 'RightHand':((.45,-.10,.64),(.45,-.16,.44),'RightForeArm'),
 'LeftUpLeg':((-.19,.035,.70),(-.255,.005,.36),'Hips'),
 'LeftLeg':((-.255,.005,.36),(-.26,-.02,.11),'LeftUpLeg'),
 'LeftFoot':((-.26,-.02,.11),(-.26,-.39,.045),'LeftLeg'),
 'RightUpLeg':((.19,.035,.70),(.255,.005,.36),'Hips'),
 'RightLeg':((.255,.005,.36),(.26,-.02,.11),'RightUpLeg'),
 'RightFoot':((.26,-.02,.11),(.26,-.39,.045),'RightLeg'),
}

def _object_mode():
 if bpy.context.object and bpy.context.object.mode!='OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
def _smooth(o):
 for p in o.data.polygons:p.use_smooth=True
 return o

def _ball(name,loc,scale,segments=16,rings=10):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=segments,ring_count=rings,location=loc)
 o=bpy.context.object;o.name=name;o.scale=scale
 bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 return _smooth(o)

def _tube(name,points,radius=.012,resolution=2):
 curve=bpy.data.curves.new(name,'CURVE');curve.dimensions='3D';curve.resolution_u=2;curve.bevel_depth=radius;curve.bevel_resolution=resolution
 sp=curve.splines.new('POLY');sp.points.add(len(points)-1)
 for p,co in zip(sp.points,points):p.co=(*co,1)
 o=bpy.data.objects.new(name,curve);bpy.context.collection.objects.link(o)
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
 bpy.ops.object.convert(target='MESH');return _smooth(bpy.context.object)

def _join(objects,name):
 _object_mode();bpy.ops.object.select_all(action='DESELECT')
 for o in objects:o.select_set(True)
 bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join();o=bpy.context.object;o.name=name
 bpy.ops.object.transform_apply(location=True,rotation=True,scale=True)
 return o

def _remesh(objects,name,voxel,target):
 o=_join(objects,name);bpy.context.view_layer.objects.active=o
 mod=o.modifiers.new('Organic continuous surface','REMESH');mod.mode='VOXEL';mod.voxel_size=voxel;mod.use_smooth_shade=True
 bpy.ops.object.modifier_apply(modifier=mod.name)
 mod=o.modifiers.new('Relaxed skin transitions','SMOOTH');mod.factor=.35;mod.iterations=2
 bpy.ops.object.modifier_apply(modifier=mod.name)
 tris=sum(len(p.vertices)-2 for p in o.data.polygons)
 if tris>target:
  mod=o.modifiers.new('Preserve silhouette mobile budget','DECIMATE');mod.ratio=target/tris
  bpy.ops.object.modifier_apply(modifier=mod.name)
 return _smooth(o)

def _web(name,points,thickness=.015,normal=(0,0,1)):
 # A genuine thin closed membrane; concave outline keeps the digit tips free.
 offset=Vector(normal)*thickness*.5
 verts=[tuple(Vector(p)+offset)for p in points]+[tuple(Vector(p)-offset)for p in points]
 n=len(points);faces=[tuple(range(n)),tuple(reversed(range(n,n*2)))]
 faces += [(i,(i+1)%n,(i+1)%n+n,i+n)for i in range(n)]
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();o=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(o);return o

def _digit(parts,name,points,radii):
 # Overlapping tapered segments + restrained round pads expose the real joints.
 for j,(p,r)in enumerate(zip(points,radii)):
  parts.append(_ball(name+' joint '+str(j),p,(r,r*.9,r),12,8))
 for j in range(len(points)-1):
  a,b=Vector(points[j]),Vector(points[j+1]);mid=(a+b)*.5;d=b-a;r=(radii[j]+radii[j+1])*.5
  o=_ball(name+' phalanx '+str(j),mid,(r,r,d.length*.64),12,8)
  o.rotation_euler=d.to_track_quat('Z','Y').to_euler();parts.append(o)


def build_hand(side,skin_material=None):
 parts=[];sx=lambda x:side*x
 parts.append(_ball('Wrist soft transition',(sx(.45),-.10,.642),(.046,.043,.057)))
 parts.append(_ball('Slender frog palm',(sx(.451),-.113,.586),(.067,.040,.076)))
 defs=[
  [(.411,-.115,.593),(.368,-.147,.555),(.338,-.164,.525)],
  [(.425,-.115,.548),(.418,-.150,.477),(.422,-.170,.428)],
  [(.461,-.115,.542),(.477,-.149,.472),(.488,-.163,.432)],
  [(.495,-.11,.558),(.530,-.137,.508),(.551,-.147,.483)],
 ]
 for i,points in enumerate(defs):
  points=[(sx(x),y,z)for x,y,z in points]
  _digit(parts,'Finger '+str(i+1),points,[.020,.016,.019])
 # Only proximal webbing on forefeet; never a solid mitten covering free digits.
 for i in range(3):
  a,b=defs[i],defs[i+1]
  pts=[a[0],a[1],tuple(Vector(a[1])*.45+Vector(b[1])*.55),b[1],b[0]]
  pts=[(sx(x),y,z)for x,y,z in pts]
  parts.append(_web('Fine forefoot web '+str(i),pts,.018,normal=(0,1,0)))
 o=_remesh(parts,'Kvak anatomical hand '+('L'if side<0 else'R'),.008,1050)
 o['bind_region']='LeftHand'if side<0 else'RightHand'
 if skin_material:o.data.materials.append(skin_material)
 return o

def build_foot(side,skin_material=None):
 parts=[];sx=lambda x:side*x
 parts.append(_ball('Heel and ankle',(sx(.26),-.028,.112),(.055,.075,.069)))
 parts.append(_ball('Long metatarsal palm',(sx(.26),-.126,.066),(.098,.133,.040)))
 defs=[]
 for i,(base,tipx,tipy)in enumerate([(-.063,-.165,-.345),(-.030,-.103,-.438),(.008,-.004,-.492),(.047,.105,-.445),(.076,.178,-.338)]):
  pts=[(.26+base,-.174,.061),(.26+(base+tipx)*.50,(-.174+tipy)*.53,.046),(.26+tipx,tipy,.039)]
  defs.append(pts);_digit(parts,'Hind toe '+str(i+1),[(sx(x),y,z)for x,y,z in pts],[.022,.016,.022])
 for i in range(4):
  a,b=defs[i],defs[i+1]
  aa=Vector(a[0]).lerp(Vector(a[-1]),.66);bb=Vector(b[0]).lerp(Vector(b[-1]),.66);saddle=(aa+bb)*.5;saddle.y+=.045;saddle.z=.045
  pts=[a[0],aa,tuple(saddle),bb,b[0]]
  parts.append(_web('Thin hind web '+str(i),[(sx(x),y,z)for x,y,z in pts],.018))
 o=_remesh(parts,'Kvak anatomical foot '+('L'if side<0 else'R'),.008,1150)
 o['bind_region']='LeftFoot'if side<0 else'RightFoot'
 if skin_material:o.data.materials.append(skin_material)
 return o

def build_extremities(materials):
 return [build_hand(-1,materials.get('skin')),build_hand(1,materials.get('skin')),build_foot(-1,materials.get('skin')),build_foot(1,materials.get('skin'))]

def _uv(o):
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
 bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=1.1519,island_margin=.012);bpy.ops.object.mode_set(mode='OBJECT')

def _paint_skin(o):
 attr=o.data.color_attributes.get('Col')or o.data.color_attributes.new(name='Col',type='FLOAT_COLOR',domain='POINT')
 o.data.color_attributes.active_color=attr
 o.data.color_attributes.render_color_index=o.data.color_attributes.find('Col')
 for v in o.data.vertices:
  x,y,z=v.co
  ventral=max(0,min(1,(-y-.035)*7))*max(0,1-abs(z-.99)/.40)
  throat=max(0,min(1,(-y-.09)*8))*max(0,1-abs(z-1.33)/.20)
  blend=min(1,max(ventral,throat))
  # Broad smooth colour modulation, no high-frequency per-vertex texture noise.
  attr.data[v.index].color=(.57+.43*blend,.66+.32*blend,.58+.36*blend,1)

def build_anatomy(materials):
 _object_mode();parts=[]
 def vol(name,loc,scale):
  o=_ball(name,loc,scale);parts.append(o);return o
 vol('Slender abdomen',(0,.015,.91),(.27,.205,.28))
 vol('Pelvis',(0,.035,.695),(.255,.205,.18))
 vol('Chest',(0,.012,1.105),(.286,.205,.175))
 vol('Upright frog neck',(0,-.012,1.265),(.215,.183,.184))
 vol('Flat broad frog skull',(0,-.025,1.50),(.374,.247,.198))
 vol('Lower throat and jaw',(0,-.092,1.372),(.300,.225,.108))
 for side in [-1,1]:
  vol('Cheek',(side*.268,-.073,1.445),(.108,.164,.095))
  vol('Anatomical orbital mound',(side*.235,-.067,1.655),(.112,.131,.107))
  vol('Shoulder',(side*.290,.004,1.173),(.104,.113,.116))
  vol('Upper arm',(side*.365,-.008,1.032),(.080,.088,.174))
  vol('Elbow',(side*.418,-.030,.899),(.074,.080,.083))
  vol('Tapered forearm',(side*.438,-.066,.772),(.066,.077,.158))
  vol('Wrist',(side*.450,-.101,.647),(.045,.044,.055))
  vol('Slender thigh',(side*.196,.047,.551),(.121,.142,.208))
  vol('Knee',(side*.249,.007,.365),(.079,.093,.088))
  vol('Long shin',(side*.262,-.009,.244),(.050,.058,.151))
  vol('Ankle',(side*.260,-.019,.126),(.051,.065,.063))
 skin=_remesh(parts,'KvakSkin',.017,18500)
 # Locally high-resolution digits retain webs while the torso has a separate budget.
 extremities=build_extremities({})
 for o in extremities:
  bpy.context.view_layer.objects.active=skin;mod=skin.modifiers.new('Continuous wrist or ankle union','BOOLEAN');mod.operation='UNION';mod.solver='EXACT';mod.object=o
  try:bpy.ops.object.modifier_apply(modifier=mod.name)
  except RuntimeError as error:raise RuntimeError('Could not join continuous extremity '+o.name)from error
  bpy.data.objects.remove(o,do_unlink=True)
 skin.name='KvakSkin';skin['bind_region']='AUTO';skin.data.materials.append(materials['skin'])
 _smooth(skin);_uv(skin);_paint_skin(skin)
 objects=[skin]
 def extra(name,loc,scale,material,region='Head',segments=20,rings=12):
  o=_ball(name,loc,scale,segments,rings);o.data.materials.append(material);o['bind_region']=region;_uv(o);objects.append(o);return o
 # An olive/amber ocular surface: no human sclera, no separate white bulging ball.
 for side in [-1,1]:
  suffix='L'if side<0 else'R';cx=side*.235
  extra('KvakEye.'+suffix,(cx,-.195,1.655),(.0905,.0702,.0897),materials.get('eye',materials['skin']))
  iris=extra('KvakIris.'+suffix,(cx,-.255,1.657),(.0702,.0125,.0686),materials.get('iris',materials.get('eye',materials['skin'])))
  uv=iris.data.uv_layers.active
  for poly in iris.data.polygons:
   for li in poly.loop_indices:
    v=iris.data.vertices[iris.data.loops[li].vertex_index].co;uv.data[li].uv=(.5+.45*v.x/.0702,.5+.45*v.z/.0686)
  extra('KvakPupil.'+suffix,(cx,-.268,1.657),(.0569,.0055,.0187),materials.get('pupil',materials['skin']),segments=20,rings=10)
  # A raised upper lid provides the essential frog gaze and an asymmetrical smirk.
  points=[]
  for j in range(25):
   a=pi*j/24;points.append((cx+cos(a)*.091,-.236-sin(a)*.006,1.655+sin(a)*.086))
  lid=_tube('KvakUpperLid.'+suffix,points,.011,2);lid.data.materials.append(materials['skin']);lid['bind_region']='Head';_uv(lid);_paint_skin(lid);objects.append(lid)
  # A real hood between the orbital skin and upper cornea, rather than a floating ring.
  verts=[];count=25
  for row in range(2):
   for j in range(count):
    a=pi*j/(count-1)
    if row==0:
     dx=cos(a)*.108;dz=sin(a)*.101
     yy=-.067-.131*sqrt(max(.015,1-(dx/.112)**2-(dz/.107)**2))
    else:
     dx=cos(a)*.087;dz=sin(a)*.044
     yy=-.195-.0702*sqrt(max(.015,1-(dx/.0905)**2-(dz/.0897)**2))-.004
    verts.append((cx+dx,yy,1.655+dz))
  faces=[(j,j+1,j+1+count,j+count)for j in range(count-1)]
  me=bpy.data.meshes.new('Kvak upper eyelid hood');me.from_pydata(verts,[],faces);me.update();hood=bpy.data.objects.new('KvakUpperHood.'+suffix,me);bpy.context.collection.objects.link(hood)
  hood.data.materials.append(materials['skin']);hood['bind_region']='Head';_smooth(hood);_uv(hood);_paint_skin(hood);objects.append(hood)
  nostril=extra('KvakNostril.'+suffix,(side*.091,-.281,1.516),(.014,.008,.009),materials.get('mouth',materials['skin']),segments=12,rings=8)
 # Raycast the finished skin: analytical ellipse placement buried the crease in the jaw.
 face_bvh=BVHTree.FromPolygons([v.co.copy()for v in skin.data.vertices],[tuple(p.vertices)for p in skin.data.polygons])
 def front_y(x,z):
  hit,normal,index,distance=face_bvh.ray_cast(Vector((x,-2,z)),Vector((0,1,0)),4)
  if hit is not None:return hit.y
  return -.025-.265*sqrt(max(.02,1-(x/.416)**2-((z-1.50)/.216)**2))
 # Narrow natural mouth crease follows the actual skull surface, with lifted corners.
 points=[]
 for i in range(41):
  x=-.311+i*.622/40;z=1.424+.047*(abs(x)/.311)**1.65+.004*(x/.311)
  face=front_y(x,z)
  points.append((x,face-.004,z))
 oral=_tube('KvakOralCrease',points,.0058,2);oral.data.materials.append(materials.get('mouth',materials['skin']));oral['bind_region']='Head';_uv(oral);objects.append(oral)
 # The lip relief is modelled in skin colour, not painted as a human mouth.
 lower=[(x,front_y(x,z-.014)-.002,z-.014)for x,y,z in points]
 lip=_tube('KvakLowerLip',lower,.009,2);lip.data.materials.append(materials['skin']);lip['bind_region']='Head';_uv(lip);_paint_skin(lip);objects.append(lip)
 facial={
  'mouthCenter':(0,-.28,1.424),'eye.L':(-.235,-.195,1.655),'eye.R':(.235,-.195,1.655),
  'mouthWidth':.622,'eyeRadius':.0897,
 }
 sockets={
  'socket.head':{'bone':'Head','position_world':(0,-.02,1.74)},
  'socket.hair':{'bone':'Head','position_world':(0,.015,1.76)},
  'socket.hand.R':{'bone':'RightHand','position_world':(.45,-.13,.57)},
  'socket.hand.L':{'bone':'LeftHand','position_world':(-.45,-.13,.57)},
  'socket.outfit':{'bone':'Spine2','position_world':(0,0,1.04)},
 }
 return{'objects':objects,'skin':skin,'landmarks':dict(LANDMARKS),'sockets':sockets,'facialAnchors':facial,
 'notes':['Original continuous boolean-unioned skin; detailed local four-digit forefeet and five-toe hindfeet.',
 'No strong vertex noise. Col is a smooth multiplicative ventral colour gradient.',
 'Blender Z-up / -Y forward. All mesh vertices and landmarks already final metre coordinates; no old height pass.',
 'Forefoot and hindfoot membranes are genuinely thin closed surfaces, with exposed phalanges and small pads.',
 'Source geometry remains a stylized anatomical interpretation; offline rendering is not game or phone acceptance.']}
