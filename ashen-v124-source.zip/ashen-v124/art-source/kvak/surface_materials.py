"""ASHEN Kvak v2: original restrained PBR materials, no scene side effects.

Interface: build_materials(output_dir) -> exact named material dictionary.
Images are original deterministic 256px UV PNGs, packed into the .blend and GLB.
No external images, generators, photographs or proprietary game resources used.
"""
import os
import math
import hashlib
import json
import bpy
import numpy as np

SIZE = 256


def _image(name, rgb, directory, noncolor=False):
    h, w = rgb.shape[:2]
    rgba = np.ones((h, w, 4), dtype=np.float32)
    rgba[:, :, :3] = np.clip(rgb, 0.0, 1.0)
    image = bpy.data.images.new(name, width=w, height=h, alpha=False)
    image.colorspace_settings.name = 'Non-Color' if noncolor else 'sRGB'
    image.pixels.foreach_set(rgba.reshape(-1))
    image.filepath_raw = os.path.join(directory, name + '.png')
    image.file_format = 'PNG'
    image.save()
    image.pack()
    return image


def _patterns(size=SIZE):
    # All frequencies are integer cycles across UV edges; no edge seams.
    v, u = np.mgrid[0:size, 0:size].astype(np.float32) / float(size)
    tau = math.tau
    broad = (np.sin(tau*(u*3+v*2))*.35 + np.cos(tau*(u*2-v*3))*.27
             + np.sin(tau*(u*7+v*5))*.16 + np.cos(tau*(u*11-v*7))*.09)
    grain = (np.sin(tau*(u*41+v*37))*.5 + np.cos(tau*(u*53-v*43))*.5)
    weave = np.sin(tau*u*64)*np.sin(tau*v*64)
    return u, v, broad, grain, weave


def _material(name, color, roughness, metalness=0, coat=0):
    m = bpy.data.materials.new('Kvak v2 | ' + name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    p = m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = (*color, 1)
    p.inputs['Roughness'].default_value = roughness
    p.inputs['Metallic'].default_value = metalness
    if 'Coat Weight' in p.inputs:
        p.inputs['Coat Weight'].default_value = coat
        p.inputs['Coat Roughness'].default_value = max(.08, roughness*.55)
    # All visible surface information must survive glTF export.
    m['ashen_original'] = True
    m['ashen_material_role'] = name
    return m


def _textured(name, color, roughness, directory, *, family='skin', pale=False):
    m = _material(name, color, roughness, coat=.025 if family=='skin' else 0)
    u, v, broad, grain, weave = _patterns()
    base = np.zeros((SIZE, SIZE, 3), dtype=np.float32)
    base[:] = color
    if family == 'skin':
        # Pigment glands are irregular soft islands, not periodic synthetic stripes.
        rng = np.random.default_rng(72491)
        glands = np.zeros((SIZE,SIZE),np.float32)
        for _ in range(92):
            cx,cy=rng.random(2);rx=rng.uniform(.008,.045);ry=rx*rng.uniform(.55,1.8)
            dx=np.minimum(np.abs(u-cx),1-np.abs(u-cx));dy=np.minimum(np.abs(v-cy),1-np.abs(v-cy))
            glands=np.maximum(glands,np.exp(-((dx/rx)**2+(dy/ry)**2)*2.2)*rng.uniform(.55,1.0))
        macro=np.clip((broad+.05)*1.2,0,1)
        base += broad[:,:,None]*np.array([.065,.072,.035],np.float32)
        base -= (glands*.8+macro*.28)[:,:,None]*np.array([.145,.135,.085],np.float32)
        base += grain[:,:,None]*.006
        pores=.5+.5*np.sin(math.tau*(u*29+v*31))*np.sin(math.tau*(u*31-v*23))
        base -= np.clip((pores-.77)/.23,0,1)[:,:,None]*np.array([.027,.023,.015],np.float32)
        rough=np.clip(roughness + broad*.075 +(pores-.5)*.035-glands*.065, .46, .78)
    elif family == 'linen':
        base += broad[:, :, None]*.018 + weave[:, :, None]*.009
        right = u >= .5
        base[right] += np.array([-.615,-.580,-.475],np.float32)
        rough = np.clip(roughness + weave*.015 + grain*.008, .82, .98)
    elif family == 'leather':
        base += broad[:, :, None]*.012 + grain[:, :, None]*.003
        # Shared atlas: left=charcoal vest, right=warmer satchel/strap.
        right = u >= .5
        base[right] += np.array([.105,.045,.016],np.float32)
        rough = np.clip(roughness + broad*.045 + grain*.015 + right*.025, .48, .72)
    else:
        base += broad[:, :, None]*.012 + weave[:, :, None]*.006
        rough = np.clip(roughness + weave*.02, .75, .96)
    slug = 'kvak-v2-' + name.replace(' ', '-')
    base_image = _image(slug+'-base', base, directory)
    rough_image = _image(slug+'-rough', np.repeat(rough[:,:,None],3,axis=2), directory, True)
    nodes, links = m.node_tree.nodes, m.node_tree.links
    p = nodes.get('Principled BSDF')
    uv = nodes.new('ShaderNodeUVMap'); uv.uv_map = 'UVMap'
    tex = nodes.new('ShaderNodeTexImage'); tex.image=base_image; tex.label='Original UV base colour'
    rtex = nodes.new('ShaderNodeTexImage'); rtex.image=rough_image; rtex.label='Original UV roughness'
    links.new(uv.outputs['UV'],tex.inputs['Vector']); links.new(uv.outputs['UV'],rtex.inputs['Vector'])
    if family == 'skin' and not pale:
        # Anatomy owns only a smooth ventral tint in Col; pores stay in UV maps.
        attr = nodes.new('ShaderNodeVertexColor'); attr.layer_name = 'Col'
        mix = nodes.new('ShaderNodeMixRGB'); mix.blend_type = 'MULTIPLY'; mix.inputs[0].default_value = 1.0
        links.new(tex.outputs['Color'], mix.inputs[1]); links.new(attr.outputs['Color'], mix.inputs[2])
        links.new(mix.outputs['Color'], p.inputs['Base Color'])
    else:
        links.new(tex.outputs['Color'],p.inputs['Base Color'])
    links.new(rtex.outputs['Color'],p.inputs['Roughness'])
    # Deliberately no tangent normal/bump node: rejected v1 showed skin patches.
    # Small geometry and roughness variation provide readable wetness safely.
    m['ashen_uv_required'] = 'UVMap'
    m['ashen_normal_policy'] = 'disabled: prevent v1 tangent artifacts'
    m['ashen_texture_size'] = SIZE
    return m


def _iris_material(directory):
    m = _material('striated amber iris',(.36,.205,.047),.27,coat=.25)
    v,u=np.mgrid[0:SIZE,0:SIZE].astype(np.float32)/float(SIZE-1)
    x=(u-.5)/.45;y=(v-.5)/.45;r=np.sqrt(x*x+y*y);theta=np.arctan2(y,x)
    fibers=(np.sin(theta*67+np.sin(theta*13)*.9+r*14)*.55+np.sin(theta*113-r*22)*.25+np.cos(theta*31+r*9)*.2)
    amber=np.zeros((SIZE,SIZE,3),np.float32);amber[:]=(.34,.195,.040)
    amber+=fibers[:,:,None]*np.array([.105,.067,.016],np.float32)
    middle=np.exp(-((r-.57)/.22)**2)
    amber+=middle[:,:,None]*np.array([.075,.042,.008],np.float32)
    outer=np.clip((r-.81)/.13,0,1);inner=np.clip((.24-r)/.09,0,1)
    dark=np.maximum(outer,inner*.22)
    amber=amber*(1-dark[:,:,None]*.80)
    image=_image('kvak-v2-amber-iris-base',amber,directory)
    node=m.node_tree.nodes.new('ShaderNodeTexImage');node.image=image
    uv=m.node_tree.nodes.new('ShaderNodeUVMap');uv.uv_map='UVMap'
    m.node_tree.links.new(uv.outputs['UV'],node.inputs['Vector'])
    m.node_tree.links.new(node.outputs['Color'],m.node_tree.nodes.get('Principled BSDF').inputs['Base Color'])
    m['ashen_uv_required']='UVMap planar iris: center .5,.5 outer radius .45'
    return m


def build_materials(output_dir: str):
    """Build original packed maps/materials; does not reset, save or export scene."""
    os.makedirs(output_dir, exist_ok=True)
    skin = _textured('olive skin', (.50,.55,.30), .62, output_dir, family='skin')
    belly = _textured('pale throat', (.565,.585,.350), .68, output_dir, family='skin', pale=True)
    eye = _material('dark olive eye globe', (.115,.145,.055), .31, coat=.2)
    amber = _iris_material(output_dir)
    dark = _material('wet pupil and mouth', (.009,.015,.011), .18, coat=.25)
    linen = _textured('unbleached linen', (.72,.675,.555), .91, output_dir, family='linen')
    leather = _textured('charcoal leather', (.115,.090,.064), .61, output_dir, family='leather')
    cape = _textured('muted teal cape', (.135,.235,.225), .87, output_dir, family='cloth')
    bronze = _material('aged bronze', (.32,.235,.105), .48, metalness=.72)
    images = []
    for image in bpy.data.images:
        if image.name.startswith('kvak-v2-') and image.filepath_raw and os.path.isfile(image.filepath_raw):
            data=open(image.filepath_raw,'rb').read()
            images.append(dict(file=os.path.basename(image.filepath_raw),sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),license='Original ASHEN procedural texture, no external inputs'))
    with open(os.path.join(output_dir,'surface-provenance.json'),'w') as f:
        json.dump(dict(version=2,source=__file__,size=SIZE,normalPolicy='disabled',leatherAtlas=dict(vest=[.02,.48],bag=[.52,.98]),linenAtlas=dict(shirt=[.02,.48],trousers=[.52,.98]),images=images),f,indent=2)
    return dict(skin=skin, belly=belly, eye=eye, iris=amber, pupil=dark,
                mouth=dark, linen=linen, leather=leather, cape=cape, bronze=bronze)
