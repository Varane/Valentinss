# Player-blocking incidents

For reports that players cannot find one another, join, start, move, or continue:

- Treat the reported player journey as the current priority. Pause unrelated art, economy and content work.
- When the user authorizes agents, delegate two bounded checks immediately: player-path triage (actual buttons, destinations and UI state), and transport triage (two identities, shared room, server state). The owner integrates their confirmed findings; neither agent publishes independently.
- Ask at most one concise question about the stopping point if it is unknown, while inspecting independent evidence. Do not repeatedly require screenshots or confirmation.
- Reproduce the failure with the actual handler or client/server path before fixing it. Test two independent clients through the shared-room transition, including reload and conflicting account/session cases when relevant.
- A test count or deployment success does not establish that the reported device journey works. Distinguish source inspection, simulation, HTTP checks and live browser tests explicitly. If browser control is unavailable, say so and do not claim a live playtest.
- Show the available action and failure recovery at the stopping point. A new generic navigation link alone does not fix a missing party, invitation or start operation.
- Never put session tokens in invitations or URLs. Invitations may carry only public room codes. Never silently leave an existing room to follow another invitation.
- Preserve existing player features and saves. Publish authorized, verified fixes through the existing Site identity; no new approval loop is required.
