# Campaign and RPG translation catalog

`dist/locales/content.mjs` exports browser-safe, immutable data with no imports:

- `CONTENT_MESSAGES`: flat semantic keys mapped to `{ru, en}` pairs. Use `t('item.blade.name')`, `t('story.threshold.intro')`, or `t('campaign.reward', {xp:60,gold:30})` after merging this export into the shared catalog.
- `CONTENT_TEXT`: exact Russian source strings mapped to English, for the shared `localize(value)` bridge. Both trimmed and one-trailing-space variants are included because existing dialogue uses `.trim()`.
- `HERO_NAMES`: canonical IDs `knight` → Грим / Grim and `mage` → Векса / Vexa, verified in `rules.mjs` `createGame()`. Saved names remain untouched.

Current coverage: all eight original item names/descriptions and three rarities; all nine original skills and their shared effect text; all three skill branches; six legacy room titles and three enemy names; all six story room titles; the quest title and every conditional objective; all currently authored dialogue branches, including introduction, victory, defeat and exit variants; static rules and campaign errors; static progression notices; semantic templates for dynamic combat logs and rewards.

Terminology: «Алая перепись» is **Crimson Census**, the campaign title and the named census; «Алая книга» is **Crimson Ledger**. «Архимясник» is **Archbutcher**. This keeps the distinction already present in the Russian source. «Спасти» means revive in the combat context and rescue in narrative context.

Dynamic sentences are assembled inside source modules. Exact lookup of the entire result alone cannot translate interpolated XP, gold, hero names, learned skills or appended reward/death suffixes. The shared bridge must support the supplied semantic templates, or translate their static parts while preserving numbers and substituting localized hero/item/skill names. The catalog does not alter campaign state, mechanics, saves or source-owned files.

Coverage checkpoint: 2026-11-11 21:18 UTC sources. `campaign/rooms.mjs`, `choices.mjs`, `puzzles.mjs`, `endings.mjs`, `items.mjs`, `skills.mjs`, `rewards.mjs`, `encounters.mjs`, `progression.mjs` and `death.mjs` were not yet present during the first read. Their additions require a second pass before claiming complete coverage. Legacy skill descriptions retain their source mechanics; later stamina-based descriptions will receive distinct keys and mappings as authored.
