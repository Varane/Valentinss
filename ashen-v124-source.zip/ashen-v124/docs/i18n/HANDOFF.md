# English / Russian integration

English team owns only `dist/i18n.mjs`, `dist/locales/**`, `tests/i18n*.test.mjs`, and `docs/i18n/**`. The lead implements the runtime; exactly three independent subagents implement UI text, campaign/RPG text, and QA. No child chats, commits, publication, servers or modifications to C/D-owned files.

## Public API

Import from `./i18n.mjs` (or `../i18n.mjs` in nested UI files):

```js
import { t, getLocale, setLocale, onLocaleChange, localize, heroName } from './i18n.mjs';
label.textContent = localize('Снаряжение');
name.textContent = heroName(hero.id);
story.textContent = localize({ ru: 'Выход', en: 'Exit' });
languageButton.onclick = () => setLocale(getLocale() === 'ru' ? 'en' : 'ru');
const stop = onLocaleChange((next, previous) => refreshAllVisibleText());
// Call stop() when the view is destroyed.
```

- `t(key, params?)`: flat semantic catalog key; substitutes named `{param}` tokens. Unknown key returns itself. Missing parameter remains visible. Values may be bilingual objects.
- `localize(value)`: resolves `{ru,en}`, or translates a known legacy source string. Unknown text passes through. Known string templates translate assembled messages. Exact reverse mappings allow already translated labels to switch back. Null/undefined becomes empty text. Other objects without locale fields become empty text.
- `heroName(id)`: canonical display name (`knight`: Грим/Grim, `mage`: Векса/Vexa); unknown IDs remain readable.
- `getLocale()`: current `ru` or `en`; default `ru`, restored from the language preference when available.
- `setLocale('ru'|'en')`: returns selected locale; unsupported values return `false`. Updates the language preference and document language, then notifies listeners once for an actual change. No reload, navigation, or profile mutation.
- `onLocaleChange(callback)`: callback receives `(newLocale, previousLocale)`; returns unsubscribe. Listener failures are isolated.
- Extra constants: `LOCALE_STORAGE_KEY = 'krovosklep-locale'`, frozen `SUPPORTED_LOCALES = ['ru','en']`.

## Integration responsibilities

D owns the visible RU/EN button and wrapping HUD, menus, controls, accessibility labels, network notices and settings. Subscribe once per UI instance and force refresh the currently open overlay, cached HUD labels, selected hero, notices and outcome text. Dispose the subscription when destroying the UI. Rendering text through `localize` must occur before HTML escaping; prefer `textContent`.

Root owns runtime notices, encounter headings, onboarding, choice prompts, quest objectives and outcomes in `dist/action-game.mjs`. C owns bilingual source data; no gameplay or save field needs to depend on the locale. Keep source objects/strings and re-resolve on refresh. Do not mutate profile hero names, inventory IDs, campaign flags, old save bytes or encounter state.

UI keys and source mapping coverage: `docs/i18n/ui-catalog.md`. Content keys and source mapping coverage: `docs/i18n/content-catalog.md`. Independent verification: `docs/i18n/qa.md`.

## Status

Runtime implemented. Catalog workers and independent tests are active. Integration and full English playable coverage are not yet verified. This file will be updated with final command output and remaining gaps.
