# UI catalog handoff

Owner: English worker 1. Initial catalog: 2026-11-11 21:21 UTC.

Only `dist/locales/ui.mjs` and this file are owned by this worker. UI, runtime,
HTML, input, campaign, and RPG code are not changed here.

## Exports

```js
import {UI_MESSAGES, UI_TEXT} from './locales/ui.mjs';
// UI_MESSAGES['ui.hud.enemyCount'] === {ru:'ВРАГОВ: {count}', en:'ENEMIES: {count}'}
// UI_TEXT['ГОТОВ'] === 'READY'
```

`UI_MESSAGES` is a flat semantic-key dictionary; each value has `ru` and `en`
strings. `UI_TEXT` maps exact original Russian strings to English. Both outer
objects are frozen. Neither export reads DOM, storage, or game state. Merge these
exports into the i18n service; interpolation belongs to `t(key, params)`.

English game name: **Bloodcrypt**. Branch names: **Blood / Steel / Abyss**.
Combat terms: **dash / parry / riposte / special attack / revive**. The static
legacy hero labels are **GRIM / VEXA**; the i18n service owns `heroName(id)`.

## Dynamic key contract

| Key | Parameters | Purpose |
| --- | --- | --- |
| `ui.hud.heroNumber` | `number` | Fallback selector name |
| `ui.hud.downTimer` | `seconds` | Selected hero revive deadline |
| `ui.hud.switchToRescue` | `name`, `seconds` | Switch to the living hero |
| `ui.hud.rescueNearby` | `name`, `seconds` | Nearby revive prompt |
| `ui.hud.rescueApproach` | `name`, `seconds` | Approach downed ally |
| `ui.hud.healthAria` | `name` | Health meter accessible name |
| `ui.hud.staminaAria` | `name` | Stamina meter accessible name |
| `ui.hud.enemyCount` | `count` | Living enemy count |
| `ui.outcome.deathLoss` | `name` | Permanent equipment loss message |
| `ui.gear.itemCount` | `count` | Inventory count |
| `ui.gear.equippedNotice` | `name` | Equip feedback |
| `ui.gear.inspectAria` | `name` | Inspect accessible label |
| `ui.gear.equipAria` | `name` | Equip accessible label |
| `ui.gear.equippedAria` | `name` | Equipped item accessible label |
| `ui.skills.pointsCount` | `count` | Unspent skill points |
| `ui.skills.requires` | `name` | Prerequisite name |
| `ui.skills.cost` | `count` | Skill cost |
| `ui.skills.learnedNotice` | `name` | Learn feedback |
| `ui.skills.learnAria` | `name` | Learn accessible label |
| `ui.skills.nodeAria` | `name`, `status` | Constellation node accessible label |
| `ui.network.codeValue` | `code` | Room code label |
| `ui.network.players` | `count` | Two-player occupancy |
| `ui.network.error` | `message` | Network error context |

Example wiring:

```js
text('remaining', t('ui.hud.enemyCount', {count: remaining}));
notice(t('ui.outcome.deathLoss', {name: heroName(h.id)}));
meter('life', hp, maxHp, t('ui.hud.healthAria', {name: heroName(hero.id)}));
```

The legacy lookup includes normalized `{param}` templates. A bridge that only
looks up exact completed strings will not translate already-interpolated text.
Prefer the semantic keys above for dynamic strings. Preserve numeric values,
keyboard shortcuts, room codes, and player-generated names.

## Static key groups

All keys begin with `ui.`. These are the exact suffixes in the initial catalog:

- `brand`: `name`, `wordmark`, `title`, `description`.
- `menu`: `label`, `gear`, `skills`, `constellations`, `pause`, `rest`, `rooms`, `roomsButton`, `roomForTwo`, `coopKicker`, `gearKicker`, `skillsKicker`.
- `action`: `close`, `closeHint`, `resume`, `resumeRun`, `restart`, `anotherRun`, `nextRoom`, `gearAndLoot`, `cancel`, `back`, `confirm`, `copy`, `retry`, `save`, `done`.
- `control`: `camera`, `gearHint`, `skillsHint`, `pauseHint`, `switchHero`, `switchHeroHint`, `switchLabel`, `joystick`, `movement`, `combat`, `dash`, `dashLabel`, `dashHint`, `attack`, `attackLabel`, `attackHint`, `space`, `parry`, `parryLabel`, `parryHint`, `special`, `specialLabel`, `specialHint`, `rescue`, `rescueHint`, `rescueLabel`, `keyboardHints`, `canvasAria`.
- `hud`: `heroes`, `heroFallback`, `allyFallback`, `heroNumber`, `ready`, `dead`, `down`, `downTimer`, `riposte`, `hurt`, `switchToRescue`, `rescueNearby`, `rescueApproach`, `healthAria`, `staminaAria`, `enemyCount`, `roomCleared`, `partyFallen`, `initialMatchup`, `initialRoom`.
- `enemy`: `stunned`, `windup`, `warden`, `guard`.
- `onboarding`: `motto`, `warning`, `defense`, `combat`, `localRoom`.
- `loading`: `enter`, `assemble`, `mark`, `failed`.
- `outcome`: `roomComplete`, `runComplete`, `riftClosed`, `roomYours`, `fallen`, `victory`, `runEnded`, `lootSaved`, `progressKept`, `deathLoss`.
- `notice`: `actionFailed`, `saveUnavailable`, `gearTiming`, `skillTiming`, `staminaLow`, `learnSpecial`, `approachAlly`, `resolveFailed`, `saveNeedsCheck`, `finishRoom`, `parryNow`, `allyDown`, `allyRevived`, `contextLost`.
- `error`: `documentRequired`, `overlayMissing`.
- `settings`: `title`, `accessibility`, `language`, `russian`, `english`, `languageAria`, `reducedMotion`, `blood`, `bloodEffects`, `inputHints`, `sound`, `music`, `musicVolume`, `soundVolume`, `on`, `off`, `saved`, `pauseNote`, `onlinePauseNote`.
- `gear`: `weapon`, `armor`, `inventory`, `equipped`, `equip`, `unequip`, `inspect`, `empty`, `emptySlot`, `noWeapon`, `noArmor`, `stats`, `attack`, `damage`, `defense`, `health`, `stamina`, `mana`, `level`, `xp`, `gold`, `potions`, `compare`, `current`, `after`, `itemCount`, `equippedNotice`, `inspectAria`, `equipAria`, `equippedAria`.
- `skills`: `learn`, `learned`, `locked`, `available`, `points`, `pointsCount`, `needPoints`, `needPrevious`, `requires`, `cost`, `learnedNotice`, `learnAria`, `nodeAria`, `blood`, `steel`, `abyss`.
- `network`: `unavailable`, `local`, `online`, `offline`, `connecting`, `connected`, `disconnected`, `reconnecting`, `reconnected`, `create`, `join`, `leave`, `code`, `codeValue`, `enterCode`, `copyCode`, `codeCopied`, `shareCode`, `waiting`, `players`, `host`, `guest`, `ready`, `roomFull`, `notFound`, `invalidCode`, `joinFailed`, `createFailed`, `error`, `left`, `sessionExpired`, `localNote`, `status`, `idle`, `closed`.
- `network.error`: `inputObject`, `movementFinite`, `unknownAction`, `sequencePositive`, `destroyed`, `noBackend`, `noSession`, `timeout`, `unreachable`, `invalidJson`, `invalidData`, `requestFailed`, `invalidSnapshot`, `wrongRoom`, `oldRevision`, `credentials`, `alreadyInRoom`, `invalidCode`, `sequenceExhausted`. These preserve the network client's exact English source errors; the i18n service may use reverse lookup for Russian.

## Source coverage and limits

Read at 21:17 UTC: `dist/ui.mjs`, `dist/ui/hud.mjs`, `dist/ui/accessibility.mjs`,
`dist/ui/network-client.mjs`, `dist/ui/input/state.mjs`, `dist/input.mjs`,
`dist/index.html`, and `dist/action-game.mjs`. HUD, static HTML, and runtime
Russian text are included, with semantic templates for interpolation. At this
snapshot, `dist/ui/skills.mjs`, `equipment.mjs`, and `overlay.mjs` are referenced
by the UI but are not yet on disk. Their prospective terms are supplied; exact
source coverage will be refreshed when those modules arrive. Item/skill names,
descriptions, and story content belong to the other English workers.

This handoff does **not** claim UI integration or browser verification. D owns
UI wiring; root owns runtime wiring. The catalog cannot change the language of
unwired text by itself. Do not advertise online availability from these strings:
connection state must come from the actual network client.

## Verification

Pending initial syntax/import and placeholder parity check.
