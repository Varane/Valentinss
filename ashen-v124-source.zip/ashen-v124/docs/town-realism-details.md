# Focused realism pass

Fountain: dedicated limestone material keeps the existing CC0 photographic color/normal/roughness maps aligned; vertex shading darkens the damp lower band. A smoother basin silhouette uses a12-by64 torus.
Water: dielectric metalness0, sharper environment response and two slow world-space normal waves, using the existing material shader. Reduced motion freezes wave time. No extra render targets, lights or texture downloads.
Metal: existing worn-metal normal maps become more readable, with restrained roughness and environment reflections.

Checks cover shader injection and shared time updates, actual fountain map alignment, wet-band variation, resource disposal and the existing mobile geometry/draw budgets. Browser/phone rendering is not available; offline Blender inspection cannot verify the actual WebGL shader.
