# Living town workshops

Fishing shows a swimming school, cast, bite, reel and held catch. Confirmed fish species and length come from the server; fish are kept in the personal town produce bag.

The forge has a shared occupancy lease and a visible heat, carry, hammer and quench sequence. Two-bone arm IK places human and Kvak tools on the workpiece. Automatic approach stops precisely at the work station. Leaving cancels unfinished work without producing items.

Nine persistent garden plots are shared between players. Harvest, planting and watering act on actual plot state. Plants mature over 90 seconds, including while players are offline; watering accelerates growth once. Concurrent gardeners reserve separate plots. Produce is personal storage, not a new exchange currency. Existing trade balances and accounts are preserved.

Rendering stays on Three.js/WebGL2: instanced fish and crops, GPU tail deformation, PBR scale normal maps, a morphing billet and bounded particle pools. Mobile pools are smaller. No engine migration is required.

Validation covers shared-state concurrency, cancellation, exactly-once results, reconnect persistence, crop growth, animation phases, real humanoid/frog tool contact, river depth, forge visibility and resource disposal. Browser/iPhone visual performance still requires a manual device check; automated Node tests do not establish device FPS.
