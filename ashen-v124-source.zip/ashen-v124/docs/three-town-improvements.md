# Three town improvements

1. Authored physical workshop signs: hanging fish, forged horseshoe and herb leaves. Batched into existing materials, inside existing obstacle footprints.
2. Three main controls, with destinations and secondary actions disclosed on demand. Menus close when switching or entering an activity. Existing action IDs and functions preserved.
3. Named patrons, short original dialogue and concrete next-step captions. Existing contract IDs, routes and rewards preserved for saved progress.

Verification: full Node regression suite; finite town geometry and forge visibility checks; exclusive menu behavior; built Worker asset hashes. Browser and physical iPhone visual verification unavailable in this session.
