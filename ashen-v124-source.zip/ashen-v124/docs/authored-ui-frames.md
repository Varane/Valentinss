# Authored frame resources

Source: Kenney Fantasy UI Borders1.0 and UI Pack RPG Expansion, CC0. Official descriptions on kenney.nl; files downloaded from Kenney author uploads on OpenGameArt after official signed-download endpoint returned403. Original PNGs are copied unchanged. Source URLs, local checksums and both packaged licenses are under dist/ui/kenney. Credits are visible through the existing author screen.

Audit/result:
- Native dialogs, town HUD surfaces, tactical panel: irregular paper edge via panelInset_beigeLight native border-image nine-slice, not a flat rounded card. Existing centering transform reset and viewport bounds remain. Padding-box paper fallback keeps text readable if the image is unavailable.
- Hero/hair/equipment choices, inventory, recipes, quest facts, skills and settings: remove repeated nested boxes; use text hierarchy, separators, underline and a small Kenney selection check.
- Main action buttons: original Kenney buttonLong_brown/pressed art with a CSS multiply color treatment. Normal/secondary actions are unframed. Focus and disabled semantics and touch target sizes remain.
- Map: authored fantasy border; viewport edges use the paper alpha mask. Joystick/icon buttons use round RPG assets.

The original Golos/Literata font setup and contrast tokens remain. Muted text on the actual paper image center measures4.62:1. Static visual boards were regenerated and inspected via scripts/render-interface-proof.py. They are component studies, not browser screenshots. Browser/iPhone DOM layout and visual touch QA remain unavailable. Existing gameplay regression suite and emitted asset checks are also run before publication.
