# Illustrated art direction overhaul

Replace the mixed photographic/plain-toy appearance with a shared illustrated rendering language across town, cave, characters, enemies, hair and inventory models. Broad softened diffuse bands preserve physical reflection for metals, glass and water. Character inverted-hull contours share the existing animated geometry/skeleton; town architecture uses one line batch. Supported desktop scenes reuse the existing five scene samples for subtle screen contours. Phones keep the direct-render path with no additional full-screen target.

Human heads use artist-authored Quaternius Universal Base Characters anatomy (CC0), extracted from Superhero Male with original normals. A continuous face, separate eye whites/irises/pupils and brows replace the primitive-built facial features. Avatar-specific shape fitting, existing barber styles and custom clothing remain. Smaller heads and articulated fingers change the old toy proportions. The sculpt's source and derived hashes and license ship beside the data.

Visible hero cost is capped at8draws/26k triangles including contours, with the main costume capped at13k triangles (12,764 measured maximum). No extra downloaded model is required at runtime:171KB raw derived head data is bundled. Accounts, saves, networking, combat and trade rules remain unchanged.

Verify shader composition/Three chunks, rig and morph attachment, shared geometry ownership, source texture borrowing, head provenance, mobile geometry budgets and full game suite. Offline character renders inspect geometry and approximate art direction; they do not verify the actual browser GPU shader or physical phone frame rate.
