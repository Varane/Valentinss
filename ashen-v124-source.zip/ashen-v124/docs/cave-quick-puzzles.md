# Shorter cave puzzles

Replace mandatory evidence popups with a saved clue and one brief toast. Each of the five floor deductions now presents existing evidence art, two short observations and two concise alternatives. Wrong attempts show one useful hint in the same panel without recording a wrong deduction or changing rewards; correct answers save the original answer ID and immediately continue to the upgrade/finale. Keep the full clue in an optional disclosure and the journal. Existing saves and legacy answers remain valid.

The optional quest plan leads with the current action and hides the full checklist under a disclosure. Do not change enemy balance, clue positions, bell station order, accounts, trading or multiplayer.

Verify all five choice sets against canonical answers, retry/save behavior, existing campaign progression and packaged assets. Browser/phone visual verification unavailable.
