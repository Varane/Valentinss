# Full character exterior replacement

The rejected costume pass retained the same bulky Vanguard exterior. Hide the original player meshes and retain their animation rig only. Build complete tailored bodies, sleeves, forearms, hands, trousers and boots; keep character headwear and face separate for hair customization. Merge body sections into one SkinnedMesh sharing the animated bones but owning its skeleton inverses and GPU bone texture. Use three visible costume batches instead of six; remain below the existing12k costume triangle budget.

Volkhv: draped shoulder cape and long robe without the inherited shoulder armor. Danik: curved work apron and visible automotive tools. Vitalik: slim jacket and rounded equipment backpack. Enemies keep their original meshes; frog keeps its independent model.

Checks: production-rig side-by-side offline render, real vertex articulation and world placement, source-mesh visibility, GPU skeleton disposal, appearance/equipment and full game regressions. Browser/physical phone checks unavailable.
