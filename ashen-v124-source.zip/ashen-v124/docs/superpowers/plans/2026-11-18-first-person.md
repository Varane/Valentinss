# First-person implementation plan

**Goal:** добавить первый вид через существующий кубик города и переключатель пещеры.
**Architecture:** существующий renderer, общий локальный контроллер yaw/pitch; старые ракурсы сохраняются.
**Tech:** Three.js / ES modules / node:test.
**Spec:** ../specs/2026-11-18-first-person-design.md

## Задачи

- [x] 1. Общий контроллер — агент first_person_camera: tests/first-person-camera.test.mjs сначала, затем dist/cinematic/first-person-camera.mjs. API createFirstPersonCamera({camera,element,enabled,onDragStart}), enter({facing,avatar}), update({x,z,avatar},dt), turn, cancel, consumeDrag, dispose. Проверить независимый yaw, высоту, ограниченный pitch, drag threshold, pointercancel и освобождение слушателей.
- [x] 2. Город — агент town_first_person: dist/town/view.mjs, app.mjs и отдельные тесты. Сохранить четыре ракурса, добавить FP, отладить клики/свайпы, скрыть только себя; восстановить после смены героя/примерки. Сохранить матрицу движения и поведение взаимодействий.
- [x] 3. Пещера — root: dist/cinematic/view3d.mjs, dist/remake/game.mjs, tests/cave-first-person.test.mjs. Цикл 0/1/2, близкая камера без bob/impulse, sight по взгляду, восстановление FOV/near/модели после выхода и welcome. Проверить реальными методами через VM + Three.js.
- [x] 4. Приёмка — Astra: docs/qa/first-person-astra-review.md; затем review внедрения. Root запускает целевые/полные проверки, собирает тот же Worker с прежним DB, публикует в существующий Site. Непроведённые браузерные/телефонные проверки отмечаются открытыми.

## Review focus
- Strafe/back не разворачивают камеру автоматически (общий контроллер).
- Отпускание пальца взгляда не освобождает джойстик (раздельные pointer owners).
- Перетаскивание не запускает ходьбу/открытие игрока (город).
- Смена режима/героя/этажа не оставляет модель невидимой в обзоре (оба мира).
- Нельзя смотреть в пустую тьму из-за sight от старого facing (пещера).

## Проверено

Общий изолированный Node-прогон: 1985 случаев, 1978 pass, 0 fail, 2 skip, 5 прежних TODO. Новые suites: 21 случай; с существующими camera-relative проверками — 24. Собран Worker, проверены все 480 ассетов по SHA256.

Живой браузер и физический телефон остаются непроверенными: среда запущена, remote_desktop объявлен, но desktop js/cua инструмент не предоставлен. Это не блокирует публикацию авторизованного проверенного изменения и не означает, что ручная приёмка проведена.
