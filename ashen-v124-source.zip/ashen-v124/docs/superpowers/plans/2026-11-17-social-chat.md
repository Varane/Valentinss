# Social Chat Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Persistent friends/DMs with presence and styled city speech.
**Architecture:** Shared chat normalization; namespaced social profiles/threads in existing optimistic D1 store; shared polling client/native UI; overhead speech stays in authoritative town pulse.
**Tech Stack:** Native ES modules/CSS, Three.js DOM overlays, Worker/D1/SQLite tests.
**Spec:** docs/superpowers/specs/2026-11-17-social-chat-design.md

## Global Constraints
Cookie sender authority; bounded60-message threads/30 recent threads/50 friends/20 requests/50 blocks. No cross-user thread reads.80codepoint speech,400DM; safe six colors/five effects,9s TTL,2.5s cooldown. Existing routes/saves/bindings unchanged. Buttons44px; reduced motion honored.

## Review Focus
Atomic friendship/message races and retry IDs. Private data/presence must not leak through public town/search. Polls cannot reset drafts or switch/reopen dialogs. Blocking must stop both directions and hide bubbles without hiding actors. Social presence must not slow movement or survive hidden tabs indefinitely.

### 1: Model and backend
- [x] RED→GREEN normalization, bounds and safe style tests.
- [x] Authenticated social API for state/search/request/accept/remove/block/unblock/message/read; bounded documents and atomic commits.
- [x] Real SQLite tests for auth, privacy, duplicate names/Cyrillic, consent, blocks, offline delivery, read races, retries and concurrency.
- [x] Town pulse speech validation/projection/cooldown/expiry tests.

### 2: Client and interface
- [x] RED→GREEN serialized client polling, retry, hidden-tab and stale response tests.
- [x] Implement shared native dialog/launcher, friends/nearby/DM/history/overhead live editor with draft preservation.
- [x] Integrate town communication actions/input ownership and standalone expedition/coop launcher/presence.
- [x] Implement capped, escaped, reduced-motion overhead bubble layer and test rendering ownership/expiry.

### 3: Verify and publish
- [x] Fresh whole-diff reviewer and regression fixes.
- [x] Full suite, cache bump, build and emitted asset hashes; preserve root-town alias.
- [ ] Commit/push matching source, package and deploy existing public Site. Report scope/limits.

Release verification:1559 total tests,1552 pass,0 fail,2 skipped,5 existing TODO. All385 emitted assets served and SHA256 matched. Executable Worker verifies identical root/town shell, both campaign/coop social entries and unauthenticated social API rejection. Five independent review findings and own-slot cap fixed via failing regressions. No browser/phone verification; DOM fixtures are controller checks only. Cache86,town31,expedition75.
