# Graphics Remake Implementation Plan

> **For agentic workers:** Use parallel agents for the independently owned art systems and review integration before publication.

**Goal:** Replace the fragmented visual language with grounded storybook realism across town, heroes, cave and interface.

**Architecture:** Preserve the Three.js engine, multiplayer simulation and asset ownership. Change production materials, geometry and presentation in place; no gameplay rewrite.

**Tech Stack:** Three.js, local PBR maps, skinned GLTF characters, CSS, Blender proof renders.

## Constraints and review focus
- Mobile: no extra full-screen passes, per-window lights or unbounded particles.
- Preserve character wardrobe/hair/rigging, navigation footprints, occlusion and all chat/trade/duel controls.
- Distinct human identities; keep Kvak recognizable.
- Reduced motion and resource disposal must remain valid.
- Offline Blender renders are geometry/material evidence, not device screenshots.

## Tasks
- [x] Environment agent: architectural relief, authored doorsteps, material variation, warm interior/cold exterior; run town environment tests.
- [x] Character agent: differentiated fitted costumes and readable identity silhouettes; run fitting/wardrobe tests.
- [x] UI agent: consistent opaque readable panels and restrained controls; preserve mobile hit areas and feature access.
- [x] Root: remove artificial postprocess outlines; improve cave scale/UV, surface variation and lighting, with bounded instancing.
- [x] Audit agent: inspect material pipeline and render actual before/after production geometry.
- [ ] Root: inspect proof images, integrate feedback, run full regression and packaged asset verification, push exact source and publish.

## Integration evidence
- Full regression: 1673 cases; 1666 pass, 0 failures, 2 skipped, 5 previously marked TODO.
- Packaged Worker: all 427 assets fetched and SHA256 verified.
- Independent review corrected instanced material transforms and garment seam propagation; all four production avatar seams remain coincident.
- Town production geometry: 72,710 to 74,714 triangles (+2.76%); no per-window lights or mobile postprocess passes added.
- Actual geometry/material proof renders: `work/graphics-remake-review/README.md`. These use CPU Cycles and do not validate WebGL shaders, CSS layout or phone performance.
- Publication is the final release operation after this source commit.
