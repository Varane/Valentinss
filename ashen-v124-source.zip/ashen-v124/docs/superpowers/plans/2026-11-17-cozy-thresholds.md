# Cozy town thresholds

**Goal:** Make the town feel inhabited through quiet physical details, without cluttering roads or interface.

**Implementation:** Static benches, folded throws, tea table, cups, kettle, book stacks and pots join the existing material batches. Two shared sparrows and bounded chimney/tea vapour add two draw objects, no lights or screen effects. All moving vapour is hidden with reduced motion; bird poses remain fixed.

**Placement:** Furniture remains in the existing blocked padding of inn/shop/bank buildings. Added regression coverage for the original doorstep shrubs after offline renders exposed overlapping benches. Bird perches and tea vapour anchors come from actual prop placement.

**Checks:** Finite geometry, footprint collision sampling, shrub clearance, reduced motion and exact-once owned GPU disposal. Use matched before/after CPU Blender views for geometry inspection; custom vapour shaders, browser appearance and phone frame rate require separate checks.

**Release:** Full regression, packaged asset hashes, exact source push and publication.

## Verified release candidate
- 1706 cases: 1699 pass, 0 fail, 2 skipped, 5 existing TODO.
- All 441 packaged files served with matching SHA256.
- Matched CPU Blender before/after porch, close and overview inspected; furniture now clears the old shrubs. Geometry79,286 triangles versus75,834 baseline (+4.55%).
- Proofs: `work/cozy-town-review/README.md`; steam/live shaders and phone frame rate are not verified by the offline renders.
