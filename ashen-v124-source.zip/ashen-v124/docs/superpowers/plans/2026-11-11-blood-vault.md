# Blood Vault implementation plan

> **For agentic workers:** Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Publish a playable illustrated cartoon dungeon update with weapons, armor, persistent skill trees and bloody combat effects.
**Architecture:** Replace the rejected stock 3D prototype with original generated background and three transparent character sprites. Keep a pure deterministic game reducer separate from DOM rendering. Use versioned local saving, validate saves, and preserve experience/skills through death.
**Tech Stack:** Buildless ES modules, HTML/CSS, SVG icons authored here, original generated PNG assets, Node test runner.
**Spec:** Current user instructions: cartoonier, bloodier, launch updated version with weapons, armor, skill tree; earlier rule: rescue ally, lose gear at final death, retain XP.

## Global Constraints
- No stock textures, models, icon packs or UI kits in the new experience.
- Russian UI, phone portrait usable, desktop responsive.
- This release keeps two locally controlled heroes. Online rooms remain a separate unimplemented subsystem and must not be represented as working.
- Existing Site identity and private audience remain unchanged.

## Review Focus
- Invalid or old local saves must not crash startup.
- Repeated reward clicks cannot award extra experience or loot.
- Skills require points and prerequisites and cannot be bought twice.
- Death clears only the dead hero's equipment and bag, preserving experience and skills.
- Modal, keyboard and mobile navigation must not accidentally issue combat actions.

## Task 1: Rules and progression — complete
Files: `dist/rules.mjs`, `tests/rules.test.mjs`.
Interfaces: `createGame()`, `stats(hero)`, `act(state,type)`, `equip(state,heroIndex,itemId)`, `learn(state,heroIndex,skillId)`, `advance(state)`, `retreat(state)`, `restoreSave(raw)`; actions return cloned state and a bounded events list.
- [ ] Write failing behavioral tests for equipment, prerequisites/points, combat victory rewards, duplicate rewards, revival/death loss, save validation, room progression.
- [ ] Run `node --test tests/*.test.mjs`, observe missing rules fail.
- [ ] Implement pure state rules and validate persisted state.
- [ ] Run full tests green.

## Task 2: Original illustrated game UI — complete
Files: replace `dist/index.html`, create `dist/blood.css`, `dist/app.mjs`, `dist/icons.mjs`, `dist/art/`, `dist/manifest.webmanifest`, `dist/sw.js`.
- [ ] Copy generated original images locally; no legacy asset referenced.
- [ ] Build illustrated stage, hit effects, health/XP HUD and touch battle actions.
- [ ] Build inventory with equip actions and computed stats; build three-branch skill tree with prerequisite connectors and purchase buttons.
- [ ] Persist reducer state after actions, recover interrupted turns safely, add reduced-motion and blood toggle.
- [ ] Verify browser combat, inventory, skill purchase, reload, rescue and defeat; inspect portrait layout through a narrow window or responsive constraints where available.

## Task 3: Publish
- [ ] Run full rules tests and syntax checks; review new code independently.
- [ ] Use Sites helper with refreshed credential, package exact pushed source, deploy existing private Site.
- [ ] Confirm terminal successful deployment; open URL and provide concise handoff with remaining multiplayer/iPhone limitations.

## Execution ledger
Ruling: latest instruction explicitly says launch; proceed without a further design approval gate.
Ruling: illustrated 2.5D replaces full 3D to match the requested cartoon art and no-stock constraint; announced before implementation.
Ruling: skill/equipment progress is stored in this browser; no cross-device account save is claimed.

Task 1 complete: 13/13 tests green including reviewer regression cases.
Task 2 complete: browser equipment, learned skills, reload, victory rewards, room 2 transition and 390px iframe verified.
Final review: independent reviewer found three issues, all fixed with regression coverage.
