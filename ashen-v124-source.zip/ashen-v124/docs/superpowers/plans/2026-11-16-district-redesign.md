# River District Redesign Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Replace the generic town scene and cast presentation with a coherent river district.
**Architecture:** Existing Three.js actor rigs, material families and shared map remain. New authored architecture asset modules feed the existing static batching; the owner integrates camera, cast, HUD and publication.
**Tech Stack:** Three.js r170, native WebGL/PBR, ES modules, Node tests, existing Worker/D1.
**Spec:** docs/superpowers/specs/2026-11-16-district-redesign.md

## Global Constraints
- Preserve shared collision/work coordinates, saved appearance/economy and Site identity.
- No extra mobile post-processing target or large new model download.
- At least 44px control targets; respect reduced motion and pause.
- Do not equate automated tests or offline renders with physical-phone visual acceptance.

## Review Focus
- Character/work tool endpoints must remain aligned after visual changes.
- Building fade must not leak through unrelated city blocks or hide selectable peers incorrectly.
- Facial blink attributes must match merged geometry and survive equipment/hair/outfit updates.
- Transparent building materials must restore opacity/depth and release cloned resources once.
- UI and camera changes must preserve direct touch control, viewport resizing and modal canvas ownership.

### 1: Architecture and landmarks
**Files:** new dist/town/district-architecture.mjs, dist/town/workshop-architecture.mjs; modify dist/town/environment.mjs; corresponding focused tests.
**Interface:** both asset builders consume add/box/beam/ball/cyl/geometry/solidProps plus caller materials; own only geometries added to caller set.
- [x] Tests of finite closed shapes, collision footprints, distinct silhouettes and work anchor visibility.
- [x] Replace old building/landmark loops, integrate authored assets and bounded per-building fade grouping.
- [x] Run town route/visual/material/work tests and inspect actual geometry renders.

### 2: Cast and facial life
**Files:** dist/cinematic/hero-kit.mjs, artist-head.mjs, face-surface.mjs, actors.mjs, frog.mjs; tests/face-surface, artist-head, cinematic-actors, frog.
**Interface:** createArtistHead returns owned geometries with faceBlinkDelta; applyFaceSurface accepts shared blink uniform; hero kit updates the uniform without extra draw.
- [x] Red/green tests for finite eyelid deformation, independent blink state and reduced/pause behavior.
- [x] Rebuild costume silhouettes and base palettes, keeping original rig and outfit recolors.
- [x] Run production rig/tools/wardrobe tests; inspect front, side and work poses.

### 3: Framing, occlusion and HUD
**Files:** dist/town/view.mjs, new town camera/visibility helpers if needed, new dist/town/district-ui.css, town.html.
**Interface:** camera helper returns rendered-frame offset; district fade responds to camera/player segment with smooth opacity and independent building states.
- [x] Red/green tests for camera orientation, fade reset, hidden target filtering and reduced motion.
- [x] Implement closer framing and readable UI preserving all semantic IDs.
- [ ] Check route controls, canvas inspection resize, SVG/button targets and pointer lifecycle.

### 4: Verify and publish
- [x] Independent review, resolve observed failures, full tests and visual studies.
- [x] Update service worker and entry cache versions.
- [ ] Build and hash-check every emitted asset, commit/push exact source and save/deploy on existing Site.
- [ ] Report actual scope and verification limits without quality-score claims.

Verification: full Node suite 1500 tests,1493 pass,0 fail,2 skipped,5 existing TODO. Offline cast/scene studies are geometry/material checks; direct browser and physical-phone visual acceptance remain unavailable.
