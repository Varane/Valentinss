# Bosses, rescue camp and distant townspeople

**Goal:** Replace more conspicuous placeholder geometry in installed game paths, retaining simulation and the mobile full-rig cap.

- Six bosses: shaped plates, hollow pauldrons, crowns, horns, shields and hats. Static accessories merge per bone/material; moving jewelry stays independent. Borrowed actor/source resources remain unchanged.
- Rescue camp: curved canvas, curtains, ropes, fishing/repair/herbal/map/sewing details and cooking hearth. Original five arrival stages, centers and ground envelopes preserved; no new services/collision or lights. Full camp12merged draws/3shared finishes/6,787triangles.
- Distant players: three instanced draws retain chosen clothing/hair colors, skin, heading, gestures and simple gait. Rounded body/limbs/feet replace generic capsule and box arms. Frog proportions stay distinct. No extra full-rig construction; geometry about1,164triangles/person, maximum40slots. Instance reuse clears prior owner gesture.

## Validation
- 1726 cases:1719 pass,0 fail,2 skipped,5 existing TODO.
- All461 packaged files fetched through Worker and hashes verified.
- Before/after six-boss, camp1vs5, and distant-pose offline production geometry inspected. Render proofs are not browser screenshots or phone FPS measurements.
- Independent review checked shader chunk/attribute order, local transforms, masking, ownership, batching, cutaway and disposal.
- Proofs: `work/graphics-remake-review/bosses-v97-after.png`, `work/camp-remake-review/README.md`, `work/graphics-remake-review/town-crowd-after.png`.

Publish exact checked source and matching artifact. No claim that the entire visual remake is finished.
