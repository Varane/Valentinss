# Armor, cave and material graphics continuation

**Goal:** Carry the shared visual direction through removable armor, wardrobe previews, crypt architecture and surface shading while retaining game behavior.

- Three actually skinned armor constructions: stitched leather, rolled/riveted steel, articulated steel. Coat waist and Danik apron masking corrected; source anatomy remains untouched.
- Ten wardrobe and three armor images rendered from actual clothing meshes, 320² transparent WebP, about125KB total. Catalogue, rewards, shop and duel look previews use these images. Source/license/hash provenance included.
- Cave masonry relief, corner piers and four-facing arched recesses stay inside existing solid cells. Flat floor engraving and palette distinguish five floor profiles. Detail is attached to original cell cutaway and owned-instance disposal.
- River gets restrained shallow/deep tint, bank roughness and flow cues; the depth adjustment excludes fountain/droplets. Water shader composes previous hooks and transforms instance coordinates.
- Existing hero/frog ground-contact draws use a soft shader fade instead of hard disc edges, with no new GPU resource or render pass.

## Verification
- Full suite1716 cases:1709 pass,0 fail,2 skipped,5 existing TODO.
- All458 packaged resources fetched through Worker and SHA256 verified.
- Independent review covered source geometry ownership, armor masking, cave cutaway, shader keys and resource cleanup.
- Actual CPU Cycles geometry/garment proofs inspected; these do not verify browser shaders, Safari behavior or device FPS.
- Cave seed123desktop triangles30,426→32,660 (+7.34%); structural batches8→10 plus one flat engraving draw. No new lights or shadow passes.
- Proofs: `work/cave-architecture-review/README.md`, `work/graphics-remake-review/armor-v96-tiers.png`, `work/graphics-remake-review/wardrobe-icons-v97.png`.

Publish only the exact checked source commit and matching built artifact.
