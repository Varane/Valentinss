# City Beginnings Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Start play in the town and add three optional, persistent discoveries.
**Architecture:** Keep campaign module/saves unchanged at a new HTML entry. Share discovery data/validation between server and town controller. Native dialog owns all puzzle interaction.
**Tech Stack:** ES modules, Three.js/SVG, existing Worker/D1 JSON store, Node/SQLite tests.
**Spec:** docs/superpowers/specs/2026-11-17-city-beginnings-design.md

## Global Constraints
Existing Site/DB, collision/work anchors, save keys and heroes unchanged. Three one-time20XP rewards, no new currency. Wrong guesses do not disconnect. Controls44px minimum; reduced motion retained. Publish only verified exact source.

## Review Focus
Root must open town and still permit solo/coop departure. Existing campaign saves must continue. Rewards must not duplicate on retries/reconnect/concurrent submissions. Stale puzzle responses cannot replace a new dialog. Peer data must not leak private discovery history.

### 1: Persistent discovery model
- [x] Test reachable anchors, right/wrong answers, invalid/remote submissions, one-time XP/title, reconnect and peer privacy.
- [x] Implement dist/remake/city-discoveries.mjs; integrate worker/town.mjs in its existing optimistic commit.
- [x] Verify focused Node and real SQLite town tests.

### 2: City entry and exploration UI
- [x] Test root/town same shell, campaign entry/saves intact, hero registration choice and guarded puzzle response ownership.
- [x] Move existing index to expedition.html, copy town shell to index; update town departure links and campaign structural tests.
- [x] Add five-hero signup choice; city discovery dialogs, progress journal, title display and inn departures. Register discovery places in navigation/atlas/labels and next objective.
- [x] Verify new and existing UI/appearance/routes tests.

### 3: Review and publish
- [x] Fresh whole-diff review and regression fixes.
- [x] Full suite, cache bump, build, all emitted asset hashes.
- [ ] Commit/push exact source, save and deploy on existing public Site. Report actual scope and testing limits.

Verification:1531 tests total,1524 pass,0fail,2skip,5existingTODO. Built Worker serves identical city at root/town and campaign at expedition; all379 assets hash-checked. Module-graph check now covers all4 HTML entries and parses compact ES imports. Independent review +capped XP reporting regression resolved. No phone/browser visual acceptance; native atlas SVG inspected offline.
