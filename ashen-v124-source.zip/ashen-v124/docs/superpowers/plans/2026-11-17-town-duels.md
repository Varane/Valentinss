# Town Duels Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement inline, then one fresh whole-diff review.

**Goal:** Real city sparring with negotiated rules/loadouts and lively truthful health bars.
**Architecture:** Pure deterministic duel model, existing optimistic multirow store, isolated authenticated duel API, town-pulse settlement, native negotiation screen and DOM health effects.
**Tech Stack:** ES modules, Three.js, CSS/DOM, Worker/D1 JSON, Node/SQLite tests.
**Spec:** docs/superpowers/specs/2026-11-17-town-duels-design.md

## Global Constraints
Cookie authority. No stakes/item loss/progression changes.100HP,3m LOS range,10m boundary,90s fight,3s countdown. Both ready +both final confirm exact terms; edits invalidate all consent. Town coordinates/seq ownership preserved.44px/reduced motion. Keep pending graphics roadmap docs unchanged.

## Review Focus
Unsolicited offers cannot freeze targets. Every rule is enforced and stale revisions cannot start a fight. Owned gear rechecked at confirmation without leaking inventories. Atomic updates cannot overwrite movement/duplicate damage. Disconnect/cancel/KO release both players and health effects never replay/fake health.

###1: Pure model/verified gear
- [x] RED→GREEN rules validation, consent reset, final review, gear ownership/class, automatic damage/LOS/block/counter/heal, timeout/escape/disconnect and bounded catch-up.
- [x] Implement dist/town/duel-model.mjs and shared display schema; model consumes authoritative positions and clock only.

###2: Server lifecycle
- [x] Real SQLite tests challenge/privacy/blocks/accept/rules/ready/confirm, simultaneous edits, stale consent/forged HP, expiry, rules enforcement and release/reconnect.
- [x] Implement worker/town-duels.mjs endpoint/context; integrate worker/site.mjs and worker/town.mjs authoritative mirrors and multirecord commit.

###3: Interface and animation
- [x] RED→GREEN client stale response/draft/terms ownership and animated HP model/DOM resource/reduced-motion tests.
- [x] Native two-column rules/loadout preview, ready/review/confirm; town challenge action and invitation banner.
- [x] Fighter HUD +world bars, capped sparks/trail/shake; attack/hit/guard animation event adapters. Preserve existing social/modal/joystick ownership.

###4: Release
- [x] Fresh review, regression fixes and full suite.
- [ ] Cache bump, build/hash all assets, commit/push exact source, save/deploy existing public Site.
- [ ] Report actual features and visual/device verification limits.

## Verification record

Full regression: 1,578 cases, 1,571 passed, zero failed, two existing skips and five existing TODOs. Following reviewer fixes, 19 focused duel model/client/DOM/SQLite cases passed. Fresh Astra whole-diff review found and resolved legacy hero mutation, stale preview consent, transient state-load recovery, and disabled movement drift. Negotiation also shows selected hero/outfit. Browser layout and real phone appearance were not verified: browser tools are unavailable. No browser automation was installed. All 390 emitted resources were served from the built Worker and matched both recorded SHA256 and current source assets. Worker size: 9,123,543 bytes. Exact source push and native publication follow.
