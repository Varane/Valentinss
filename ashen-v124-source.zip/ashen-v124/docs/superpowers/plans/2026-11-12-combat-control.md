# Combat control consistency Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Make retreat, enemy guidance and timed dodge rewards consistent with the player's actions.
**Architecture:** Retain the existing simulation and Three.js view. Fix decision rules in core/assistance, expose no new network protocol, and pin behaviors with regression tests and visibility-limited campaigns.
**Tech Stack:** JavaScript ESM, Three.js, Node test runner, existing Sites Worker.
**Spec:** docs/superpowers/specs/2026-11-12-combat-control-design.md

## Global Constraints
- Preserve +50% next-hit counter and 1.4s duration, HP/damage, save version and PvP rules.
- Final 0.28s of a nearby melee windup qualifies; earlier/remote/wall-blocked dashes do not.
- Manual attacks override assistance; no new browser QA claims.

## Review Focus
- Retreat with a held joystick must not turn into an automatic attack toward the pursuer.
- Stationary assistance and manual attacks retain current behavior.
- Near hidden guard must not suppress a farther visible threat.
- A successful dash leaves melee range and still receives its counter exactly once.
- Multiple threats, walls and repeated frames must not farm rewards or change saved enemy schema.

### Task 1: Retreat-safe assistance
Files: dist/remake/assistance.mjs; tests/solo-assistance.test.mjs.
Interface: soloIntent(run,input,automatic) remains unchanged.
- [x] Add tests for retreat, stationary assist, hidden ranged target and manual override; run red.
- [x] Filter automatic targets with canSee using the intended facing; reject movement away (normalized movement/target dot < -0.25).
- [x] Run assistance tests green.

### Task 2: Visible objective priority
Files: dist/remake/core.mjs; tests/playability/combat-control.test.mjs.
Interface: objectiveFor(run) remains unchanged.
- [x] Test nearer hidden versus farther visible guard; run red.
- [x] Choose the nearest visible guard when one exists; retain hidden fallback for perception-aware UI.
- [x] Run objective and guidance tests green.

### Task 3: Timed evade counter
Files: dist/remake/core.mjs; tests/playability/combat-control.test.mjs.
Interface: act(run,'dash',direction) remains unchanged.
- [x] Test imminent melee dash, early/distant/blocked/caster exclusions, and no duplicate reward at strike; run red.
- [x] Mark rewarded windups in transient WeakSet on run; reset on fresh windup. Preserve existing damage-resolution perfect-dodge fallback.
- [x] Run combat regressions, full campaign acceptance and complete suite; investigate failures.
- [x] Independent code review, exact Worker build/route checks, commit and publish existing public Site. Record actual results and limitations.

## Execution record

All three tasks completed inline. Each original defect was reproduced before correction. Final independent Astra review found two further failures (multi-enemy autoaim bypass and repeated reward after reload); both gained failing regressions, were fixed and passed. No deferred findings.

Ruling: share auto-target eligibility in `dist/remake/targeting.mjs` and carry an automatic-attack marker through the actual strike — assistance alone cannot constrain target reselection.
Ruling: persist optional `dodgeRewards` IDs while retaining save version 1, and conservatively reconstruct marked windups for legacy mid-dash saves with an active counter — transient WeakSet alone cannot preserve once-only rewards across reload.

Final complete suite: 1133 tests, 1126 pass, 0 fail, 2 skipped, 5 existing TODO. Final Worker 9,803,777 bytes; exact build routes verified. Browser/GPU/phone play remains unverified.
