# Gear, Activities and Battle Graphics Continuation

**Goal:** Extend the common visual direction to equipped items, inventory, city production and combat feedback.

**Constraints:** Preserve combat, rewards, work timers, collision, mobile visibility, reduced motion and resource lifetimes. No new fullscreen passes or local lights. Actual rendered assets must match installed production paths.

- [x] Gear: differentiate production blade/staff geometry and fitted craft details; remove detached rotating jewels.
- [x] Runtime: load optional bounded weapon library for town as well as expedition, keep procedural fallback and release late/owned resources.
- [x] Inventory: render the eight production weapons as transparent images; connect catalogue and definition image paths.
- [x] Activities: model fish anatomy, folded leaves, flowers, staged plant growth, coal and shaped forged billet.
- [x] Growth review: distinguish plant maturity from physical hand-held bouquet scale.
- [x] Combat: small directional projectiles, soft-edged haze/dust, physical potion labels, two-draw ordinary health bars and independent rarity.
- [x] Cave: remove floor-transition overrides of the lighting direction.
- [ ] Verify final integrated source, rendered geometry, asset hashes and publish exact source.

Evidence must distinguish offline asset renders, model/resource tests and real-device checks. No device FPS claim from triangle counts.

## Release checks
- Full suite: 1688 cases, 1681 pass, 0 fail, 2 skipped, 5 previously marked TODO.
- All 439 packaged assets fetched through Worker and SHA256 verified.
- Independent reviewer approved optional weapon loading/resource leases, botanical maturity and icon installation.
- Eight transparent production gear renders total 42,832 bytes.
- Activity geometry: mobile26 draws/13,228 triangles; these are scene statistics, not phone FPS.
- CPU Blender proofs in `work/graphics-remake-review`: gear-icons-after.png and activities-{fish,garden,forge}-offline.png. They omit custom shader rendering and do not constitute device verification.
- Publication follows exact source push.
