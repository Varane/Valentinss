# Readable Town Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Make the whole town navigation/action loop readable and consistent.
**Architecture:** Pure navigation/atlas model plus existing town controller; reusable 3D route trail; existing native dialog owns atlas focus. Shared collision/work coordinates stay authoritative.
**Tech Stack:** Native ES modules, Three.js, SVG, Node tests, Worker/D1.
**Spec:** docs/superpowers/specs/2026-11-17-town-legibility-design.md

## Global Constraints
Preserve Site/DB and all existing town anchors. Controls >=44px. No heavier mobile rendering pipeline or large download. Selecting a place never starts work without an explicit action.

## Review Focus
Manual input/modal/reconnect must clear every route representation. Destination distances follow routed corners. Work starts only at the existing exact station. Atlas must include board and be accessible via native dialog. Dense nearby place labels must not cover the hero or capture movement gestures.

### 1: Navigation and action model
- [x] Write failing tests for createTownJourney start/read/cancel, valid routed segments to every city place, all route distances and nearest-place selection.
- [x] Implement dist/town/navigation.mjs, consuming existing townRoute/TOWN_PLACES and UNICORN; expose CITY_PLACES, createTownJourney, nearestTownPlace and townObjective.
- [x] Integrate all controller route entry/exit paths, explicit actions and a single persistent objective/route tracker.
- [x] Verify focused route/control tests and source lifecycle regressions.

### 2: Atlas and information hierarchy
- [x] Test atlas has real footprints, correct normalized positions, all destinations including jobs, and escaped labels.
- [x] Implement dist/town/atlas.mjs with an authored inline SVG atlas. Native townmap modal renders routes/player and grouped destinations, with explicit close button.
- [x] Simplify skills into current/next unlock with optional details; show active job before the other contracts. Add persistent modal close affordance and clear labels on primary controls.
- [x] Verify UI action integration including modal cancel and late async responses.

### 3: Spatial cues
- [x] Test route-trail geometry bounded/reused/disposed and static work paths preserve walkability and budget.
- [x] Validate service NPC frontages with townWalkable/townPath; put hosts beside rather than inside buildings.
- [x] Implement dist/town/route-trail.mjs, update view labels/route ownership; add secondary paths to work stations in environment.mjs.
- [x] Verify route corners, repeated destination change, occlusion and no resource growth.

### 4: Release
- [x] One fresh whole-diff reviewer, fix important findings with regression tests.
- [x] Full suite, build and emitted asset hash verification; advance cache versions.
- [ ] Commit/push matching source, package and publish on the existing public Site. Report exact scope and testing limits.

Release verification:1516 total tests,1509 pass,0 fail,2 skipped,5 existing TODO. All375 preflight assets served and matched their SHA256. Independent review findings and equivalent appearance-save late-close regression fixed. Native SVG atlas inspected offline; browser/phone visual acceptance unavailable.
