# Cave clarity and rescued camp

User requests clearer first-time play, distinct rounds/bosses, reasoning puzzles, rescued people growing a city camp with meaningful unlocks. Existing campaign is browser-local five-floor investigation, while town activity/economy is authenticated and authoritative.

Implement inline on current branch; preserve pending visual roadmap docs. Keep auto combat, tactical mode, old saves, duels and trading. No new engine or dependencies.

New runs opt into caveVersion1 authored encounters: shield timing; banner priority; healer priority; ranged crossfire; final bell shield. Existing AI already enforces armor, banner aura, healer and fan shots. Give each floor one concise tactical instruction and an optional expanded explanation. Replace wordy briefing with objective and rescue portrait/name. Add five short visual reasoning challenges at existing deduction gates, preserving deduction persistence and free hints/no death penalties. No change to old saves' combat composition.

Five rescued residents are awarded at actual cleared-floor deduction gates. Persist arrivals per account in town, with retryable account-bound client sync from local campaign progress. Local campaign progress is self-reported and is not competitive proof: arrivals grant no money/tradable items/leaderboard power. Repeated reports are idempotent; authenticated account isolation. Each resident offers one town skill task measured from a server-captured XP baseline after accepting it, then a bounded one-time cosmetic or skill XP reward. New cosmetic outfit uses existing rendering palette mechanism and explicit camp entitlement, not a forged completed-jobs count.

Camp is an accessible new city point. Add tents, beds, supplies and five distinct civilian residents as arrivals increase; use existing actors and bounded meshes. Personal camp reflects own account; do not pretend shared world milestones. One concise resident/task/reward card at a time. City progress survives reload and new device; local saved campaign sync can be retried.

Approaches: Full campaign rewrite rejected for save/coop risk. Pure copy edits rejected because combat would remain identical. Selected: authored compositions + interactive deductions + persistent camp using existing model and actors.

Validation: deterministic compositions/seeds and save round-trip; challenge solving/reset; real SQLite auth/isolation/idempotency/task baselines/one-time rewards; town route and camp geometry disposal; full regression, fresh reviewer, build/hashes and existing Site publication. Browser/device tools unavailable: do not claim visual/device QA.
