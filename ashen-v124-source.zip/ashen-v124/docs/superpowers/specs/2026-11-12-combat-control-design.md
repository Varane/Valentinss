# Consistent combat controls and guidance

Improve solo play without replacing the renderer or changing PvP. Automatic attacks must respect current visibility and the intended movement direction: movement away from a target should remain a retreat. Explicit manual attack remains authoritative. Guidance should prefer a visible guard over a nearer hidden one. A dash started inside a nearby melee telegraph's final 0.28 seconds earns the promised counter even when it successfully moves outside strike range; each windup awards once. Earlier/remote/wall-blocked dodges do not award.

Keep the existing +50% next-hit counter, 1.4s duration, HP, enemy damage, progression, public hosting audience and save version. Rendering/mobile browser QA remains unavailable and cannot be claimed. No difficulty gate based solely on bots.
