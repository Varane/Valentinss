# Friends, private chat and overhead speech

User requests a better in-game chat: friends, online/last-seen, private messages and custom overhead text with RuneScape-like colors/effects. Implement/publish without additional questions under standing authorization.

Chosen approach: native shared social dialog and a small authenticated Worker API using existing D1 JSON documents, independent from high-frequency town movement. No external chat service or new database migration. Town has a built-in entry; expedition/classic get the same friends/messaging launcher and presence heartbeat.

Friends use reciprocal requests/acceptance. Online/last-seen outside the public city are visible to accepted friends only. Search by name or exact account ID, disambiguating duplicate names with a short tag. Russian/ASCII name matching is case-insensitive. Nearby players are available directly. DMs can be sent to any known account except blocked relationships; requests and message sends are rate-limited and bounded. Users can remove/block/unblock. Blocking cancels friendship/requests in both directions; old conversations remain readable privately, future delivery is stopped. No unsolicited real-user messages during testing.

Private threads retain60 messages; each profile tracks30 recent threads,50 friends,20 incoming/outgoing requests,50 blocks. Thread writes and both profiles commit atomically with optimistic storage versions. Session cookie is the only sender authority. Client-generated timestamped request IDs give retry idempotence for10minutes. Server rejects expired IDs without delivery; retains every accepted receipt in that window (at most601 at one send/second), and also checks retained thread IDs. Mutations include an expected-actor precondition checked against cookie identity so queued drafts cannot cross account switches. Only participants may read a thread. Unread badges and explicit read-through IDs cannot mark newer unseen messages read.

Presence updates on visible tabs every10s (3s while social dialog open), shared across town/campaign/coop. Online expires after35s, current town presence after15s. Last-seen is server time, shown in relative local UI. No per-frame social network calls.

Overhead speech is town-only, up to80 Unicode codepoints,9s lifetime,2.5s cooldown; six named safe colors and five allowed effects (none/wave/bounce/glow/type). No markup interpretation. Public town projection exposes only active speech. DMs allow400 codepoints. Control and bidi formatting chars are removed; safe color/effect allowlists and reduced-motion equivalents. Bubble rendering has separate anchors from name labels, at most4 mobile/8 desktop nearby peers plus self; no geometry allocations or extra WebGL effects.

One native dialog includes Nearby/Friends/Private/Overhead editor, live preview, send feedback, history, unread and request badges. No poll overwrites a typed draft/focused editor. Closed/changed conversations cannot be reopened by late responses. Dialog opening pauses direct town input/cancels route; closing restores it. Existing emotes/party search remain reachable.

Constraints: preserve current Site, root-city entry and expedition/coop saves, town collision, economy and existing API privacy. Buttons>=44px. No browser-control tools available; do not claim browser/physical-phone acceptance from Node tests.
