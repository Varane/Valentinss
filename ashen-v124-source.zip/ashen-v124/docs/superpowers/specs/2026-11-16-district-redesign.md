# River district and cast redesign

The user rejected incremental surface changes and authorized a complete reworking of the representative town scene and its heroes. Previous numerical quality claims and test counts are not visual acceptance. The deliverable is a visibly different, coherent playable scene, not another texture swap.

Direction: an old river trading town with stone arcades, layered timber galleries, real roof thickness and dormers, warm workshop light and a restrained slate/linen/clay palette. Four distinct architectural identities and working landmarks replace the generic sheds. Human silhouettes and clothes are rebuilt around Volkhv, wizard, mechanic Danik and IT master Vitalik; Kvak remains an expressive courier. Natural blink/head motion and readable framing make characters feel present. Compact dark HUD frees the scene from the large cream banner.

Approach chosen by implementation judgment under the user's standing instruction to work without questions: retain Three.js, the server, shared collision coordinates, account/save data and live Site. Replace scene geometry and character presentation, not networking or economy. A completely new engine would disrupt the playable web/mobile product and is outside this scene-first artistic reset.

Requirements:
- Preserve TOWN_BUILDINGS, TOWN_PLACES, collision, work anchors, hair/outfit ownership and gameplay controls.
- Replace all four main building assemblies and forge/dock/garden silhouettes with authored closed mesh assets using existing PBR material families.
- Rework base hero costumes and palettes while earned outfits, gear, barber and all animations remain functional.
- Add facial blinking through the existing merged face draw; respect reduced motion and pause.
- Frame the player closer; fade only occluding building surfaces smoothly if the closer camera would hide them. Touch movement uses the rendered camera.
- Keep 44px control targets, avoid more help text, preserve semantic IDs and accessible states.
- Keep mobile scene budgets bounded, adaptive resolution, no extra mobile post-processing target, no large new downloads.
- Preserve current Site/DB/audience and publish the verified commit.

Acceptance: real scene geometries/animations/material composition and UI structure checked; independent source review and full regression suite; compare representative renders. Direct browser/phone GPU QA is unavailable when the managed environment has no cua_repl/browser tools. Do not claim that renders or passing tests prove 9/10 visual quality or physical-device FPS.
