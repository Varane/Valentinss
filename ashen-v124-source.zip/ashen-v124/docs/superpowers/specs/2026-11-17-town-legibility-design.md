# A town a player can read

The user wants a larger rework because objects/actions are still misplaced and unclear. Rebuild the navigation and interaction structure, retaining the new river district and all saved progress. Standing instruction: implement without additional questions and publish on the existing Site.

Chosen approach (builder's decision): coherent spatial wayfinding plus explicit interactions. A cosmetic-only reskin would preserve inconsistent flows; relocating collision/work stations would disrupt shared server coordinates. Keep those coordinates and give them a readable atlas, connected side paths, in-world place labels and one persistent next action.

- A native-dialog town atlas shows actual building footprints, river, fountain, player and destination. Group destinations into town services, workshops and adventures; rows have a short outcome and icon. Selecting one walks there, never silently starts work.
- Every route entry (atlas, world click, skill, job, reward) uses one navigation helper. Show the target and remaining routed distance; Stop/manual movement/modal opening/reconnect cancels both route and marker. Failed routes must explain failure. On arrival reveal the explicit contextual action.
- The next job step remains accessible in one compact tracker, with no paragraph of instructions. If no job is active, point to the board; avoid repeated tutorial overlays.
- Skills show level/current benefit/next unlock initially; full unlocks remain in an expandable detail. Tasks show the active assignment first with clear next stop.
- Nearest context uses distance ordering rather than array order, and actions stay bound to the displayed place. Local skills align exactly before starting (existing work rigs require it), with no automatic work just from selecting a place.
- Move service NPCs out of building collision footprints and away from solid props, leaving space beside each shared approach anchor.
- In-world labels identify visible nearby places and route target; hide blocked/offscreen labels. Give workshops side lanes that actually lead to their existing anchors. No new collision obstacles, network protocol or heavy downloads.

Constraints: preserve existing Site, DB/economy/avatar/outfit state and town anchors. Controls >=44px. Existing mobile render governor and reduced motion remain. Browser tooling unavailable in this environment at investigation time; do not equate module tests/offline proofs with phone QA.
