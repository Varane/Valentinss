# Begin in a city with things to discover

User asks that the city be more interesting and that the game starts in it. Standing authorization: implement and publish on existing Site without more questions.

Chosen: city is the root entry, existing campaign moves intact to /expedition.html. /town.html remains an alias with the same shell. Keep all saves/appearance/accounts and classic coop route. A redirect-only root would retain an unnecessary extra navigation; replacing the campaign would lose existing play. Root and town shells share exact source bytes, enforced by a test.

New players pick one of five existing heroes in the sign-up form before entering the city. Returning profiles preserve their look. Existing key recovery remains.

Add three optional city discoveries, each with an actual reachable anchor and one short puzzle: repeat a fountain's three-note pattern; reconstruct the boatman's recipe in the inn; choose two numbers totalling seven at the watchman's lock. Wrong answers reset safely, with no punishment. Three discoveries each award20 XP once (fishing/cooking/smithing), persisted atomically with the town player. A player who solves all three receives the public title «Свой в городе». No new currency or grind system. These are optional; solo campaign/coop can be entered immediately.

Native-dialog interactions show visual symbols and concise instructions, explicit back/close, correct pending guards. No late answer can replace a newer panel. Disconnected/remote/forged submissions cannot award progress. Public peers see only the earned title, not puzzle answers or discovery history. Existing JSON storage supports this without schema migration.

City atlas, nearest-place controls, labels and current objective include the new encounters. Active assigned jobs retain priority; otherwise guide to the next undiscovered city secret, then back to jobs. Inn offers direct solo/coop entrances. Existing town bounds/collision/work anchors stay unchanged; don't add solid objects into walkable space. Browser tools unavailable, so automated module/server tests and build verification cannot establish phone FPS or visual acceptance.
