# Clothing from town jobs

Unlock four account-wide clothing sets at1/3/5/8 completed jobs: traveler, artisan, ranger and warden. Every set has actual torso-attached geometry plus an outfit palette; all five heroes support it. Existing coins, weapon pairs, master armor, hair colors and artifact rewards remain. Existing completed counts unlock clothes retroactively without reissuing wallet rewards.

Appearance stores an optional outfit field per hero. Old two-field hair/color records remain unchanged. Server town wardrobe changes validate eligibility; haircut requests preserve an omitted outfit for older clients. Co-op derives eligibility from the authenticated town record and removes unearned claims. Town peers receive the actual selected outfit.

Full-body wardrobe preview is available through Hero and My outfits on the job board. Cancel makes no network mutation; Wear saves authoritatively. Reward screens prioritize outfit preview and direct try-on; old lastReward metadata resolves to the new clothing milestone.

Verify old appearance compatibility, unlock checks, peer/reconnect persistence, co-op forgery rejection, actual geometry/hair/equipment behavior, preview cancellation, model resources and full regressions. Offline outfit renders inspect fit; no browser/physical-phone verification claimed.
