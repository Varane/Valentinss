# Cave combat: decisions and contact feedback

This release addresses three concrete problems in the current authored solo cave (`caveVersion: 1`):

1. Automatic light hits cancelled the sentinel's warning; hits during recovery replaced its authored recovery with a 0.18s stun. Basics now preserve its committed swing, while the existing skill interrupts it. Recovery windows remain intact, including the frog's stomp. Health and damage budgets are unchanged.
2. A dodge counter could be spent on a missed swing and ignored by a skill. It now applies on confirmed contact. One skill target receives the bonus. Mage bolts launched while armed remain eligible through save/reload; only one can redeem a currently live charge. The 1.4s window remains unchanged.
3. The renderer previously announced a counter before it landed. It now distinguishes the ready window from an actual empowered hit, using a bounded green impact, stronger animation emphasis and a marked damage number. The simulation does not pause. Existing reduced-motion camera suppression remains in force.

Automatic basics, existing skill/dash buttons, tactical mode, old saves and the separate authoritative co-op/PvP engine are preserved. The real-time sentinel cue names the skill interrupt.

Verification includes regression scenarios for windup, recovery, misses, area targets, airborne projectiles and save/reload; full five-chapter tactical journeys for both current and legacy cave campaigns with different heroes and upgrades; and the repository suite. These are executable engine/controller checks, not a live browser or phone playtest. Browser control is unavailable in this session. Subjective enjoyment remains to be assessed in play.

Final verification: 1,858 passing, zero failing, two skipped and five pre-existing TODO cases (1,865 total). Twelve five-chapter journeys passed across current/legacy campaigns. Worker build emitted 470 assets; every emitted asset was fetched through the built worker and its SHA-256 matched the report. Tactical counter reporting was also corrected to depend on confirmed hit events, preserving deterministic forecast/execution results.
