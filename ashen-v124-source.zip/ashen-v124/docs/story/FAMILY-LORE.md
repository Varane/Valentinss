# Кровосклеп — family lore handoff / семейный лор

Author: delegated lore writer Astra. Delivered 2026-11-11. Scope: `dist/lore/**` and this document. The C director approved `knight = Danik`, `mage = Valentin`; C1 owns adoption into the campaign. Publication and runtime integration remain with their owners.

## Ready data

`dist/lore/family.mjs` contains all six rooms in RU and EN. It has no imports or side effects. It changes no saved actor ID, reward, choice, enemy or party size.

| Export | Use |
| --- | --- |
| `FAMILY_ALIASES` | `knight → danik`, `mage → valentin`; preserve existing save IDs. |
| `FAMILY_CAST` | Five named voices, localized names, narrative role and channel. Only Danik/Valentin have actor IDs. |
| `FAMILY_ROOMS` | Six room records: hook, intro, branched victory/exit, defeat, optional exchange, implementation note. Every authored text has RU/EN. |
| `familyName(id, locale='ru')` | Display alias for an actor or cast ID. Unknown ID returns an empty string. |
| `familyDialogueFor(roomId,campaign={},locale='ru',profile?)` | Fresh `{intro,victory,defeat,exit}` strings; unknown room returns `null`. |
| `familyLoreFor(roomId,campaign={},locale='ru',profile?)` | Dialogue plus `roomId,hook,optional,encounter`. `encounter` is an authoring note, not player-facing copy. |
| `familyText(value,locale='ru')` | Localize a `{ru,en}` value or pass through a string. |

`profile` is optional for author previews. Supply the current resolved profile in the game: dead or zero-HP heroes are excluded from direct dialogue. This does not revive or rename them. A missing flag gets its own neutral line, so an undecided choice never becomes an invented rescue, execution, broken seal or burned book. Only own boolean flags count. False and absent remain distinct.

Integration example, to be adopted by the file owner:

```js
const extra = familyDialogueFor(room.id, campaign, locale, profile);
const story = extra ? {...room.story, ...extra} : room.story;
// Keep the canonical survivor-aware ending on final victory.
if (room.id === 'throne' && campaign.status === 'complete') {
  story.victory = room.story.victory;
}
```

Keep the canonical title, objective, choice label, mechanical description and final `endingFor(campaign,profile)`. These exchanges are seasoning alongside the objective, not a substitute for telling the player what to do. A final overlay may be shown separately after the canonical ending. Recompute on language change. There is no save migration.

## Tone and fictional roles

**RU.** Даник и Валентин идут в склеп за Алой переписью. Мама держит открытым путь домой; Гюлин ведёт карту проходов и помогает тем, кого удалось вывести. Рядом с воротами оставлен старый разговорный камень: он передаёт короткие голоса из лагеря. Это литературная условность для текста, не новый предмет, модель или сетевая функция. Родство проявляется в доверии, ожидании и действиях: «Идите, я с ними»; «Свет у порога. Я жду».

**EN.** Danik and Valentin descend for the Scarlet Ledger. Mama keeps the road home open; Gülin maps the passages and helps those brought out. An old speaking stone carries brief voices from camp. It is a narrative convention for text, with no new item, model or network feature. Family feeling comes from trust and follow-through: “Keep going. I’m with them.” “There’s a light at the threshold. I’m waiting.”

All personalities and deeds here are invented for these game characters. Their real ages, occupations, temperaments, faiths, relationships and private histories are unspecified. Mama commands the return route; Gülin makes independent decisions. Neither is reduced to a running family joke or a compulsory captive. There are still two player slots.

Danik notices physical absurdities and answers in short concrete phrases. Valentin reads the runes and the trap behind a polite sentence. Their humor concerns an immediate object: a gate, a bell, a ridiculous blood form. Mama's care is practical and firm. Gülin's calm promises are followed by action only when the rescue branch allows it. No jokes over the cost of an abandoned prisoner or a final death.

## Six-room arc

| Existing room ID | Scene and choice connection | Short exchange |
| --- | --- | --- |
| `threshold` | A welcome inscription conceals a blood toll. Learn to recognize a wind-up and stay close enough to help. | Даник: «На воротах: “Добро пожаловать”». Валентин: «Мелким шрифтом: “С кровью”». / Danik: “The gate says ‘Welcome.’” Valentin: “Fine print: ‘Bring blood.’” |
| `surgery` | Numbered chains surround people who still answer to names. `freedPrisoners` alone permits Gülin's evacuation line after victory. | Даник: «Люди всё ещё там». Валентин: «Да. Я слышу». / Danik: “They’re still in there.” Valentin: “Yes. I can hear them.” |
| `chapel` | A bell cast from old defenders' swords now summons collectors. `silencedBell` selects relief or audible danger. | Валентин: «На колоколе руна гостеприимства». Даник: «Стража очень торопится нас встретить». / Valentin: “That’s a hospitality rune on the bell.” Danik: “The guards seem very keen to meet us.” |
| `chains` | The clerk who kept the book became its prisoner. `sparedKeeper` determines whether a witness or only a diagram leaves. | Даник: «Идёшь впереди. Цепь оставь». / Danik: “You lead. Leave the chain.” |
| `antechamber` | An oath rune now feeds a throne with coerced blood. `brokenSeal` controls whether that supply has stopped. | Валентин: «Печать больше не питает трон». Даник: «Пусть встанет сам». / Valentin: “The seal can’t feed the throne now.” Danik: “He can stand up himself.” |
| `throne` | The old oath-hall became an office for owning living names. `claimedLedger` separates possession of power from release. Canonical ending handles survivors. | Даник: «Он приготовил нам места в книге». Валентин: «Я предпочитаю у огня». / Danik: “He’s saved us places in the book.” Valentin: “I prefer a place by the fire.” |

## Optional goblin and saga texture

**Щеп / Splinter** is a small goblin copy clerk who knows that a form can be used as a weapon. The optional gate exchange fits in two lines: «Имя? Цель визита? Предпочтительная группа крови?» — «Жалоба. Групповая». / “Name? Purpose of visit? Preferred blood type?” — “A complaint. Group booking.” He can later appear as a witness in a recess of the archive. He never replaces the canonical keeper, creates a quest dependency, grants a hidden reward or forces another NPC model. Use his text only if an optional interaction surface exists; otherwise leave it out.

The northern atmosphere comes from oath-halls, runes cut into worked stone, a bell made from surrendered swords, the weight of a long blade and the work of carrying people home. The original central image is **a protective record of names corrupted into a debt ledger**. This echoes the scale and weather of heroic sagas without borrowing a franchise's characters, locations, dialogue or plot.

Optional equipment flavor, for gear owners to adopt only on confirmed corresponding items:

| Concept | RU | EN |
| --- | --- | --- |
| Restrained blue steel two-handed rune blade | **Грозовая грань.** На синей стали одна руна: «Держись». | **Stormedge.** One rune on the blue steel: “Hold.” |
| Heavy blue steel boots | **Сапоги долгой дороги.** Скалу не впечатлили. Зато дошли. | **Longroad boots.** The mountain was unimpressed. They made it across. |

These are optional authored names and descriptions, not assertions that an item ID, boots slot, model or mechanical bonus exists. The canonical gear catalog is authoritative.

## Display and timing

Show at most one two-line exchange at room entry or after a resolved outcome. Never require the player to tap through a conversation before moving. Leave the objective visible. Hooks belong in an optional journal or inspect view. Optional NPC lines should not stack on the mandatory exchange. `encounter` strings are integration notes and stay out of the game interface. Retreat copy must be requested for the room actually exited, not the next advanced room index.

The opening can establish the whole premise in one line: **«Внизу книга с нашими именами. Наверху нас ждут». / “Below: a book with our names. Above: people waiting for us.”** Let room choices carry the rest.

## Verification and limits

Data delivered at 21:20 UTC; handoff delivered at 21:25 UTC. A Node import and assertion run passed **36 room × locale × flag cases** (six rooms, RU/EN, true/false/absent), plus alias mapping, unknown-room fallback, inherited-flag exclusion, input immutability and suppression of a dead hero's speech. All tested required fields were nonempty. The longest baseline/undecided dialogue field was 114 characters. This validates the independent lore module; it does not claim the live game has adopted it.

Campaign/runtime files were not edited. No publication, commit, server or browser session was started. The extra voices and goblin are text hooks; they do not imply recorded audio or additional rendered characters.
