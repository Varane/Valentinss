# BALANCE implementation and audit

Spec: coordination/v4/C/CONTRACT.md, checked 2026-11-11 21:04 UTC.

Four independently owned modules: items.mjs (items), skills.mjs (skills), rewards.mjs (rewards), balance.mjs (lead). Exactly three child agents; no recursion.

Lead implementation: add auditBalance(overrides={}) returning fresh JSON {ok,errors,warnings}; reexport ITEMS, SKILLS, BRANCHES, rewardForRoom. Audit preserves baseline IDs/slots/icons/stats, checks skill prerequisites and branch membership, validates all six room rewards, monotonic XP/gold, and prohibits epic gear in rooms 1–4. No simulation imports, Node dependencies or input mutation.

Verification: failing audit tests first, then implement; independently rerun all campaign.balance tests, rules/runtime tests, inspect real exports and current A handoff. Unsupported action skills remain explicitly documented.

Pending final catalogue tables and verification.
