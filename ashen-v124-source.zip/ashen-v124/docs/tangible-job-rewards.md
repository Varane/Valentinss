# Tangible city-job rewards

Every completed city job still grants its previous XP bonus and now advances an explicit account-wide reward track. The board previews the next reward before acceptance. A nonblocking received-reward notice opens a reveal with all colors, items, quantities, gold and next unlock. Colors preview on the actual selected hero; item art and effects are the real catalog entries. Bag and barber actions are explicit. Ack is local presentation state, captures the displayed reward number, and cannot acknowledge a later unseen completion. Switching reward/barber/trade panels returns the borrowed renderer.

| Jobs | Unlock |
|---|---|
|1|Amber hair|
|2|Ward weapons for fighter and mage, tier I|
|3|Teal hair|
|4|Ember weapons, tier II|
|5|Amethyst hair|
|6|Dawn weapons, tier III|
|7|Frost hair|
|8|Master armor, tier III|
|9|Aurora hair and three gemstones|
|10|Rose gold hair, artifact and three fish feasts|

Gold rises from10 to100 through the first ten completions, then105..200 and caps at200; later completions provide gemstones and meals. Power caps stay unchanged. Weapon rewards use existing real rare models/effects. They never downgrade stronger gear; rare ownership/equipping is captured by normal campaign receipts. Both class variants are shown and credited. Bound reward items cannot be purchased at zero price or traded.

Server rewardsClaimed and the wallet share the existing atomic multi-document CAS with the town player (and garden world when needed). Past completed jobs backfill once. Reconnect/replay cannot mint another set; there is no client-provided completion/claim counter. Existing five basic hair colors stay available. New reward colors are validated against authoritative completed jobs at the barber and co-op room create/join. Worker identity resolves the town record; guest/body completion fields are not trusted. Local singleplayer saves are not an online authority.

Validation covers reward-range conservation/nondecreasing payout, explicit item previews, actual rare equipping without downgrades, backfill/reconnect, zero-price purchase rejection, town cosmetic locks and real HTTP co-op eligibility for owner/other account/guest. Browser/iPhone visual verification remains unavailable.
