import {encounter, command, step} from '../../dist/action.mjs';
import {createGame} from '../../dist/rules.mjs';
import {createDuel, reduceDuel} from '../../dist/duel/simulation.mjs';
import {newRun,advance,act} from '../../dist/remake/core.mjs';
import {monsterProfile,MONSTERS} from '../../dist/remake/monsters.mjs';
import {roomDefinition} from '../../dist/campaign/rooms.mjs';

const out={};
function coop(enemy,{revive=true,attack=true,seconds=180}={}) {
 const s=encounter(createGame(),{enemies:[enemy]});s.cooperative=true;s.companionAI=false;s.externalPlayers=[0,1];
 Object.assign(s.players[0],{x:0,z:0,yaw:0});Object.assign(s.players[1],{x:0,z:-1,yaw:0});Object.assign(s.enemies[0],{x:0,z:1,yaw:Math.PI});
 const counts={};let seen=0;
 for(let n=0;n<seconds*50&&s.phase==='active';n++){
  for(let i=0;i<2;i++){if(revive)command(s,'revive',i);if(attack)command(s,'attack',i);}
  step(s,.02,{players:[{x:0,z:0},{x:0,z:0}]});
  for(const e of s.events)if(e.id>seen)counts[e.type]=(counts[e.type]??0)+1;
  seen=s.eventSeq;
 }
 return {phase:s.phase,time:s.time,hp:s.players.map(p=>p.hp),dead:s.players.map(p=>p.dead),enemyHp:s.enemies[0].hp,counts};
}
out.reviveStress=coop({hp:100000,damage:10000,boss:true,windupDuration:.45,attackCooldown:.5},{attack:false});
out.reviveStressControl=coop({hp:100000,damage:10000,boss:true,windupDuration:.45,attackCooldown:.5},{attack:false,revive:false});
out.reviveRegularBoss=coop({hp:2000,damage:32,boss:true,windupDuration:1.4,attackCooldown:2.6});
out.reviveRegularBossControl=coop({hp:2000,damage:32,boss:true,windupDuration:1.4,attackCooldown:2.6},{revive:false});

function shieldScenario(deadAlly){
 const boss=roomDefinition(10).enemies.find(e=>e.boss),s=encounter(createGame(),{enemies:[boss]});s.cooperative=true;s.companionAI=false;s.externalPlayers=[0,1];
 Object.assign(s.players[0],{x:0,z:0,yaw:0});Object.assign(s.players[1],{x:1.5,z:1,yaw:-Math.PI/2});Object.assign(s.enemies[0],{x:0,z:1,yaw:Math.PI,cooldown:0});
 if(deadAlly)Object.assign(s.players[1],{hp:0,dead:true,down:0});
 const counts={};let seen=0;
 for(let n=0;n<180*50&&s.phase==='active';n++){
  const e=s.enemies[0];if(e.windup>0&&e.windup<.22)command(s,'parry',0);
  if(deadAlly)command(s,'attack',0);else if(e.teamOpening)command(s,'attack',1);
  step(s,.02,{players:[{x:0,z:0},{x:0,z:0}]});
  for(const ev of s.events)if(ev.id>seen)counts[ev.type]=(counts[ev.type]??0)+1;seen=s.eventSeq;
 }
 return{boss:boss.name,bossHp:boss.hp,phase:s.phase,time:s.time,hp:s.players.map(p=>p.hp),enemyHp:s.enemies[0].hp,counts};
}
out.shieldPair=shieldScenario(false);out.shieldSoloFallback=shieldScenario(true);

function fullRoomRescue(index,reviveCooldown=0){
 const s=encounter(createGame(),roomDefinition(index));s.cooperative=true;s.companionAI=false;s.externalPlayers=[0,1];
 const counts={};let seen=0,lastRescue=-Infinity;
 for(let n=0;n<180*50&&s.phase==='active';n++){
  const tank=s.players[0],support=s.players[1],enemy=s.enemies.filter(e=>e.hp>0).sort((a,b)=>Math.hypot(a.x-tank.x,a.z-tank.z)-Math.hypot(b.x-tank.x,b.z-tank.z))[0];if(!enemy)break;
  command(s,'attack',0);
  if(s.time-lastRescue>=reviveCooldown&&command(s,'revive',1))lastRescue=s.time;
  const towards=(a,b,stop)=>{const dx=b.x-a.x,dz=b.z-a.z,d=Math.hypot(dx,dz);return d>stop?{x:dx/d,z:dz/d}:{x:0,z:0};};
  const vectors=[towards(tank,enemy,1.5),towards(support,tank,1.6)];
  step(s,.02,{players:vectors});
  for(const ev of s.events)if(ev.id>seen)counts[ev.type]=(counts[ev.type]??0)+1;seen=s.eventSeq;
 }
 return{room:index,reviveCooldown,phase:s.phase,time:s.time,hp:s.players.map(p=>p.hp),enemyHp:s.enemies.map(p=>p.hp),counts};
}
out.fullRoomRescue=[0,1,2,3,4,5,6,7,8,9].flatMap(i=>[0,6].map(cd=>fullRoomRescue(i,cd)));

function duel(){let s=createDuel({id:'audit',peerIds:['a','b']});for(const peerId of s.peerIds)s=reduceDuel(s,{type:'accept',peerId});return reduceDuel(s,{type:'tick',steps:60});}
const send=(s,i,action,v={})=>reduceDuel(s,{type:'action',peerId:s.peerIds[i],action,...v});
function parryDefense(delay){let s=duel();s.players[0].x=-.6;s.players[1].x=.6;let seen=0;const counts={};let attackAnnounced=null;
 for(let t=0;t<120*20&&s.phase==='active';t++){
  s=send(s,0,'attack');if(s.players[0].attackAtTick!==null&&attackAnnounced===null)attackAnnounced=s.tick;
  if(attackAnnounced!==null&&s.tick>=attackAnnounced+delay)s=send(s,1,'parry');
  s=reduceDuel(s,{type:'tick'});if(s.players[0].attackAtTick===null)attackAnnounced=null;
  for(const e of s.events)if(e.id>seen)counts[e.type]=(counts[e.type]??0)+1;seen=s.eventSeq;
 }
 return {delayTicks:delay,phase:s.phase,time:s.time,hp:s.players.map(p=>p.hp),stamina:s.players.map(p=>p.stamina),counts};
}
out.parryDefense=[2,3,4,5].map(parryDefense);
let idle=duel();for(let i=0;i<60;i++)idle=reduceDuel(idle,{type:'tick',steps:200});out.idleDuel={phase:idle.phase,time:idle.time};

out.stationaryCampaignSpam=[];
for(const kind of MONSTERS){const r=newRun({seed:1});r.map={width:40,height:34,grid:Array.from({length:34},(_,y)=>Array.from({length:40},(_,x)=>x&&y&&x<39&&y<33?0:1)),start:{x:320,y:272},exit:{x:560,y:440},chest:{x:560,y:440},relic:{x:560,y:440}};Object.assign(r.player,{x:320,y:272,invuln:0,facing:{x:1,y:0}});r.enemies=[{...monsterProfile(kind.id,4),id:0,x:340,y:272,cooldown:0,state:'idle',timer:0,hurt:0,facing:{x:-1,y:0}}];
 for(let n=0;n<60*60&&r.phase==='playing'&&r.enemies[0].hp>0;n++)advance(r,1/60,{attack:true});
 out.stationaryCampaignSpam.push({species:kind.id,time:r.time,heroHp:r.player.hp,enemyHp:r.enemies[0].hp});
}
console.log(JSON.stringify(out,null,2));
