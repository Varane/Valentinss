# UI audit: 15 reproduced interaction defects

All reproductions run the actual exported handlers with DOM boundary fixtures. Every new regression failed before its fix. These are controller simulations, not live browser or visual playtests.

| ID | Trigger and previous behavior | Fix | Regression |
| --- | --- | --- | --- |
| UI01 | Type Space in a contenteditable editor: combat attack fires. | Respect editable content and editable ancestors. | audit-ui-input: contenteditable |
| UI02 | Dispatch an already-consumed shortcut or an IME composition key: combat still receives the action. | Respect event ownership and composition before keyboard processing. | audit-ui-input: consumed and IME |
| UI03 | Hold W, then focus a text editor: hero continues moving while typing. | Clear held input on entering editable fields. | audit-ui-input: entering an editor |
| UI04 | A key or keyboard-generated accessible click arrives while document is hidden: combat action fires although the page is inactive. | Gate keyboard and accessible click actions on visibility, matching pointer and read behavior. | audit-ui-input: hidden pages |
| UI05 | Send a PM, switch tabs and reopen PM before completion: new Send button remains disabled when request completes. | Refresh the currently mounted controls after pending latch settles. | audit-ui-social: changing tabs updates button |
| UI06 | Submit speech form via keyboard during cooldown: handler sends despite disabled Send button. | Recheck preview eligibility within the submit handler. | audit-ui-social: cannot bypass cooldown |
| UI07 | Send a PM and switch to Friends before success: reopening conversation restores already-sent draft, inviting duplicate sends. | Delete matching saved draft after success, including when view changed; retain edits and account isolation. | audit-ui-social: submitted saved draft |
| UI08 | Leave an open PM tab in background; receive a poll with a new message: message is marked read although user cannot see it. | Only acknowledge messages while document is visible. | audit-ui-social: background updates unread |
| UI09 | Open city chat then open a blocking town modal: chat remains editing, retaining input ownership behind the modal. | Close editor whenever chat availability is lost, including modal/account conditions. | audit-ui-chat: another modal blocks chat |
| UI10 | Press Escape to cancel IME composition inside overlay: menu closes and returns gameplay focus. | Ignore composition Escape and shortcuts already consumed by an editor. | audit-ui-overlay: cancel IME |

Verification: elevated `node --test tests/audit-ui-input.test.mjs tests/audit-ui-social.test.mjs tests/audit-ui-chat.test.mjs tests/audit-ui-overlay.test.mjs tests/remake-controls.test.mjs tests/social-ui.test.mjs tests/input-ui-overlay.test.mjs` passed 39 tests, including 10 new regressions. Ordinary sandbox Node test execution hides individual test output here; elevated execution showed individual results. No full suite, build, publication, or commit performed.

## Second independent pass

| ID | Trigger and previous behavior | Fix | Regression |
| --- | --- | --- | --- |
| UI11 | Open trading with an existing cookie while account request is pending: a new-character registration form is displayed before identity is known. Failed identity checks also present registration instead of connection recovery. | Render checking status until account lookup resolves; failed checks provide Retry. | audit-ui-trade: checks existing identity |
| UI12 | Submit registration or key login and receive a validation/network error: busy/error redraw erases entered fields and closes the existing-player form. Wallet redraws similarly erase unsubmitted invitation codes. | Carry matching register/login/join fields and focused selection across redraws; keep login details open. | audit-ui-trade: failed registration; login errors |
| UI13 | Keyboard-activate a gear item: rebuilding inventory removes the focused button and sends focus to the document body. | Restore focus to the corresponding equipment item after render. | audit-ui-equipment: keyboard activation |

Second-pass verification: elevated `node --test tests/audit-ui-equipment.test.mjs tests/input-ui-equipment.test.mjs tests/night-gear-skill-locale.test.mjs tests/audit-ui-trade.test.mjs` passed after the fixes. The initial two trade regressions and equipment regression were observed failing before edits. The expanded login-state regression verifies the shared input-preservation fix.

## Third independent pass

| ID | Trigger and previous behavior | Fix | Regression |
| --- | --- | --- | --- |
| UI14 | Exchange quantity 10000 and unit price 1000000 both satisfy field constraints; Continue silently removes review because total exceeds 1e9, with no explanation or recovery. | Show an alert explaining the total cap and how to reduce the order. | audit-ui-exchange: oversized total |
| UI15 | Review an exchange order, then authenticate as another account without recreating the interface: old account's draft and confirmation remain visible for the new wallet. | Reset exchange draft, quote initialization and review when account ID changes; late completion cannot reset another owner's review. | audit-ui-exchange: switching exchange accounts |

Both third-pass regressions failed before edits. Elevated targeted verification passed 13/13: `node --test tests/audit-ui-exchange.test.mjs tests/exchange-ui.test.mjs tests/audit-ui-trade.test.mjs tests/panel-motion.test.mjs`.

Panel motion, feedback motion, accessibility preferences, localization caching and the actual narrator module (`dist/remake/case-cinematics.mjs`) were also inspected. No further defensible reachable defects claimed in those modules.
