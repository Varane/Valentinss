# Native browser audit before the overhaul

Run: https://agent.tinyfish.ai/runs/413522e9-5e2a-4691-b189-d04d2b92e268

Revision provenance: the public URL was mutable and the runner did not pin a commit. Local baseline was v114; parallel v115–v119 town-dialogue updates were subsequently discovered. Their renderer/equipment paths share the v114 baseline, but this trace must not be labelled an exact-commit live test.

Evidence class: external browser automation using visible controls. Not Astra directly controlling a browser, not a completed campaign, not a physical-phone test. Astra reviewed this report alongside source/handler/geometry checks. The gray scene is an observation in this runner, not a confirmed device-independent production rendering failure. The report's interpretation of «На площади 1 → 2» as locations is incorrect: those numbers show online population. Registration creates a persistent test account; «no account required» is also incorrect. The overall claim that all UI works is unsupported given the uncompleted flows. No conversations/trades/duels with real players were requested.

## Unedited runner report

# Ashen (Кровосклеп) — First-Time Usability Playtest Report

## Site & Authentication
- **URL**: https://ashen-vault-room-7d29.ardent-ibex-0809.chatgpt.site/
- **Town**: Ивовый мост (Willow Bridge)
- **Guest access**: YES — registration via character name + hero selection, no account required
- **Registration flow**: Input field "Ваше имя" (Your name) → hero dropdown (5 classes) → "Начать играть" (Start playing) → "Продолжить в город" (Continue to town)
- **Existing player login**: "Уже играли? Войти по ключу" (Already played? Log in by key) with password field "Ключ входа"

## Hero Selection (5 classes available)
1. **Волхв** (Mage/Channeler) — default selected, 120 HP, leather armor + bronze sword
2. **Волшебник** (Wizard)
3. **Даник**
4. **Квак** (Frog character)
5. **Виталик**

## Town Exploration — Ивовый мост
- **Locations visited**: На площади 1 → На площади 2 → Кривой причал (Crooked Pier)
- **POIs visible**: Лавка Мары (Mary's Shop), Оружейные ряды (Armory Rows), Поющий фонтан (Singing Fountain), Северные ворота (Northern Gates), Замок сторожа (Guard's Castle)
- **Movement**: Circular joystick (bottom-left) — worked to move between map nodes
- **Emotes**: "Эмоции" button opens emote selection — clickable, functional
- **Bounty board**: "Поручения" — took contract "Ужин для лодочника" (Dinner for the boatman, 3 steps). Step 1 completed: fishing at pier (Ловить · ур. 1). Step 2: "Помочь в саду" (Help in the garden)
- **Bottom nav buttons**: В пещеру (To the cave), Сумка (Bag), Сказать всем (Say to everyone), Меню (Menu)
- **Top bar buttons**: Карта (Map), Повернуть камеру (Rotate camera)
- **City chat tools**: Чат города (City Chat), Эмоции (Emotes), Друзья и личка (Friends and DMs)

## Bag/Inventory
- **Currency**: 100 золота (100 gold)
- **Tab**: "Все способы торговли" (All trading methods)
- Items move to current expedition; buttons show "Сначала начните дело" (Start the activity first)
- Gold from palaces vs shop coins are different currencies

## Cave/Expedition — /expedition.html
- **Dungeon name**: КРОВOCКЛЕП (Ashen Vault/Blood Crypt)
- **Current floor**: Этаж I / V (Floor 1 of 5)
- **Room name**: Зал праха (Hall of Dust)
- **Hero class**: Волхв (Mage), 120/120 HP
- **Equipped weapon**: Бронзовый меч (Bronze Sword), Урон 22 (Damage 22)
- **Potions**: 2 available (F — use potion)
- **Quest objective**: "Найдите слепок" (Find the cast) — Step 1 of 4, distance ~39-39m
- **Coins collected**: 0

### Controls (per "Помощь/How-to" modal)
- **WASD / Joystick**: movement
- **Auto-attack**: attacks go automatically when near visible enemies
- **Space**: special ability (e.g. "РАЗМАХ" Swing)
- **Shift / E**: dash ("РЫВОК")
- **F**: use potion
- **R**: interact with bell/puzzle objects
- **Combat rules** (from "Правила боя"): Normal guards can be interrupted with a regular strike before their swing; large enemies (Gromila, Hunters, big bosses) finish their attacks. Precise dodge boosts next attack.

## Equipment Inspection Panel
- **Tabs**: Герой (Hero), Оружие (Weapon), Броня (Armor) — all clickable
- Current equipment shown: "Кожаный доспех" (Leather armor), "Бронзовый меч" (Bronze Sword)
- **Animation previews**: "Посмотреть удар" (Watch attack), "Праздновать" (Celebrate) — buttons present
- **3D model rendering**: The "equipment-stage" div is a placeholder — the actual 3D WebGL model rendering appears as a grey/empty canvas in the screenshot. The canvas element exists in the DOM with aria-labels for 3D movement, but the rendered scene shows only a grey gradient background with no visible 3D dungeon, walls, enemies, or hero model. This may be a rendering limitation in the automation environment.

## Visual Assets Inspected (image URLs found)
**Armor/outfit textures**: armor-1.webp, armor-2.webp, armor-3.webp, traveler.webp, linen.webp, longcoat.webp, scholar.webp
**Weapons**: bronze-sword.webp/svg, greatsword.webp, steel-axe.webp, spiral-staff.webp, rune-staff.webp, runeblade.webp, hunting-bow.svg, longbow.svg
**Items**: raw-fish.svg, cooked-fish.svg, herbs.svg, seal-relic.svg, arrows.svg, ingot.svg, runite.svg, charm.svg, boots.svg
**3D materials**: floor-color.webp, floor-normal.webp, floor-rough.webp, wall-color.webp, wall-normal.webp, wall-rough.webp, sky/kloppenheim-sky.webp, various PBR surfaces (metal, leather, knight/mage/barbarian textures)

## Cooperative Interface
- **"В пещеру вместе · до 4"** — Cooperative cave mode (up to 4 players)
- **"Обмен"** — Trading mode
- **"Арена"** — Duel/PvP arena
- **Arena modal**: Shows "Создать комнату" (Create room) button, room code input field (ABC123 format, 6 chars), "Войти" (Join) button, and "Вернуться к походу" (Return to expedition)
- Did NOT join any strangers or create a room — only inspected the interface

## WebGL/Canvas Assessment
- Canvas element IS present in the DOM within #game container
- WebGL is implied for 3D rendering
- However, the actual rendered scene appears as a grey gradient placeholder — no 3D dungeon, walls, enemies, doors, or hero model are visible in the captured screenshot
- The game states "Восстанавливаем графику…" (Restoring graphics…) initially, which resolved
- The game controls (touch joystick, dash/attack/heal buttons) are all present and visible
- Without actual user keyboard/mouse input (WASD, Space, etc.), the 3D scene may not render properly in the automation environment

## Achieved Stages
1. ✅ Town registration (character name "ТестИгрок", hero "Волхв")
2. ✅ Town entry and navigation (squres 1→2, pier)
3. ✅ Emote interaction tested
4. ✅ Bounty board — took "Ужин для лодочника", completed step 1/3 (fishing)
5. ✅ Bag/Inventory inspected (100 gold, trading tabs)
6. ✅ Expedition cave entry (Floor 1/5, Зал праха)
7. ✅ Equipment panel — all tabs (Hero/Weapon/Armor), attack/celebrate buttons
8. ✅ Cooperative modes inspected (coop/join/create/trade/arena) — no strangers joined
9. ✅ Game controls read (WASD, Space, Shift, F, R)
10. ✅ Credits and help docs reviewed

## Uncompleted / Blocked
- ⚠️ **Could not complete all 5 floors**: The 3D scene does not render properly (shows grey gradient), preventing actual exploration, fights, and puzzle-solving within the cave. Touch controls are visible but movement in the 3D environment cannot be verified.
- ⚠️ **Could not engage in fights**: No enemies are visible in the rendered scene.
- ⚠️ **Could not solve puzzles**: No interactive puzzle objects are visible in the rendered scene.
- ⚠️ **Costume switching not fully testable**: Equipment panel tabs are clickable, but the 3D model display is a placeholder — cannot visually confirm costume changes or weapon holding/clipping during idle/moving/attacking.
- ⚠️ **Weapon holding/clipping during animations**: Could not verify due to lack of visible 3D rendering.

## Summary
The game is a Russian-language browser-based 3D dungeon crawler with full town hub (Ивовый мост), 5 hero classes, inventory, quests, cooperative modes, and PvP arena. The UI is fully functional — registration, town navigation, emotes, bounties, bag, equipment inspection, and cooperative interfaces all work. The cave expedition loads correctly (Floor 1/5, Зал праха, hero equipped with bronze sword and leather armor, 120 HP). However, the actual WebGL 3D rendering appears to show only a grey placeholder — no dungeon geometry, enemies, or character models are visible, blocking actual exploration of all 5 floors, combat, puzzle-solving, and animation/visual inspection. WebGL canvas elements exist in the DOM, but the rendered output is incomplete in this environment.
