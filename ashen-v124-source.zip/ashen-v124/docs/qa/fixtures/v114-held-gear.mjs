// v114 baseline sampler. Local-Y assumption is historical; use current grip markers after calibration.
import * as THREE from '../../../dist/lib/three.module.js';
import {readFile} from 'node:fs/promises';
import {GLTFLoader} from '../../../dist/cinematic/lib/GLTFLoader.js';
import {setOpenWeaponModels} from '../../../dist/cinematic/open-weapons.mjs';
import {createActor} from '../../../dist/cinematic/actors.mjs';
import {createFrog} from '../../../dist/cinematic/frog.mjs';
import {productionRig} from '../../../tests/helpers/actor-rig.mjs';

const dataRoot = new URL('../../../dist/cinematic/assets/kaykit/', import.meta.url).pathname;
const production = await productionRig();
const models = {};
for (const id of ['wand', 'staff', 'axe_1handed', 'sword_1handed']) {
  const bytes = await readFile(dataRoot + id + '.glb');
  const loader = new GLTFLoader();
  // Replace texture decoding only. Meshes, joints and imported transforms stay intact.
  loader.register(() => ({name: 'node-texture-boundary', loadTexture: async () => new THREE.Texture()}));
  models[id] = await loader.parseAsync(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength), '');
}
const release = setOpenWeaponModels(models);
const results = [];
for (const [hero, tier, rare] of [['knight',0], ['knight',1], ['knight',2], ['mage',0], ['mage',2], ['knight',1,'town-bow']]) {
  const actor = createActor({gltf:production, hero, avatar:hero, mobile:true});
  const equipment = {weapon:tier, rare};
  const player = {x:0, y:0, hp:100, facing:{x:0, y:1}};
  actor.update(player, 1/60, 0, {equipment});
  let weapon;
  actor.root.traverse(node => {if (node.name.startsWith('weapon:')) weapon = node;});
  const targets = [actor.root.getObjectByName('outfit:base'), actor.root.getObjectByName('hero-kit:' + hero + ':TailoredBody')];
  const localBox = new THREE.Box3();
  for (const part of weapon.children) {
    if (!part.geometry) continue;
    part.geometry.computeBoundingBox();
    localBox.union(part.geometry.boundingBox.clone().applyMatrix4(part.matrix));
  }
  const bow = rare === 'town-bow';
  let bowGripOffset = null;
  if (bow) {
    actor.root.updateMatrixWorld(true);
    const grip = weapon.children.find(node => node.geometry?.type === 'CylinderGeometry' && node.geometry.parameters.radiusTop === .039);
    bowGripOffset = grip.getWorldPosition(new THREE.Vector3()).distanceTo(weapon.getWorldPosition(new THREE.Vector3()));
  }
  const frames = [], hitMeshes = new Set();
  let minWorldY = Infinity;
  for (let i = 0; i < 121; i++) {
    if (i === 30 || i === 72) actor.attack();
    if (i === 88) actor.guard();
    actor.update({...player, x:i*.1, y:i*.025}, 1/60, i/60, {moving:i>45, equipment});
    actor.root.updateMatrixWorld(true);
    minWorldY = Math.min(minWorldY, new THREE.Box3().setFromObject(weapon,true).min.y);
    if (bow) continue;
    const start = weapon.localToWorld(new THREE.Vector3(0, Math.max(.18, localBox.min.y+.1), 0));
    const end = weapon.localToWorld(new THREE.Vector3(0, localBox.max.y, 0));
    const ray = new THREE.Raycaster(start, end.clone().sub(start).normalize(), 0, start.distanceTo(end));
    for (const mesh of targets) {
      mesh.skeleton.update();
      mesh.computeBoundingSphere();
      mesh.computeBoundingBox();
    }
    const contacts = ray.intersectObjects(targets,false);
    if (contacts.length) frames.push(i);
    for (const hit of contacts) hitMeshes.add(hit.object.name);
  }
  results.push({hero, weapon:weapon.name, framesSampled:121, centerlineHitFrames:bow?null:frames.length, frames:bow?null:frames, hitMeshes:[...hitMeshes], minWorldY, bowGripOffset});
  actor.dispose();
}
const frog = createFrog({mobile:true});
const frogSequence = [];
for (const weapon of [0,1,0]) {
  frog.update({x:0,y:0,hp:100,hero:'knight'},1/60,0,{equipment:{weapon}});
  frog.root.traverse(node => {if(node.name.startsWith('weapon:')) frogSequence.push({weapon:node.name, zDegrees:THREE.MathUtils.radToDeg(node.rotation.z)});});
}
frog.dispose();
release();
console.log(JSON.stringify({method:'Three.js model-space test, one frame at 60 Hz, two strikes and one guard. Above-grip longitudinal centerline against the two visible skinned body/cloth meshes. Bow measured separately. Texture decoding replaced.', results, frogSequence},null,2));
