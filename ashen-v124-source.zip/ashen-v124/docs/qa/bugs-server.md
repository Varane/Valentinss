# Server audit regressions

The checks below use actual Worker handlers, two authenticated accounts, and an in-memory SQLite database through the D1 adapter. They are API simulations, not a live browser playtest.

| ID | Confirmed defect and reproduction | Minimal correction | Regression |
| --- | --- | --- | --- |
| SERVER-01 | A sends B a message; B replies without marking A's message read. B's conversation immediately reports `unread: false`, hiding the unseen incoming message. Before correction the assertion failed `false !== true`. | Persist the unread state independently of the newest message's sender; clear it only through an explicit read-through operation. | `tests/audit-server-social.test.mjs`: replying does not clear an earlier incoming unread message. |
| SERVER-02 | Send a message, then retry its request ID with a different body. The API returned 200 although the replacement text was never stored. Before correction the assertion failed `200 !== 409`. | Compare the normalized text against both the durable receipt and retained message; reject mismatched reuse with 409. | `tests/audit-server-social.test.mjs`: a message request key cannot silently acknowledge a different text. |

Trading account switching is one joint client/server finding owned by the root audit, not an additional counted server defect. `tests/audit-server-trading.test.mjs` reproduces the server accepting a mismatched `actorId` (`create` returned 200 instead of 409), then verifies all twelve mutation routes reject that mismatch without changing the wallet or creating a trade. The server now checks the supplied actor before initialization or mutation, with legacy requests still supported.

Verification: elevated `node --test tests/audit-server-social.test.mjs worker/social.test.mjs` passed **10 tests**; elevated `node --test tests/audit-server-trading.test.mjs worker/trading.test.mjs` passed **22 tests**. No full suite, build, commit, or deployment was run.

| ID | Confirmed defect and reproduction | Minimal correction | Regression |
| --- | --- | --- | --- |
| SERVER-03 | The workshop stores lifetime earned produce and its separate lifetime claimed ledger, but capped the earned counter at 1,000,000. Once that total had been claimed, spending the stock never let future completed work pay again: a completed catch reported quantity 1 but the wallet stayed at 2 rather than 3. | Allow the cumulative earned counter to grow to JavaScript's safe integer limit, keeping the existing per-wallet transfer limit unchanged. This applies equally to fishing, smithing, and harvesting. | `tests/audit-server-produce.test.mjs`: claimed lifetime catches do not stop future production after stock is spent. |

Additional focused verification: elevated `node --test tests/audit-server-produce.test.mjs tests/workshop-state.test.mjs worker/town.test.mjs` passed **40 tests** (one new regression, three existing workshop state tests, and 36 town API tests). Inspected `worker/produce-wallet.mjs` and `worker/town-equipment.mjs`; wardrobe validation lives in `worker/town.mjs`. No changes to those files were needed for this correction.
