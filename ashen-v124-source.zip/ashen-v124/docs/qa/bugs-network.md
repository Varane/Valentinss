# Network-client audit

Verified by injected real client handlers and HTTP Response objects; no browser playtest.

1. **Withdrawn: town coordinate alias is intentional.** Existing `town-lag-regressions.test.mjs` requires queued action requests to read the latest live position rather than replay an older corner. The coordinate clone and incorrect new regression were removed; this is not a defect.
2. **Preparation validates one item then sends a mutated item.** Block room creation, queue equip sword, mutate original intent to axe: the body sent axe. Capture preparation fields before queueing. Regression: `room preparation captures mutable intent before joining queue`.
3. **Duel logout crashes account observation.** Observe a signed-in identity then observe(null,null): account.id dereference throws. Optional account access now resets account/match state. Regression: `duel observation supports account logout`.
4. **Social logout retains uncertain message request IDs.** Lose message response, receive401, sign in and send same text: former session's request ID is reused. Clear pending deduplication IDs on unauthorized reset. Regression: `social unauthorized session forgets uncertain send IDs`.
5. **Rendering exceptions reject acknowledged network operations.** Throwing onState rejects successful town join/social refresh/duel refresh, starves later subscribers and causes an unhandled rejection in duel refresh cleanup. Isolate each observer callback. Three regressions cover the affected clients; counted as one shared bug class.
6. **Leave during town join silently does nothing.** Start delayed join then request leave before its acknowledgement; captured actor is undefined and leave skips its operation after join succeeds. Resolve missing identity when queued leave executes, retaining the existing captured-identity guard when an actor was already known. Regression: `town leave queued behind joining leaves the acknowledged identity`.
7. **Unauthorized duel refresh keeps private actionable match state.** Load active duel then receive401: old duel/account remain exposed. Clear duel identity, mirror, options and account when401 invalidates authentication. Regression: `duel unauthorized refresh removes actionable private duel state`.

Before fixes: seven failures in initial eight-test run (one already-passing reset regression), followed by two failures for join/leave and duel401. After fixes: 56 tests passed, zero failures using elevated `node --test tests/audit-network-lifecycle.test.mjs tests/social-client.test.mjs tests/town-duel-client.test.mjs tests/town-client-latency.test.mjs tests/network-client.test.mjs tests/town-network-motion.test.mjs`.

Item1 was withdrawn after the broader existing town lag regression exposed the intended live-coordinate invariant. Preparation item capture remains correct because it represents a validated command rather than a live movement sample. No full suite, build, commit or publication performed.

## Cooperative return audit

8. **Returning from coop loses an already completed solo result.** Finish a solo battle, enter a cooperative room, then leave it. `updateRoomStatus` restored the terminal solo battle and marked it settled while hiding the outcome panel. The normal frame never settled it again, so its result and primary Continue/New run action disappeared. Retain the solo outcome payload independently of cooperative outcomes, restore it after leaving, and clear it when spawning a fresh solo room. The actual status-handler VM regression failed before the change and passes after. Startup/campaign/invitation verification:21 passed,0 failed, including two real client transports through a shared authoritative room. Browser playtest unavailable.

The suggested cached invitation failure was not counted: `enterInvitedRoom` has startup callers but no demonstrated retry interaction. No modifications were needed in room-invite, campaign or solo-support.

## Renderer lifecycle audit

9. **Cinematic canvas keeps context lifecycle listeners after teardown.** `dispose` removed viewport resize listeners but left both registered WebGL context callbacks on the canvas, retaining the full view and allowing a late restoration event to resize/re-notify a destroyed view. Explicitly remove both listeners. Actual returned dispose method regression observed two listeners before, zero after.
10. **Pending shader compilation renders after teardown.** Call `prepare`, dispose while `renderer.compileAsync` is pending, then complete compilation: its continuation reset/rendered disposed resources. Guard both entry and completion against disposal (and skip rendering during context loss). Actual prepare/dispose boundary regression observed one invalid late render before, zero after.
11. **Mercenary source model assets never released.** Actors share source mercenary geometry and copy materials; actor disposal intentionally releases only clone-owned resources. View disposal released skeleton enemy/artist assets but omitted the mercenary GLTF itself. Include the mercenary source in the deduplicated asset disposal pass, including boot cleanup. Actual view dispose plus production `disposeCreatureAssets` regression observed zero source releases before versus geometry/material/texture releases after. View disposal is now idempotent to avoid repeating this ownership release.

The renderer regressions invoke the source's actual returned methods in a VM with renderer/DOM boundaries stubbed; they are not browser/WebGL playtests. Three assertions failed before fixes, then all52 focused renderer/actor/figure/startup tests passed. No changes to equipment-studio, figures or reference-image were justified by the inspected lifecycle paths.

Current accepted count in this document:10 independently reproduced defects (items2–11; item1 explicitly withdrawn). Initial56-test result predates the withdrawal; latest town lag plus remaining network regressions passed14/14.
