# Campaign audit: reproduced bugs

Verification is Node simulation, not a browser playtest. Each regression failed before its fix in `tests/audit-campaign-timing.test.mjs`.

1. **Lethal tick continued awarding scene progress.** An enemy's finishing swing while the player stands on a clue/chest set `phase=dead`, then the same tick picked up the clue and opened the chest. Stop simulation immediately after lethal enemy or projectile damage, before later enemies, projectiles, and scene interactions.
2. **Retreat could remain stationary during dash cooldown.** At overlapping player/enemy positions, the retreat direction and both alternatives were zero; the walk fallback consumed a complete turn without movement. Use the reverse facing direction when separation is zero, then test normal escape alternatives.
3. **Projectile expiry dropped its last movement segment.** A projectile with less than one simulation step remaining lost all remaining travel and collision detection because lifetime was decremented before the movement loop. Integrate the remaining flight time first, then expire it. The regression demonstrates a final-segment hit that previously missed.
4. **Dash movement exceeded its remaining duration.** A dash with 1/120 second remaining advanced at dash speed for a full 1/60 step. Limit dash movement to the remaining dash duration; normal 0.16-second dashes otherwise overshot their intended travel at the expiry boundary.

Validation command: `node --test tests/audit-campaign-timing.test.mjs tests/remake-core.test.mjs tests/tactics.test.mjs tests/investigation.test.mjs tests/quest-guide.test.mjs tests/hero-saves.test.mjs` (57 passed).

Additional exploration: snapshot/restore roundtrip remained valid across 29 seeds with up to 3,000 real movement/attack/dash simulation frames per seed. No save-validation issue is claimed from that exploration.

## Second pass: legacy combat

5. **Blood recovery healed from overkill rather than inflicted damage.** With Blood I/II learned, a 1-HP enemy restored 5 HP instead of 1. Clamp damage to enemy HP before applying the skill, emitting hit feedback, and logging damage. Reproduced using the real `learn` and `act` functions.
6. **Potion feedback overstated healing near maximum HP.** At 99/100 HP, the combat log and floating label both claimed +45. The action now emits actual restored HP, and the real animation handler renders that amount. Both producer and animation regression failed before the fix.

Second-pass verification: `node --test tests/audit-campaign-legacy.test.mjs tests/rules.test.mjs tests/rules.progression.test.mjs tests/balance-regressions.test.mjs` (28 passed).
