# First person — v121 release candidate

Changes: existing town cube cycles the four district bearings then first person; cave cycles overview, near and first person. Left drag/touch drag looks around, grounded movement follows the rendered camera. Local actor only is hidden, with a cached shadow refresh. Kvak eye height differs from humans. Existing peer models, chat history, HUD and menus remain. Modal/scene transitions cancel captured gestures. Look never follows strafe/back movement-facing; cave visual perception uses look without mutating authoritative player state.

Astra source review found and helped resolve: town overlays failed to cancel active look; focused camera buttons swallowed movement keys; root also refreshed town shadow cache. No live browser playthrough is claimed.

Validation:
- `node --experimental-loader ./tests/figures-loader.mjs --test --test-concurrency=4 $(rg --files tests worker -g '*.test.mjs')` outside sandbox child-process restriction: 1985 cases; 1978 pass, 0 fail, 2 skip, 5 pre-existing TODO. Log /tmp/first-person-verified-full.log.
- New first-person suites: 21 pass; plus camera-relative suite: 24 pass. Shared camera verifies independent pointer ownership including nonprimary second touch and capture lifecycle; view tests execute production handlers/camera functions with Three.js in VM.
- Build work/first-person-v121-final with scripts/build-coop.mjs, existing Worker entry and DB binding preserved. All480 emitted assets requested through built Worker and hash checked. No extra renderer or frame-time effects added.
- Initial broad isolation=none attempt mixed existing global DOM mocks; sandbox denied existing spawned-worker benchmark. Those failures are recorded in /tmp/first-person-full-tests.log and /tmp/first-person-isolated-suite.log; final isolated full run above succeeds. No unrelated gameplay code changed to hide environment failures.

Unverified: actual WebGL image, eye-level architecture appearance, phone FPS, physical multitouch, end-to-end camera switching on the production page. Environment status was running with remote_desktop enabled/unknown, but no desktop JS tool exposed. No browser installed or alternative local control path improvised.
