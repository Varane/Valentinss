# Integration audit ledger

Request: find and fix 50 actual game bugs. This ledger deliberately records only reproduced, independently caused defects. Multiple manifestations/regressions for one cause are not counted separately. This is not a live browser/device playtest.

Accepted total: **44**. The requested 50 have not been established. Three parallel passes across clients, server, city, UI, campaign and renderer did not justify inventing six more.

| IDs | Subsystem | Count | Detail/evidence |
|---|---|---:|---|
| 01–10 | Network and renderer lifecycle | 10 | bugs-network.md; original coordinate-cloning finding was withdrawn because existing tests establish intentional live-position reads |
| 11–17 | City, shops and appearance | 7 | bugs-town.md |
| 18–32 | Controls, messaging and forms | 15 | bugs-ui.md |
| 33–38 | Combat and campaign | 6 | bugs-campaign.md |
| 39–41 | Server unread/idempotency and lifetime production | 3 | bugs-server.md |
| 42 | Trading account ownership | 1 | Queued wallet/exchange commands followed a later cookie identity. Capture intended actor at invocation and reject mismatched actor on server before any trade mutation. audit-trading-transport + audit-server-trading. This is shared client/server work counted ONCE. |
| 43 | Mutable exchange order payload | 1 | A caller's draft changed while preceding work was pending, changing the later transmitted order. Snapshot payload when order is requested. audit-trading-transport. |
| 44 | Completed-room navigation | 1 | Reopening a victorious/defeated coop room falsely showed a disabled wait-for-friend action although both members existed. Explicit finished state and enabled return-to-results action. room-lobby + input-ui-overlay. |

Trading observer isolation also prevents renderer exceptions from stranding the busy queue; this is part of item01–10's shared observer-isolation class, not an extra counted bug.

Scope held fixed: preserve saves, rewards, trading, quests and existing actions. Reproductions use actual engine/controller/HTTP handlers or extracted shipped UI handlers. Graphics cleanup tests use resource/lifecycle spies. None of these establish visual correctness or touch feel on a phone.

Final integration verification: `node --experimental-loader ./tests/figures-loader.mjs --test --test-concurrency=4` across all test files under tests/ and worker/ produced 1821 cases: 1814 passed, 0 failed, 2 skipped, 5 existing TODO. All 467 emitted production assets matched build hashes. Follow-up account-change recovery is covered under42, not added to the defect count. Production release108.
