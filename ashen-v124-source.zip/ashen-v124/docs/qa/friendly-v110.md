# User-friendly entry, release110

- City menu exposes Find partner directly. Search filters actual online names without replacing focused input; preserves query across roster refresh and retains explicit invitation actions.
- Room code field accepts a complete copied public invitation URL on paste as well as formatted six-character codes. A pasted origin never controls navigation. Invalid paste cannot reuse the previous code.
- Supported mobile browsers use native share. Cancelling share does not silently copy a link. Clipboard failure reveals a readonly selectable link; it is cleared on room leave. Fields are at least16px to avoid introducing small-field mobile focus zoom.
- Existing room join remains explicit, and all existing trade, party, duel and start actions remain available.

Verification:1847 total cases,1840 passed,0failed,2skipped,5existingTODO. New controller/handler tests cover filtering/focus/query retention, complete-link paste, invalid input, native-share cancellation and copy-denied recovery. All468 emitted assets verified. Browser visuals and physical phone interaction remain unverified because browser-control tools were unavailable.
