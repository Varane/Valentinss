# Returning warmth to town, release111

Town's key light now illuminates the front-facing inhabited buildings instead of hiding the inn facade in backlight. Warm window glass and five restrained threshold light spills strengthen the safe-place contrast against the unchanged cool sky, river hills and outer terrain. The spills use one instanced draw, a48px shared texture, no extra lights, shadow maps, raycasting hits or collision.

Existing benches gained rounded linen cushions; the inn gained a drying kitchen herb bunch. Existing geometry and material batches are reused, and decorations remain inside blocked building padding, clear of door shrubs and left-hand bird perches. Camp embers breathe gently through the existing material uniform and remain static in reduced-motion mode. Camp warmth is hidden before the first rescue.

Visual check: actual production geometry/materials rendered with Blender at identical camera/ambient settings; each version's direct sun follows its actual TOWN_LIGHT configuration. Inspected before-lit.png and after-final.png in work/cozy-return-proof. This is offline geometry evidence, not a browser screenshot. Shader sky/steam, additive floor spills, actors, UI and game postprocessing are excluded. No phone FPS or live browser visual acceptance claim.

Verification:1852 test cases,1845pass,0fail,2skip,5existingTODO. Placement, geometry budget, reduced motion, camp visibility, raycast exclusion and exact-once resource disposal covered. All469 emitted assets checked against build hashes.
