# Direct cooperative invitations: worker verification

The town handler previously ignored `coopInvite`; its existing `inviteCode` path validated market trades only. Running the new SQLite tests against the HEAD handler reproduced missing `coopInvites` and accepted invalid cooperative payloads.

The distinct pulse payload is `coopInvite: {to, code}`. The server stores `{to, code, until}` on the host and returns `coopInvites: [{from, name, code, until}]` only to the recipient. Codes reference actual cooperative rooms, with one host member bound to the authenticated account, an open room and a future expiry. Neither bearer tokens nor internal room/player identities enter the invitation view. Existing trade invitations remain separate.

Invitations last 60 seconds, capped by room expiry. Leaving town preserves the invitation because hosts immediately navigate to the cooperative room. Inbox reads do not require host town presence and revalidate that the room remains available. Joining a full room is handled by the existing room service; inbox reads hide filled or closed rooms. Town duel locks apply to sending and target availability.

Verification used actual `townRequest`, account registration, D1 SQLite fixtures and `createRoomService`, with independent authenticated accounts. Tests cover host leave, recipient reload, TTL, recipient isolation, trade/foreign/self/malformed/stale target rejection, full/closed/expired rooms, duel locks and account mismatch.

Command: `node --test tests/night-coop-server.test.mjs worker/town.test.mjs worker/town-duels.test.mjs`.

This is handler-level simulation, not a live browser playtest. No build, full suite, commit or publication was performed.
