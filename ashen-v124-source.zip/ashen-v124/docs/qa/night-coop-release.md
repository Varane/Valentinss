# Night continuation: release109

Completed the missing player-to-player route: select an online city player (or use the party list), invite into an authoritative shared room, host leaves town, recipient receives a separate cooperative request, accepts, and joins the same room through the existing public-link flow. Trade invitations remain separate. Existing active rooms are preserved; only authoritative expired sessions cleared by the room client may be recreated.

Party list now includes online peers without requiring the seeker flag. The sender remains bound to the captured identity/recipient, while town movement stays a live coordinate source at queue execution. BFCache navigation preserves the city invitation controller. Lost city connectivity gives feedback and disables the action.

Verification: 1841 cases, 1834 pass,0fail,2skip,5 existing TODO. Includes real cookie-authenticated town/room clients over the actual HTTP handlers with SQLite: create/invite/host-leave/inbox/accept/join/shared authority and distinct account ownership. Tests also cover expiration, foreign/full/closed/terminal rooms, duel locks, recipient isolation, missing publication acknowledgement, pending account changes, failed publication retry, and disposal. All468 built assets verified against hashes.

No live browser, phone input or visual acceptance test was available. This completed work occurred in the current session; no continuous overnight monitoring or autonomous background agent was installed. The previous audit's accepted44 defects remain44: a new cooperative capability is not counted as six invented defects to meet50.
