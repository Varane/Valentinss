# First integrated character/cave overhaul candidate (local v115 label)

Plan: ../superpowers/plans/2026-11-18-character-cave-overhaul.md — ten work packages, exactly 100 individually tracked actions. Open acceptance checks remain open; this release is not a 100/100 or GTA-quality claim.

## User-visible changes

- Bought and camp-earned costumes survive party admission. Older v114 rooms can recover the original hero's currently selected, lawfully owned outfit once; historical deleted selections cannot be reconstructed. Hair, hero, combat stats and subsequent room appearance remain unchanged.
- Town wardrobe, tailor and equipment studio start from the confirmed appearance and actual equipment. Drafts do not persist; save/cancel requests and stale responses cannot silently overwrite a newer confirmed outfit, including other tabs/accounts.
- Weapons use calibrated palm grips, closed fingers and a two-hand bow pose. Frog re-equipping uses one grip path. Cloth seams, pockets, lapels and lower armor layers have been fitted to the moving torso; Kvak has outfit-specific wide-body clothing and three real armor shapes.
- Human neck/nape geometry is fitted around the existing skeleton. Existing head faces, hair and earned customization remain.
- Five cave chapters have consistent material/light profiles and differing carved arches. Selected walls use detailed neutral stone, others retain brick; the rejected blank plaster variant was not accepted. Mobile receives a cheap directional fill using the previous light budget. No discovery/visibility/collision bypass was added.
- One missing weapon model no longer aborts the entire cave: only that family falls back to existing procedural geometry. Optional texture timeouts and late-resource release are bounded.
- Party restart correctly follows host ownership; hero labels, first combat cue, puzzle retry and keyboard focus are clearer.

## Evidence and limits

1,957 tests passed, no failures; two skipped and five pre-existing TODO remain. Tests include trusted D1 ownership and recovery/CAS, real handler races, ten full solo mechanical journeys, full 2/4-member mechanical journeys, four authenticated room clients, and retained solo saves.

Held gear checks include 88 human outfits/loadouts ×26 action samples =2,288 double-sided geometric probes covering cloth, torso, face and headwear; 513 continuous longbow frames and existing all-frame greatsword checks. Separate human/frog wardrobe matrices exercise200 outfit/armor combinations. Passing these probes does not prove absence of all imaginable collisions.

Comparative proofs use actual production geometry in fixed offline lighting. They do not establish in-game shading, physical-mobile frame rate, unaided puzzle understanding or live campaign completion. The initial native browser reached floor1 and reported a gray scene; its cause was not established. New world renderer state/frame/draw-call fields and separate studio phase/frame fields support diagnosis; nonzero draw calls alone are not a visible-image acceptance test.

Native baseline: v114-native-newcomer-browser.md. Costume fitting: wardrobe-motion-fit.md and wardrobe-fit-three-views.webp. Weapon before/after: ../../work/weapon-fit-v115/{before,after}.png. Neck before/after: ../../work/overhaul-v115-evidence/neck-{before,after}.png. Cave current production before/after frames: /tmp/cave-overhaul-proof/{before,after}-{0..4}.png. Post-publication browser result will be recorded separately.

## Parallel changes retained

Before publication, Sites history and Git main were refreshed: town-dialogue changes through public v119 (b7179e9) were ahead of the local v114 baseline. They were merged, preserving August’s floating branching topic dialogue and its environment/UI. Modal close integration retains both dialogue dismissal and pending wardrobe-save guards. Public release numbering is assigned by Sites, so the local v115 filename is not the final user-visible version number.

Final merged-source verification: the root city shell was synchronized with town.html to retain the latest floating dialogue mount and interface CSS. Full suite rerun after merge: 1,957 PASS / 0 FAIL / 2 SKIP / 5 existing TODO; 1,964 total. Build contains479 assets.
