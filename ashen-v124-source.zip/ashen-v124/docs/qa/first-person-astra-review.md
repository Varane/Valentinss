# First-person camera acceptance review

Source review, 18 November 2026. These are acceptance cases for the two production 3D views. Device and browser results should be recorded separately.

| Journey | Expected result |
| --- | --- |
| Cycle the existing cube in town | Four quarter-turn district views remain available. Fourth press from the initial district view enters first person, fifth restores the starting view. The accessible button description identifies the current view. |
| Cycle the cave button | Overview, near, first person and overview appear in order. FOV and near plane return to their previous values. A welcome scene and gear inspection use their own framing. |
| Enter at rest, turn 90°, then hold forward, sideways and backward | Movement follows the rendered heading, sideways movement holds a straight line, backward movement backs up without rotating the view. Pitching upward leaves walking speed unchanged. The cave objective indicator follows the same camera axes as the stick. |
| Move with one finger and drag the scene with a second | The stick keeps its pointer. Releasing or canceling the look pointer leaves the stick usable. A look drag ending over an NPC does not open interaction. A stationary tap on a visible town player still opens their menu. |
| Stand next to a wall, change avatar and go down a floor | Camera stays at the local avatar’s eye with no trailing through walls. Hidden local geometry includes helmet, hair and equipped weapon. Other actors, signs, pickups and enemies remain visible. Floor recreation and avatar swaps preserve this behavior. |
| Return to third person while moving or working | Local avatar, labels, town activity framing and existing camera cycle resume. If the player returns from studio or closes a modal during a drag, a fresh pointer can start looking. |

Town coordinates are already in world units. Cave simulation positions are converted with worldPoint. In both views initialize heading once on entry. Updating it from movement-facing every frame creates positive feedback when the stick is held sideways. Update the camera’s world matrix before projecting objective arrows, labels or mapping input. Three.js layers apply per drawable, so hiding only the root layer can leave children visible. Root visibility is sufficient when reapplied to the current actor after an avatar or floor replacement. Keep the local hero’s simulation, animation and action events running.

## Implementation re-review

The town cube returns focus to the game scene after a switch. The cave cube returns focus after pointer activation and keeps keyboard focus for repeated keyboard cycling. Both changes address the shared controller’s exclusion of key events originating on buttons. Town chat, social and duel opening handlers cancel captured look and tap gestures immediately. A separate join and panel-state check prevents starting a new gesture while a panel is open. Town view switching also requests a shadow-map refresh when local avatar visibility changes.

An independent run of the three first-person test files passed all 21 cases. They exercise camera math, mode handlers and gesture events in Node. The review did not include a live browser session, physical multitouch, or visual inspection of the rendered shadow and eye-height framing.
