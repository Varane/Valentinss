# Overhaul baseline — v114

Source commit: da4fe70b0c86eb17654f97f91c0872233d2350ea. Service-worker cache: krovosklep-night-full-v118. Entry points: town `/` and `/town.html`; main investigation `/expedition.html`; four-person party `/expedition.html?coop=1`; legacy `/classic.html` retained.

## Evidence classes

- Native browser automation: docs/qa/v114-native-newcomer-browser.md, 56 actions, reached floor one and gear tabs. It reported a gray scene. No full visual campaign, device-independent render diagnosis or physical-phone acceptance.
- Engine/handler exercise: /tmp/newcomer114-expedition.log and /tmp/newcomer114-astra.log; five heroes × seeds1,7, five trials, Bell and verdict. Known answers and fixed builds mean reachability, not unaided comprehension. Existing party simulations complete two-/four-player expeditions.
- Production geometry: archived held-gear diagnostic JSON and sampler. 121 posed frames intersect base clothes/body on44/42/35/59/55 frames for bronze sword/axe/greatsword/wand/staff. Bow grip offset0.28m; active frog bronze0→1→0 changes98.6°. Sampler local-Y assumptions are historical; current regressions must use the actual calibrated handle/tip markers.
- Real HTTP/D1: worker/room-entitlements.test.mjs reproduces lost purchased and camp costumes, then pins trusted ownership through create/join/start/reload with different accounts.

## State ownership and route

| State | Authority | Consumer |
|---|---|---|
| Purchased outfit unlock | Server wallet/town state | Tailor, wardrobe, room admission |
| Camp unlock | Server camp.claimed | Wardrobe, room admission |
| Selected cosmetic appearance | Confirmed town look/looks; local profile cache | Town actor, solo appearance, party admission |
| Draft try-on | Modal local draft | Studio only; cancel must not persist |
| Solo gear tiers/stats | Hero run save / authorized trade receipts | Solo actor + studio |
| Party personal appearance/gear | Server member and party snapshot | Own actor, peer actors, studio |

User-visible route: town tailor → buy/own → select «Надеть» → wait for server self-confirmation → town model → main solo/party cave → return. Browser could not complete visual confirmation; real handler tests must cover the state route while visual acceptance stays open.

## Repeatable comparison stations

Main cave seed123 floor0 entry; additionally all five floors using the same start camera and exposure recorded by cave art exporter. Four humans: base/longcoat +armor2+real weapon2, standing/front/back/side, walk, slash, guard. Active frog: tier0→1→0 and all nine outfits. Two and four participant shared snapshots with independent looks. Compare390×844 coarse DPR2 and1280×800 desktop render profiles; record pixelratio/shadow/post/light budgets separately from measured frame time.

## Mobile v114 baseline

renderProfile mobile starts at min(DPR,1.1), frameRate30, staticShadow512, no post/local point lights; desktop starts max1.75,60fps,1536dynamic shadows. Source settings are not proof of actual brightness or FPS. Native browser gray frame requires diagnosed drawing state before calling it a confirmed production GPU bug. Simulator correctness, studio Blender images and HTTP success never stand in for live rendered usability.
