# Town movement/performance correction

Base v85 dcf03f591986ccae7e584df946c2b5b5dd4a890c. User reports multi-player frame drops, barber-area rollback, poor remote movement.

Reproduced causes: queued town requests snapshot position before dispatch; generic action errors trigger app rollback to stale cached self; server validates a single chord while local movement can legally route around barber props; remote extrapolation overshoots a stop then reverses; mobile render gate discards timing remainder. Static scene occlusion casts detailed triangle rays (57 blockers, ~1.1ms per ray in Node CPU probe; not phone FPS). Actor creation is ~40ms/instance on this CPU and boundary churn recreates rigs.

Fix boundaries: bounded safe path journal compresses only wall-clear segments; dispatch reads live position; path length and every segment validated server-side within existing movement budget. Only fresh explicit movement/spawn/foreign-position authority may correct local position. Errors on chat/appearance never reuse stale authority. Serial queue and account guard preserved. Remote interpolation buffers actual snapshots without speculative overshoot, adapting bounded delay to packet cadence/latency. Cheap box occlusion and retained frame-clock remainder replace expensive repeated ray work; actor membership range/hysteresis avoids churn. No combat/economy/appearance change.

Tests: corner-path SQLite, speed/wall forgery rejection, stale queued snapshots, generic failure, sequence recovery, 30/60/120Hz jitter+stop/loss, cheap occlusion no triangle raycasting, frame clock jitter average, full regression. Browser/physical phone tools unavailable; do not claim measured FPS/ping. Fresh review and exact build/hash/source/native publication.

## Verified result

Fresh Astra review resolved the fullprecisionpath/payload mismatch (bounded body8192bytes, max64points) and144Hz fractional-remainder bug. Tightened barber visibility proxy to actual visualpole/chair dimensions rather than padded walkingcollision; directselection regression passes. Fullregression exposed account-switch guard recovery, now resets oldpresence beforejoining newaccount. Lost-committed-response test additionally preserves protected journalanchor duringunknown outcomes.

Ten actual controller instances against real in-memory SQLite/API were driven by a deterministic network simulator (80–690ms RTT and delivery jitter) with queued requests; legalmovement produced zero position corrections. This is not ten physicalcomputers or a production ping test. Server rejects wallcutting, excessive travelpath length, invalid endpoint and wrong actor.

Framegate tests cover irregularRAF and144Hz (exact300/600 renders over10seconds for30/60targets), not observedphysicaldeviceFPS. The reproducible NodevisibilityCPUprobe (`node --experimental-loader ./tests/figures-loader.mjs scripts/benchmark-town-visibility.mjs`) measured detailed57-mesh query~0.731ms versus7logicalvolumes~0.000322ms in this environment. This does not imply an equivalent FPSincrease.

Final fullsuite1610cases:1603pass,0fail,2pre-existingskips,5knownTODOs. All409 emittedresources match build/source/servedSHA256. Worker11,670,375bytes. Browser/GPU/physicalphoneQA unavailable. Cachev90, townmodulev35; bothclientsmustreload toreplace their alreadyrunningoldJS.
