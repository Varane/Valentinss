# Gameplay action transitions

Town menus, skills, barber, trade/cooking and party search reuse the campaign panel-motion coordinator. Navigation and input changes remain synchronous; motion never delays commands. Same-panel updates preserve scroll, focus and expanded details. Quest panels have a distinct horizontal entrance and optional art fade. Reduced motion skips presentation animations.

Keyed feedback highlights real work phases, incoming combat cues and tactical engagement changes, with no repeated animation on every poll/frame. Feedback changes opacity only, preserving the CSS centering transform of toast/tactical panels. Cross-document view transitions progressively enhance supported same-origin navigation, with native fallback.

Tool appearance eases over120ms, cancellation fades over160ms while movement resumes immediately, and confirmed result props fade before expiry. No rewards or game clocks wait for these visual transitions. Combat windup anticipation eases in and out rather than snapping; existing creature clips retain their crossfades and actual attack timing.

Partner search is an explicit server-owned presence boolean. It is visible to fresh town peers, clears on leave/expired rejoin, and is shown as a badge and a list of actual nearby seekers. Selecting a candidate approaches that player; the existing co-op room workflow remains the route into a shared expedition. This does not claim automatic matching or automatic room invitation. Offline state hides stale candidates and disables the toggle. Late toggle responses never reopen a closed panel or cancel another action.

Tests cover real server visibility/lifecycle, late-response UI races, preserved HUD transforms, reduced motion, panel focus/scroll, tool fades with immediate movement, rig/tool contacts and combat anticipation/recovery. Browser/iPhone animation QA remains unavailable.
