# Public-domain score provenance

Verified on 11 November 2026 from Mutopia's item records and the downloaded LilyPond notation retained in `sources/`. The browser runtime uses only the explicit numeric notes in `dist/music/score-data.mjs`. It fetches no recording, MIDI file, soundfont or external audio. The synthetic performance is newly produced by the game.

## Edvard Grieg — In the Hall of the Mountain King

[Mutopia item 1888](https://www.mutopiaproject.org/cgibin/piece-info.cgi?id=1888) identifies Grieg's own piano arrangement of Op. 46 No. 4, The University Society 1918, engraved by Coyau, and marks it Public Domain. The retained source is `grieg-mountain-king.ly`, whose header and footer also state that dedication.

Excerpt: bars 2–9, the first eight thematic bars after the preparatory fermata chord. `rightOne` supplies melody; `left` supplies every quarter-note bass. The secondary right-hand voice is silent here. Both hands are raised exactly one octave for small speakers; pitch classes, intervals and notated rhythmic values are preserved. The opening held chord, later sections and accelerations are omitted. Quarter=138 comes from this source. The synthetic envelope is a performance approximation and does not reproduce every staccato/accent mark or orchestral timbre. No new counterline is added.

## Erik Satie — Gymnopédie No. 1

[Mutopia item 37](https://www.mutopiaproject.org/cgibin/piece-info.cgi?id=37) gives the 1888 composition, a Dover reproduction as source, Evin Robertson as engraver, and Public Domain status. The retained `satie-gymnopedie-1.ly` explicitly notes that the Dover edition's modern translated text was excluded from the notation file.

Excerpt: bars 5–12, using all three encoded voices (`top`, `middle`, `bottom`) without pitch transposition. The opening four accompaniment-only bars are omitted. The F-sharp tied across bars 9–12 is represented as a single twelve-beat event. Quarter=66 is this game's performance choice; the source's verbal indication is retained in the source file and has no numeric metronome value. Synthetic gain balances and envelopes are editorial; the notated melody, bass and chord pitches/durations are retained. The remainder and volta repeat are omitted.

## Johann Sebastian Bach — Cello Suite No. 1 Prelude, BWV 1007

[Mutopia item 517](https://www.mutopiaproject.org/cgibin/piece-info.cgi?id=517) gives Schirmer 1916, engraving by Andreas Scherer, and Public Domain status. Retained files are `bach-bwv1007-header.ily` and `bach-bwv1007-prelude.ly`.

Excerpt: bars 1–4, every sixteenth note from `prelude`, no added accompaniment. The retained source encodes the part relative to C4 with G3 as its first note. This game's rendition uses that exact encoded register, one octave above conventional cello sounding register, for a light synthetic upper-register arrangement. This is disclosed rather than presented as an authentic cello recording. Quarter=72 is an editorial performance choice, not a claimed original Bach marking. Slur grouping is approximated by the common envelope; there is no invented ending chord.

## Scope of the claim

The named editions/engravings are explicitly marked Public Domain by their source. We preserve that attribution and retain their notation for audit. This is not a claim about an unrelated modern edition or recording. No copyrighted recording was copied. The excerpts are deliberately short reductions with transparent register, tempo, articulation and boundary choices, not claims of complete performances.
