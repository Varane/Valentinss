# Music for the Crimson Ledger

Music follows the cost of the descent: apprehension at the threshold, human fragility in the donor ward, a moment of stillness in the chapel, restrained curiosity in the archive, then explicit threat at the seal and throne. Relief should sound earned rather than like a festive victory fanfare.

The arrangement uses real score passages played by a small synthetic instrument. Source pitch classes and durations are preserved, with the documented octave/register choices in PROVENANCE.md; instrumental color and volume serve the game. This is a synthesized reduction, not an orchestral recording. Source verification, excerpt boundaries and omitted parts are recorded in PROVENANCE.md.

## Cue plan

| Cue | Use | Musical function | Space after excerpt |
| --- | --- | --- | --- |
| sanctuary | Camp, quiet chapel, pause in the journey | Satie: suspended, fragile rest | 28 seconds |
| exploration | Threshold, ward and archive before engagement | Bach's cello Prelude: a short thread of forward motion, low in the mix | 48 seconds |
| danger | Seal/throne approach, explicit threat | Grieg: a brief warning of the subterranean court | One pass only |
| combat | Ordinary active encounter | Bach's cello Prelude: measured momentum, below attack/defense cues | 20 seconds |
| boss | Living boss during active combat | Grieg: the court motif finally foregrounded | 8 seconds |
| discovery | Rescue, solved mechanism, ledger revealed | A short release into the reflective material | One pass only |
| victory | Room clear or completed descent | Survival and release, not a triumphant joke | One pass only |
| defeat | Final defeat | Quiet aftermath, no melodramatic victory sound | One pass only |

Three verified excerpts form the score catalog: Grieg's In the Hall of the Mountain King, Satie's Gymnopédie No. 1, and Bach's Cello Suite No. 1 Prelude. Grieg is reserved for danger and the boss; ordinary combat uses Bach. All cue references must resolve before integration; the exact map is `dist/music/cues.mjs`. The quiet Satie excerpt also supports defeat as aftermath rather than acting as a literal funeral march.

## Host decisions

- Call `musicCueFor({encounter,campaign,room,event})` only on meaningful state changes, then pass the result to `music.setScene`. Repeating the same cue is harmless.
- An active fight takes priority over discovery; save a rescue/discovery accent for when fighting has ended. Defeat/victory take priority over stale room hints.
- Respect the actual room data. `room.musicCue` or `room.story.musicCue` may override the quiet-room map. Boss detection comes from living `enemy.boss` actors, never merely a room's name.
- Do not switch from victory/discovery back to exploration on the next frame. Let the one-shot finish, or change the cue when the player continues to a new room.
- Pause while the game is paused or hidden. The soundtrack must not obscure attack tells; default master volume is .2 and cue gains are below unity.
- Do not use a continuously accelerating Mountain King loop throughout the dungeon. Its source tempo and rhythms are preserved, with a disclosed octave lift; scene intensity comes from placement, mix and quiet intervals.

No additional UI cards or text are needed for music. A compact on/off control and volume slider in existing settings are sufficient. No music is enabled for a new user until they choose it.
