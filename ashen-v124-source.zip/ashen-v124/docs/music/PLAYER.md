# Music player integration

`dist/music.mjs` exports `createMusic({volume = .2})`. Imports are static and the module is safe to import in Node. It uses the score events in `dist/music/score-data.mjs` and the narrative cue map in `dist/music/cues.mjs`.

```js
import { createMusic } from './music.mjs';
const music = createMusic();
music.setScene('sanctuary');
// Call directly in a click/pointer/keyboard handler, before awaiting other work.
musicButton.addEventListener('click', () => {
  music.setEnabled(!music.getEnabled());
  if (music.getEnabled()) void music.unlock();
});
volumeSlider.value = music.getVolume();
volumeSlider.addEventListener('input', () => music.setVolume(Number(volumeSlider.value)));
```

The required API is `unlock(): Promise<boolean>`, `setScene(cue)`, `setEnabled(boolean)`, `getEnabled(): boolean`, `setVolume(number)`, `pause()`, `resume()`, and `dispose()`. Additional read-only helpers are `getVolume()` and `getScene()`.

Music defaults to off. A valid saved enabled preference can restore the switch, but **no AudioContext is created and no sound can play before `unlock()`**. On a returning visit the first suitable user gesture should call `unlock()` if the switch is enabled. The separate local-storage key `krovosklep-music-v1` stores `{enabled, volume}`; storage failures are harmless. An explicitly passed initial volume overrides stored volume; omitted volume restores stored volume or uses `.2`. Volumes are clamped to 0–1; non-finite values are ignored.

`setScene()` accepts `sanctuary`, `exploration`, `danger`, `combat`, `boss`, `discovery`, `victory`, and `defeat`. Unknown cues remain silent. Repeating the same scene request does not restart a score or create another timer. A changed scene cancels all future notes from the prior scene and releases sounding notes, using the outgoing cue's fade duration. Only score-authored MIDI pitches and durations are synthesized. Melody uses a triangle wave; bass and low notes use a sine wave. There are no recordings, samples, added harmonies, drums, random notes, external requests, or dependency on the sound-effects context.

A single 50 ms timer schedules 150 ms ahead. At most 16 oscillator voices exist per player, including scene release tails. Gain is normalized to the score's simultaneous note count. Entry fades use `fadeSeconds`; repeats start after the score duration plus `gapSeconds`. A stalled timer skips elapsed notes/cycles instead of playing a backlog. Pause/disable use a 15 ms silent fade to avoid clicks; disposal and backgrounding stop and disconnect immediately. Resume restarts the current excerpt, which avoids resuming in the middle of an abandoned musical phrase. One-shot cues finish without repeating; repeating the same scene after completion still does not restart them.

The player tracks page visibility, page navigation caching, and context state changes. It never suspends/closes another audio context. A browser interruption cancels pending sound; recovery restarts the selected cue if music remains enabled and the game is not paused. Some mobile interruptions still require a fresh user gesture: call `unlock()` again from the music control or a suitable interaction. `unlock()` resolves `false` when unavailable/blocked and can be retried; failures do not reject into gameplay. Call `dispose()` when permanently destroying the game; a disposed player cannot be restarted.

Browser behavior references: [MDN scheduled-source stop](https://developer.mozilla.org/en-US/docs/Web/API/AudioScheduledSourceNode/stop), [MDN AudioContext state and iOS interruptions](https://developer.mozilla.org/en-US/docs/Web/API/BaseAudioContext/state), and [MDN AudioContext resume](https://developer.mozilla.org/en-US/docs/Web/API/AudioContext/resume). Score provenance and musical choices are documented separately by the score/cue authors.

Verification is performed by the independent music QA tests in `tests/music*.test.mjs`. A real browser and iPhone listening check remains an integration check; mocked audio tests cannot establish perceptual mix quality or OS-specific gesture behavior.
