# Music verification

Final command `node --test tests/music.test.mjs tests/music-data.test.mjs tests/music-provenance.test.mjs` exited 0: 28 tests passed, 0 failed (22:04 UTC). The previous import failure was resolved by delivering `dist/music/score-data.mjs`.

Behavioral tests use a deterministic AudioContext/timer model and cover: disabled defaults, explicit unlock, silence until opt-in, duplicate scene calls, stale scheduled-note cancellation, pause/resume, disable, teardown, bounded resource usage over four simulated minutes, volume clamp, storage denial and malformed preferences, unavailable audio, retry after a rejected resume, and disposal during pending unlock. Data tests cover every cue's actual score, finite note duration/pitch/gain, living-boss selection, outcome priority and non-mutating room selection.

`tests/music-provenance.test.mjs` independently checks the source-derived Grieg opening/rhythm and octave shift, Satie's sustained tie and accompaniment counts, and all 64 sixteenths in the disclosed Bach excerpt. These complement the source documents; they are not a listening test.

Mix design: one oscillator per score note; maximum 16 live voices; source-score polyphony normalization; default volume .2; scene gain .38–.8. Pause/disable use a brief release, and hidden/disposed state cancels immediately. Quiet gaps intentionally avoid nonstop classical playback. No downloaded audio or soundfont.

## Root's browser/device check

1. Clear only the music preference if testing a new-user flow. Load the game: silence and the music control off. Gameplay saves must survive.
2. Enable music with a tap; verify sound starts. Reload: preference remains, but no sound before a new user gesture.
3. Move from a quiet room to combat to a living boss; verify Bach, then Grieg, without overlapping abandoned phrases. Clear the room and let the Satie one-shot finish.
4. Pause, mute, background the tab, switch apps and return: no background notes or queued burst. If iOS requires a new gesture after interruption, retry using the control.
5. Listen at low/default/max slider settings on desktop speakers and iPhone; confirm attack warnings remain distinguishable and no clicks/distortion are audible.

Real browser output, phone speakers, iOS interruption behavior and subjective mix balance have not been listened to by this music team. No claim of end-to-end runtime integration or deployment is made here; root owns that work.
