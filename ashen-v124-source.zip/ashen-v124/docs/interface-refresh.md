# Interface typography and controls

The main game, town, remake entry and classic view now share ui/interface.css. This replaces the loaded signature.css override sheet. Existing gameplay, accounts, pointer handling and trade event IDs are unchanged.

Open source: button foundation adapted from Bootstrap5.3.3 scss/_buttons.scss (MIT), with source/license bundled under ui/vendor. No Bootstrap JS, framework reset or runtime dependency is added. Original ASHEN palette uses warm paper, burgundy actions and ink text. Explicit normal/hover/active/focus/selected/disabled states replace inconsistent button variants.

Locally hosted Golos Text400/600 and Literata400/600 support Russian Cyrillic, Ё, Latin and punctuation. The four WOFF subsets total about200KB. OFL1.1 license files are bundled and referenced in game credits. Headers use Literata; controls use Golos Text.

The welcome sheet clears the old bottom-half dock/translate transform and fits the viewport. The shop uses one list column. Hero choices clear the inherited30px icon column. Inputs remain16px; important controls have44–48px touch targets; focus rings and reduced-motion handling remain.

Validation: scripts/render-interface-proof.py renders six STATIC DESIGN BOARDS from shipped fonts/colors and original UI labels, checking Cyrillic coverage, touch-target dimensions in those boards and text contrast. Main text11.42:1, muted text4.93:1, primary text9.39:1. Boards were visually inspected under coordination/ui-proof. These are Pillow component/layout studies, NOT browser screenshots, and do not validate DOM layout, WebGL or device interaction. SVG previews use MuPDF, whose gradient rendering may differ from browsers. A separate review checked the actual loaded CSS cascade and caught/fixed the welcome transform, shop grid and hero icon-column conflicts.

Browser QA was unavailable: Sites managed-Linux environment declares remote desktop but does not expose cua_repl.js or another supported browser tool. In accordance with Sites rules, no improvised browser/server was used. Final in-browser/iPhone appearance and interaction remain unverified.
