# Camera-relative joystick movement

The town View button rotated the camera while manual movement still used fixed world X/Z axes. This reversed screen direction after half a turn.

Both town and campaign map stick/keyboard input through the normalized ground projection of the actual camera right vector. They use the current interpolated camera matrix rather than the requested destination yaw. Camera pitch does not alter analog movement speed. Campaign dash actions use the same conversion as movement. Town click-to-walk and workshop approach routes remain in world coordinates.

Regression checks project real Three.js camera movement to the screen at seven headings and twenty intermediate turn steps, checking signs, cardinal axes, analog magnitude and retained action fields. Pointer ownership and town route tests are unchanged. Real phone touch/browser QA is unavailable in this environment.
