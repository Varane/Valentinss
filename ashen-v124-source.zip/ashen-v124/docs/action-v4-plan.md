# Кровосклеп v4 — 3D action room

User-approved direction: BloodRayne-inspired pace, boldness and simple believable silhouettes; no borrowed characters, models, stock textures or generic text-card skill tree. Deliver one actual 3D room with movement, attack, dash, timed parry/counterattack, live equipment models and visual skills. Preserve RPG progression and save key. Local solo control with companion assistance; online rooms remain pending and are not claimed.

1. Add pure `action.mjs` encounter simulation. Test movement boundary, directional dash invulnerability, parry stun/riposte, encounter victory and damage. Use existing rules stats and skills.
2. Add custom articulated humanoids in `figures.mjs`: proportional bodies, visible simple faces/hair, separate joints, weapon and armor replacement. No imported character assets.
3. Add authored 3D room and real-time controls in `action-game.mjs`; keyboard and touch stick; telegraphed enemy attacks, hits, blood, companion follow/assist, rescue.
4. Replace entry page with minimal non-card HUD. Add equipment on hero inspection view and visual SVG skill constellation with one selected skill description.
5. Verify rules/simulation, browser movement/combat/equipment/skills and phone-width layout. Independent final review, fix important issues, deploy same private Site and show actual screenshot.

Visual limit: consciously simple custom procedural 3D, not AAA/GTA fidelity. No sprite characters and no rendered background standing in for a 3D room.
