# Observatory graphics release

Adds original suspended astrolabe, rotating rings, architectural skyline, additive shafts, ground haze, PBR water sheen and an exit portal activation effect. Geometry remains above/outside the walkable arena. The opening menu moves to a side panel or mobile bottom sheet; gameplay camera is closer.

Poly Haven CC0 kloppenheim_06_puresky (Greg Zaal, Jarod Guest) supplies a compact 512x256 HDR environment and 1024x512 WebP sky. Optional sky loading has a five-second deadline and disposes late results. Existing procedural environment remains the fallback.

A bounded half-float render target and fullscreen pass add highlight glow and restrained grading. Unsupported HDR buffers use direct rendering. Mobile post resolution is capped at 1,048,576 pixels and 2 samples; slow frames reduce effects, post resolution and DPR. Instanced buffers are disposed between floors. Multiplayer, trading and the classic boss encounter logic are unchanged.

Validation: 1095 tests, 1088 passed, 0 failed, 2 skipped, 5 existing TODO. HDR decoded to 512x256 successfully. Final Worker 9,790,889 bytes. Artifact fetches returned 200 for entry, both new modules, loader, stylesheet, HDR, sky and service worker. Read-only code review fixes applied. Browser/GPU rendering, perceived appearance and real phone FPS were not verified because managed browser QA was unavailable.
