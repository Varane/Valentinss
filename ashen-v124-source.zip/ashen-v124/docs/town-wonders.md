# A small pocket of town magic

Add an original ivory unicorn by the garden, a translucent seven-color arch over the river and slow colored motes above a thin ground halo. Keep the rest of the town palette intact. No post-processing, added lights, downloaded models or persistent data changes.

August has six short original lines and can be reached using Places. The nearby action opens a local dialogue; Escape and the goodbye button return to movement without a trade cancellation. Reduced motion freezes the ambient time animation. Geometry and materials are owned and disposed once.

Validation: full game regression suite, actual geometry/route/disposal tests and packaged asset hash checks. Offline mesh inspection does not constitute a browser or phone check.
