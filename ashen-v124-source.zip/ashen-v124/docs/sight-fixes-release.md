# Sight fixes release

Reproduced and fixed three defects from version 26:

- Actor visibility could retain the previous facing for up to the 75ms terrain refresh interval. Eye position/facing now updates every frame; expensive terrain sampling stays throttled.
- Easing directly into an 8-bit array rounded away small changes and stalled at 252/255 at 120Hz. A Float32 accumulator now converges before conversion to texture bytes.
- LOS accepted a first endpoint outside the map and nonfinite facing. Both are rejected before grid traversal.

Three regression tests failed before the fixes and pass afterward. Full suite: 1103 tests, 1096 passed, 0 failed, 2 skipped, 5 existing TODO. Read-only review found no important issues. Final Worker: 9,799,836 bytes. Entry, perception modules and service worker returned HTTP 200 from the exact build artifact. Browser cache updated. Managed browser QA unavailable; actual GPU and phone rendering not verified.
