# Distinct Volkhv, Danik and Vitalik

The three heroes shared a rig, nearly identical desaturated base clothing and small accessories. Keep the production rig, animations, weapons, hair customization and save IDs; make each silhouette legible at game scale through the existing merged bone-attached sections.

Volkhv: warm linen, wide shoulder mantle and long flared robe. Danik: terracotta workwear, broad dark apron, a prominent spare metal ring and open wrench at the belt. Vitalik: navy jacket, equipment backpack, shoulder straps and enlarged headset with microphone. Far town crowd colors follow the same avatar palette. No additional character draw sections or downloads.

Verify actual geometry bounds, all existing character/appearance tests, five-hero offline render and full game regression suite. Offline renders are not browser/phone verification.
