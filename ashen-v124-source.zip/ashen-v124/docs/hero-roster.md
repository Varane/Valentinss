# Five town heroes

Volkhv (legacy knight), Wizard (legacy mage), Danik, Kvak and Vitalik are selectable in the campaign, town and classic character selector. Danik and Vitalik retain the existing melee combat archetype; this is a visual identity change, not a new balance system. Existing knight/mage/frog save identifiers are preserved. Each avatar has independent campaign storage and barber appearance.

The humanoid kit has six merged bone-attached sections, with face and headwear separate so haircuts preserve the face. Original cloth, face, beard, hats, mechanic apron/spark plug/wrench/brake disc and IT glasses/headset/computer geometry replace the colorful ornamented raider kit on heroes. Enemy models remain separate. Armor upgrades preserve each hero palette. Kvak retains its articulated expressions with muted clothing colors.

The existing source humanoid rig and animation clips remain. Hero shoulder tailoring owns and disposes cloned geometry without modifying shared enemy geometry. Source body textures are replaced by neutral cloth colors.

Verification: real production rig tests cover independent geometry disposal, all animation blends, appearance changes, tool reach and finite costume meshes. Five hero campaigns round-trip independently, and five barber profiles synchronize to peers and survive reconnect. Offline mesh renders check fit and silhouette; they do not establish browser/iPhone FPS or final WebGL appearance.
