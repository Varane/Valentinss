# Skills, meals and hair

Six original hairstyles extend the existing four styles plus no-hair option: side part, bob, long, bun, curls and buzz. Shared appearance validation, barber profiles and actual merged hairstyle geometry support all five heroes and all existing equipment.

Town fishing, forging and harvest rewards are credited to the existing market wallet. The legacy produce counters become an earned ledger; produceClaimed is advanced in the same optimistic commit as the wallet and player (plus garden world when dirty). Reconnect cannot claim the same stock twice. Existing accounts and balances are preserved.

Fresh fish, herbs, ingots and cooked food are tradable via merchant, player exchange and exchange orders. Crafted armor remains bound. Cooking consumes real fish and herbs; server-owned skill levels gate recipes. Cooking/crafting XP and ingredient spending share a multi-document commit; request receipts prevent replay.

Visible level 1/3/5 paths: fishing and smithing yield one/two/three units; gardening level3 reduces newly planted growth to67.5seconds, level5 doubles harvest. Cooking offers20/35/50HP meals from one fish plus0/1/2 herbs; gardening unlocks15/30HP herbal drinks, smithing unlocks bound tier-I iron/tier-II steel armor. Recipes show ingredients, required and current level. Raw fish has a direct Cook button.

Meals heal inside a campaign through existing server consumption receipts. The normal UI refuses use at full HP. Confirmed receipts still mark themselves applied if health becomes full before delivery, preventing a future replay heal, including on a full-health checkpoint. PvP consumption remains disabled.

Validation covers geometry, profile persistence, old-stock migration, gathering yields, growth, server recipe locks, atomic XP/material updates, replay recovery, actual campaign healing and cooked-fish merchant/direct/exchange transfers. Browser/iPhone visual and touch QA remains unverified in this environment.
