# Main cave cooperation, up to four players

## Confirmed defect

Town invitations and the main cave's cooperative link opened `classic.html`. That client used the separate Crimson Ledger campaign/action engine, whereas the main investigation lives at `expedition.html` with remake/core, five chapters, cave trials and bell mechanisms. The room service also rejected the third and fourth clients. Increasing the old capacity alone would not fix the content mismatch.

## Delivered path

Town, inn and main-cave cooperative entry now open `expedition.html?coop=1`. A cave-scoped saved session preserves existing classic sessions separately. Create a party, invite up to three friends using its public code/link, then the host starts once the intended members have joined (one to four participants). Joining an already started party requires its saved session; new members join before start.

The cave server is authoritative. It uses the same main run, authored encounters, evidence, five visual trials, bell operation and final investigation verdict. Player positions, health, consumables, cooldowns and equipment are independent; world time, enemies, evidence and chapter progression are shared. Enemies and projectiles tick once per simulation step, not once per party member. An incapacitated player waits for the next chapter while living members can continue. Chapter upgrades reunite the party. The current party upgrade choice applies to the whole group.

Cave trials are validated on the server; sending an answer before the evidence/floor completion cannot grant progress. Solved rescues update each connected player's existing camp. The shared room survives reload. Individual solo saves are not overwritten. Existing classic rooms and duel authority remain supported separately.

A missing connection pauses shared simulation. The member can reconnect using the saved session, or the host can explicitly remove an absent member and continue. Session tokens never enter invitation URLs. Remote models retain separate animation and appearance, interpolate presentation positions, and release resources on departure/floor changes. Map identity persists between snapshots so exploration memory is retained. Server tick batches restore shared state once rather than regenerating it on each tick.

## Verification scope

Engine simulation physically navigates all five chapters with both two and four actors, actual combat, 24 kills, five pieces of evidence, three bell interactions, upgrades, deductions and final verdict. Checkpoints are serialized/reloaded at transitions. This verifies reachability, not subjective fun.

Actual client controllers call the HTTP room handler; additional tests use four cookie-authenticated accounts and SQLite/D1-compatible storage. Checks cover capacity, explicit host start, independent movement, wrong/locked puzzle attempts, shared progression, session reload, pauses, absent-member recovery, fresh joystick direction for dash, safe invitation destinations and retained exploration. Renderer layer tests exercise distinct peer instances and resource cleanup. Browser/phone control is unavailable; no live device playtest is claimed.

Solo shopping/trading and tactical pause remain in solo mode; simultaneous cave combat uses automatic basic attacks plus the existing spell, dash and healing buttons. The existing classic cooperative campaign is retained, rather than overwritten or migrated in place.

Final release checks: 1,887 total cases — 1,880 passed, zero failed, two skipped and five pre-existing TODO. The Worker build emitted 473 assets; all were fetched through the built Worker and matched the manifest SHA-256 hashes.
