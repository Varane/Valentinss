# River town at golden hour

Compose a more memorable arrival using a warm low sun, cool sky fill, a procedural cloud veil, distant layered river hills and sparse water highlights. Keep the existing HDR environment and one shadow map. The atmosphere owns three draw objects, no extra render targets or downloaded textures, with stationary highlights in reduced-motion mode. Decorative sky and points do not participate in scene picking.

Place an original curved wooden boat at14,-19 inside the unwalkable river. Double hull surfaces, tubular gunwales, benches, oar and mooring line merge with existing wood and bronze material batches. No new obstacles, action prompts or menus.

Verify finite geometry, river positions, resource ownership, picking, routes, existing phone draw/triangle budgets and full regressions. Inspect town geometry and approximate new lighting offline; this is not a browser rendering or physical phone FPS test.
