# Authoritative two-player room API

Production rooms use the Worker and persistent D1 storage. See DEPLOYMENT.md for packaging details.

## HTTP

All bodies are JSON. Create and join return {roomId,code,token,playerId,revision,snapshot}. State/input return {roomId,revision,snapshot}; accepted inputs also return acceptance flags. Snapshot contains capacity:2, public members, the full authoritative encounter, and the server-owned profile. Public members expose playerId and heroIndex. Tokens never appear in public snapshots.

| Method | Route | Body |
| --- | --- | --- |
| POST | /api/rooms/create | {profile?} |
| POST | /api/rooms/join | {code} |
| GET | /api/rooms/:roomId/state | none |
| POST | /api/rooms/:roomId/input | {revision,seq,x,z,actions} |
| POST | /api/rooms/:roomId/leave | {} |

Encode roomId as a URL path component. State, input and leave require Authorization: Bearer <token>. The six-character invitation code is shareable and cannot authenticate a member. Each member gets a distinct private token. Capacity is exactly two, including concurrent joins. Leaving revokes only that token and frees its slot. Room expiry or closure can also invalidate a session.

Input uses the latest received revision and a positive, monotonically increasing safe integer seq per member. Movement components must be finite and within [-1,1]; diagonal vectors are normalized. The only actions are attack, dash, parry, special, revive, expressed as a distinct string array. Server cooldowns, stamina, range and skill requirements decide whether an accepted action takes effect. Token membership determines the actor; client actor IDs, damage, rewards, position and elapsed time have no authority. Extra input properties are ignored.

An identical retry of the last accepted seq and intent is idempotent even with a stale revision. It returns current state without advancing simulation or spending resources again. Different intent reusing that seq and older seq values are conflicts. The retry history covers the last accepted command, not unlimited past commands.

Errors use {error:{code,message},revision?,snapshot?}. A 409 REVISION_CONFLICT includes current revision and snapshot: apply them and retry the same unaccepted sequence once. Other conflicts, such as ROOM_FULL or STALE_SEQUENCE, are errors. Invalid input is 400, unauthorized membership 401, unknown rooms/codes 404; expired/closed rooms are 410.

Server time advances in fixed 20ms steps with at most one second catch-up per request. Clock-only updates retain the command revision and still publish a fresh snapshot. Rooms wait for a second member before simulation. Each common tick advances both humans together with separate intent vectors and companion AI disabled. Movement intent expires after 300ms without fresh input. This is request-driven synchronization, not WebSocket push.

## Browser client and root rendering integration

Import createRoomClient from dist/ui/network-client.mjs. Construct with {baseUrl,onSnapshot,onStatus,fetchImpl?,storage?}. Empty baseUrl is visibly unavailable and rejects create/join with UNAVAILABLE. A static website address is not a verified backend.

Methods: create({profile?}), join(code), resume(), sendInput({x,z,actions,seq?}), poll(), leave(), getState(), destroy(). Operations are asynchronous except getState/destroy. getState exposes connection status, room metadata and snapshot, never the token. Client serialization prevents older polls from rolling back new input state. A revision conflict applies server state and retries the same sequence once. A network error displays reconnecting; a later successful poll reconnects with existing credentials. Unauthorized credentials are cleared, without silently rejoining by code.

Root runtime integration:

1. Wire create/join/resume/leave controls and render onStatus. Display code only; retain token privately.
2. Replace the encounter rendered by the root loop with onSnapshot's snapshot.encounter. Use snapshot.profile for the room profile view. Preserve the independent local save.
3. During a room session, send bounded movement/action intentions from the existing input module. Do not locally step or command the authoritative encounter or locally award network victory rewards.
4. Render the latest server snapshot each frame. Resolve the controlled actor using authenticated playerId and members.heroIndex. Local hero switching cannot command the other member.
5. Poll and send intent at bounded intervals. Stop timers and call destroy on disposal. destroy preserves resumable credentials; leave clears them. A failed request is not proof of a successful server leave.
6. Call resume on return. Show disconnected state until the server confirms membership; offer create/join after expiry or revocation.

The client transports state; it does not attach controls, render the scene or own the root animation loop. Visual interpolation may smooth positions but must not mutate authoritative combat or turn predicted rewards into final rewards.

## Progression limits

Rooms use a server-owned ten-room campaign. Candidate names may be copied as safe cosmetic strings; client XP, equipment, skills, HP, gold and damage are never imported. Combat uses dist/action.mjs and canonical campaign settlement pays each victory once. Authenticated same-origin account cookies bind the controlled hero privately when joining; new rooms initialize that hero from the protected co-op victory XP ledger. Guests start with zero XP and retain progression only within their room.

Permanent co-op XP is separate from the client-authored solo save. Only server-confirmed victory XP is durable; choice bonus XP, equipment, gold and selected skills remain in the current expedition. Death clears equipment and preserves XP. An existing room can restart after defeat or campaign completion with the same memberships. Leaving and creating a new room imports account victory XP, but not the previous expedition's loadout. Anonymous room expiry loses room-only progression. No endpoint accepts a client claim for rewards or account identity.

The D1 store commits the room and unique per-account/hero XP receipts in one transaction. A fresh private nonce plus storage version gates each receipt, so losing CAS writers and repeated requests cannot pay twice. Pure disconnect/resume keeps eligibility; a replacement who joined after combat began cannot claim that fight. Duels never award co-op XP. Public snapshots expose `durableCoopXp` and per-member `durableXp` booleans, never private account/session identifiers. `GET /api/account` returns the protected `coopProgress` totals.

`POST /api/rooms/:roomId/prepare` accepts a bearer token and `{revision,type,itemId?,skillId?,choiceId?}`. Types: `equip`, `learn`, `choice`, `next`, `restart`. Equipment and skills affect only the authenticated member's hero. Preparation is locked during started combat and any unreturned duel. `next` requires a cleared unfinished room; `restart` requires defeat or a completed campaign and two members. Revision conflicts include a current snapshot; clients must not automatically repeat transitions. Snapshots include the authoritative campaign and metadata for the currently displayed encounter.

## Core and storage

server/room-core.mjs exports createRoomService({store?,now?,randomBytes?}), MemoryRoomStore and RoomError. Service methods: create({profile?,mode?},trustedContext?), join({code},trustedContext?), state({roomId,token}), input({roomId,token,revision,seq,x,z,actions}), prepare({roomId,token,revision,type,...}), duel({roomId,token,message}), leave({roomId,token}). Only the Worker can supply trustedContext.accountId after session resolution; request JSON is not that context. Direct creation supports only the default/`coop` mode; PvP starts through mutual invitation inside a room. RoomError carries status,code,message and optional revision/snapshot.

Store methods are async create(room)->boolean, get(id), findByCode(code), compareAndSet(id,expectedStorageVersion,nextRoom)->boolean. Compare-and-set must be atomic across Worker instances. Storage version is distinct from public revision. MemoryRoomStore is a one-process development/test adapter and loses rooms on restart. Deploy the persistent Worker adapter for online play.

Run node --test tests/network-core*.test.mjs tests/network-client*.test.mjs from the repository root. These are local authority/transport checks; they do not verify deployed availability from two devices.
