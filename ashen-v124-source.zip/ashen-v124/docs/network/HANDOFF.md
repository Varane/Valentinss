# Final D4 evidence — 2026-11-11 22:03 UTC

This section supersedes earlier dependency/blocker observations below. Exactly three historical subagent starts, all requested/accepted ultra, no model override; children disappeared after app interruptions, no replacements/new agents were created. Lead completed the missing independent QA/audit files itself.

Delivered: build adapter, accessibility helper, settings/PWA/network QA, docs/network/HANDOFF.md, DEPLOYMENT.md, QA.md. Static artifact work/d4-static-final-2200:64 files / 1,158,148 bytes; all sizes/SHA-256 and unchanged manifests verified by node work/d4-verify-build.mjs. Retired art/ rasters excluded; static staging omits migrations. Earlier 2123 staging is superseded. Snapshot proves artifact integrity, not a device/runtime release.

Actual D3: worker/index.mjs default {fetch}; worker/d1-room-store.mjs requires env.DB; optional env.CORS_ORIGINS is an exact comma-separated allowlist, normally unset. Migration drizzle/0000_coop_rooms.sql creates coop_rooms(id,code UNIQUE,storage_version,room_json); no Drizzle journal/config, so hosted migration discovery remains unverified. Root may invoke node server/local-server.mjs (127.0.0.1:4183; memory rooms disappear on restart); D4 started no listener. Worker build command node scripts/build-coop.mjs --mode worker --out work/d4-worker-verify-2142 failed explicitly: esbuild unavailable. No install/publication attempted. Root retains project_id appgprj_6af4c1565ba48191b1671993771a6312, omits static for Worker and must validate the exact logical d1:DB manifest declaration against hosting schema; required runtime env.DB is certain, declaration shape/provisioning is not claimed verified. Preserve private audience and unused r2:null.

Verification: accessibility12/12; independent network security4/4 and PWA API bypass1/1; client20/20 and SQLite-backed D1 store5/5. Broader final command node --test tests/input*.test.mjs tests/network*.test.mjs worker/*.test.mjs =>139 tests,135 pass,4 fail (work/d4-all-final.log). All network/core/HTTP and D4 tests pass. Remaining failures belong to D2: input-ui-localization.test.mjs has3 RU restoration/live-source/script-style expectations failing, and input-ui-skills.test.mjs:87 expects blood2 but receives blood3 during geometry keyboard navigation. Do not claim whole relevant suite green. Earlier missing campaign/save.mjs and v3 API interception were fixed concurrently by their owners; latest PWA/network tests pass.

Root must rerun a fresh artifact after final integration, bundle Worker with an available esbuild, provision D1/apply the migration, and verify actual two-device play before advertising online. No deployed/iPhone/VoiceOver/device/offline-install test was performed by D4. Exact browser API and consumer responsibilities are documented below and in docs/network/API.md.

---
# D4 integration handoff

Initial handoff: 2026-11-11 21:25 UTC. Read `API.md` for the final D3 contract, `DEPLOYMENT.md` for staging/manifest constraints, and `QA.md` for device/PWA release checks. No online service or iPhone execution is claimed.

## Browser imports

```js
import { createAccessibility } from './ui/accessibility.mjs';
import { createRoomClient } from './ui/network-client.mjs';
```

Accessibility: `createAccessibility({root?,storage?})` returns `getSettings()`, `setSetting(name,value)`, `subscribe(fn)`, `destroy()`. Boolean settings `reducedMotion`, `blood`, `inputHints`; key `ashen-accessibility-v4`, version 1. OS reduced-motion is used until explicitly overridden. Consume the initial snapshot and later updates; root must forward blood/reduced motion to WebGL effects/world. The helper only owns preference DOM attributes/scoped motion CSS, no simulation/HUD. Settings suite: 12/12 reported passing by assigned subagent.

D3 provisional/frozen service API: `createRoomClient({baseUrl,onSnapshot,onStatus,fetchImpl?,storage?})` → async `create({profile?})`, `join(code)`, `resume()`, `sendInput({x,z,actions,seq?})`, `poll()`, `leave()`, plus `getState()`, `destroy()`. Final D3 file/API documentation takes precedence. Unset backend is unavailable, not a pretend connection. Root's local renderer must adopt authoritative snapshot and controlled player slot when connected, avoid running a second local authority, and clear input on disconnect/pause.

HTTP contract: POST `/api/rooms/create`, POST `/api/rooms/join`, POST `/api/rooms/:id/input`, GET `/api/rooms/:id/state`, POST `/api/rooms/:id/leave`. Protected requests use opaque bearer token separate from code. Input includes revision and monotonically increasing member sequence; identical sequence/payload retries are idempotent before stale-revision rejection. Capacity two. Core imports from `server/room-core.mjs`: `RoomError`, `MemoryRoomStore`, `createRoomService`. Service methods `create`, `join`, `state`, `input`, `leave`; response `{roomId,code?,token?,playerId?,revision,snapshot,accepted?,duplicate?}`. Snapshot `{encounter,profile,members,capacity:2}`. Memory store is a test/local store, not hosted persistence.

## Build and limitations

`node scripts/build-coop.mjs --mode static --out work/FRESH_DIRECTORY` stages a local static artifact without changing root files. Worker mode additionally needs actual D3 entry + esbuild; see DEPLOYMENT. Output is confined below repository `work/`. No server is started. No source hosting changes, publish, commit or access change was performed. Existing `preview.cjs` remains root-owned and static-only.

At initial handoff the Worker entry and final API documentation were still arriving. Final D3 migrations/environment/error codes must be reconciled before release. Worker/D1 deployment and actual two-device play are required to call online mode verified. PWA root changes are instructions only in QA.md; old v3 SW must not cache protected `/api/` responses.

