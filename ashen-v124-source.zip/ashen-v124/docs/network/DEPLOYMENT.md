# Final D4 evidence — 2026-11-11 22:03 UTC

This section supersedes earlier dependency/blocker observations below. Exactly three historical subagent starts, all requested/accepted ultra, no model override; children disappeared after app interruptions, no replacements/new agents were created. Lead completed the missing independent QA/audit files itself.

Delivered: build adapter, accessibility helper, settings/PWA/network QA, docs/network/HANDOFF.md, DEPLOYMENT.md, QA.md. Static artifact work/d4-static-final-2200:64 files / 1,158,148 bytes; all sizes/SHA-256 and unchanged manifests verified by node work/d4-verify-build.mjs. Retired art/ rasters excluded; static staging omits migrations. Earlier 2123 staging is superseded. Snapshot proves artifact integrity, not a device/runtime release.

Actual D3: worker/index.mjs default {fetch}; worker/d1-room-store.mjs requires env.DB; optional env.CORS_ORIGINS is an exact comma-separated allowlist, normally unset. Migration drizzle/0000_coop_rooms.sql creates coop_rooms(id,code UNIQUE,storage_version,room_json); no Drizzle journal/config, so hosted migration discovery remains unverified. Root may invoke node server/local-server.mjs (127.0.0.1:4183; memory rooms disappear on restart); D4 started no listener. Worker build command node scripts/build-coop.mjs --mode worker --out work/d4-worker-verify-2142 failed explicitly: esbuild unavailable. No install/publication attempted. Root retains project_id appgprj_6af4c1565ba48191b1671993771a6312, omits static for Worker and must validate the exact logical d1:DB manifest declaration against hosting schema; required runtime env.DB is certain, declaration shape/provisioning is not claimed verified. Preserve private audience and unused r2:null.

Verification: accessibility12/12; independent network security4/4 and PWA API bypass1/1; client20/20 and SQLite-backed D1 store5/5. Broader final command node --test tests/input*.test.mjs tests/network*.test.mjs worker/*.test.mjs =>139 tests,135 pass,4 fail (work/d4-all-final.log). All network/core/HTTP and D4 tests pass. Remaining failures belong to D2: input-ui-localization.test.mjs has3 RU restoration/live-source/script-style expectations failing, and input-ui-skills.test.mjs:87 expects blood2 but receives blood3 during geometry keyboard navigation. Do not claim whole relevant suite green. Earlier missing campaign/save.mjs and v3 API interception were fixed concurrently by their owners; latest PWA/network tests pass.

Root must rerun a fresh artifact after final integration, bundle Worker with an available esbuild, provision D1/apply the migration, and verify actual two-device play before advertising online. No deployed/iPhone/VoiceOver/device/offline-install test was performed by D4. Exact browser API and consumer responsibilities are documented below and in docs/network/API.md.

---
# Cooperative build and deployment

D4 build adapter is local-only. No deployment, access changes, dependency installs, preview servers or source manifest edits were performed. Existing project ID: `appgprj_6af4c1565ba48191b1671993771a6312`; preserve its private audience.

## Verified build entry

From the repository root:

```sh
node scripts/build-coop.mjs --mode static --out work/d4-static-verify-2123
```

The output is a separate staging checkout with `.openai/hosting.json`, `dist/`, immutable copied `drizzle/` when present, and `build-report.json` (asset sizes and SHA-256). Existing output is refused; choose a fresh directory. The adapter never deletes files or overwrites source `dist/`.

Static staging preserves offline/local play only. It does not supply room-code networking. Source files are being authored concurrently: rerun to a fresh directory after freeze for a coherent final snapshot.

## Worker build

```sh
node scripts/build-coop.mjs --mode worker --entry worker/index.mjs --out work/d4-worker-final --esbuild ABSOLUTE_PATH_TO_esbuild/lib/main.js
```

The D3 entry must exist and default-export `{fetch(request,env,ctx)}`. Override `--entry` with its actual final filename. `esbuild` may instead be installed in the module resolution path; no install is automatic. The adapter bundles the relative module graph, embeds all static assets, routes `/api` and `/api/*` to D3, serves only GET/HEAD assets with MIME/ETag/no-sniff, returns real 404s, and verifies the bundled default export plus GET `/` before writing. Worker output: `dist/server/index.js`. This mode removes `static` only from its staging manifests; it does not provision D1.

## Manifest change for root only

Static manifest remains exactly `{ "project_id": "appgprj_6af4c1565ba48191b1671993771a6312", "static": { "directory": "dist" } }` plus any existing fields.

For Worker hosting preserve `project_id` and all unrelated declarations, omit `static`, declare logical D1 binding `DB` according to the installed Sites manifest schema, and leave unused `r2` null. Do not invent a database UUID. The adapter deliberately preserves the existing D1 declaration rather than guessing schema/provisioning state. Required runtime: `env.DB` implementing Cloudflare D1. Exact D1 declaration shape is a provisioning check still required before publication; source manifest currently has no D1 field. Sites storage guidance says the platform provisions/connects logical bindings and applies hosted migrations before Worker upload. Browser storage is only for device-local preferences/reconnect credentials, never durable authoritative room state.

## Migrations and security

D3 owns `drizzle/` and the D1 store. Review the actual migration and journal before root packages. Never execute schema creation from request handlers. Applied migrations are immutable, schema-only; local and hosted databases are separate. This repository does not currently include the Vinext/Wrangler local database toolchain: no `npm run db:generate` or Wrangler command is claimed to work here. Use D3's actual migration files and a configured local D1 runner, or the Sites deployment migration pipeline, after root verifies the manifest binding.

Room codes are invitations, not authorization. Bearer credentials must remain separate, never appear in UI codes/URLs/logs or static assets. Preserve same-origin private hosting; no permissive CORS. API traffic must bypass service-worker caches. Online multiplayer remains unverified until actual Worker + D1 deployment and two-device testing. No iPhone test was run by D4.

