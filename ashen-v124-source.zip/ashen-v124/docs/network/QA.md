# Final D4 evidence — 2026-11-11 22:03 UTC

This section supersedes earlier dependency/blocker observations below. Exactly three historical subagent starts, all requested/accepted ultra, no model override; children disappeared after app interruptions, no replacements/new agents were created. Lead completed the missing independent QA/audit files itself.

Delivered: build adapter, accessibility helper, settings/PWA/network QA, docs/network/HANDOFF.md, DEPLOYMENT.md, QA.md. Static artifact work/d4-static-final-2200:64 files / 1,158,148 bytes; all sizes/SHA-256 and unchanged manifests verified by node work/d4-verify-build.mjs. Retired art/ rasters excluded; static staging omits migrations. Earlier 2123 staging is superseded. Snapshot proves artifact integrity, not a device/runtime release.

Actual D3: worker/index.mjs default {fetch}; worker/d1-room-store.mjs requires env.DB; optional env.CORS_ORIGINS is an exact comma-separated allowlist, normally unset. Migration drizzle/0000_coop_rooms.sql creates coop_rooms(id,code UNIQUE,storage_version,room_json); no Drizzle journal/config, so hosted migration discovery remains unverified. Root may invoke node server/local-server.mjs (127.0.0.1:4183; memory rooms disappear on restart); D4 started no listener. Worker build command node scripts/build-coop.mjs --mode worker --out work/d4-worker-verify-2142 failed explicitly: esbuild unavailable. No install/publication attempted. Root retains project_id appgprj_6af4c1565ba48191b1671993771a6312, omits static for Worker and must validate the exact logical d1:DB manifest declaration against hosting schema; required runtime env.DB is certain, declaration shape/provisioning is not claimed verified. Preserve private audience and unused r2:null.

Verification: accessibility12/12; independent network security4/4 and PWA API bypass1/1; client20/20 and SQLite-backed D1 store5/5. Broader final command node --test tests/input*.test.mjs tests/network*.test.mjs worker/*.test.mjs =>139 tests,135 pass,4 fail (work/d4-all-final.log). All network/core/HTTP and D4 tests pass. Remaining failures belong to D2: input-ui-localization.test.mjs has3 RU restoration/live-source/script-style expectations failing, and input-ui-skills.test.mjs:87 expects blood2 but receives blood3 during geometry keyboard navigation. Do not claim whole relevant suite green. Earlier missing campaign/save.mjs and v3 API interception were fixed concurrently by their owners; latest PWA/network tests pass.

Root must rerun a fresh artifact after final integration, bundle Worker with an available esbuild, provision D1/apply the migration, and verify actual two-device play before advertising online. No deployed/iPhone/VoiceOver/device/offline-install test was performed by D4. Exact browser API and consumer responsibilities are documented below and in docs/network/API.md.

---
# D4 release QA and concrete limits

No D4 browser, device, iPhone, hosted Worker or hosted D1 test occurred. Node/static checks cannot establish touch usability, VoiceOver behavior, frame rate, installability or actual online availability. Root owns the sole preview and browser.

## Automated commands

```sh
node --test tests/input-accessibility-settings.test.mjs tests/input-accessibility-audit.test.mjs tests/network-qa-security.test.mjs
node --test tests/input-controls*.test.mjs tests/input-hud*.test.mjs tests/input-ui*.test.mjs
node --test worker/http.test.mjs worker/d1-room-store.test.mjs tests/network-core*.test.mjs tests/network-client*.test.mjs
```

Settings checks cover blocked/corrupt storage, independent preferences, OS reduced motion, explicit overrides, immutable snapshots, notification ordering and cleanup. Independent network checks cover cross-room token isolation, invitation-code rejection as authorization, concurrent room capacity, idempotent retry, stale revision, invalid vectors, token revocation and slot replacement. The PWA audit executes the real service worker in a Node VM and requires authenticated API GET/POST to bypass interception. Mocks do not establish actual D1 service behavior.

## Root-owned service worker and manifest actions

1. Use a new versioned cache name for the final v4 module graph, including local Three.js, world/figures/combat/campaign/UI/input/i18n/music modules actually imported by the final entry. Do not retain v3 raster-scene precache as the active app. Check transitive and dynamic imports; an HTML shell alone is not offline support.
2. Before any cache lookup, bypass non-GET, cross-origin and same-origin `/api` or `/api/` requests; never cache Authorization-bearing responses. Server uses `Cache-Control: no-store`, which must not be defeated by a custom SW cache strategy.
3. Verify cache installation handles unavailable optional assets and cache upgrade removes obsolete caches only after the new app is ready. Check reload under an already-installed v3 worker and then airplane-mode local play. Online rooms must become visibly disconnected offline.
4. Root must validate manifest name/short_name, start_url/scope matching the final deployment path, standalone display, actual available icon files and iOS-compatible home-screen icon. Confirm viewport safe-area support and portrait/landscape controls on real hardware. No icon-generation or manifest edit was made by D4.

## Required manual gate on root preview / actual device

- Keyboard: WASD/arrows, Space/Shift/E/R/F, Q, I/K, Escape; gameplay stops while text inputs/dialogs are focused. Opening and closing menus returns focus meaningfully. Tab order and visible focus reach pause/settings/equipment/skills/room actions.
- Touch: joystick plus another finger attacking; pointercancel/lost capture/blur/background clears held movement and attacks. No stuck input after rotating or returning from app switcher. Controls fit safe areas at 320px width and do not obscure combat.
- Settings: OS reduced-motion applies before interaction; explicit override survives reload. Blood toggles actually call WebGL consumer; hints toggle does not hide required action labels. VoiceOver labels and health/room status are meaningful without narrating every frame.
- Two devices on deployed private Worker+D1: create/join same code; distinct tokens and actor slots; simultaneous movement/combat; disconnect/reconnect; stale input retry; third join refused; leave revokes token; backend missing is visibly unavailable. Never infer this from passing in-process Node tests.

## Build status

Static staging was generated under `work/d4-static-verify-2123` (64 files, 21,110,744 bytes at that earlier source snapshot). It includes retired raster assets and is not the final optimized release. Worker build was attempted after D3 entry appeared and failed explicitly because esbuild is unavailable in module resolution; no install or publication was performed. Root must rerun a fresh artifact after final source integration. D1 binding/provisioning/migration application, deployment package size and actual two-device flow remain release blockers for online mode.

