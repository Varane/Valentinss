# Astra playability audit — 2026-11-12

## Verdict and boundary

**Simulation progression: PASS for the sampled campaigns. Rendered browser playability: NOT TESTED. Human usability and fun: NOT ESTABLISHED.**

I did not play the rendered published site. No usable browser/computer-interaction tool was available in this session; the managed Sites environment disallowed launching a replacement preview/browser. These results exercise the local production simulation modules underlying the published game. They do not verify the screen, rendering performance, pointer hit targets, visual clarity, touch-device behavior, or production connectivity. A simulation rate of 30/60 Hz is not measured browser FPS.

## Evidence

32 independent campaigns completed all five floors and defeated all 24 enemies. They collected the investigation evidence, recorded five deductions, and reached the justice ending using public game APIs. No player teleports, health edits, enemy mutations, or forced progression were used.

| Profile | Seeds | Heroes / rates | Wins | Simulation duration | Dodges / potions |
| --- | --- | --- | --- | --- | --- |
| Precise movement and visible-telegraph dodge | 1, 27, 4229 | knight + mage; 30 + 60 Hz | 12/12 | 300–514 seconds | 75 / 0 total |
| Approx. 150 ms decisions, no dodge | 1, 27, 991, 4229, 100003 | knight + mage; 30 + 60 Hz | 20/20 | 323–581 seconds | 0 / 0 total |

At 30 Hz the rounded slow cadence is 5 frames (167 ms); at 60 Hz it is 9 frames (150 ms). All runs used the default autoattack through `soloIntent`. Movement, optional dash, healing attempts, upgrades, deductions and verdict use the shipped exported functions. The bot consumes visible enemy telegraphs, remembers floor tiles discovered with `canSee`, and navigates only that remembered geometry. It pursues clues/exits only after observing them. It does not consume the omniscient objective compass. Dead/alive guard count is available in the HUD and is used for exit readiness.

This is still a competent scripted explorer with perfect map memory, exact pathfinding, and precise analog vectors. It reads the correct deduction option from content metadata: that verifies state progression, not mystery comprehension. Modal reading time and physical button acquisition are omitted. The slower decision profile improves the temporal model but does not turn it into a human player. No stalled or dead runs occurred in this sample; no claim is made for every seed.

## Findings

1. **Visibility leak, reproducible source-level defect (parent fixed).** `objectiveFor` returns a fresh coordinate object for a guard. `r.enemies.includes(goal.position)` therefore always fails in the prior compass/minimap code. The resulting routes could disclose enemies behind walls and outside the field of view. Parent replaced the identity test with perception keyed by objective type and added guidance regressions. The campaign runner deliberately did not rely on this leak.
2. **Tactical depth remains unproven; forgiving combat is a concern.** Every slower campaign won without a dodge or potion. Automatic heart pickups and between-floor healing were enough despite 992 total incoming damage across those 20 campaigns. This supports accessibility/reachability but does not demonstrate meaningful pressure to use dodge, potion, shop, or equipment tradeoffs. Do not infer engaging combat or rebalance solely from these bots.
3. **No sampled campaign progression blocker.** Exploration, defeating guards, finding evidence, reaching the portal, four upgrades, and final verdict all remained reachable at both simulation rates. This is a bounded simulation claim, not approval of the rendered UI.

## Durable artifacts and reproduction

- `tests/helpers/visible-play-session.mjs`: exported `visiblePlaySession` runner; supports hero, seed, rate, decision cadence, dodge enablement, auto/manual attack, and time budget.
- `tests/playability/visible-campaign.test.mjs`: 12 regression campaigns (seeds 1/27/4229, both heroes, both rates), 150–167 ms decisions without dodge. Asserts win, 24 kills, five clues/deductions, four transitions, justice ending and no stall.
- `docs/playability-evidence/results.jsonl`: original 12 precise-run metrics.
- `docs/playability-evidence/delayed-results.jsonl`: original 20 slower-run metrics.
- `scripts/playability-sessions.mjs`: CLI metrics wrapper.

Run the regression file with `node --test tests/playability/visible-campaign.test.mjs`. Reproduce slower metrics with `ASHEN_DELAYED=1 ASHEN_NO_DASH=1 node scripts/playability-sessions.mjs 1 4229 27 991 100003`.

The regression command passed after helper extraction (about 5.4 seconds). Those 12 repeat checks are not counted as new independent campaigns in the 32-run total. The parent separately owns and validates pointer-input/lifecycle tests; this audit does not claim browser evidence from them.
