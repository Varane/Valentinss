# Parallel Kvak production — four actual artist agents

User feedback supersedes initial candidate: clearer distinguishable clothes, real frog paws, photoreal direction with some goofy warmth. A separate user-visible ChatGPT chat cannot be created from this session. Four actual collaborating agents were used:

1. Anatomy: `anatomy_parts.py` owns continuous skin/head and four front/five hind digits/webbing, landmarks and socket positions.
2. Clothes: `clothing_parts.py` owns linen shirt, vest, cape, cropped breeches and messenger bag; semantic garment roles survive GLB extras.
3. Surfaces: `surface_materials.py` owns UV/PBR/vertex-colour mapping, separate skin/linen/leather/iris appearance.
4. Assembly: `build_kvak_v2.py` owns rig/weights, facial targets, clips, sockets, export and combined source renders. It is the sole writer of the combined export.

Contract: BlenderZup/-Yforward metres; GLBYup/+Zforward. Actual anatomy landmarks are authoritative; no second height conversion. Rest sockets must be world-aligned for existing accessory layers. Source scripts do not pretend concepts are 3D assets.

The rejected v1 is archived and excluded from runtime. v2 remains a candidate in the manifest. Main game does not load candidate models or square while the visual review is open. `/art-review.html` explicitly opts into the candidate and supports model rotation, face/hand/foot views, movement/gesture, clothes and scene sample.

External alternative: Tripo text-to-3D availability/schema inspected, quote12.5 service credits. Submission rejected with Out of credits (Private/free workspace); no job or charge occurred. No account upgrade/payment was attempted. Local Blender work continued independently.

Acceptance still open: model is a stylized authored candidate, below the generated photoreal target. Remaining concerns include rigid cloth folds, small shoulder gap, muted skin microdetail, production mesh/material budget, in-game contact and physical-phone visual/performance tests. These cannot be replaced by a passing parser test or a flattering numerical score. Phase1 is **not yet visually accepted/closed**.
