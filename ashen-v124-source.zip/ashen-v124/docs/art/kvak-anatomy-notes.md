# Kvak v2 anatomy handoff

`art-source/kvak/anatomy_parts.py` is an original Blender-only builder. It does not clear the scene, save, export, rig, or assign animation. `build_anatomy(materials)` returns `objects`, `skin`, `landmarks`, `sockets`, `facialAnchors`, `notes`.

Frame: Blender +Z up, -Y forward, metres. No old piecewise height conversion. Highest anatomical point after the final head reduction is about1.77m. Shoulder1.18, hip0.70, knee0.36, ankle0.11, wrist0.64. Clothing was directly coordinated to these landmarks. The large flat skull, upright neck and long thin shins replace the rejected squat silhouette.

Each forefoot has four separate tapering digits with visible knuckle volumes and restrained pads; hindfeet have five long toes with varied lengths. Membranes are thin closed geometry proximal to the fingers and deeper between hind toes. Exposed digit tips remain separate. Local hand/foot remesh preserves detail; exact Boolean unions connect them to the lower-resolution torso. The final skin is one surface. Eyes, irises, horizontal pupils, upper lids/hoods and oral crease are separate permitted meshes. Final ocular radii are78% of the first v2 assembly, and the globe is inset instead of protruding as a large button. The upper skin hood actually covers the upper cornea.

`Col` is a smooth multiplicative mask: dorsal(.57,.66,.58), ventral up to(1,.98,.94), with no high-frequency vertex noise. UV0 is created for all meshes. Skin/material maps remain owned by the surface artist. Every object has `bind_region`: skinAUTO, eyes/lids/oralHead. Logical socket positions and bone endpoints are authoritative for the assembly artist.

The mouth crease and lower lip are placed by raycast against the finished skin rather than an analytical skull ellipse; this corrects the buried central mouth in the first assembly. Iris UVs are front-planar X/Z, centered(.5,.5) with outer radius.45 for the radial iris texture.

Blender4.3.2 standalone probe succeeded after the final patch:15 objects,27,456 triangles including facial objects,11,250 skin vertices,15 named bone landmarks,UV0 and active Col. `python -m py_compile` passes. These are geometry/build checks, not visual acceptance.

The anatomy is an authored interpretation aimed at the new photoreal-ish/goofy target. It is not proof of concept-image parity, physical anatomy simulation, or browser/phone acceptance. Parent/lead must inspect the actual assembled preview before publication.
