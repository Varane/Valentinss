# Kvak v2 — original tailored clothing handoff

Source: `art-source/kvak/clothing_parts.py`. Interface: `build_clothing(materials, landmarks=None) -> list[bpy.types.Object]`. Blender Z-up, -Y forward, final metre coordinates. The builder does not reset, save, export, rig, or apply a global height transform.

Landmark-aware fitting consumes bone heads from the anatomy artist: shoulders1.18m, elbows0.90m, wrists0.64m, hips0.70m and knees0.36m. Optional `landmarks['measurements']` can override waist/neck/chest heights and ellipse radii. Current waist0.81m, chest radii0.27×0.20m. All final meshes have applied world-space vertices, `UVMap`, `bind_region`, `clothing_role` and `surface_role`.

## Garments

- Unbleached linen shirt with a visible lower hem, standing collar and two folded collar leaves.
- Upper sleeves follow the actual shoulder/elbow axis and end in two small cloth rolls.
- Charcoal leather waistcoat with an actual V opening, lower seam, three restrained bronze buttons and two welt pockets.
- Short asymmetrical muted-teal shoulder cape with bound front edges and a sewn hem.
- Messenger satchel with separate folded flap, closure tongue, rectangular buckle and a continuous flat cross-body strap. Bag sits behind the hanging forearm rather than intersecting it.
- One bifurcated trouser surface with a shared crotch topology, open waist and real cropped cuffs. There are no intersecting sphere trouser caps. Cuffs end0.465m, above the frog knees, preserving the long visible shins.

Meshes use prefixes `garment_shirt__`, `garment_vest__`, `garment_cape__`, `garment_breeches__` and `garment_bag__`. Underscores survive Three.js GLTF node-name sanitization. Preserve semantic groups when batching so earned appearance can selectively hide or tint base garments. If merging, merge by **garment group and material**, not material alone.

## Shared surface contract

The surface artist supplies four shared garment materials. Clothes deliberately do **not** create a `Col` attribute.

- Linen atlas: UV.u0.02–0.48 = unbleached shirt/collar/sleeves;0.52–0.98 = charcoal matte woven trousers.
- Leather atlas: UV.u0.02–0.48 = charcoal waistcoat;0.52–0.98 = warm-brown messenger bag and carrying strap.
- Cape uses its complete teal atlas; bronze closures use the supplied aged-bronze material.

`clothing_role` distinguishes `shirt`, `vest`, `cape`, `trousers`, `bag`; `surface_role` specifies linen/leather/cape/bronze/aliases. The material aliases `bag -> leather`, `trousers -> linen` avoid adding extra draw materials.

## Verification

Blender4.3.2 isolated module build succeeded.43 source objects,7,844 triangles before assembly batching, five semantic garment groups, four shared materials. All vertex coordinates finite; all meshes have `UVMap`. Syntax compilation succeeded.

The first combined source render exposed a waistcoat/shirt top intersection. A bounded patch expanded the upper leather shell outside the shirt, flared the linen lower hem clear of the trousers, lowered the trouser crotch to cover the body, and moved the bag behind the forearm. The updated combined source preview (2026-11-17,11:17) was inspected: the jagged neckline/waist seam and exposed green crotch were eliminated. A small exposed upper-shoulder connection remains and fabric folds are still restrained/stiff compared with the aspirational target. The assembly artist is checking a wave pose before acceptance. These source checks are **not** browser/phone visual acceptance or a claim of concept-image parity.

All geometry is original and built specifically for ASHEN; no downloaded garment meshes or copied franchise designs.
