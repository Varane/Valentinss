# ASHEN — Phase 1 art direction

Target concept: generated original image, 2026-11-17, `/workspace/generated_images/exec-e20eaec1-435f-4539-a0b8-c3c8fdbe8de7.png`. Concept is aspirational, not an in-game screenshot. Six art phases, separate technical preparation. Current target: 20×20m sample and Kvak.

Quiet stylized realism. Palette: olive skin #68784b, linen #d2c5a6, slate #31454b, worn leather #514435, muted teal #4b6967, pale limestone #c5beaa. Warm interior windows, neutral soft sun. Local highlights only; no global gold/no neon bloom.

Five surfaces under the same light: limestone (rough/damp by basin), plaster (mottled broad variation), oak (directional grain), linen (matte weave), leather (seam wear with restrained sheen). World metres and visible actual geometry at edges. No texture repetition scaled to tiny tiles. UV/bakes are model-specific.

Kvak: original friendly adult frog courier, 1.4–1.6m; coherent skin body, amber eyes, eyelids and expressive mouth, webbed fingers/feet. Vest/cape/satchel are separate wearable pieces. Hair and all existing outfit IDs remain supported. +Z forward, Y up, named logical sockets. Real authored mesh/rig/GLB, not the concept image as a billboard.

Square: fountain at0,0, basin inside existing collision radius2.6; inn centered-12,-9 inside9×8 footprint. Preserve all server approach/work points. Sculpture, actual rim bevels, door jambs, roof thickness and hardware. Keep paths clear. Controls: matte slate, warm neutral text, restrained bronze edge; mobile targets44px; typography16px minimum for inputs.

Acceptance: compare actual rendered game to concept by silhouette/materials/light/animation/readability. Record browser/physical device results separately; no subjective numerical quality guarantee. Device30FPS/p95<=40ms remain targets until measured.

## Revised Kvak target after user rejection

The initial squat candidate was rejected. New image target: `art-source/reference/kvak-v2-target.png` (generated original, not a screenshot). Slimmer real frog paws with distinct digits/webbing, natural inset amber eyes/eyelids, readable rolled linen sleeves/collar vs fitted buttoned leather vest, separate teal cape and satchel. Some goofy asymmetry is welcome. v2 is a candidate; it does not yet achieve the target. Four specialist agents work through the contract in parallel-art-workflow.md.
