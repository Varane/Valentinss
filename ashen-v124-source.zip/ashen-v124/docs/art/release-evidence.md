# Art candidate release evidence

Base: v84,538e0ea9d63c67757c11b6516b6d88273102cdf5. Production work uses four actual parallel artist agents; original sources and manifests retained. No literal new user-chat was created.

New source candidate: Kvak v2,35,300 triangles; runtimeGLB2,358,088 bytes; SHA256c670be1427f9f6ca37bc90de42a46facdf5c053f416087cc7be43490337f2d91. Source assembly reports9materials; GLB manifest counts8exportedmaterials. Above original model/material targets. Two source-only LODs are preserved. Square18,955triangles/9groups/1,056,036bytes, fountain/inn verified inside existing authoritative bounds.

Reviewer found three Important adapter/lifecycle defects: rest accessory frames, indefinite startup load, and weapon-class compatibility. Fixed with bind-rest normalization,5second deadline/late disposal and equipment.weaponHero/constructor class. Actual GLB/parser tests and candidate gating pass. Source pose review caught hand→leg weights and strap→arm tearing; corrected and verified by actual skin-weight tests. No browser texture decoding or GPU acceptance claimed.

Final suite:1,596 cases;1,589pass,0fail,2existing skips,5knownTODOs. All405 emitted Worker resources decoded and checked SHA256, and matched current source assets. Worker11,665,684bytes; total source asset bytes15,445,118. These are package statistics, not initial download/HAR, GPU memory or FPS.

Main game skips candidate assets. A separate public art-review page opts into model/square and offers rotation, face/hands/feet framing, walk/wave/expression and appearance choices. Current playable Kvak and existing square stay active.

Visual/device result: aspirational generated target and actual offline source previews are distinct. Target photorealism has not been reached. Cloth stiffness/small shoulder gap and insufficient microdetail remain visible. Real phone/browser/GPU route not measured. Phase1of6 remains OPEN, no10/10 claim. External Tripo attempt rejected for missing service credits; no job was launched.
