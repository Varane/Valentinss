# Kvak v2 surface handoff

`art-source/kvak/surface_materials.py` exports `build_materials(output_dir)` with the agreed ten keys. It produces nine distinct PBR materials: skin, pale throat/belly, dark olive eye globe, striated amber iris, shared dark pupil/mouth, linen, charcoal leather, muted teal cape, aged bronze. Original procedural UV PNG maps are deterministic256×256, packed in Blender and GLB; no third-party assets.

Use UV layer `UVMap` on textured skin and clothing. Base colour maps contain subtle broad mottling/weave/grain. Roughness maps separate moist skin, matte cloth, worn leather. No tangent normal/bump node is enabled: the rejected v1 showed jagged patch artifacts, and micro-roughness is safer than adding a noisy normal map before visual acceptance. No pure white bulging eye material is supplied: the eye/iris are amber-olive with a dark wet pupil; anatomy should expose enough upper lid to avoid a vacant stare.

Skin multiplies the UV base texture by the anatomy artist's `Col` vertex-colour layer (smooth ventral tint only). Anatomy should use near-white dorsal tint, softly warmer/lighter ventral tint; it must not paint high-frequency per-vertex pore colour. The separate belly material remains available for independent throat parts. The shader/export test checks `COLOR_0` and base-colour texture together.

This is a material/source production handoff, not a browser visual or phone performance acceptance claim. The generated aspirational concept has not been matched merely by creating these materials.

Leather uses one atlas/material: vest and dark leather accessories UV.u0.02–0.48; satchel/strap UV.u0.52–0.98. Clothing generator remaps those UVs by role. This keeps the bag warm brown and the vest charcoal without another material draw group. Cloth materials do not consume Col. Build writes surface-provenance.json with original texture hashes and byte counts.

Skin texture base(.50,.55,.30) is intentionally pale enough for the anatomy Col tint: dorsal(.57,.66,.58), ventral(1,1,1). This multiplies to a natural olive back and lighter throat/belly, with a smooth anatomical mask rather than jagged vertex noise.

Linen also uses one atlas: shirt/collar/cuffs UV.u0.02–0.48; charcoal matte trousers UV.u0.52–0.98. Trousers use linen material and its weave/roughness, not leather. No extra material is added.

Export verification (Blender4.3): texture×Col is represented correctly only when the skin's active/render colour layer is Col AND glTF export sets `export_vertex_color='ACTIVE', export_all_vertex_colors=False`. With the default MATERIAL setting our small probe produced white COLOR_0 plus the actual tint in COLOR_1; Three.js would ignore that tint. The verified ACTIVE export yielded actual varying COLOR_0 values (.8–1 in probe) and a PBR baseColorTexture. Texture decoding in the real browser remains a separate acceptance step.

## Actual-asset QA correction

The combined source render showed overly glossy uniform green skin and flat yellow iris discs. Corrected skin roughness to .62 (belly .68), reduced coat to .025 and replaced tiny washed-out pigment with soft irregular original gland islands plus restrained microdots. No tangent normals were enabled. Eye globe is now dark olive, and iris has a separate original256px radial fibre texture with a dark limbal ring. It requires planar iris UVMap centered(.5,.5), outer radius.45, agreed with anatomy. This increases the source candidate from eight to nine unique materials; visual/readability acceptance takes priority before later batching optimization.
