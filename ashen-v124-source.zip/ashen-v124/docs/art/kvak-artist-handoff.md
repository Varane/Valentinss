# Kvak v2 — artist assembly handoff (candidate only)

**Status: NOT APPROVED for replacing the current game character.** The user rejected v1; its files are archived under `art-source/kvak/rejected-v1/` and were removed from runtime delivery. V2 improves anatomy and garment readability, but remains below the photoreal target. The main game must retain its existing Kvak until visual acceptance. Do not call phase 1 complete from these artifacts.

## Current frozen artifacts

- Editable source: `art-source/kvak/kvak-v2.blend`.
- Assembly: `art-source/kvak/build_kvak_v2.py` (compatibility entry point `build_kvak.py`).
- Original artist modules: `anatomy_parts.py`, `clothing_parts.py`, `surface_materials.py`.
- Runtime candidate: `/art-assets/kvak/kvak-lod0.glb`.
- Manifest: `dist/art-assets/kvak/manifest.json`, approval `NOT_APPROVED_SOURCE_REVIEW_REQUIRED`.
- Source-only lower LODs: `art-source/kvak/exports-v2/`.
- Neutral offline source render: `art-source/kvak/kvak-v2-source-preview.png`.
- Isolated wave offline source render: `art-source/kvak/kvak-v2-wave-preview.png`.

The renders are Blender source reviews, **not** game screenshots or phone/device evidence. Rebuild: `blender -b --python art-source/kvak/build_kvak_v2.py`. To update structural export without re-rendering unchanged neutral geometry, set `KVAK_SKIP_PREVIEW=1`. Validate: `python art-source/kvak/validate_kvak_v2.py`.

Frozen LOD0: **35,300 triangles; 2,358,088 raw bytes; 1,245,981 gzip bytes; nine materials**. SHA256: `c670be1427f9f6ca37bc90de42a46facdf5c053f416087cc7be43490337f2d91`. This exceeds the original 20–30k / approximately650KB gzip initial target. Do not silently label the asset phone-budget compliant. Only LOD0 is under dist; LOD1/2 remain source artifacts.

## Integration contract

Meters; +Y up and +Z forward after glTF export. No 180-degree actor correction. Bones: Hips, Spine2, Head; LeftArm/LeftForeArm/LeftHand; Right equivalents; LeftUpLeg/LeftLeg/LeftFoot; Right equivalents. Four in-place clips: `idle`, `walk`, `turn`, `wave`. All rotation channels are quaternion tracks, avoiding mixed Euler/quaternion exporter ambiguity. Actor movement owns world translation/yaw.

Five facial targets: `Smile`, `Frown`, `Surprise`, `BlinkLeft`, `BlinkRight`. They are on continuous skin and the appropriate separate eye/lid/lip geometry; resolve by `morphTargetDictionary`, never hardcoded indices. LOD1/2 omit facial targets by design.

Logical empties: `socket.head`, `socket.hair`, `socket.hand.R`, `socket.hand.L`, `socket.outfit`. Their **world bind rotations are identity in glTF**, proven by matrix composition (error<.002 required; observed<6e-7). Blender exporter changes basis by conjugation: setting Blender world identity before bone parenting is correct; adding +90X is incorrect. Parent bones animate the sockets after rest. Use loaded socket world transforms, not guessed bone tails.

Garment semantic prefixes survive export: `garment_shirt__`, `garment_vest__`, `garment_cape__`, `garment_breeches__`, `garment_bag__`. Export extras are not required for identifying roles. Shared texture atlas UVs distinguish charcoal vest from warm leather bag, and linen shirt from dark trousers. Skin active color layer `Col` must export with `export_vertex_color='ACTIVE', export_all_vertex_colors=False`; default MATERIAL mode produced white COLOR0 and hid the true tint in COLOR1, which Three does not use.

Each actor instance must own its cloned skeleton/mixer and any recolored materials. Shared GLB geometry/textures belong to the asset library. Do not let disposing one instance destroy resources used by another. Runtime adapter still owns root/update/setAppearance/expression/attack/guard/hit/dash/spell/celebrate/stats/dispose and accessory behavior.

## Verified and corrected

All three GLBs pass finite positions, indices, skin weights, UV0, named bones/sockets/clips, intended morph presence/absence and SHA checks. Semantic regression rejects arm weights on bag/vest/cape/torso shirt. Forearm/hand vertices below hips are explicitly not assigned to leg bones.

Actual isolated wave review caught and corrected two severe integration errors: forefeet had been classified as legs by height-only weighting, and an AUTO shoulder strap stretched into a large black triangle when the arm rose. Hand regions now use anatomical X/Y/Z masks; torso garments are restricted to Spine2/Hips while sleeves retain explicit arm bindings. The wave is authored from rest-bone world directions, not guessed local Euler angles. The final wave image has no prior detached hand stretch or black garment spikes.

## Remaining quality limits

The current source still reads more stylized/toy-like than the supplied photoreal character target. Cloth is relatively stiff and lacks the target's tailored fold/edge wear; skin pigmentation is weak at full-body distance; eye/oral anatomy needs an artist sculpt/texture refinement before claiming photorealism. Rigged clothing has no cloth simulation. Tool-contact<=.04m, every hairstyle/outfit combination, source front/back clips and real browser/phone GPU behavior remain integration acceptance work. No optional procedural normal is used to fake that acceptance.

The production asset is original project-authored geometry, textures, rig and clips. No ripped franchise mesh, copied fan art or paid external 3D generation was used. This handoff is a real candidate asset and reproducible pipeline, not an image presented as a 3D model.
