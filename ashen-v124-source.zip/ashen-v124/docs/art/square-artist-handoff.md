# River square: original phase-1 art handoff

Actual source and export (not an image placeholder):
- `art-source/river-square.blend`
- Rebuild: `blender -b --python art-source/river-square/build_square.py`
- `dist/art-assets/river-square.glb`
- `dist/art-assets/river-square.asset.json`

Original geometry and texture maps produced specifically for ASHEN. No third-party meshes or texture photographs. CC0-1.0 to the extent rights exist. Procedural art source is retained, not merely the final binary.

## Runtime contract

Load once through GLTFLoader. Root child groups are exactly `fountain`, `inn`, `paving`. Vertices are already in world-space city coordinates; group roots are identity transforms. Unit1 =1 metre. glTF Y-up, +Z points toward the inn's front. Do not translate the inn group to its centre a second time.

- Fountain centre game(0,0), outer body radius2.35m inside existing radius2.6 collision. A carved bird tops the turned column, four water arcs, folded wing relief and a scalloped bowl edge. Static water material is intentionally restrained; runtime may animate its roughness/UV or attach existing water effects.
- Inn centre game(-12,-9), foundation fits existing9×8 footprint. Door and stone threshold face +Z near z=-5. No collision/work coordinates changed. The model is a full shell plus front joinery, window recesses, warm glass, detailed slate roof, chimney and carved willow sign. It replaces the inn visual shell, not the other town buildings.
- Paving is a compact ring around fountain with stone centres within5.5m (outer corners extend to about6m). Existing ground should remain beneath it. Its top is near y=.01 to prevent z-fighting; remove/disable the old decorative fountain paving ring if it overlaps.

Keep each group independently removable for fallback/visibility. Materials and meshes are merged to9 draw groups in total, with18,955 triangles. Export size1,056,036 bytes (slightly over the initial1MB target; about1.01MiB). Do not duplicate the source PNG maps at runtime: they are embedded in GLB.

## Material evidence

128px original UV base-colour, normal and roughness images for limestone, limewash and oak; actual Cycles mesh-AO bakes on the five textured draw groups. Textures are packed in .blend and GLB. Slate, dark recesses, amber glass and water use intentional PBR values. GLB contains no lamps/camera and needs existing town lighting. Repeated tile silhouettes are merged geometry; no per-tile runtime objects.

## Verification and limits

Blender4.3.2 background build/export succeeded. Actual exported POSITION vertices were parsed through glTF node transforms by `verify_export.py`: fountain x/z±2.34865m; inn x[-16.37974,-7.61946], z[-12.8,-5.02331], so both contain inside authoritative footprints. Root groups are identity; inner draw nodes may carry transforms and must remain children. Parent should also validate loaded group bounds in runtime. Geometry is an authored procedural sample; no claim of parity with the aspirational generated concept. `asset-preview.png` is an OFFLINE Blender QA view, not a screenshot from the browser game. Browser GPU/phone performance and in-game final visual approval remain unverified.

## Integration checklist

1. Load GLB via manifest before suppressing existing inn/fountain visuals.
2. On successful load, attach child groups under environment/district visibility ownership and preserve disposal.
3. Keep existing world collision, interaction markers, town positions and all other buildings.
4. Preserve inn visibility fading semantics on all new inn materials; clone shared materials only if actor/world ownership requires.
5. Confirm no doubled fountain/roof, no surface flicker, and doorway aligns with the existing approach point.
