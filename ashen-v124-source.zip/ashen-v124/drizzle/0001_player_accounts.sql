CREATE TABLE IF NOT EXISTS player_accounts (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  key_hash TEXT NOT NULL UNIQUE,
  revision INTEGER NOT NULL DEFAULT 0,
  save_json TEXT
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS player_sessions (
  token_hash TEXT PRIMARY KEY,
  player_id TEXT NOT NULL REFERENCES player_accounts(id),
  expires INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS player_sessions_expiration ON player_sessions(expires);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS player_registration_limits (
  bucket TEXT PRIMARY KEY,
  attempts INTEGER NOT NULL,
  expires INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS player_registration_limits_expiration ON player_registration_limits(expires);
