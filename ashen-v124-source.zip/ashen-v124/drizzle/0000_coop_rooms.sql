CREATE TABLE coop_rooms (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE,
  storage_version INTEGER NOT NULL CHECK (storage_version >= 0),
  room_json TEXT NOT NULL CHECK (json_valid(room_json))
);
