CREATE TABLE coop_xp_receipts (
  room_id TEXT NOT NULL,
  encounter_id TEXT NOT NULL,
  account_id TEXT NOT NULL REFERENCES player_accounts(id),
  hero_id TEXT NOT NULL CHECK (hero_id IN ('knight', 'mage')),
  xp INTEGER NOT NULL CHECK (xp BETWEEN 1 AND 100000),
  reward_version INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  PRIMARY KEY (room_id, encounter_id, account_id, hero_id)
);
--> statement-breakpoint
CREATE INDEX coop_xp_by_account ON coop_xp_receipts(account_id, hero_id);
